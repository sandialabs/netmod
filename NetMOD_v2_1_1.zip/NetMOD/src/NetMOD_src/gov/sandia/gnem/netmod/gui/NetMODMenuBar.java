/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.simulation.Simulation;
import gov.sandia.gnem.netmod.simulation.SimulationPlugin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.DecimalFormat;

/**
 * NetModMenuBar that is positioned at the top of the main application frame
 * 
 * @author bjmerch
 */
public class NetMODMenuBar extends JMenuBar
{
    private NetMOD _netMod = null;
    
    //  ActionListeners for each of the menu items
    private ActionListener fileProjectNew;
    private ActionListener fileProjectOpen;
    private ActionListener fileProjectSave;
    private ActionListener fileProjectSaveAs;
    private ActionListener fileProperties;
    private ActionListener fileOutputOpen;
    ActionListener fileExit;
    
    private ActionListener helpAbout;
    private ActionListener helpManual;
    private ActionListener helpMathematicalFramework;
    private ActionListener helpParameters;
    private ActionListener helpGarbageCollect;
    
    // Text area for displaying console output
    private JTextArea _consoleOutput = new JTextArea();

    public NetMODMenuBar(NetMOD netMod)
    {
        _netMod = netMod;
        updateMenuBar();
        
        // set both System.out and System.err to that stream
        _consoleOutput.setEditable(false);
        ConsoleStream.getOutConsoleStream().setTextArea(_consoleOutput);
        ConsoleStream.getErrConsoleStream().setTextArea(_consoleOutput);
    }

    /**
     * Regenerate the menu bar
     */
    public void updateMenuBar()
    {
        removeAll();
        
        add(createFileMenu());
        add(createHelpMenu());

        JButton button = GUIUtility.createButton(Icons.HELP.getIcon());
        button.setToolTipText("User Manual");
        button.addActionListener(helpManual);
        
        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.add(button);
        add(toolBar);
    }

    private JMenu createFileMenu()
    {
        //  Create the action listeners
        fileProjectNew = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                
            }
        };
        fileProjectOpen = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                File[] files = GUIUtility.showOpenDialog(null, "", "Open simulation project file", JFileChooser.FILES_ONLY, false, null, null);
                if ( files == null )
                    return;
                
                File file = files[0];
                
                //  Get the parameter set for the file
                NetSimParameters parameters = new NetSimParameters();
                if ( !parameters.read(file) )
                {
                    GUIUtility.showExceptionDialog(null,  "Simulation Read Error",  "The selected file does not contain a known parameter set", null);
                    return;
                }

                //  Create a simulation object appropriate for this project file
                Simulation simulation = SimulationPlugin.getPlugin().getComponentFor(null, parameters, false);
                if ( simulation == null )
                {
                    GUIUtility.showExceptionDialog(null,  "Simulation Read Error",  "The selected file does not contain a known simulation", null);
                    return;
                }
                
                try
                {
                    simulation.load(parameters);
                }
                catch (Exception e)
                {
                    GUIUtility.showExceptionDialog(null,  "Simulation Read Error",  "Error processing the selected file", e);
                    return;
                }
                
                //  Insert the simulation into the project
                _netMod.getProject().add(simulation);
                _netMod.getProject().getViewer().refresh();
            }
        };
        fileProjectSave = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                
            }
        };
        fileProjectSaveAs = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                
            }
        };
        fileProperties = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                new PropertyViewer();
            }
        };
        fileOutputOpen = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                
            }
        };
        fileExit = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                new SwingWorker<Void, Void>()
                {
                    @Override
                    protected Void doInBackground() throws Exception
                    {
                        int i = JOptionPane.YES_NO_OPTION;

                        String[] str = new String[2];

                        str[0] = "Are you sure that you wish to exit?";
                        int result = JOptionPane.showConfirmDialog(null, str, "Exit Warning", i, JOptionPane.QUESTION_MESSAGE);

                        if (result == JOptionPane.YES_OPTION)
                            System.exit(0);

                        // Exit the application
                        return null;
                    }
                }.execute();
            }
        };
        
        //  Create the menu items
        JMenuItem jMenuItemProjectNew = newJMenuItem("New Project", "Start a new project", fileExit, null);
        JMenuItem jMenuItemProjectOpen = newJMenuItem("Open Project", "Open a saved project", fileProjectOpen, null);
        JMenuItem jMenuItemProjectSave = newJMenuItem("Save Project", "Save the project", fileProjectSave, null);
        JMenuItem jMenuItemProjectSaveAs = newJMenuItem("Save Project As", "Save the project to a file", fileProjectSaveAs, null);
        JMenuItem jMenuItemProperties = newJMenuItem("Properties", "Modify appliation properties", fileProperties, Icons.PREFERENCES.getIcon());
        JMenuItem jMenuItemExit = newJMenuItem("Exit", "Exit the application", fileExit, null);

        //  Assemble and organize the menu items
        JMenu jMenuFile = new JMenu("File");
        //jMenuFile.add(jMenuItemProjectNew);
        //jMenuFile.add(jMenuItemProjectOpen);
        //jMenuFile.addSeparator();
        //jMenuFile.add(jMenuItemProjectSave);
        //jMenuFile.add(jMenuItemProjectSaveAs);
        //jMenuFile.addSeparator();
        jMenuFile.add(jMenuItemProperties);
        jMenuFile.addSeparator();
        jMenuFile.add(jMenuItemExit);
        
        return jMenuFile;
    }

    /**
     * Create a new JMenuItem with the provided properties
     * 
     * @param label
     * @param tooltip
     * @param actionListener
     * @param icon
     * @return
     */
    private JMenuItem newJMenuItem(String label, String tooltip, ActionListener actionListener, Icon icon)
    {
        JMenuItem menuItem = new JMenuItem(label);
        menuItem.setToolTipText(tooltip);
        menuItem.addActionListener(actionListener);
        menuItem.setIcon(icon);
        
        return menuItem;
    }

    private JMenu createHelpMenu()
    {
        //  Create the action listeners
        helpAbout = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                JTextArea textAreaNotice = new JTextArea(GUIUtility.getNotice(), 10, 0);
                textAreaNotice.setEditable(false);
                JScrollPane detailsDisplay = new JScrollPane(textAreaNotice);
                detailsDisplay.setBorder(BorderFactory.createTitledBorder("Legal Notice"));

                JTextArea textAreaJavaClassPath = new JTextArea(System.getProperty("java.class.path").replace(';',  '\n'), 10, 0);
                textAreaJavaClassPath.setEditable(false);
                JScrollPane jclasspathDisplay = new JScrollPane(textAreaJavaClassPath);
                jclasspathDisplay.setBorder(BorderFactory.createTitledBorder("Java Classpath"));

				JTextArea textAreaLibraryPath = new JTextArea(System.getProperty("java.library.path").replace(';',  '\n'), 10, 0);
				textAreaLibraryPath.setEditable(false);
				JScrollPane librarypathDisplay = new JScrollPane(textAreaLibraryPath);
				librarypathDisplay.setBorder(BorderFactory.createTitledBorder("Library Classpath"));

                JPanel panel = new JPanel();
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
                panel.add(detailsDisplay);
                panel.add(jclasspathDisplay);
                panel.add(librarypathDisplay);
                
                // Add button to dismiss the dialog.
                final JDialog dialog = new JDialog(NetMOD.getFrame(), "About");
                dialog.setLayout(new BorderLayout());
                dialog.add(panel, BorderLayout.CENTER);
                dialog.add( GUIUtility.createButtonPanel(new AbstractAction("Ok")
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
                        dialog.setVisible(false);
                        dialog.dispose();
                    }
                }), BorderLayout.SOUTH);
                dialog.pack();
                dialog.setLocationRelativeTo(NetMOD.getFrame());
                dialog.setVisible(true);
            }
        };
        helpManual = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
            	openPDF(IOUtility.openFile("docs", "NetMOD_Manual.pdf"));
            }
        };
        helpMathematicalFramework = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
            	openPDF(IOUtility.openFile("docs", "NetMOD_MathematicalFramework.pdf"));
            }
        };
        helpParameters = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
            	openPDF(IOUtility.openFile("docs", "NetMOD_Parameters.pdf"));
            }
        };
        helpGarbageCollect = new ActionListener()
        {
            private DecimalFormat format = new DecimalFormat("###,###,###,###");
            
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                System.gc();

                long totalMemory = java.lang.Runtime.getRuntime().totalMemory();
                long freeMemory = java.lang.Runtime.getRuntime().freeMemory();
                long maxMemory = java.lang.Runtime.getRuntime().maxMemory();

                Object[] mesg = new Object[8];

                mesg[0] = "Performed garbage collection on Java Virtual Machine";
                mesg[1] = " ";
                mesg[2] = format.format(totalMemory - freeMemory) + " bytes allocated Heap Memory.";
                mesg[3] = format.format(freeMemory) + " bytes free Heap Memory.";
                mesg[4] = "-----------------------------------------";
                mesg[5] = format.format(totalMemory) + " bytes total Heap Memory.";
                mesg[6] = " ";
                mesg[7] = format.format(maxMemory) + " bytes maximum Heap Memory.";

                JOptionPane.showMessageDialog(null, mesg, "Garbage Collection", JOptionPane.PLAIN_MESSAGE, null);
            }
        };
        
        //  Create the menu items
        JMenuItem jMenuItemManualPDF = newJMenuItem("User Manual", "Open the User Manual as a PDF", helpManual, Icons.HELP.getIcon());
        JMenuItem jMenuItemMathematicalFrameworkPDF = newJMenuItem("Mathematical Framework", "Open the Mathematical Framework reference as a PDF", helpMathematicalFramework, null);
        JMenuItem jMenuItemParametersPDF = newJMenuItem("Parameters", "Open the Parameters reference as a PDF", helpParameters, null);
        JMenuItem jMenuItemAbout = newJMenuItem("About", "About this application", helpAbout, null);
        JMenuItem jMenuItemGarbageCollect = newJMenuItem("Garbage Collect", "Clean up memory and display allocations", helpGarbageCollect, null);

        //  Assemble and organize the menu items
        JMenu jMenuHelp = new JMenu("Help");
        jMenuHelp.add(jMenuItemManualPDF);
        jMenuHelp.add(jMenuItemMathematicalFrameworkPDF);
        jMenuHelp.add(jMenuItemParametersPDF);
        jMenuHelp.addSeparator();
        jMenuHelp.add(jMenuItemGarbageCollect);
        jMenuHelp.addSeparator();
        jMenuHelp.add(jMenuItemAbout);
        
        return jMenuHelp;
    }
    
    private void openPDF(File file)
    {
        try
        {
            file = IOUtility.findFile(file);

            if (file.exists())
            {
                if (Desktop.isDesktopSupported())
                    Desktop.getDesktop().open(file);
            }
            else
            {
                GUIUtility.showExceptionDialog(null, "Error opening document", "Unable to open document: " + file.getAbsolutePath(), null);
            }
        }
        catch (Exception ex)
        {
            GUIUtility.showExceptionDialog(null, "Error opening document", "Unable to locate document", ex);
        }
    }
}
