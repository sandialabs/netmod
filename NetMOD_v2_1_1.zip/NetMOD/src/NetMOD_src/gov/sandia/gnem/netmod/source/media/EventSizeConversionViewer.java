/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.media;

import gov.sandia.gnem.netmod.gui.DoubleRangeFormatter;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
class EventSizeConversionViewer extends NetModComponentViewer<EventSizeConversion>
{
    private List<JFormattedTextField> _slopes = new ArrayList<JFormattedTextField>();
    private List<JFormattedTextField> _yIntercepts = new ArrayList<JFormattedTextField>();

    EventSizeConversionViewer(EventSizeConversion nmc)
    {
        super(nmc, false, true);

        int N = nmc.getConversionCount();
        for (int i = 0; i < N; i++)
        {
            _slopes.add(new JFormattedTextField(new DoubleRangeFormatter()));
            _yIntercepts.add(new JFormattedTextField(new DoubleRangeFormatter()));
        }

        //  Register the controls that are monitored after updating
        registerControls(_slopes.toArray(new JComponent[_slopes.size()]));
        registerControls(_yIntercepts.toArray(new JComponent[_yIntercepts.size()]));
    }

    @Override
    public void apply(EventSizeConversion nmc)
    {
        int N = nmc.getConversionCount();
        for (int i = 0; i < N; i++)
        {
            nmc.setSlope(i, ((Number) _slopes.get(i).getValue()).doubleValue());
            nmc.setYIntercept(i, ((Number) _yIntercepts.get(i).getValue()).doubleValue());
        }
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Setup the longitude panel
            GUIUtility.addRow(panel, new JLabel("<html>log(Mo)&nbsp;&nbsp;&nbsp;<br>vs</html>"), new JLabel("<html><br>Slope</html>"), new JLabel(
                    "<html><br>Y-intercept</html>"));

            int N = _nmc.getConversionCount();
            for (int i = 0; i < N; i++)
                GUIUtility.addRow(panel, new JLabel(_nmc.getMagnitudeType(i).toESCString() + ": "), _slopes.get(i), _yIntercepts.get(i));

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(EventSizeConversion nmc)
    {
        int N = nmc.getConversionCount();
        for (int i = 0; i < N; i++)
        {
            _slopes.get(i).setValue(nmc.getSlope(i));
            _yIntercepts.get(i).setValue(nmc.getYIntercept(i));
        }
    }

}
