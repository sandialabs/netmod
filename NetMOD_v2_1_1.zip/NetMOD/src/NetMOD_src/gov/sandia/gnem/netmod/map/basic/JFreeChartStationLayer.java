/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.gui.AbstractVisibleXYDataset;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.TextAnchor;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class JFreeChartStationLayer extends AbstractVisibleXYDataset implements Layer<Receivers>, JFreeChartLayer<Receivers>
{
    private XYLineAndShapeRenderer _renderer = new XYLineAndShapeRenderer();
    private Receivers _receivers;
    private List<Station> _stations;
    private DISPLAY _display = DISPLAY.ALL;
    
    public JFreeChartStationLayer(Receivers receivers)
    {
        setNMC(receivers);
    }

    @Override
    public int getItemCount(int arg0)
    {
        if ( !isVisible() )
            return 0;
        
        return _receivers.getStations().getStations().size();
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public Receivers getNMC()
    {
        return _receivers;
    }

    @Override
    public int getSeriesCount()
    {
        return 4;
    }

    @Override
    public Comparable getSeriesKey(int series)
    {
        switch (series)
        {
        case 0:
            return "Selected Array";
        case 1:
            return "Unselected Array";
        case 2:
            return "Selected Single Station";
        case 3:
            return "Unselected Single Station";
        }
        
        return "";
    }

    @Override
    public Number getX(int series, int item)
    {
        //  Get the station;
        Station station = _stations.get(item);
        
        boolean isSelected = _receivers.getSelectedStations().contains(station);
        boolean isArray = station.getStationType().equalsIgnoreCase("ar") || station.getStationType().equalsIgnoreCase("hydrophone");

        if ( series == 0 && isSelected && isArray && _display != DISPLAY.NOT_SELECTED )
            return station.getLongitude();
        else if ( series == 1 && !isSelected && isArray && _display != DISPLAY.SELECTED )
            return station.getLongitude();
        else if ( series == 2 && isSelected && !isArray && _display != DISPLAY.NOT_SELECTED  )
            return station.getLongitude();
        else if ( series == 3 && !isSelected && !isArray && _display != DISPLAY.SELECTED )
            return station.getLongitude();
        
        return Double.NaN;
    }

    @Override
    public Number getY(int series, int item)
    {
        //  Get the station;
        Station station = _stations.get(item);
        
        boolean isSelected = _receivers.getSelectedStations().contains(station);
        boolean isArray = station.getStationType().equalsIgnoreCase("ar") || station.getStationType().equalsIgnoreCase("hydrophone");

        if ( series == 0 && isSelected && isArray && _display != DISPLAY.NOT_SELECTED )
            return station.getLatitude();
        else if ( series == 1 && !isSelected && isArray && _display != DISPLAY.SELECTED  )
            return station.getLatitude();
        else if ( series == 2 && isSelected && !isArray && _display != DISPLAY.NOT_SELECTED )
            return station.getLatitude();
        else if ( series == 3 && !isSelected && !isArray && _display != DISPLAY.SELECTED  )
            return station.getLatitude();
        
        return Double.NaN;
    }

    @Override
    public void setNMC(Receivers data)
    {
        _receivers = data;         
        _stations = new ArrayList<Station>(data.getStations().getStations());
        fireDatasetChanged();
    }

    /**
     * @return
     */
    public XYItemRenderer getRenderer(int index)
    {
        _renderer.setBaseLinesVisible(false);
        _renderer.setBaseItemLabelsVisible(true);
        _renderer.setBaseNegativeItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.CENTER_LEFT));
        _renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.CENTER_LEFT));
        _renderer.setItemLabelAnchorOffset(5.0);
        _renderer.setBaseItemLabelGenerator(new XYItemLabelGenerator()
        {
            @Override
            public String generateLabel(XYDataset dataset, int series, int item)
            {
                if ( dataset instanceof JFreeChartStationLayer )
                {
                    Station station = ((JFreeChartStationLayer) dataset)._stations.get(item);
                    return station.getName();
                }
                
                return null;
            }
        });
        _renderer.setBaseToolTipGenerator(new XYToolTipGenerator()
        {
            @Override
            public String generateToolTip(XYDataset dataset, int series, int item)
            {
                if ( dataset instanceof JFreeChartStationLayer )
                {
                    return ((JFreeChartStationLayer) dataset)._stations.get(item).getName();
                }
                
                return null;
            }});
        
        int size;
        int fontsize;
        
        //  Selected Array
        size = (int) Property.MAP_STATION_ENABLED_POINTSIZE.getFloatValue();
        fontsize = (int) Property.MAP_STATION_ENABLED_FONTSIZE.getFloatValue();
        _renderer.setSeriesPaint(0, Property.MAP_STATION_ENABLED_COLOR.getColorValue());
        _renderer.setSeriesItemLabelPaint(0, Property.MAP_STATION_ENABLED_LABEL_COLOR.getColorValue());
        _renderer.setSeriesShape(0, new Polygon(new int[]{0, size/2, -size/2}, new int[]{ -size/2, size/2, size/2 }, 3));
        _renderer.setSeriesItemLabelFont(0, new Font(Font.SANS_SERIF, Font.PLAIN,  fontsize));
        
        //  Unselected Array
        size = (int) Property.MAP_STATION_ENABLED_POINTSIZE.getFloatValue();
        fontsize = (int) Property.MAP_STATION_DISABLED_FONTSIZE.getFloatValue();
        _renderer.setSeriesPaint(1, Property.MAP_STATION_DISABLED_COLOR.getColorValue());
        _renderer.setSeriesItemLabelPaint(1, Property.MAP_STATION_DISABLED_LABEL_COLOR.getColorValue());
        _renderer.setSeriesShape(1, new Polygon(new int[]{0, size/2, -size/2}, new int[]{ -size/2, size/2, size/2 }, 3));
        _renderer.setSeriesItemLabelFont(1, new Font(Font.SANS_SERIF, Font.PLAIN,  fontsize));
        
        //  Selected Single Station
        size = (int) Property.MAP_STATION_DISABLED_POINTSIZE.getFloatValue();
        fontsize = (int) Property.MAP_STATION_ENABLED_FONTSIZE.getFloatValue();
        _renderer.setSeriesPaint(2, Property.MAP_STATION_ENABLED_COLOR.getColorValue());
        _renderer.setSeriesItemLabelPaint(2, Property.MAP_STATION_ENABLED_LABEL_COLOR.getColorValue());
        _renderer.setSeriesShape(2,  new Ellipse2D.Double(-size/2, -size/2, size, size));
        _renderer.setSeriesItemLabelFont(2, new Font(Font.SANS_SERIF, Font.PLAIN,  fontsize));
        
        //  Unselected Single Station
        size = (int) Property.MAP_STATION_DISABLED_POINTSIZE.getFloatValue();
        fontsize = (int) Property.MAP_STATION_DISABLED_FONTSIZE.getFloatValue();
        _renderer.setSeriesPaint(3, Property.MAP_STATION_DISABLED_COLOR.getColorValue());
        _renderer.setSeriesItemLabelPaint(3, Property.MAP_STATION_DISABLED_LABEL_COLOR.getColorValue());
        _renderer.setSeriesShape(3,  new Ellipse2D.Double(-size/2, -size/2, size, size));
        _renderer.setSeriesItemLabelFont(3, new Font(Font.SANS_SERIF, Font.PLAIN,  fontsize));
        
        return _renderer;
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
        _display = display;
    }

    @Override
    public DISPLAY getDisplay()
    {
        return _display;
    }
    
}
