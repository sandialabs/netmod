/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.view.orbit.BasicOrbitView;
import gov.nasa.worldwindx.examples.util.SectorSelector;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.Set;
import java.util.TreeSet;


/**
 * @author bjmerch
 *
 */
public class StationSelectionTool<TYPE extends NetModComponent> extends AbstractAction
{
    private WorldWindow _wwd;
    private Receivers _receivers;
    private boolean _mapSelection = true;
    private SectorSelector _selector;

    public StationSelectionTool(WorldWindow wwd, Receivers receivers)
    {
        _wwd = wwd;
        _receivers = receivers;
        _selector = new SectorSelector(wwd)
        {
            
            @Override
            public void mouseReleased(MouseEvent mouseEvent)
            {
                super.mouseReleased(mouseEvent);
                
                //  Check for layer not visible
                if ( !getWwd().getModel().getLayers().contains(_receivers.getMapLayer()) )
                {
                    _selector.disable();
                    return;
                }
                
                //  Get the sector selected
                Sector sector = _selector.getSector();
                
                //  Build a sector around click point if none provided
                if ( sector == null )
                {
                    //  Get the cursors current position
                    Position currentPos = getWwd().getCurrentPosition();
                    
                    //  Get the sector that defines the area +/- around the point
                    BasicOrbitView view = (BasicOrbitView) getWwd().getView();
                    double dLat = 2 * view.getZoom() / 50000000;
                    double dLon = 2 * view.getZoom() / 50000000;
                    
                    //  Determine the lat/lon points of those points
                    double minLat = currentPos.getLatitude().getDegrees() - dLat;
                    double maxLat = currentPos.getLatitude().getDegrees() + dLat;
                    double minLon = currentPos.getLongitude().getDegrees() - dLon;
                    double maxLon = currentPos.getLongitude().getDegrees() + dLon;

                    sector = Sector.fromDegrees(minLat, maxLat, minLon, maxLon);
                }
                
                //  Get the set of selected station names
                Set<Station> names = _receivers.getNetwork().getStations();
                
                //  Iterate over all stations to determine which are inside the selection sector
                for (Station station : _receivers.getStations().getStations())
                {
                    if ( sector.containsDegrees(station.getLatitude(),  station.getLongitude()) )
                    {
                        if ( _mapSelection )
                            names.add(station);
                        else
                            names.remove(station);
                    }
                }
                
                //  Store the selected station names
                _receivers.getNetwork().setStations(names);
                
                //  Update the map
                NetMOD.getMap().refresh();
                
                //  Keep the the selector enabled
                _selector.disable();
                _selector.enable();
            }
        };
    }

    /**
     * Override the action performed method to display a JPopupMenu.
     */
    public void actionPerformed(ActionEvent e)
    {
        boolean selected = (Boolean) getValue(SELECTED_KEY);

        //  Toggle selection off
        _selector.disable();
        ((Component) _wwd).setCursor(Cursor.getDefaultCursor()); 
        if ( !selected )
        {
            ((Component) _wwd).setCursor(Cursor.getDefaultCursor()); 
            return;
        }
        putValue(SELECTED_KEY, Boolean.FALSE);
        
        //  Only display the popup if it's selected
        createPopupMenu(getSelectedLayer()).show((JComponent) e.getSource(), 0, ((JComponent) e.getSource()).getHeight());
    }

    /**
     * Create a popup menu that allows the user to change the media type for a region
     * 
     * @param layer
     */
    private JPopupMenu createPopupMenu(StationLayer layer)
    {
        JPopupMenu popupMenu = new JPopupMenu();

        if ( layer == null )
            return popupMenu;
        
        JMenuItem allItem = new JMenuItem("All");
        allItem.setToolTipText("Select all stations");
        allItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                TreeSet<Station> names = new TreeSet<Station>();
                for (Station station : _receivers.getStations().getStations())
                    names.add(station);
                
                _receivers.getNetwork().setStations(names);
                
                NetMOD.getMap().refresh();
                putValue(SELECTED_KEY, Boolean.FALSE);
            }
        });
        
        JMenuItem noneItem = new JMenuItem("None");
        noneItem.setToolTipText("Unselect all stations");
        noneItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _receivers.getNetwork().getStations().clear();
                
                NetMOD.getMap().refresh();
                putValue(SELECTED_KEY, Boolean.FALSE);
            }
        });
        
        JMenuItem selectItem = new JMenuItem("Map Select");
        selectItem.setToolTipText("Select stations interatively on the map");
        selectItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _mapSelection = true;
                _selector.enable();
                putValue(SELECTED_KEY, Boolean.TRUE);
            }
        });
        
        JMenuItem unselectItem = new JMenuItem("Map Unselect");
        unselectItem.setToolTipText("Unselect stations interatively on the map");
        unselectItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _mapSelection = false;
                _selector.enable();
                putValue(SELECTED_KEY, Boolean.TRUE);
            }
        });
        
        popupMenu.add(allItem);
        popupMenu.add(noneItem);
        popupMenu.addSeparator();
        popupMenu.add(selectItem);
        popupMenu.add(unselectItem);
        
        return popupMenu;
    }

    /**
     * Get the selected media grid layer from the map
     * 
     * @return
     */
    private StationLayer getSelectedLayer()
    {
        return (StationLayer) _receivers.getMapLayer();
    }
}
