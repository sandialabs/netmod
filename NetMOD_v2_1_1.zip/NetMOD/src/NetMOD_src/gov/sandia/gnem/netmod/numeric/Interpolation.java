/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

/**
 * Base class for interpolation.  Contains bracketing function and the main
 * interpolate() function that determines if interpolation or extrapolation 
 * should be performed.
 */
public abstract class Interpolation
{
	/**
     * Perform quad-linear interpolation across the provided values
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param x3 monotonically increasing x3 values
     * @param x4 monotonically increasing x4 values
     * @param y array of y[x1][x2][x3][x4] values
     * @param x1_ x1 value at which to interpolate at
     * @param x2_ x2 value at which to interpolate at
     * @param x3_ x3 value at which to interpolate at
     * @param x4_ x4 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateQuadlinear(double[] x1, double[] x2, double[] x3, double[] x4, double[][][][] y, double x1_, double x2_, double x3_, double x4_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
            index = 0;
        //  Extrapolate right
        else if (index >= N - 1)
            index = N - 2;
        
        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateTrilinear(x2, x3, x4, y[index], x2_, x3_, x4_);
        else if ( x1_ == x1[index+1] )
        	return interpolateTrilinear(x2, x3, x4, y[index + 1], x2_, x3_, x4_);

        //  Otherwise, interpolate across x2, x3, and x4 first
        double y1 = interpolateTrilinear(x2, x3, x4, y[index], x2_, x3_, x4_);
        double y2 = interpolateTrilinear(x2, x3, x4, y[index + 1], x2_, x3_, x4_);
        
        //  Interpolate across x1 second
        return linear(x1[index], x1[index + 1], y1, y2, x1_);
    }


    /**
     * Perform trilinear interpolation across the provided values
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param x3 monotonically increasing x3 values
     * @param y array of y[x1][x2][x3] values
     * @param x1_ x1 value at which to interpolate at
     * @param x2_ x2 value at which to interpolate at
     * @param x3_ x3 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateTrilinear(double[] x1, double[] x2, double[] x3, double[][][] y, double x1_, double x2_, double x3_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
            index = 0;
        //  Extrapolate right
        else if (index >= N - 1)
            index = N - 2;
        
        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateBilinear(x2, x3, y[index], x2_, x3_);
        else if ( x1_ == x1[index+1] )
        	return interpolateBilinear(x2, x3, y[index + 1], x2_, x3_);

        //  Otherwise, interpolate across x2, x3, and x4 first
        double y1 = interpolateBilinear(x2, x3, y[index], x2_, x3_);
        double y2 = interpolateBilinear(x2, x3, y[index + 1], x2_, x3_);

        //  Interpolate across x1 second
        return linear(x1[index], x1[index + 1], y1, y2, x1_);
    }
    
    /**
     * Perform quad-quadratic interpolation across the provided values.
     * Interpolate first across x4, then x3, then x2, and then x1
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param x3 monotonically increasing x3 values
     * @param x4 monotonically increasing x4 values
     * @param y array of y[x1][x2][x3][x4] values
     * @param x1_ x1 value at which to interpolate at
     * @param x2_ x2 value at which to interpolate at
     * @param x3_ x3 value at which to interpolate at
     * @param x4_ x4 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateQuadquadratic(double[] x1, double[] x2, double[] x3, double[] x4, double[][][][] y, double x1_, double x2_, double x3_, double x4_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
        {
            double y1 = interpolateTriquadratic(x2, x3, x4, y[0], x2_, x3_, x4_);
            double y2 = interpolateTriquadratic(x2, x3, x4, y[1], x2_, x3_, x4_);

            return linear(x1[0], x1[1], y1, y2, x1_);
        }
        //  Extrapolate right
        else if (index >= N - 1)
        {
            double y1 = interpolateTriquadratic(x2, x3, x4, y[N - 2], x2_, x3_, x4_);
            double y2 = interpolateTriquadratic(x2, x3, x4, y[N - 1], x2_, x3_, x4_);

            return linear(x1[N - 2], x1[N - 1], y1, y2, x1_);
        }
        
        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateTriquadratic(x2, x3, x4, y[index], x2_, x3_, x4_);
        else if ( x1_ == x1[index+1] )
        	return interpolateTriquadratic(x2, x3, x4, y[index + 1], x2_, x3_, x4_);
        
        //  Otherwise, perform a triquadratic evaluation across x2, x3, and x4
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        double y1 = interpolateTriquadratic(x2, x3, x4, y[i1], x2_, x3_, x4_);
        double y2 = interpolateTriquadratic(x2, x3, x4, y[i2], x2_, x3_, x4_);
        double y3 = interpolateTriquadratic(x2, x3, x4, y[i3], x2_, x3_, x4_);
        double y4 = interpolateTriquadratic(x2, x3, x4, y[i4], x2_, x3_, x4_);

        //  Interpolate across x1
        return quadratic(x1[i1], x1[i2], x1[i3], x1[i4], y1, y2, y3, y4, x1_);
    }

    /**
     * Perform tri-quadratic interpolation across the provided values.
     * Interpolate first across x3, then x2, and then x1
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param x3 monotonically increasing x3 values
     * @param y array of y[x1][x2][x3] values
     * @param x1_ x1 value at which to interpolate at
     * @param x2_ x2 value at which to interpolate at
     * @param x3_ x3 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateTriquadratic(double[] x1, double[] x2, double[] x3, double[][][] y, double x1_, double x2_, double x3_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
        {
            double y1 = interpolateBiquadratic(x2, x3, y[0], x2_, x3_);
            double y2 = interpolateBiquadratic(x2, x3, y[1], x2_, x3_);

            return linear(x1[0], x1[1], y1, y2, x1_);
        }
        //  Extrapolate right
        else if (index >= N - 1)
        {
            double y1 = interpolateBiquadratic(x2, x3, y[N - 2], x2_, x3_);
            double y2 = interpolateBiquadratic(x2, x3, y[N - 1], x2_, x3_);

            return linear(x1[N - 2], x1[N - 1], y1, y2, x1_);
        }
        
        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateBiquadratic(x2, x3, y[index], x2_, x3_);
        else if ( x1_ == x1[index+1] )
        	return interpolateBiquadratic(x2, x3, y[index + 1], x2_, x3_);

        //  Otherwise, perform a biquadratic evaluation across x2 and x3
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        double y1 = interpolateBiquadratic(x2, x3, y[i1], x2_, x3_);
        double y2 = interpolateBiquadratic(x2, x3, y[i2], x2_, x3_);
        double y3 = interpolateBiquadratic(x2, x3, y[i3], x2_, x3_);
        double y4 = interpolateBiquadratic(x2, x3, y[i4], x2_, x3_);

        //  Interpolate across x1
        return quadratic(x1[i1], x1[i2], x1[i3], x1[i4], y1, y2, y3, y4, x1_);
    }
    
    /**
     * Perform bilinear interpolation across the provided values
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param y array of y[x1][x2] values
     * @param x1_ x1 value at which to interpolate
     * @param x2_ x2 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateBilinear(double[] x1, double[] x2, double[][] y, double x1_, double x2_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
            index = 0;
        //  Extrapolate right
        else if (index >= N - 1)
            index = N - 2;

        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateLinear(x2, y[index], x2_);
        else if ( x1_ == x1[index+1] )
        	return interpolateLinear(x2, y[index + 1], x2_);

        //  Otherwise, interpolate across x2 first
        double y1 = interpolateLinear(x2, y[index], x2_);
        double y2 = interpolateLinear(x2, y[index + 1], x2_);

        //  Interpolate across x1 second
        return linear(x1[index], x1[index + 1], y1, y2, x1_);
    }

    /**
     * Perform bi-quadratic interpolation across the provided values.
     * Interpolate first across x2 and then across x1
     * 
     * @param x1 monotonically increasing x1 values
     * @param x2 monotonically increasing x2 values
     * @param y array of y[x1][x2] values
     * @param x1_ x1 value at which to interpolate
     * @param x2_ x2 value at which to interpolate at
     * @return interpolated y value
     */
    public static final double interpolateBiquadratic(double[] x1, double[] x2, double[][] y, double x1_, double x2_)
    {
        int N = x1.length;

        //  Bracket around x1
        int index = bracket(x1, x1_);

        //  Extrapolate left
        if (index < 0)
        {
            double y1 = interpolateQuadratic(x2, y[0], x2_);
            double y2 = interpolateQuadratic(x2, y[1], x2_);

            return linear(x1[0], x1[1], y1, y2, x1_);
        }
        //  Extrapolate right
        else if (index >= N - 1)
        {
            double y1 = interpolateQuadratic(x2, y[N - 2], x2_);
            double y2 = interpolateQuadratic(x2, y[N - 1], x2_);

            return linear(x1[N - 2], x1[N - 1], y1, y2, x1_);
        }
        
        //  Check for an exact match of x1 to cut down execution time
        if ( x1_ == x1[index] )
        	return interpolateQuadratic(x2, y[index], x2_);
        else if ( x1_ == x1[index+1] )
        	return interpolateQuadratic(x2, y[index + 1], x2_);

        //  Interpolate across x2 first
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        double y1 = interpolateQuadratic(x2, y[i1], x2_);
        double y2 = interpolateQuadratic(x2, y[i2], x2_);
        double y3 = interpolateQuadratic(x2, y[i3], x2_);
        double y4 = interpolateQuadratic(x2, y[i4], x2_);

        //  Interpolate across x1
        return quadratic(x1[i1], x1[i2], x1[i3], x1[i4], y1, y2, y3, y4, x1_);
    }

    /**
     * Linearly interpolate the provided x and y values
     * 
     * @param x x values, monotonically increasing
     * @param y y values
     * @param x0 x value to interpolate at
     * @return
     */
    public static final double interpolateLinear(double[] x, double[] y, double x0)
    {
        int N = x.length;

        //  Find the index within the x values
        int index = bracket(x, x0);

        //  Extrapolate left
        if (index < 0)
            index = 0;
        //  Extrapolate right
        else if (index >= N - 1)
            index = N - 2;

        return linear(x[index], x[index + 1], y[index], y[index + 1], x0);
    }

    /**
     * Perform monotone, quadratic interpolation of function f(x).   The 
     * interpolating function between two points is monotone in value and 
     * linear in derivative.
     * @param x 
     * @param y
     * @param x0 value of independent variable for interpolation (the point at which to find the interpolated value)
     * @return
     */
	public static Double interpolateQuadratic(double[] x, Double[] y, double x0)
	{
        int N = x.length;
        if ( N == 0 )
        	return Double.NaN;
        else if ( N == 1 )
        	return y[0];

        //  Matching index in x
        int index = bracket(x, x0);

        //  Extrapolate left
        if (index < 0)
            return linear(x[0], x[1], y[0], y[1], x0);
        //  Extrapolate right
        else if (index >= N - 1)
            return linear(x[N - 2], x[N - 1], y[N - 2], y[N - 1], x0);
        else if ( x[index] == x0 )
            return y[index];

        // Find the points x1, x2, x3, x4 such that
        // x1 <= x2 <= x0 <= x3 <= x4
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        return quadratic(x[i1], x[i2], x[i3], x[i4], y[i1], y[i2], y[i3], y[i4], x0);
	}

    /**
     * Perform monotone, quadratic interpolation of function f(x).   The 
     * interpolating function between two points is monotone in value and 
     * linear in derivative.
     * @param x 
     * @param y
     * @param x0 value of independent variable for interpolation (the point at which to find the interpolated value)
     * @return
     */
    public static final double interpolateQuadratic(double[] x, double[] y, double x0)
    {
        int N = x.length;
        if ( N == 0 )
        	return Double.NaN;
        else if ( N == 1 )
        	return y[0];

        //  Matching index in x
        int index = bracket(x, x0);

        //  Extrapolate left
        if (index < 0)
            return linear(x[0], x[1], y[0], y[1], x0);
        //  Extrapolate right
        else if (index >= N - 1)
            return linear(x[N - 2], x[N - 1], y[N - 2], y[N - 1], x0);
        else if ( x[index] == x0 )
            return y[index];

        // Find the points x1, x2, x3, x4 such that
        // x1 <= x2 <= x0 <= x3 <= x4
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        return quadratic(x[i1], x[i2], x[i3], x[i4], y[i1], y[i2], y[i3], y[i4], x0);
    }

    /**
     * Perform monotone, quadratic interpolation of the derivative of function f(x).   The 
     * interpolating function between two points is monotone in value and 
     * linear in derivative.
     * @param x 
     * @param y
     * @param x0 value of independent variable for interpolation (the point at which to find the interpolated value)
     * @return
     */
    public static final double interpolateQuadraticDerivative(double[] x, double[] y, double x0)
    {
        int N = x.length;
        if (N < 2)
            return 0;

        //  Matching index in x
        int index = Interpolation.bracket(x, x0);

        //  Extrapolate left
        if (index < 0)
            index = 0;
        //  Extrapolate right
        else if (index >= N - 1)
            index = N - 2;

        // Find the points x1, x2, x3, x4 such that
        // x1 <= x2 <= x0 <= x3 <= x4
        int i1 = Math.max(0, index - 1);
        int i2 = index;
        int i3 = index + 1;
        int i4 = Math.min(N - 1, index + 2);

        return quadratic_derivative(x[i1], x[i2], x[i3], x[i4], y[i1], y[i2], y[i3], y[i4], x0);
    }
    
    /**
     * Spline interpolate the provided x and y values
     * 
     * @param x x values, monotonically increasing
     * @param y y values
     * @param x0 x value to interpolate at
     * @return
     */
    public static final double interpolateSpline(double[] x, double[] y, double x0, int N)
    {
        //  Compute the 2nd derivatives
        double[] y_2dev = spline(x, y, N);
        
        //  Evaluate the derivatives
        return splint_deriv(x, y, y_2dev, x0, N);
    }

    /**
     * Perform linear interpolation between two points to find the desired value.  Extrapolation will
     *  occur as required if aX is not in [aX0, aX1]
     * @param x1 first x value to interpolate from
     * @param x2 second x value to interpolate from
     * @param y1 f(x0)
     * @param y2 f(x1)
     * @param x approximate function at this point
     * @return approximation of f(aX) and slope between the first and second input points.  The slope is forced
     *  to 0.0 if the x0 and x1 are the same (implying the inputs do not form a function in the first place).  
     */
    public static final double linear(double x1, double x2, double y1, double y2, double x)
    {
        //  Check for an exact match of x to cut down execution time
    	if ( x == x1 )
    		return y1;
    	if ( x == x2 )
    		return  y2;
    	
        double slope = slope(x1, x2, y1, y2);
        double y = y1 + slope * (x - x1);

        return y;
    }

    /**
     * Perform a quadratic interpolation on the provided x,f(x) points at the value x0.
     * 
     * @param x1
     * @param x2
     * @param x3
     * @param x4
     * @param f1
     * @param f2
     * @param f3
     * @param f4
     * @param x0
     * @return
     */
    public static final double quadratic(double x1, double x2, double x3, double x4, double f1, double f2, double f3, double f4, double x0)
    {
        // Find widths of the three intervals.  h23 is guaranteed
        // to be > 0 due to the bracket function's contractual 
        // guarantee that x[lLeft] < x[lLeft+1] so it safe to divide
        // by h23 below.
        double h12 = x2 - x1;
        double h23 = x3 - x2;
        double h34 = x4 - x3;

        // Set the finite difference derivative in the center interval      
        double s23 = (f3 - f2) / h23;
        double s12 = 0.0;
        double s34 = 0.0;

        double fp2 = 0.0;
        double fp3 = 0.0;

        // Assign a function derivative, fp2, to point 2.  The 
        // derivative of the parabola fitting points 1,2,3 
        // (evaluated at x2) is used.  If h12 is 0, use s23 for the
        // derivative.
        if (h12 > 0.0)
        {
            s12 = (f2 - f1) / h12;
            fp2 = (s23 * h12 + s12 * h23) / (h12 + h23);
        }
        else
            fp2 = s23;

        // Assign a function derivative, fp3, to point 3.  The
        // derivative of the parabola fitting points 2, 3, 4
        // (evaluated at x3) is used.  If h34, is 0, use s23
        // for the derivatrive.
        if (h34 > 0.0)
        {
            s34 = (f4 - f3) / h34;
            fp3 = (s23 * h34 + s34 * h23) / (h34 + h23);
        }
        else
            fp3 = s23;

        // Adjust derivative at point 2 (fp2) and derivative at 
        // point 3 (fp3) such that they average to the finite difference
        // derivative from points 2 to 3 (s23) but neither gets 
        // farther from s23
        double fpdev = 0.0;
        double fpdev2 = s23 - fp2;
        double fpdev3 = fp3 - s23;

        if (fpdev2 * fpdev3 <= 0.0)
            fpdev = 0.0;
        else if (fpdev2 < 0.0)
            fpdev = -Math.min(-fpdev2, -fpdev3);
        else
            fpdev = Math.min(fpdev2, fpdev3);

        // Adjust derivatives such that the Hermite cubic interpolant
        // is monotonic
        if (s23 != 0.0)
        {
            double fac = Math.abs(fpdev / s23);
            if (fac > 1.0)
                fpdev = fpdev / fac;
        }

        fp2 = s23 - fpdev;
        fp3 = s23 + fpdev;
        // Do a straight Hermite cubic interpolation between points 2 and 3
        double f = hermite(x2, x3, f2, f3, fp2, fp3, x0);
        return f;
    }

    /**
     * Using a bisection search, find those values of an array that bracket 
     * a given value.  Given the input array values(i), i=0,...,N-1, 
     * in non-decreasing order, and given the value aCompare, find
     * left in -1...N-1 such that 
     * 		values[leftBracket]  <= value <= values[leftBracket+1]
     * 		values[leftBracket] < values[leftBracket+1]
     * where left = -1 is assumed to mean -infinity and
     *       left =  N is assumed to mean  infinity
     * @see Fortran brack.f file from NetSim
     * @param values values used for bracketing, must be in non-decreasing order
     * @param value value to compare against
     * @return left bracket index meeting the constraints detailed above.
     */
    private static final int bracket(double[] values, double value)
    {
        int left = -1;
        int right = values.length;

        // Bisection search to find the bracket
        int mid = 0;
        while (true)
        {
            mid = (right + left) / 2;

            // Mid became negative - went off the left end, return -1
            if ((right + left) < 0)
            {
                return -1;
            }

            // Found the bracket, return
            if (mid == left)
            {
                return left;
            }

            // Lower right bracket
            else if (value < values[mid])
                right = mid;

            // Raise left bracket
            else if (value > values[mid])
                left = mid;

            // If the mid point equals the comparison value then find the
            // bracket such that values[leftBracket] < value[leftBracket+1]
            else
            {
                return moveBracket(values, value, mid);
            }
        }
    }

    /**
     * Perform a two point Hermitian cubic interpolation of function
     * f(x) between two sample points x1, x2.
     * @see Fortran hermit.f file from NetSim
     * @param x1 first sample point 
     * @param x2 second sample point
     * @param y1 y(x1) - function sampled at point x1
     * @param y2 y(x2) - function sampled at point x2
     * @param yp1 y'(x1) - derivative of function at x1
     * @param yp2 y'(x2) - derivative of function at x2
     * @param x0 point to evaluate function at using interpolation
     * @return a tuple (y0, yp0) where 
     *  y0  = y(x0)  - interpolated value of function at x0
     *  yp0 = y'(x0) - interpolated derivative of function at x0
     */
    private static final double hermite(double x1, double x2, double y1, double y2, double yp1, double yp2, double x0)
    {
        double dx = x2 - x1;
        double t = (x0 - x1) / dx;

        double f1, f2, fp1, fp2;

        if (t <= 0.5)
        {
            f1 = y1;
            f2 = y2;
            fp1 = yp1;
            fp2 = yp2;
        }
        else
        {
            t = 1.0 - t;
            dx = -dx;
            f1 = y2;
            f2 = y1;
            fp1 = yp2;
            fp2 = yp1;
        }

        fp1 *= dx;
        fp2 *= dx;

        double df = f2 - f1;
        double sfp = fp1 + fp2;
        double a = f1;
        double b = fp1;
        double c = (3.0 * df) - sfp - fp1;
        double d = (-2.0 * df) + sfp;

        double y0 = ((d * t + c) * t + b) * t + a;
        //double  yp0 = ((3.0 * d * t + 2.0 * c) * t + b) / dx;

        return y0;
    }

    /**
     * Perform a two point Hermitian cubic interpolation of function
     * f(x) between two sample points x1, x2.
     * @see Fortran hermit.f file from NetSim
     * @param x1 first sample point 
     * @param x2 second sample point
     * @param y1 y(x1) - function sampled at point x1
     * @param y2 y(x2) - function sampled at point x2
     * @param yp1 y'(x1) - derivative of function at x1
     * @param yp2 y'(x2) - derivative of function at x2
     * @param x0 point to evaluate function at using interpolation
     * @return a tuple (y0, yp0) where 
     *  y0  = y(x0)  - interpolated value of function at x0
     *  yp0 = y'(x0) - interpolated derivative of function at x0
     */
    private static final double hermite_derivative(double x1, double x2, double y1, double y2, double yp1, double yp2, double x0)
    {
        double dx = x2 - x1;
        double t = (x0 - x1) / dx;

        double f1, f2, fp1, fp2;

        if (t <= 0.5)
        {
            f1 = y1;
            f2 = y2;
            fp1 = yp1;
            fp2 = yp2;
        }
        else
        {
            t = 1.0 - t;
            dx = -dx;
            f1 = y2;
            f2 = y1;
            fp1 = yp2;
            fp2 = yp1;
        }

        fp1 *= dx;
        fp2 *= dx;

        double df = f2 - f1;
        double sfp = fp1 + fp2;
        double a = f1;
        double b = fp1;
        double c = (3.0 * df) - sfp - fp1;
        double d = (-2.0 * df) + sfp;

        //double  y0 = ((((d * t + c) * t) + b) * t) + a;
        double yp0 = ((((3.0 * d * t) + (2.0 * c)) * t) + b) / dx;

        return yp0;
    }

    /**
     * Moves a bracket such that  values[leftBracket] < value[leftBracket+1]
     * It is assumed on input that aCompare == aValues[aMid] and so
     * the bracket needs to be shifted from aMid to meet this inequality
     * constraint.
     * @param values values used for bracketing, must be in non-decreasing order
     * @param compare value to compare against
     * @param mid index into aValues, must satisfy aValues[aMid] == aCompare
     * @return leftBracket index meeting the constraints 
     * 	aValues[leftBracket] < aValues[leftBracket+1]
     *  aValues[leftBracket]  <= aCompare <= aValues[leftBracket+1]
     */
    private static final int moveBracket(double[] values, double compare, int mid)
    {
        int N = values.length;

        // Try moving up until a value > compare is found
        for (int i = mid + 1; i < N; ++i)
        {
            if (values[i] > compare)
                return i - 1;
        }

        // Try moving down until a value < compare is found
        for (int i = mid - 1; i >= 0; --i)
        {
            if (values[i] < compare)
                return i;
        }

        // Left bracket is off the end of the array
        return -1;
    }

    /**
     * Perform a quadratic interpolation on the provided x,y points at the value x0.
     * 
     * @param x1
     * @param x2
     * @param x3
     * @param x4
     * @param y1
     * @param y2
     * @param y3
     * @param y4
     * @param x0
     * @return
     */
    private static final double quadratic_derivative(double x1, double x2, double x3, double x4, double y1, double y2, double y3, double y4, double x0)
    {
        // Find widths of the three intervals.  h23 is guaranteed
        // to be > 0 due to the bracket function's contractual 
        // guarantee that x[lLeft] < x[lLeft+1] so it safe to divide
        // by h23 below.
        double h12 = x2 - x1;
        double h23 = x3 - x2;
        double h34 = x4 - x3;

        // Set the finite difference derivative in the center interval      
        double s23 = (y3 - y2) / h23;
        double s12 = 0.0;
        double s34 = 0.0;

        double fp2 = 0.0;
        double fp3 = 0.0;

        // Assign a function derivative, fp2, to point 2.  The 
        // derivative of the parabola fitting points 1,2,3 
        // (evaluated at x2) is used.  If h12 is 0, use s23 for the
        // derivative.
        if (h12 > 0.0)
        {
            s12 = (y2 - y1) / h12;
            fp2 = (s23 * h12 + s12 * h23) / (h12 + h23);
        }
        else
            fp2 = s23;

        // Assign a function derivative, fp3, to point 3.  The
        // derivative of the parabola fitting points 2, 3, 4
        // (evaluated at x3) is used.  If h34, is 0, use s23
        // for the derivatrive.
        if (h34 > 0.0)
        {
            s34 = (y4 - y3) / h34;
            fp3 = (s23 * h34 + s34 * h23) / (h34 + h23);
        }
        else
            fp3 = s23;

        // Adjust derivative at point 2 (fp2) and derivative at 
        // point 3 (fp3) such that they average to the finite difference
        // derivative from points 2 to 3 (s23) but neither gets 
        // farther from s23
        double fpdev = 0.0;
        double fpdev2 = s23 - fp2;
        double fpdev3 = fp3 - s23;

        if (fpdev2 * fpdev3 <= 0.0)
            fpdev = 0.0;
        else if (fpdev2 < 0.0)
            fpdev = -Math.min(-fpdev2, -fpdev3);
        else
            fpdev = Math.min(fpdev2, fpdev3);

        // Adjust derivatives such that the Hermite cubic interpolant
        // is monotonic
        if (s23 != 0.0)
        {
            double fac = Math.abs(fpdev / s23);
            if (fac > 1.0)
                fpdev = fpdev / fac;
        }

        fp2 = s23 - fpdev;
        fp3 = s23 + fpdev;

        // Do a straight Hermite cubic interpolation between points 2 and 3
        double y = hermite_derivative(x2, x3, y2, y3, fp2, fp3, x0);

        return y;
    }

    /**
     * Compute linear slope between two points.
     * 
     * @param x1 first x value to interpolate from
     * @param x2 second x value to interpolate from
     * @param y1 f(x0)
     * @param y2 f(x1)
     * @return approximation of f(aX) and slope between the first and second input points.  The slope is forced
     *  to 0.0 if the x0 and x1 are the same (implying the inputs do not form a function in the first place).  
     */
    private static final double slope(double x1, double x2, double y1, double y2)
    {
        return (x2 == x1) ? 0.0 : (y2 - y1) / (x2 - x1);
    }

    /**
     * Return the second derivative of the provided x and y values
     * 
     * @param x
     * @param y
     * @return
     */
    private static final double[] spline(double[] x, double[] y, int N)
    {
        double[] u = new double[N-1];
        double[] y2 = new double[N];
        
        y2[0] = u[0] = 0.0;
        y2[N-1] = 0;

        /* Decomposition loop for tridiagonal algorithm */
        for (int i=1; i<N-1; i++)
        {
            double sig   = (x[i]-x[i-1])/(x[i+1]-x[i-1]);
            double p     = sig*y2[i-1] + 2.0;
            y2[i] = (sig-1.0)/p;
            u[i]  = (y[i+1]-y[i])/(x[i+1]-x[i]) 
                - (y[i]-y[i-1])/(x[i]-x[i-1]);
            u[i]  = (6.0*u[i]/(x[i+1]-x[i-1])-sig*u[i-1])/p;
        }

        /* Back substitution loop of tridiagonal algorithm */
        for (int i = N-2; i >= 0; i--)
            y2[i] = y2[i]*y2[i+1] + u[i];
        
        return y2;
    }

    /**
     * Evaluate the x and values using the provided second derivative and x0.
     * 
     * @param x
     * @param y
     * @param y2
     * @param x0
     * @return
     */
    private static final double splint_deriv(double[] x, double[] y, double[] y2, double x0, int N)
    {
        int klo, khi, k;
        double  h, b, a;

        klo = 0;
        khi = N-1;
        while (khi-klo > 1)
        {
            k = (khi + klo) >> 1;
            if (x[k] > x0)
                khi = k;
            else
                klo = k;
        }   /* klo and khi now bracket the input value of x */

        h = x[khi] - x[klo];
        if (h == 0)
            System.out.println("Bad xa input to routine splint");

        a    = (x[khi] - x0)/h;
        b    = (x0 - x[klo])/h;
        double y0   = a*y[klo] + b*y[khi] + ((a*a*a - a)*y2[klo] 
               + (b*b*b - b)*y2[khi])*(h*h)/6.0;
        
        return y0;
    }
}
