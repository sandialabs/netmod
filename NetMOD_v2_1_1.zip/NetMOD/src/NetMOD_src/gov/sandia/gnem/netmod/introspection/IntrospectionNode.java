/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.introspection;

import gov.sandia.gnem.netmod.gui.Icons;

import javax.swing.*;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 * An introspection node represents the results of
 * single level of a simulation
 * 
 * @author bjmerch
 *
 */
public class IntrospectionNode
{
    public enum StatusType
    {
        GOOD(Icons.STATUS3.getIcon()), 
        WARNING(Icons.STATUS2.getIcon()), 
        ERROR(Icons.STATUS1.getIcon());

        private Icon _icon;

        StatusType(Icon icon)
        {
            _icon = icon;
        }

        /**
         * @return
         */
        public Icon getIcon()
        {
            return _icon;
        }
    };
    
    private IntrospectionNode _parent = null;
    private List<IntrospectionNode> _children = null;
    private List<Object[]> _notes = null;
    private StatusType _status = StatusType.GOOD;
    private IntrospectionListener _listener = null;

    /**
     * @param parent
     */
    public IntrospectionNode(IntrospectionNode parent)
    {
        _parent = parent;
    }

    /**
     * Add this child to the introspection node
     * 
     * @param child
     */
    public void addChild(IntrospectionNode child)
    {
        if ( _children == null )
            _children = new ArrayList<IntrospectionNode>();
        
        _children.add(child);
        
        fireUpdate();
    }

    /**
     * Add a note to this introspection node
     * 
     * @param notes
     */
    public void addNote(Object[] notes)
    {
        if ( _notes == null )
            _notes = new ArrayList<Object[]>();
            
        _notes.add(notes);
        
        fireUpdate();
    }

    /**
     * Get the children of this node
     * 
     * @return
     */
    public List<IntrospectionNode> getChildren()
    {
        return _children;
    }
    
    /**
     * Get the recorded notes for this introspection node.
     * @return 
     */
    public List<Object[]> getNotes()
    {
        return _notes;
    }
    
    /**
     * Get the parent of this node
     * 
     * @return
     */
    public IntrospectionNode getParent()
    {
        return _parent;
    }
    
    /**
     * @return the status
     */
    public StatusType getStatus()
    {
        StatusType status = _status;
        
        //  Check for a higher ordinal child status
        if ( _children != null )
        {
            int N = _children.size();
            for (int i=0; i<N; i++)
            {
                IntrospectionNode child = _children.get(i);
                if (child == null)
                    continue;
                
                StatusType childStatus = child.getStatus();
                
                if ( childStatus.ordinal() > status.ordinal() )
                    status = childStatus;
            }
        }
        
        return status;
    }
    
    /**
     * Set the children of this node
     * 
     * @param children
     */
    public void setChildren(List<IntrospectionNode> children)
    {
        _children = children;
        
        fireUpdate();
    }

    /**
     * @param status the status to set
     */
    public void setStatus(StatusType status)
    {
        //  Don't allow a null status
        if ( status == null )
            return;
        
        _status = status;
        
        fireUpdate();
    }
    
    @Override
    public String toString()
    {
        if ( _notes == null || _notes.size() == 0 || _notes.get(0) == null )
            return "";
       
        StringBuilder sb = new StringBuilder();
        if ( getNotes() != null )
            for (Object[] notes : getNotes())
            {
                if ( notes != null )
                {
                    for (Object note : notes)
                        sb.append(note);
                    sb.append("\n");
                }
            }

        return sb.toString();
    }
    
    /**
     * @param os
     */
    public void write(PrintStream os)
    {
        
    }
    
    /**
     * Send message up that this node has been updated
     */
    public void fireUpdate()
    {
        if ( _listener != null )
            _listener.update(this);
    }

    /**
     * @param listener
     */
    public void setIntrospectionListener(IntrospectionListener listener)
    {
        _listener = listener;
    }
}
