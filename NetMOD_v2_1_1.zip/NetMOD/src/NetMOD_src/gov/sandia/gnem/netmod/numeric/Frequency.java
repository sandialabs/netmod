/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

/**
 * High level container for a frequency
 * 
 * @author bjmerch
 *
 */
public abstract class Frequency
{
    /**
     * Convert the provided frequencies to a comma delimited string representation
     * 
     * @param frequencies
     * @return
     */
    static public String formatFrequencies(Frequency[] frequencies)
    {
        StringBuffer sb = new StringBuffer();
        
        for (Frequency frequency : frequencies)
        {
            if ( frequency == null )
                continue;
            
            sb.append(frequency.toString()).append(",");
        }
        
        if ( sb.length() > 1 )
            sb.deleteCharAt(sb.length()-1);
        
        return sb.toString();
    }
    
    /**
     * Parse frequencies from a comma delimited string representation
     * 
     * @param str
     * @return
     */
    static public Frequency[] parseFrequencies(String str)
    {
        String[] strings = str.trim().split("\\s*(,)\\s*");
        int N = strings.length;
        
        Frequency[] frequencies = new Frequency[N];
        
        for (int i=0; i<N; i++)
            frequencies[i] = parseFrequency(strings[i]);
        
        return frequencies;
    }
    
    /**
     * Parse a single frequency (discrete or range) from the provided string
     * 
     * @param str
     * @return
     */
    static public Frequency parseFrequency(String str)
    {
        String[] strings = str.trim().split("\\s*(-)\\s*");
        
        if ( strings.length == 1 )
            return new DiscreteFrequency(Double.parseDouble(strings[0]));
        else if ( strings.length == 2 )
        {
            double min = Double.parseDouble(strings[0]);
            double max = Double.parseDouble(strings[1]);
            
            return new FrequencyRange(min, max);
        }
        
        return null;
    }

    private double _minValue;
    private double _maxValue;
    private double[] _frequencies;

    protected Frequency(double value)
    {
    	this(value, value);
    }
    
    protected Frequency(double minValue, double maxValue)
    {
        _minValue = Math.min(minValue, maxValue);
        _maxValue = Math.max(minValue, maxValue);
        
        //  Generate arbitrary frequency ranges that span the passband
        if ( _minValue == _maxValue )
            _frequencies = new double[]{ _minValue };
        else
            _frequencies = NumericUtility.logspace(_minValue, _maxValue, 10);
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof Frequency) )
            return false;
        
        Frequency f = (Frequency) o;
        
        return getMinimumFrequency() == f.getMinimumFrequency() && getMaximumFrequency() == f.getMaximumFrequency();
    }

    /**
     * Get the central frequency as the geometric
     * mean of the frequency bounds.
     * 
     * @return
     */
    public double getCentralFrequency()
    {
        return Math.sqrt(_minValue * _maxValue);
    }

    /**
     * @return the value
     */
    public double getMaximumFrequency()
    {
        return _maxValue;
    }

    /**
     * @return the value
     */
    public double getMinimumFrequency()
    {
        return _minValue;
    }
    
    @Override
    public int hashCode()
    {
        return Float.floatToIntBits((float) (getMaximumFrequency() * 1000 + getMinimumFrequency()));
        
    }
    
    /**
     * @param value the value to set
     */
    public void setMaximumFrequency(double value)
    {
        _maxValue = value;
    }

    /**
     * @param value the value to set
     */
    public void setMinimumFrequency(double value)
    {
        _minValue = value;
    }

    /**
     * Get representative frequency samples that span the passband
     * 
     * @return
     */
    public double[] getFrequencySamples()
    {
        return _frequencies;
    }
}
