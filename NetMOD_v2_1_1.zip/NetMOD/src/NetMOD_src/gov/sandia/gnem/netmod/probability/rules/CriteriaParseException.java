/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

/**
 * An exception indicating that there was an error when parsing a criteria.
 * 
 * @author bjmerch
 *
 */
public class CriteriaParseException extends Exception
{
    public CriteriaParseException(String message)
    {
        super(message);
    }

}
