/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.metal.MetalBorders;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.Enumeration;

/**
 * Custom JTable that supports drag and drop
 * cut and paste, etc.
 * 
 * @author bjmerch
 *
 */
public class NetMODTable extends JTable
{
    /**
     * Listener for providing cut and paste within tables
     * 
     * @author bjmerch
     *
     */
    public class CutPasteListener implements ActionListener
    {
        private static final String Copy = "Copy";
        private static final String Paste = "Paste";

        private static final String TAB = "\t";
        private static final String NEWLINE = "\n";

        private JTable _table;

        /**
         * The Excel Adapter is constructed with a
         * JTable on which it enables Copy-Paste and acts
         * as a Clipboard listener.
         */
        public CutPasteListener(JTable myJTable)
        {
            _table = myJTable;
            KeyStroke copy = KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK, false);
            // Identifying the copy KeyStroke user can modify this
            // to copy on some other Key combination.
            KeyStroke paste = KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK, false);
            // Identifying the Paste KeyStroke user can modify this
            //to copy on some other Key combination.
            _table.registerKeyboardAction(this, "Copy", copy, JComponent.WHEN_FOCUSED);
            _table.registerKeyboardAction(this, "Paste", paste, JComponent.WHEN_FOCUSED);
        }

        public void actionPerformed(ActionEvent e)
        {
            //  Copy in to clipboard
            if (e.getActionCommand().compareTo(Copy) == 0)
            {
                StringBuilder sb = new StringBuilder();

                //  Get the selected rows and columns
                int[] rows = _table.getSelectedRows();
                int[] cols = _table.getSelectedColumns();

                if (rows == null || rows.length == 0 || cols == null || cols.length == 0)
                    return;

                //  Builder a string representation of the selection
                for (int i = 0; i < rows.length; i++)
                {
                    sb.append(_table.getValueAt(rows[i], cols[0]));
                    for (int j = 1; j < cols.length; j++)
                    {
                        sb.append(TAB);
                        sb.append(_table.getValueAt(rows[i], cols[j]));
                    }
                    sb.append(NEWLINE);
                }

                StringSelection selection = new StringSelection(sb.toString());
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, selection);
            }
            //  Paste out of clipboard
            else if (e.getActionCommand().compareTo(Paste) == 0)
            {
                //  Get the selected rows and columns
                int[] rows = _table.getSelectedRows();
                int[] cols = _table.getSelectedColumns();

                try
                {
                    String str = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(this).getTransferData(DataFlavor.stringFlavor).toString();

                    String[] strRows = str.split(NEWLINE);

                    //  Replicate a single pasted row
                    if (rows.length > 1 && strRows.length == 1)
                    {
                        String[] strCols = strRows[0].split(TAB);

                        //  Replicate a single pasted column
                        if (cols.length > 1 && strCols.length == 1)
                        {
                            for (int i = 0; i < rows.length; i++)
                                for (int j = 0; j < cols.length; j++)
                                    _table.setValueAt(strCols[0], rows[i], cols[j]);
                        }
                        //  Insert the pasted columns
                        else
                        {
                            for (int i = 0; i < rows.length; i++)
                                for (int j = 0; j < strCols.length; j++)
                                    if (cols[0] + j < _table.getColumnCount())
                                        _table.setValueAt(strCols[j], rows[i], cols[0] + j);
                        }
                    }
                    //  Inserted the pasted rows
                    else
                    {
                        for (int i = 0; i < strRows.length; i++)
                        {
                            String[] strCols = strRows[i].split(TAB);

                            //  Replicate a singled pasted column
                            if (cols.length > 1 && strCols.length == 1)
                            {
                                for (int j = 0; j < cols.length; j++)
                                    if (rows[0] + i < _table.getRowCount())
                                        _table.setValueAt(strCols[0], rows[0] + i, cols[j]);
                            }
                            //  Insert the pasted columns
                            else
                            {
                                for (int j = 0; j < strCols.length; j++)
                                {
                                    if (rows[0] + i < _table.getRowCount() && cols[0] + j < _table.getColumnCount())
                                        _table.setValueAt(strCols[j], rows[0] + i, cols[0] + j);

                                }
                            }
                        }
                    }

                    // Refresh the table
                    SwingUtilities.updateComponentTreeUI(_table);
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }

    static public class TableHeaderRenderer extends DefaultTableCellRenderer implements PropertyChangeListener
    {
        private static final Font FONT = UIManager.getFont("TableHeader.font");
        private static final Color FOREGROUND = UIManager.getColor("TableHeader.foreground");
        private static final Color BACKGROUND = UIManager.getColor("TableHeader.background");
        private static final Border BORDER = (UIManager.getBorder("TableHeader.cellBorder") != null) ? UIManager.getBorder("TableHeader.cellBorder")
                : new MetalBorders.TableHeaderBorder();

        /**
         * Use an instance of this class to render all header cells in the specified
         * table. The table must have its TableModel set before being given to this
         * method.
         */
        public static void register(JTable table)
        {
            TableHeaderRenderer renderer = new TableHeaderRenderer();

            // Add listener to handle the event that a new TableModel is set for the
            // table (e.g., via JTable.setModel). When that happens, we need to 
            // re-register the table with this class because the previous renderer 
            // will have been removed along with the previous TableModel.
            table.addPropertyChangeListener(renderer);

            for (Enumeration<TableColumn> e = table.getColumnModel().getColumns(); e.hasMoreElements();)
            {
                TableColumn tc = e.nextElement();
                tc.setHeaderRenderer(renderer);
                tc.setCellRenderer(new DefaultTableCellRenderer());
            }
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            // Explicitly set the appearance of the header cell each time this
            // method is called.
            setFont(FONT);
            setBorder(BORDER);
            setForeground(FOREGROUND);
            setBackground(BACKGROUND);
            setHorizontalAlignment(SwingConstants.CENTER);

            return this;
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt)
        {
            // Re-register the table with a TableHeaderRenderer when a new 
            // TableModel is set for the JTable.
            if ("model".equals(evt.getPropertyName()))
            {
                register((JTable) evt.getSource());
            }
        }
    }

    static public class TableTransferHandler extends TransferHandler
    {
        private static DataFlavor[] flavors;
        static
        {
            try
            {
                flavors = new DataFlavor[] { new DataFlavor("text/html;class=java.lang.String") }; // html
            }
            catch (ClassNotFoundException ex)
            {
                ex.printStackTrace();
            }
        }

        public TableTransferHandler()
        {
        }

        private class TocTransferable implements Transferable
        {
            private String _data;

            public TocTransferable(String s)
            {
                _data = s;
            }

            @Override
            public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
            {
                if (!isDataFlavorSupported(flavor))
                    throw new UnsupportedFlavorException(flavor);
                return _data;
            }

            @Override
            public DataFlavor[] getTransferDataFlavors()
            {
                return flavors;
            }

            @Override
            public boolean isDataFlavorSupported(DataFlavor flavor)
            {
                for (int i = 0; i < flavors.length; i++)
                {
                    if (flavor.equals(flavors[i]))
                        return true;
                }
                return false;
            }
        }

        public static String createHTMLTable(JTable table)
        {
            StringBuffer contents = new StringBuffer();

            contents.append("<TABLE><TR>");

            // Only for selected columns and rows!!!
            int[] columns = table.getSelectedColumns();
            int[] rows = table.getSelectedRows();

            for (int i = 0; i < columns.length; i++)
            {
                int col = columns[i];
                String columnName = table.getColumnName(col);
                columnName = columnName.replaceAll("<br>", " "); // replace line breaks with spaces
                columnName = columnName.replaceAll("\\<.*?>", ""); // remove all html
                contents.append("<TD>").append(columnName); // add a tab
            }
            contents.append("<TR>");

            // get row data
            for (int i = 0; i < rows.length; i++)
            {
                for (int j = 0; j < columns.length; j++)
                {
                    int row = rows[i];
                    int col = columns[j];
                    String value = table.getValueAt(row, col).toString();
                    value = value.replaceAll("\\<.*?>", ""); // remove all html
                    contents.append("<TD>").append(value); // add a tab
                }
                if (i < rows.length - 1)
                { // do not add row at the very end
                    contents.append("<TR>");
                }
            }

            contents.append("</TABLE>");
            return contents.toString();
        }

        protected Transferable createTransferable(JComponent c)
        {
            String contents = "<HTML>";
            contents += TableTransferHandler.createHTMLTable((JTable) c);
            contents += "</HTML>";
            return new TocTransferable(contents);
        }

        public int getSourceActions(JComponent c)
        {
            return COPY;
        }

    }

    /**
     * Custom table model supporting features of the NetMODTable
     * 
     * @author bjmerch
     *
     */
    abstract static public class NetMODTableModel extends DefaultTableModel
    {
        /**
         * Remove the provided rows from the table model
         * 
         * @param rows
         */
        abstract public void remove(int[] rows);
    }

    public NetMODTable()
    {
        super();

        init();
    }

    public NetMODTable(NetMODTableModel model)
    {
        super(model);

        init();
    }

    public NetMODTable(NetMODTableModel model, JTableHeader header)
    {
        super(model);

        init();

        header.setColumnModel(getColumnModel());
        setTableHeader(header);
    }

    private void init()
    {
        setDragEnabled(true);
        setColumnSelectionAllowed(true);
        setRowSelectionAllowed(true);
        getTableHeader().setReorderingAllowed(false);
        setTransferHandler(new TableTransferHandler());

        Dimension d = getPreferredScrollableViewportSize();
        d.height = 150;
        setPreferredScrollableViewportSize(d);
        setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        //  Enable multi-line headers
        TableHeaderRenderer.register(this);

        //  Keep column width greater than the preferred cell width
        //TableColumnAdjuster.register(this);

        //  Enable copy/paste of text
        new CutPasteListener(this);

        //  Enable deleting
        addKeyListener(new KeyAdapter()
        {
            public void keyReleased(KeyEvent e)
            {
                JTable table = (JTable) e.getSource();

                if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                {
                    if ( getModel() instanceof NetMODTableModel )
                    {
                        NetMODTableModel model = (NetMODTableModel) getModel();
                        model.remove(table.getSelectedRows());
                    }
                }
            }
        });
    }

    @Override
    public boolean getScrollableTracksViewportWidth()
    {
        //  Display columns wider than their preferred widths and enabled scrolling only if needed
        return getPreferredSize().width < getParent().getWidth();
    }

}
