/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

/**
 * A discrete frequency value
 * 
 * @author bjmerch
 *
 */
public final class DiscreteFrequency extends Frequency
{
    public DiscreteFrequency(double value)
    {
        super(value, value);
    }
    
    @Override
    public String toString()
    {
        return Double.toString(getMinimumFrequency());
    }
}
