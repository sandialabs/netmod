/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.gui.DoubleRangeFormatter;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import java.awt.*;

/**
 * @author bjmerch
 *
 */
class SimulationTypeProbabilityViewer extends NetModComponentViewer<SimulationTypeProbability>
{
    private JFormattedTextField _magnitude = new JFormattedTextField(new DoubleRangeFormatter());
    private JComboBox _magnitudeType;

    SimulationTypeProbabilityViewer(SimulationTypeProbability nmc)
    {
        super(nmc, true, false);
        
        _magnitudeType = new JComboBox(((Simulation) nmc.getParent()).getMagnitudeTypes().toArray());
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored after updating
        registerControls(_magnitude, _magnitudeType);
    }

    @Override
    public void apply(SimulationTypeProbability nmc)
    {
        nmc.setMagnitude(((Number) _magnitude.getValue()).doubleValue());
        nmc.setMagnitudeType((MagnitudeType) _magnitudeType.getSelectedItem());
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Define tooltips
            _magnitude.setToolTipText("Magnitude to simulate");
            _magnitudeType.setToolTipText("Magnitude unit");
            
            GUIUtility.addRow(panel, new JLabel("Magnitude: "), _magnitude, _magnitudeType);
            
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(SimulationTypeProbability nmc)
    {
        _magnitude.setValue(nmc.getMagnitude());
        _magnitudeType.setSelectedItem(nmc.getMagnitudeType());
    }
}
