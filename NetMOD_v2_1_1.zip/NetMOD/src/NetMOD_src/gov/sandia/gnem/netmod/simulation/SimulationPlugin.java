/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.io.libpar.ParLoader;
import gov.sandia.gnem.netmod.plugin.Plugin;

import java.io.File;

/**
 * @author bjmerch
 *
 */
public class SimulationPlugin extends Plugin<Simulation>
{
    private static SimulationPlugin _plugin = new SimulationPlugin();
    
    /**
     * Get the plugin framework for Sources
     * 
     * @return
     */
    public static SimulationPlugin getPlugin()
    {
        return _plugin;
    }
    
    /**
     * Load a simulation from the provided parameter file
     * 
     * @param parFile
     * @param parameters Parameters to override in the par file
     * @return
     */
    public static Simulation load(String parFile, LibParParameters parameters)
    {
        try
        {
            //  Load the LibPAR parameters from the file
            File file = IOUtility.openFile(parFile).getCanonicalFile();
            
            LibParParameters parFileParameters = new LibParParameters();
            parFileParameters.set("NS_CONFIG", file.getParent());

            //  Pre-Load any command line parameters into the libPAR parameters
            if ( parameters != null )
            	parFileParameters.set(parameters);

            //  Mid-load the parfile parameters
            parFileParameters = ParLoader.load(file, parFileParameters);

            //  Post-Load any command line parameters into the libPAR parameters
            if ( parameters != null )
            	parFileParameters.set(parameters);

            //  Find a netsim style parameter set that is correct for this par file
            NetSimParameters netsimParameters = new NetSimParameters();
            if (netsimParameters.read(parFileParameters))
            {
                //  Find a simulation for this parameter set
                Simulation simulation = SimulationPlugin.getPlugin().getComponentFor(null, netsimParameters);

                //  Load the simulation from the parameter set
                simulation.load(netsimParameters);
                
                return simulation;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        //  Could not load a simulation
        return null;
    }
}
