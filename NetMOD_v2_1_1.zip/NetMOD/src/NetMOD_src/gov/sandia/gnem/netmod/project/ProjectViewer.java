/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.project;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.io.libpar.ParLoader;
import gov.sandia.gnem.netmod.simulation.Simulation;
import gov.sandia.gnem.netmod.simulation.SimulationPlugin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.Arrays;

/**
 * @author bjmerch
 *
 */
public class ProjectViewer extends NetModComponentViewer<Project>
{
    public ProjectViewer(Project nmc)
    {
        super(nmc, false, false, true);

        addNetModPostControl(createOpenSimulationButton());
        addNetModPostControl(createAddSimulationButton());

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored after updating
        registerControls();
    }

    @Override
    public void apply(Project nmc)
    {
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
            _expandedPanel = new JPanel(new GridBagLayout());

        return (JPanel) _expandedPanel;
    }

    @Override
    public void reset(Project nmc)
    {
        JPanel panel = getExpandedPanel();

        //  Remove any existing simulation viewers
        panel.removeAll();

        //  Add the simulation viewers
        for (Simulation sim : nmc.getSimulations())
            GUIUtility.addRow(panel, sim.getViewer());
        
        GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, new JLabel(" "));
    }

    private JButton createAddSimulationButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Create new simulation");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                SimulationPlugin sp = SimulationPlugin.getPlugin();

                //  Get the type of the new simulation
                Object type = JOptionPane.showInputDialog(NetMOD.getFrame(), "Select a simulation to create", "Simulations", JOptionPane.INFORMATION_MESSAGE,
                        null, sp.getTypes().toArray(), sp.getDefaultType());
                if (type == null)
                    return;

                //  Get a simulation of that type
                Simulation sim = sp.getComponent(_nmc, type.toString());
                if (sim == null)
                    return;

                //  Add the simulation to the project
                _nmc.add(sim);

                //  Update the display
                refresh();
            }
        });

        return button;
    }

    private JButton createOpenSimulationButton()
    {
        JButton button = GUIUtility.createButton(Icons.OPEN.getIcon());
        button.setToolTipText("Open a simulation file");

        button.addActionListener(new ActionListener()
        {
            /**
             * An accessory panel to allow the user to override the NS_CONFIG variable
             * 
             * @author bjmerch
             *
             */
            class ParfilePanel extends JPanel implements PropertyChangeListener
            {
                private JTextField _textField;

                public ParfilePanel()
                {
                    super(new GridBagLayout());
                    setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

                    _textField = new JTextField();
                    GUIUtility.addRow(this, new JLabel(" "), new JLabel("NS Config variable:"));
                    GUIUtility.addRow(this, _textField);
                    GUIUtility.addRow(this, GridBagConstraints.REMAINDER, new JLabel(" "));

                    setPreferredSize(new Dimension(250, 50));
                }

                @Override
                public void propertyChange(PropertyChangeEvent changeEvent)
                {
                    String changeName = changeEvent.getPropertyName();
                    if (JFileChooser.SELECTED_FILES_CHANGED_PROPERTY.equals(changeName))
                    {
                        //  Check for no change in selection
                        if (changeEvent.getOldValue() != null && changeEvent.getNewValue() != null)
                            if (Arrays.deepEquals((File[]) changeEvent.getOldValue(), (File[]) changeEvent.getNewValue()))
                                return;

                        if (changeEvent.getNewValue() != null)
                            for (File file : (File[]) changeEvent.getNewValue())
                            {
                                final File choosenFile = file;

                                SwingUtilities.invokeLater(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        File file = choosenFile;
                                        _textField.setText(file.getParent());
                                        int count = 0;
                                        while (file.getParentFile() != null && count < 10)
                                        {
                                            count++;
                                            LibParParameters parfile = new LibParParameters();

                                            String nsConfig = file.getParent();
                                            parfile.set("NS_CONFIG", nsConfig);
                                            try
                                            {
                                                parfile = ParLoader.load(choosenFile, parfile);
                                            }
                                            catch (Exception e)
                                            {
                                                file = file.getParentFile();
                                                continue;
                                            }

                                            //  Get the parameter set for the file
                                            NetSimParameters parameters = new NetSimParameters();
                                            if (!parameters.read(parfile))
                                            {
                                                file = file.getParentFile();
                                                continue;
                                            }
                                            
                                            //  Test for a parent that satisfies the project file
                                            Simulation simulation = SimulationPlugin.getPlugin().getComponentFor(_nmc, parameters, false);
                                            if (simulation == null)
                                            {
                                                file = file.getParentFile();
                                                continue;
                                            }
                                            
                                            _textField.setText(nsConfig);
                                            break;
                                        }
                                    }
                                });
                            }
                    }
                    else if (JFileChooser.SELECTED_FILE_CHANGED_PROPERTY.equals(changeName))
                    {
                        final File choosenFile = (File) changeEvent.getNewValue();
                        if (choosenFile == null)
                            return;

                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                File file = choosenFile;
                                _textField.setText(file.getParent());
                                int count = 0;
                                while (file.getParentFile() != null && count < 10)
                                {
                                    count++;
                                    LibParParameters parfile = new LibParParameters();

                                    String nsConfig = file.getParent();
                                    parfile.set("NS_CONFIG", nsConfig);
                                    try
                                    {
                                        parfile = ParLoader.load(choosenFile, parfile);
                                    }
                                    catch (Exception e)
                                    {
                                        file = file.getParentFile();
                                        continue;
                                    }

                                    //  Get the parameter set for the file
                                    NetSimParameters parameters = new NetSimParameters();
                                    if (!parameters.read(parfile))
                                    {
                                        file = file.getParentFile();
                                        continue;
                                    }
                                    
                                    //  Test for a parent that satisfies the project file
                                    Simulation simulation = SimulationPlugin.getPlugin().getComponentFor(_nmc, parameters, false);
                                    if (simulation == null)
                                    {
                                        file = file.getParentFile();
                                        continue;
                                    }
                                    
                                    _textField.setText(nsConfig);
                                    break;
                                }
                            }
                        });

                    }
                }
            }

            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                ParfilePanel panel = new ParfilePanel();

                File[] files = GUIUtility.showOpenDialog(NetMOD.getFrame(), "", "Open simulation project file", JFileChooser.FILES_ONLY, false, null, panel);
                if (files == null)
                    return;

                File file = IOUtility.openFile(files[0].getPath());
                String nsConfig = IOUtility.cleanString(panel._textField.getText());

                LibParParameters parfile = new LibParParameters();
                parfile.set("NS_CONFIG", nsConfig);
                try
                {
                    parfile = ParLoader.load(file, parfile);
                }
                catch (Exception e)
                {
                    GUIUtility.showExceptionDialog(null, "Simulation Read Error", "Error loading the par file", e);
                    return;
                }

                //  Get the parameter set for the file
                NetSimParameters parameters = new NetSimParameters();
                if (!parameters.read(parfile))
                {
                    GUIUtility.showExceptionDialog(null, "Simulation Read Error", "The selected file does not contain a known parameter set", null);
                    return;
                }

                //  Create a simulation object appropriate for this project file
                Simulation simulation = SimulationPlugin.getPlugin().getComponentFor(_nmc, parameters, false);
                if (simulation == null)
                {
                    GUIUtility.showExceptionDialog(null, "Simulation Read Error", "The selected file does not contain a known simulation", null);
                    return;
                }

                try
                {
                    simulation.load(parameters);
                }
                catch (Exception e)
                {
                    GUIUtility.showExceptionDialog(null, "Simulation Read Error", "Error processing simulation file", e);
                }
                
                simulation.setName(file.getName());

                //  Insert the simulation into the project
                _nmc.add(simulation);
                refresh();
            }
        });

        return button;
    }
}
