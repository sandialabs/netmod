package gov.sandia.gnem.netmod.simulation;

import java.util.ArrayList;
import java.util.Collection;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

/**
 * Implementation of JSON command-line output for a simulation.
 * 
 * @author bjmerch
 *
 */
public class SimulationOutputJSON extends AbstractNetModComponent implements SimulationOutput
{
    public static final String _type = "JSON";
    static
    {
        SimulationOutputPlugin.getPlugin().registerComponent(_type, SimulationOutputJSON.class);
    }
    
	private Thread thread = null;

	public SimulationOutputJSON(NetModComponent parent)
	{
		super(parent);
	}

	@Override
	public void start(final ProgressDialog pd, final Output output, final EpicenterGrid epicenters)
	{
		thread = new Thread()
		{
			@Override
			public void run()
			{
				int N = epicenters.size();

				System.out.println("{");
				System.out.println("  \"title\": \"" + output.getName() + "\",");
				
				//  Print the station information
				System.out.println("  \"stations\": [");
				int staCount = output.getNumberStations();
				for (int i=0; i< staCount; i++)
				{
					if ( i > 0 )
						System.out.println(",");
					
					// Output the results
					System.out.println("    {");
					System.out.println("      \"name\": \""        + output.getStationValue(i, 0) + "\",");
					System.out.println("      \"technology\": \""  + output.getStationValue(i, 1) + "\",");
					System.out.println("      \"longitude\": "   + output.getStationValue(i, 2).trim() + ",");
					System.out.println("      \"latitude\": "    + output.getStationValue(i, 3).trim() + ",");
					System.out.println("      \"reliability\": " + output.getStationValue(i, 4).trim() + ",");
					System.out.println("      \"channels\": "    + output.getStationValue(i, 5).trim() + ",");	
					System.out.println("      \"type\": \""        + output.getStationValue(i, 6) + "\"");						
					System.out.print("    }");
				}
				System.out.println();
				System.out.println("    ],");
				
				//  Print the parameter information
				System.out.println("  \"parameters\": {");
				int paramCount = output.getSimulKeyCount();
				ArrayList<String> keys = new ArrayList<String>(output.getSimulKeyKeys());
				for (int i=0; i<paramCount; i++)
				{
					if ( i > 0 )
						System.out.println(",");
					
					String key = keys.get(i);
					String value = output.getSimulKeyValue(key).trim();
					System.out.print("      \"" + key + "\": \"" + value + "\"");
				}
				System.out.println();
				System.out.println("    },");
				
				//  Print the epicenter output values
				System.out.println("  \"output_unit\": \"" + output.getSimulKeyValue(Output.SIMULKEY_SIZE_TYPE) + "\",");
				System.out.println("  \"output_count\": " + N + ",");
				System.out.println("  \"output\": [");
				long time = 0;
				int iterations = 0;
				long t1 = System.currentTimeMillis();

				for (int i = 0; i < N; i++)
				{
					Point.Double location = epicenters.get(i);
					pd.setMainLabel("Simulating Source: " + location);

					// Wait until the output is ready
					while (!output.getOutputSet(i) && !pd.isCanceled())
						pd.sleep(0.1);

					if (pd.isCanceled())
						break;
					
					if ( i > 0 )
						System.out.println(",");

					// Output the results
					System.out.println("    {");
					System.out.println("      \"latitude\": " + output.getEpicenterValue(i,  Output.SIMULGRID_LAT) + ",");
					System.out.println("      \"longitude\": " + output.getEpicenterValue(i,  Output.SIMULGRID_LON) + ",");
					System.out.println("      \"value\": " + output.getEpicenterValue(i, Output.SIMULGRID_SIZE) + ",");
					System.out.println("      \"probability\": " + output.getEpicenterValue(i,  Output.SIMULGRID_NETPROB) + ",");
					System.out.println("      \"iterations\": " + output.getIterations(i) + ",");
					System.out.println("      \"time\": " + output.getTime(i));					
					System.out.print("    }");

					time += output.getTime(i);
					iterations += output.getIterations(i);

					// Increment the progress bar
					pd.incrementMainProgressBar();
				}
				long t2 = System.currentTimeMillis();

				System.out.println();
				System.out.println("    ],");
				System.out.println("  \"iterations\": " + iterations + ",");
				System.out.println("  \"execution_time\": " + time + ",");
				System.out.println("  \"clock_time\": " + (t2 - t1) );
				System.out.println("}");
			}
		};
		thread.start();
	}

	@Override
	public void join()
	{
		try
		{
			thread.join();
		}
		catch (InterruptedException e)
		{}
	}
}
