/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 *
 * Notice: This computer software was prepared by Sandia Corporation,
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are
 * reserved by DOE on behalf of the United States Government and the
 * Contractor as provided in the Contract. You are authorized to use this
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 *
 * Ported From:
 * Horizontal Wind Model 08 (HWM08)
 * Version HWM071308E_DWM07B104i.01
 * See readme.txt file for detailed release notes.
 *
 * AUTHORS
 * Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 * DATE
 * 6 April 2009
 *
 * REFERENCES
 * Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner,
 * Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez,
 * M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu,
 * Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model
 * of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 * Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W.
 * Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 * DWM07 global empirical model of upper thermospheric storm-induced
 * disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jhwm08;

import java.util.Arrays;

public class HWM08 {

  //private double alttns = 0.0;       // Transition 1
  //private double altsym = 0.0;       // Transition 2
  //private double altiso = 0.0;       // Constant Limit

  private double[][] tparm; // Model Parameters

  // Global store for quasi-static model space parameters
  // These will change internally depending on the input parameters
  private double[] gprevious;
  private int gpriornb = 0;

  private double[] gfs0;
  private double[] gfs1;
  private double[] gfm0;
  private double[] gfm1;
  private double[] gfl0;
  private double[] gfl1;
  private double[] gbz;//, gbm;

  private double[] gzwght;
  private int glev = 0;

  // Miscellaneous flags and indicies
  private int cseason = 0;
  private int cwave = 0;
  private int ctide = 0;

  private boolean[] content = {true, true, true, true, true}; // Season/Waves/Tides
  private boolean[] component = {true, true}; // Compute zonal/meridional

  // Member classes
  public ALF alf;
  public DWM07b dwm;

  public HWM08() {
    HWM08_Data hwm08_data = HWM08_Data.getInstance();

    tparm = new double[hwm08_data.splineNodes + 1][hwm08_data.nbf];
    for (int i = 0; i < hwm08_data.splineNodes - hwm08_data.splineOrder; i++) {
      parity(hwm08_data.order[i], hwm08_data.nb[i], hwm08_data.mparm[i], tparm[i]);
    }
    //alttns = vnode[splineNodes-2];
    //altsym = vnode[splineNodes-1];
    //altiso = vnode[splineNodes];

    // Initialize remaining member variables
    gfs0 = new double[hwm08_data.maxs + 1];
    gfs1 = new double[hwm08_data.maxs + 1];
    gfm0 = new double[hwm08_data.maxm + 1];
    gfm1 = new double[hwm08_data.maxm + 1];
    gfl0 = new double[hwm08_data.maxl + 1];
    gfl1 = new double[hwm08_data.maxl + 1];
    gbz = new double[hwm08_data.nbf];
    //gbm    = new double[nbf];
    gzwght = new double[hwm08_data.splineOrder + 1];

    dwm = new DWM07b();
    alf = new ALF();

    gprevious = new double[5];
    for (int i = 0; i < gprevious.length; i++) {
      gprevious[i] = Double.MIN_VALUE;
    }
  }

  private double[] bspline_N = null;

  public double bspline(double alt, int iz) {
    HWM08_Data hwm08_data = HWM08_Data.getInstance();

    double Vleft, Vright;
    double saved, temp;

    if (bspline_N == null || bspline_N.length != hwm08_data.splineOrder + 2) {
      bspline_N = new double[hwm08_data.splineOrder + 2];
    }

    if ((iz == 0) && (alt == hwm08_data.vnode[0])) {
      return 1.0;
    } else if ((iz == (hwm08_data.numEquations - hwm08_data.splineOrder - 1)) && (alt
        == hwm08_data.vnode[hwm08_data.numEquations])) {
      return 1.0;
    } else if ((alt < hwm08_data.vnode[iz]) || (alt >= hwm08_data.vnode[iz + hwm08_data.splineOrder
        + 1])) {
      return 0.0;
    }

    for (int j = 0; j <= hwm08_data.splineOrder; j++) {
      if (alt >= hwm08_data.vnode[j + iz] && alt < hwm08_data.vnode[j + iz + 1]) {
        bspline_N[j] = 1.0;
      } else {
        bspline_N[j] = 0.0;
      }
    }

    for (int k = 1; k <= hwm08_data.splineOrder; k++) {
      if (bspline_N[0] == 0.0) {
        saved = 0.0;
      } else {
        saved = ((alt - hwm08_data.vnode[iz]) * bspline_N[0]) / (hwm08_data.vnode[iz + k]
            - hwm08_data.vnode[iz]);
      }

      for (int j = 0; j <= hwm08_data.splineOrder - k; j++) {
        Vleft = hwm08_data.vnode[iz + j + 1];
        Vright = hwm08_data.vnode[iz + j + k + 1];

        if (bspline_N[j + 1] == 0.0) {
          bspline_N[j] = saved;
          saved = 0.0;
        } else {
          temp = bspline_N[j + 1] / (Vright - Vleft);
          bspline_N[j] = saved + (Vright - alt) * temp;
          saved = (alt - Vleft) * temp;
        }
      }
    }

    return bspline_N[0];
  }

  public int findspan(int n, int p, double u, double[] V) throws Exception {
    if (u < 0) {
      throw new Exception(
          "Received a negative altitude. Make sure altitudes are positive. This corresponds to a negative depth.");
    }

    int low, mid, high;

    if (u >= V[n + 1]) {
      return n;
    }

    low = p;
    high = n + 1;
    mid = (low + high) / 2;

    do {
      if (u < V[mid]) {
        high = mid;
      } else {
        low = mid;
      }
      mid = (low + high) / 2;

    }
    while (u < V[mid] || u >= V[mid + 1]);

    return mid;
  }

  public double[] getGzwght() {
    return gzwght;
  }

  //  Arrays used in simulation
  private double[] dw = new double[2];
  private double[] wind = new double[2];
  private double[] input = new double[5];

  public void simulation(int iyd, double sec, double alt, double glat, double glon, double stl,
      double f107a, double f107, double[] ap, double[] w)
      throws Exception {
    // Initialize variables
    input[0] = (iyd % 1000);
    input[1] = sec;
    input[2] = glon;
    input[3] = glat;
    input[4] = alt;

    updateHWM(input, gprevious, ap, wind);

    if (ap[1] >= 0.0) {
      dwm.DWM07b_HWM_interface(iyd, sec, alt, glat, glon, ap, dw, alf);
      w[0] = dw[0] + wind[1];
      w[1] = dw[1] + wind[0];
    } else {
      w[0] = wind[1];
      w[1] = wind[0];
    }
  }

  ///  Arrays used in vertwght
  private double[] we = new double[5];
  private double[] e1 = new double[]{1.0, 0.428251121076233, 0.192825112107623, 0.484304932735426,
      0.0};
  private double[] e2 = new double[]{0.0, 0.571748878923767, 0.807174887892377, -0.484304932735426,
      1.0};

  /**
   * Updates the vertical basis functions of the quiet-time model.
   */
  public void vertwght(double alt) throws Exception {
    HWM08_Data hwm08_data = HWM08_Data.getInstance();
    final double H = 60.0;

    glev =
        findspan(hwm08_data.numEquations - hwm08_data.splineOrder - 1, hwm08_data.splineOrder, alt,
            hwm08_data.vnode) - hwm08_data.splineOrder;
    glev = Math.min(glev, 26);

    gzwght[0] = bspline(alt, glev);
    gzwght[1] = bspline(alt, glev + 1);
    if (glev <= 25) {
      gzwght[2] = bspline(alt, glev + 2);
      gzwght[3] = bspline(alt, glev + 3);
      return;
    } else {
      if (alt > 250.0) {
        we[0] = 0.0;
        we[1] = 0.0;
        we[2] = 0.0;
        we[3] = Math.exp(-(alt - 250.0) / H);
        we[4] = 1.0;
      } else {
        we[0] = bspline(alt, glev + 2);
        we[1] = bspline(alt, glev + 3);
        we[2] = bspline(alt, glev + 4);
        we[3] = 0.0;
        we[4] = 0.0;
      }
    }
    try {
      gzwght[2] = mathutil.dotProduct(we, e1);
      gzwght[3] = mathutil.dotProduct(we, e2);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void parity(int[] order, int nb, double[] mparm, double[] tparm) {
    int amaxs, amaxn, pmaxm, pmaxs, pmaxn, tmaxl, tmaxs, tmaxn;
    int c;

    amaxs = order[0];
    amaxn = order[1];
    pmaxm = order[2];
    pmaxs = order[3];
    pmaxn = order[4];
    tmaxl = order[5];
    tmaxs = order[6];
    tmaxn = order[7];

    c = 0;

    /*********************************************************************
     Seasonal - Zonal average (m = 0)
     *********************************************************************/
    for (int n = 1; n <= amaxn; n++) {
      tparm[c] = mparm[c + 1];
      tparm[c + 1] = -mparm[c];
      c += 2;
    }
    for (int s = 1; s <= amaxs; s++) {
      for (int n = s; n <= amaxn; n++) {
        tparm[c] = mparm[c + 2];
        tparm[c + 1] = mparm[c + 3];
        tparm[c + 2] = -mparm[c];
        tparm[c + 3] = -mparm[c + 1];
        c += 4;
      }
    }

    /*********************************************************************
     Stationary Planetary Waves
     *********************************************************************/
    for (int m = 1; m <= pmaxm; m++) {
      for (int n = m; n <= pmaxn; n++) {
        tparm[c] = mparm[c + 2];
        tparm[c + 1] = mparm[c + 3];
        tparm[c + 2] = -mparm[c];
        tparm[c + 3] = -mparm[c + 1];
        c += 4;
      }

      for (int s = 1; s <= pmaxs; s++) {
        for (int n = m; n <= pmaxn; n++) {
          tparm[c] = mparm[c + 2];
          tparm[c + 1] = mparm[c + 3];
          tparm[c + 2] = -mparm[c];
          tparm[c + 3] = -mparm[c + 1];
          tparm[c + 4] = mparm[c + 6];
          tparm[c + 5] = mparm[c + 7];
          tparm[c + 6] = -mparm[c + 4];
          tparm[c + 7] = -mparm[c + 5];
          c += 8;
        }
      }
    }

    /*********************************************************************
     Migrating Solar Tides
     *********************************************************************/
    for (int l = 1; l <= tmaxl; l++) {
      for (int n = l; n <= tmaxn; n++) {
        tparm[c] = mparm[c + 2];
        tparm[c + 1] = mparm[c + 3];
        tparm[c + 2] = -mparm[c];
        tparm[c + 3] = -mparm[c + 1];
        c += 4;
      }
      for (int s = 1; s <= tmaxs; s++) {
        for (int n = l; n <= tmaxn; n++) {
          tparm[c] = mparm[c + 2];
          tparm[c + 1] = mparm[c + 3];
          tparm[c + 2] = -mparm[c];
          tparm[c + 3] = -mparm[c + 1];
          tparm[c + 4] = mparm[c + 6];
          tparm[c + 5] = mparm[c + 7];
          tparm[c + 6] = -mparm[c + 4];
          tparm[c + 7] = -mparm[c + 5];
          c += 8;
        }
      }
    }

    return;
  }

  //  Arrays used in updateHWM
  boolean[] refresh = new boolean[5];

  /**
   * Computes the quiet-time model terms, updating only the terms that have not changed
   * since the last call. Applies the model parameters to the terms to get the winds.
   */
  private void updateHWM(double[] input, double[] previous, double[] ap, double[] wind)
      throws Exception {
    HWM08_Data hwm08_data = HWM08_Data.getInstance();

    // Local Variables
    double cs, ss, cm, sm, cl, sl;
    double cmcs, smcs, cmss, smss;
    double clcs, slcs, clss, slss;
    double AA, BB, CC;
    double vb, wb;
    double sccs, scss;

    int c, d;

    int amaxs, amaxn;
    int pmaxm, pmaxs, pmaxn;
    int tmaxl, tmaxs, tmaxn;

    Arrays.fill(refresh, false);

    // Seasonal Variations
    if (input[0] != previous[0]) {
      AA = input[0] * 2 * Math.PI / 365.25;

      for (int s = 0; s <= hwm08_data.maxs; s++) {
        BB = s * AA;
        gfs0[s] = Math.cos(BB);
        gfs1[s] = Math.sin(BB);
      }
      Arrays.fill(refresh, true);
      previous[0] = input[0];
    }

    // Hourly time changes, tidal variations
    if ((input[1] != previous[1]) || (input[2] != previous[2])) {
      AA = (input[1] / 3600.0 + input[2] / 15.0 + 48.0) % (24.0);
      BB = AA * 2 * Math.PI / 24.0;
      for (int i = 0; i <= hwm08_data.maxl; i++) {
        CC = i * BB;
        gfl0[i] = Math.cos(CC);
        gfl1[i] = Math.sin(CC);
      }
      refresh[2] = true;
      previous[1] = input[1];
    }

    // Longitudinal variations, planetary waves
    if (input[2] != previous[2]) {
      AA = Math.toRadians(input[2]);
      for (int i = 0; i <= hwm08_data.maxm; i++) {
        BB = i * AA;
        gfm0[i] = Math.cos(BB);
        gfm1[i] = Math.sin(BB);
      }
      refresh[1] = true;
      previous[2] = input[2];
    }

    // Latitude
    if (input[3] != alf.getGlat_alf()) {
      AA = Math.toRadians(90.0 - input[3]);
      alf.ALFBasisGBar(AA);
      refresh[0] = true;
      refresh[1] = true;
      refresh[2] = true;
      refresh[3] = true;
      alf.setGlat_alf(input[3]);
      previous[3] = input[3];
    }

    // Altitude
    if (input[4] != previous[4]) {
      vertwght(input[4]);
      previous[4] = input[4];
    }

    // Calculate the VSH functions
    wind[0] = 0.0f;
    wind[1] = 0.0f;

    for (int b = 0; b <= hwm08_data.splineOrder; b++) {
      if (gzwght[b] != 0.0) {
        d = b + glev;

        if (gpriornb != hwm08_data.nb[d]) {
          Arrays.fill(refresh, true);
        }
        gpriornb = hwm08_data.nb[d];

        if (!(refresh[0] || refresh[1] || refresh[2] || refresh[3] || refresh[4])) {
          c = hwm08_data.nb[d];
          if (component[0]) {
            wind[0] += gzwght[b] * mathutil.dot_product(gbz, hwm08_data.mparm[d], c);
          }
          if (component[1]) {
            wind[1] += gzwght[b] * mathutil.dot_product(gbz, tparm[d], c);
          }
          continue;
        }

        int[] order = hwm08_data.order[d];

        amaxs = order[0];
        amaxn = order[1];
        pmaxm = order[2];
        pmaxs = order[3];
        pmaxn = order[4];
        tmaxl = order[5];
        tmaxs = order[6];
        tmaxn = order[7];

        c = 0;

        /*************************************************************
         Seasonal - Zonal average (m = 0)
         *************************************************************/
        if (refresh[0] && content[0]) {

          for (int n = 1; n <= amaxn; n++) {
            gbz[c++] = -0.5 * alf.getGvbar(n, 0);
            gbz[c++] = 0.0;
          }

          for (int s = 1; s <= amaxs; s++) {
            cs = gfs0[s];
            ss = gfs1[s];
            for (int n = s; n <= amaxn; n++) {
              vb = alf.getGvbar(n, s);
              wb = alf.getGwbar(n, s);

              gbz[c++] = -vb * cs;
              gbz[c++] = vb * ss;
              gbz[c++] = -wb * ss;
              gbz[c++] = -wb * cs;
            }
          }
          cseason = c;
        } else {
          c = cseason;
        }

        /*************************************************************
         Stationary Planetary Waves
         *************************************************************/
        if (refresh[1] && content[1]) {
          for (int m = 1; m <= pmaxm; m++) {
            cm = gfm0[m];
            sm = gfm1[m];

            for (int n = m; n <= pmaxn; n++) {
              vb = alf.getGvbar(n, m);
              wb = alf.getGwbar(n, m);

              gbz[c++] = -vb * cm;
              gbz[c++] = vb * sm;
              gbz[c++] = -wb * sm;
              gbz[c++] = -wb * cm;
            }

            for (int s = 1; s <= pmaxs; s++) {
              cs = gfs0[s];
              ss = gfs1[s];

              cmcs = cm * cs;
              smcs = sm * cs;
              cmss = cm * ss;
              smss = sm * ss;

              for (int n = m; n <= pmaxn; n++) {
                vb = alf.getGvbar(n, m);
                wb = alf.getGwbar(n, m);

                gbz[c++] = -vb * cmcs;//cm * cs;
                gbz[c++] = vb * smcs;//sm * cs;
                gbz[c++] = -wb * smcs;//sm * cs;
                gbz[c++] = -wb * cmcs;//cm * cs;
                gbz[c++] = -vb * cmss;//cm * ss;
                gbz[c++] = vb * smss;//sm * ss;
                gbz[c++] = -wb * smss;//sm * ss;
                gbz[c++] = -wb * cmss;//cm * ss;
              }
            }
            cwave = c;
          }
        } else {
          c = cwave;
        }

        /*************************************************************
         Migrating Solar Tides
         *************************************************************/
        if (refresh[2] && content[2]) {
          for (int l = 1; l <= tmaxl; l++) {
            cl = gfl0[l];
            sl = gfl1[l];

            for (int n = l; n <= tmaxn; n++) {
              vb = alf.getGvbar(n, l);
              wb = alf.getGwbar(n, l);

              gbz[c++] = -vb * cl;
              gbz[c++] = vb * sl;
              gbz[c++] = -wb * sl;
              gbz[c++] = -wb * cl;
            }

            for (int s = 1; s <= tmaxs; s++) {
              cs = gfs0[s];
              ss = gfs1[s];

              clcs = cl * cs;
              slcs = sl * cs;
              clss = cl * ss;
              slss = sl * ss;

              for (int n = l; n <= tmaxn; n++) {
                vb = alf.getGvbar(n, l);
                wb = alf.getGwbar(n, l);

                gbz[c++] = -vb * clcs;//cl * cs;
                gbz[c++] = vb * slcs;//sl * cs;
                gbz[c++] = -wb * slcs;//sl * cs;
                gbz[c++] = -wb * clcs;//cl * cs;
                gbz[c++] = -vb * clss;//cl * ss;
                gbz[c++] = vb * slss;//sl * ss;
                gbz[c++] = -wb * slss;//sl * ss;
                gbz[c++] = -wb * clss;//cl * ss;
              }
            }
            ctide = c;
          }
        } else {
          c = ctide;
        }

        /*************************************************************
         Calculate the wind components
         *************************************************************/

        if (component[0]) {
          wind[0] += gzwght[b] * mathutil.dot_product(gbz, hwm08_data.mparm[d], c);
        }
        if (component[1]) {
          wind[1] += gzwght[b] * mathutil.dot_product(gbz, tparm[d], c);
        }
      }
    }
  }

}
