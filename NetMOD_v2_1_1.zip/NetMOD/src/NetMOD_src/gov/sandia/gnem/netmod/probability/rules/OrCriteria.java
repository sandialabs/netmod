/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author bjmerch
 *
 */
public class OrCriteria extends Criteria
{
    public static final String OR = "+";
    private Criteria _criteria1;
    private Criteria _criteria2;
    
    public OrCriteria(Criteria criteria1, Criteria criteria2)
    {
        _criteria1 = criteria1;
        _criteria2 = criteria2;
        
        criteria1.setParent(this);
        criteria2.setParent(this);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getCriteria1());
        children.add(getCriteria2());

        return children;
    }

    /**
     * @return the criteria1
     */
    public Criteria getCriteria1()
    {
        return _criteria1;
    }
    
    /**
     * @return the criteria2
     */
    public Criteria getCriteria2()
    {
        return _criteria2;
    }

    @Override
    public Set<Phase> getPhases()
    {
        Set<Phase> phases = getCriteria1().getPhases();
        phases.addAll(getCriteria2().getPhases());
        
        return phases;
    }

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    @Override
    public double getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        startIntrospection();
        recordIntrospection(this);
        
        //  Get the probabilities for each of the criteria
        double p1 = getCriteria1().getProbability(probabilities);
        double p2 = getCriteria2().getProbability(probabilities);
        
        double result = 1.0 - ( 1.0 - p1 ) * ( 1.0 - p2 );
        
        recordIntrospection("Probability: ", result);
        stopIntrospection();
        
        return result;
    }

    @Override
    public String toString()
    {
        return PAREN_OPEN + _criteria1 + OR + _criteria2 + PAREN_CLOSE;
    }

}
