/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.util.List;

/**
 * Class used to control zooming in and out of a ChartPanel. Clicking the left 
 * mouse button to zoom in, right mouse button to zoom out. Dragging a rectangle
 * on the chart zooms in on that region, and clicking the middle mouse button 
 * resets the graph so the all data points in plot is visible.
 * 
 * @author bjmerch 
 */
public final class ChartPanelZoomListener extends MouseAdapter
{
    private Point _startPoint = null;
    private Rectangle2D _zoomRectangle = null;

    /**
     * Mouse button has been pushed and held and is now being moved (dragged) 
     * across the screen.
     */
    @Override
    public void mouseDragged(MouseEvent e)
    {
        // Only draw zoom rectangles on a left mouse button click
        if (SwingUtilities.isLeftMouseButton(e))
        {

            ChartPanel chartPanel = (ChartPanel) e.getSource();
            Graphics2D g2 = (Graphics2D) chartPanel.getGraphics();

            // Erase the previous rectangle (if any)
            g2.setXORMode(java.awt.Color.gray);
            if (_zoomRectangle != null)
                g2.draw(_zoomRectangle);

            if (_startPoint == null)
                return;

            // Draw the new zoom rectangle
            _zoomRectangle = new Rectangle2D.Double(_startPoint.getX(), _startPoint.getY(), 0, 0);
            _zoomRectangle.add(e.getPoint());

            g2.draw(_zoomRectangle);
            g2.dispose();
        }
    }

    /**
     * Initial press-and-hold prior to zooming.
     */
    @Override
    public void mousePressed(MouseEvent e)
    {
        _startPoint = e.getPoint();

        // Add a key listener to the ChartPanel to cancel a zoom operation when
        // the ESCAPE key is pressed.
        final ChartPanel chartPanel = (ChartPanel) e.getSource();
        for (KeyListener kl : chartPanel.getKeyListeners())
        {
            chartPanel.removeKeyListener(kl);
        }
        chartPanel.setFocusable(true);
        chartPanel.requestFocusInWindow();
        chartPanel.addKeyListener(new KeyAdapter()
        {
            public void keyPressed(KeyEvent e)
            {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
                { // cancel zoom operation
                    SwingUtilities.updateComponentTreeUI(chartPanel);
                    _startPoint = null;
                    _zoomRectangle = null;
                }
            }
        });
    }

    /**
     * Mouse released after dragging.
     */
    @Override
    public void mouseReleased(MouseEvent e)
    {
        ChartPanel chartPanel = (ChartPanel) e.getSource();
        if (chartPanel == null)
            return;

        // Complete the zooming drag box
        if (_zoomRectangle != null && SwingUtilities.isLeftMouseButton(e))
        {
            chartPanel.zoom(_zoomRectangle);
        }
        else if (_startPoint != null)
        {
            // Zoom in a fixed amount
            if (SwingUtilities.isLeftMouseButton(e))
            {
                chartPanel.zoomInBoth(e.getX(), e.getY());
            }
            // Zoom out a fixed amount
            else if (SwingUtilities.isRightMouseButton(e))
            {
                chartPanel.zoomOutBoth(e.getX(), e.getY());
            }
            // Zoom Full
            else if (SwingUtilities.isMiddleMouseButton(e))
            {
                Object obj = chartPanel.getChart().getXYPlot();

                // Zoom Full (reset)
                if (obj instanceof CombinedDomainXYPlot)
                {
                    CombinedDomainXYPlot plot = (CombinedDomainXYPlot) obj;

                    List<XYPlot> plots = plot.getSubplots();
                    XYPlot p1 = plots.get(0);
                    XYPlot p2 = plots.get(1);

                    NumberAxis domain = (NumberAxis) p1.getDomainAxis();
                    domain.setAutoRangeIncludesZero(false);
                    domain.setAutoRange(true);
                    NumberAxis range = (NumberAxis) p1.getRangeAxis();
                    range.setAutoRangeIncludesZero(false);
                    range.setAutoRange(true);

                    domain = (NumberAxis) p2.getDomainAxis();
                    domain.setAutoRangeIncludesZero(false);
                    domain.setAutoRange(true);
                    range = (NumberAxis) p2.getRangeAxis();
                    range.setAutoRangeIncludesZero(false);
                    range.setAutoRange(true);
                }
                else
                {
                    XYPlot plot = (XYPlot) obj;

                    NumberAxis domain = (NumberAxis) plot.getDomainAxis();
                    domain.setAutoRangeIncludesZero(false);
                    domain.setAutoRange(true);
                    NumberAxis range = (NumberAxis) plot.getRangeAxis();
                    range.setAutoRangeIncludesZero(false);
                    range.setAutoRange(true);
                }
            }
        }

        _startPoint = null;
        _zoomRectangle = null;
    }
}
