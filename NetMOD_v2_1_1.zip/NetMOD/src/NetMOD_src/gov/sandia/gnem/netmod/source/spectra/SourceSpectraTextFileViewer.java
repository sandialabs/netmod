/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.spectra;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.gui.ChartViewer.AxisScale;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import org.jfree.chart.plot.XYPlot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * @author bjmerch
 *
 */
public class SourceSpectraTextFileViewer extends NetModComponentViewer<SourceSpectraTextFile>
{
    private class SourceSpectraDataset extends AbstractVisibleXYDataset
    {
        int N = 100;
        Magnitude _moment;
        private SourceSpectraTextFile _sourceSpectra = null;

        @Override
        public int getItemCount(int series)
        {
            if (isVisible())
            {
                if ( series == 0 )
                    return (_sourceSpectra == null ? 0 : _sourceSpectra.getFrequencies().length);
                else
                    return (_sourceSpectra == null ? 0 : N * (_sourceSpectra.getFrequencies().length - 1) + 1);
            }
            else
                return 0;
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return "log(Mo) = " + _moment;
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _sourceSpectra.getFrequencies()[item];
            else
            {
                int index = item / N;
                double[] f = _sourceSpectra.getFrequencies();

                if (index == f.length - 1)
                    return f[index];

                return Interpolation.linear(index * N, (index + 1) * N, f[index], f[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            double f = getX(series, item).doubleValue();
            return _sourceSpectra.getAmplitude(_moment, new DiscreteFrequency(f)).getFrequencyValue(f);
        }

        public void setSourceSpectra(SourceSpectraTextFile sourceSpectra, Magnitude moment)
        {
            _sourceSpectra = sourceSpectra;
            _moment = moment;
            fireDatasetChanged();
        }
    }

    private class SourceSpectraTableModel extends NetMODTableModel
    {
        private SourceSpectraTextFile _sourceSpectra = null;

        @Override
        public int getColumnCount()
        {
            if (_sourceSpectra == null)
                return 1;

            double[] moments = _sourceSpectra.getMoments();
            if (moments == null)
                return 1;

            return moments.length + 1;
        }

        public String getColumnName(int column)
        {
            if (column == 0)
                return "<html>Frequency<br>(Hz)</html>";
            else
                return "<html>" + Double.toString(_sourceSpectra.getMoments()[column - 1]) + "<br>log(Mo)</html>";
        }

        @Override
        public int getRowCount()
        {
            if (_sourceSpectra == null)
                return 0;

            double[] frequencies = _sourceSpectra.getFrequencies();
            if (frequencies == null)
                return 0;

            return frequencies.length + 10;
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_sourceSpectra == null || row >= _sourceSpectra.getFrequencies().length || column > _sourceSpectra.getMoments().length)
                return "";

            double f = _sourceSpectra.getFrequencies()[row];

            if (column == 0)
                return f;
            else
            {
                double m = _sourceSpectra.getMoments()[column - 1];
                return _sourceSpectra.getAmplitude(new Magnitude(m), new DiscreteFrequency(f));
            }
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return true;
        }

        public void setSourceSpectra(SourceSpectraTextFile sourceSpectra)
        {
            _sourceSpectra = sourceSpectra;
            fireTableStructureChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
            if (aValue == null || _sourceSpectra == null)
                return;

            try
            {
                double f = 0;

                //  Set value for an existing row
                if (row < _sourceSpectra.getFrequencies().length)
                    f = _sourceSpectra.getFrequencies()[row];

                //  Update the column
                if (column == 0)
                {
                    //  Get the amplitudes for this frequency
                    double[] moments = _sourceSpectra.getMoments();
                    double[] amplitudes = new double[moments.length];
                    for (int i = 0; i < moments.length; i++)
                        amplitudes[i] = _sourceSpectra.getAmplitude(new Magnitude(moments[i]), new DiscreteFrequency(f)).getFrequencyValue(f);

                    _sourceSpectra.removeAmplitudeFrequency(f);
                    f = Double.parseDouble(aValue.toString());

                    for (int i = 0; i < moments.length; i++)
                        _sourceSpectra.setAmplitude(moments[i], f, amplitudes[i]);
                }
                else
                {
                    double m = _sourceSpectra.getMoments()[column - 1];
                    double a = Double.parseDouble(aValue.toString());
                    _sourceSpectra.setAmplitude(m, f, a);
                }

                fireTableDataChanged();

                //  Keep row selected
                int index = _sourceSpectra.findIndex(_sourceSpectra.getFrequencies(), f);
                _table.getSelectionModel().setSelectionInterval(index, index);
                _table.scrollRectToVisible(_table.getCellRect(index, 0, true));
            }
            catch (Exception e)
            {
            }
        }

        @Override
        public void remove(int[] rows)
        {
            for (int row : rows)
            {
                double f = _sourceSpectra.getFrequencies()[row];
                _sourceSpectra.removeAmplitudeFrequency(f);
            }
        }
    }

    private ChartViewer _chartViewer = new ChartViewer();

    private SourceSpectraTableModel _tableModel = new SourceSpectraTableModel();

    private NetMODTable _table = new NetMODTable(_tableModel);

    public SourceSpectraTextFileViewer(SourceSpectraTextFile nmc)
    {
        super(nmc, false, false, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);
    }

    @Override
    public void apply(SourceSpectraTextFile nmc)
    {
    }

    /* (non-Javadoc)
     * @see gov.sandia.gnem.netmod.gui.NetModComponentViewer#getExpandedPanel()
     */
    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Configure the chart viewer
            _chartViewer.setXScale(AxisScale.LOG);
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Frequency (Hz)");
            plot.getRangeAxis().setLabel("log (Amplitude)");

            //  Setup the table
            _table.addKeyListener(new KeyAdapter()
            {
                public void keyReleased(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                    {
                        // Get selected rows
                        int[] rows = _table.getSelectedRows();

                        double[] frequencies = _nmc.getFrequencies();
                        for (int i = 0; i < rows.length; i++)
                            _nmc.removeAmplitudeFrequency(frequencies[rows[i]]);

                        reset(_nmc);
                    }
                }
            });

            JScrollPane sp = new JScrollPane(_table);
            sp.setCorner(ScrollPaneConstants.UPPER_RIGHT_CORNER, createAddMomentButton());
            sp.getVerticalScrollBar().setPreferredSize(new Dimension(Math.max(20, Icons.ADD.getIcon().getIconWidth()), 0));

            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.CENTER, sp);
            spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            spPanel.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(spPanel);

            //  Setup the panel
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);
            
            _expandedPanel = panel;
        }

        return _expandedPanel;
    };

    @Override
    public void reset(SourceSpectraTextFile nmc)
    {
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the datasets
        XYPlot plot = (XYPlot) _chartViewer.getChart().getPlot();
        for (int i=0; i<100; i++)
            plot.setDataset(i, null);
        double[] m = nmc.getMoments();
        for (int i=0; i<m.length; i++)
        {
            SourceSpectraDataset dataset = new SourceSpectraDataset();
            dataset.setSourceSpectra(nmc,  new Magnitude(m[m.length-i-1]));
            plot.setDataset(i, dataset);            
        }

        //  Update the table
        _tableModel.setSourceSpectra(nmc);
    }

    private JButton createAddMomentButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Add Moment");
        button.setMargin(new Insets(0, 0, 0, 0));
        button.setBorder(null);
        button.setContentAreaFilled(false);

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                String value = JOptionPane.showInputDialog(SourceSpectraTextFileViewer.this, "Moment log(nt-m) :");
                if (value == null)
                    return;

                double frequency = Double.parseDouble(value);
                _nmc.setAmplitude(_nmc.getMoments()[0], frequency, 0);
                refresh();
            }
        });

        return button;
    }
}
