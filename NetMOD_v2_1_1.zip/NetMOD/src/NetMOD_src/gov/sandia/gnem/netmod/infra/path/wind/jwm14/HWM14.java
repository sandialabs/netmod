/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 * 
 * Notice: This computer software was prepared by Sandia Corporation, 
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are 
 * reserved by DOE on behalf of the United States Government and the 
 * Contractor as provided in the Contract. You are authorized to use this 
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE 
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY 
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import java.util.Arrays;

/**
 * Container used for HWM information that is variable between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class HWM14
{
	// Global store for quasi-static model space parameters
	// These will change internally depending on the input parameters
	private int priornb = 0;

	private double[] fs0;
	private double[] fs1;
	private double[] fm0;
	private double[] fm1;
	private double[] fl0;
	private double[] fl1;
	private double[] bz;

	private double[] zwght;
	private int lev = 0;

	// Miscellaneous flags and indicies
	private int cseason = 0;
	private int cwave = 0;
	private int ctide = 0;

	private boolean[] content = { true, true, true, true, true }; // Season/Waves/Tides
	private boolean[] component = { true, true }; // Compute zonal/meridional
    public double[] previous = new double[]{ -1.0, -1.0, -1.0, -1.0, -1.0 };

	// Member classes
	public ALF alf;
	public DWM07b dwm;
	
	//  Internal array used in simulation
	private double[] dw = new double[2];
	
	//  Internay array used in vertwght
	private double[] vertwght_we = new double[5];
	
	//  Internal array used in bspline
	private double[] bspline_N = null;

	//  Internal arrays used in hwmqt
	private final double[] input = new double[5];
	private final boolean[] refresh = new boolean[5];
	private double[] hwmqt_sin = null;

	public HWM14()
	{
		HWM14_Data hwm14_data = HWM14_Data.getInstance();

		// Initialize remaining member variables
		fs0 = new double[hwm14_data.maxs + 1];
		fs1 = new double[hwm14_data.maxs + 1];
		fm0 = new double[hwm14_data.maxm + 1];
		fm1 = new double[hwm14_data.maxm + 1];
		fl0 = new double[hwm14_data.maxl + 1];
		fl1 = new double[hwm14_data.maxl + 1];
		bz = new double[hwm14_data.nbf];
		zwght = new double[hwm14_data.p + 1];

		dwm = new DWM07b();
		alf = new ALF();
	}

	private double bspline(int p, int m, double[] V, int i, double u)
	{
		if ( bspline_N == null || bspline_N.length != p+2 )
			bspline_N = new double[p + 2];

		double Vleft, Vright;
		double saved, temp;

		if ((i == 0) && (u == V[0]))
			return 1.0;

		if ((i == m - p - 1) && (u == V[m]))
			return 1.0;

		if ((u < V[i]) || (u >= V[i + p + 1]))
			return 0.0;

		for (int j = 0; j <= p; j++)
		{
			if ((u >= V[i + j]) && (u < V[i + j + 1]))
				bspline_N[j] = 1.0;
			else
				bspline_N[j] = 0.0;
		}

		for (int k = 1; k <= p; k++)
		{
			if (bspline_N[0] == 0.0)
				saved = 0.0;
			else
				saved = ((u - V[i]) * bspline_N[0]) / (V[i + k] - V[i]);

			for (int j = 0; j <= p - k; j++)
			{
				Vleft = V[i + j + 1];
				Vright = V[i + j + k + 1];

				if (bspline_N[j + 1] == 0.0)
				{
					bspline_N[j] = saved;
					saved = 0.0;
				}
				else
				{
					temp = bspline_N[j + 1] / (Vright - Vleft);
					bspline_N[j] = saved + (Vright - u) * temp;
					saved = (u - Vleft) * temp;
				}
			}
		}

		return bspline_N[0];
	}

	private static int findspan(int n, int p, double u, double[] V)
	{
		int low, mid, high;

		if (u >= V[n + 1])
		{
			return n;
		}

		low = p;
		high = n + 1;
		mid = (low + high) / 2;

		while (u < V[mid] || u >= V[mid + 1])
		{
			if (u < V[mid])
			{
				high = mid;
			}
			else
			{
				low = mid;
			}
			mid = (low + high) / 2;

		}

		return mid;
	}

	public double[] getGzwght()
	{
		return zwght;
	}

	public void simulation(int iyd, double sec, double alt, double glat, double glon, double stl, double f107a, double f107, double[] ap, double[] w)
	        throws Exception
	{
		hwmqt(iyd, sec, alt, glat, glon, stl, f107a, f107, ap, w);

		if (ap[1] >= 0.0)
		{
			dwm.dwm07(iyd, sec, alt, glat, glon, ap, dw, alf);
			w[0] += dw[0];
			w[1] += dw[1];
		}
	}

	/**
	 * Updates the vertical basis functions of the quiet-time model.
	 * 
	 * @throws Exception
	 */
	private int vertwght(double alt, double[] wght)
	{
		HWM14_Data hwm14_data = HWM14_Data.getInstance();

		final double H = 60.0;

		int iz = findspan(hwm14_data.nnode - hwm14_data.p - 1, hwm14_data.p, alt, hwm14_data.vnode) - hwm14_data.p;
		iz = Math.min(iz, 26);

		wght[0] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz, alt);
		wght[1] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 1, alt);
		if (iz <= 25)
		{
			wght[2] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 2, alt);
			wght[3] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 3, alt);
			return iz;
		}
		else
		{
			if (alt > hwm14_data.alttns)
			{
				vertwght_we[0] = 0.0;
				vertwght_we[1] = 0.0;
				vertwght_we[2] = 0.0;
				vertwght_we[3] = Math.exp(-(alt - hwm14_data.alttns) / H);
				vertwght_we[4] = 1.0;
			}
			else
			{
				vertwght_we[0] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 2, alt);
				vertwght_we[1] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 3, alt);
				vertwght_we[2] = bspline(hwm14_data.p, hwm14_data.nnode, hwm14_data.vnode, iz + 4, alt);
				vertwght_we[3] = 0.0;
				vertwght_we[4] = 0.0;
			}
		}

		/*
		 * Debugging statements
		System.out.println("vertwght");
		System.out.println("alt = " + alt);
		System.out.println("iz = " + iz);
		System.out.println("we = " + Arrays.toString(we));
		 */
		wght[2] = mathutil.dotProduct(vertwght_we, hwm14_data.e1);
		wght[3] = mathutil.dotProduct(vertwght_we, hwm14_data.e2);
		
		return iz;
	}
	
	/**
	 * Computes the quiet-time model terms, updating only the terms that have
	 * not changed since the last call. Applies the model parameters to the
	 * terms to get the winds.
	 */
	private void hwmqt(int iyd, double sec, double alt, double glat, double glon, double stl, double f107a, double f107, double[] ap, double[] w)
	{
		HWM14_Data hwm14_data = HWM14_Data.getInstance();

		/*
		 * Debugging statements
		System.out.println("");
		System.out.println("");
		System.out.println("");
		System.out.println("");
		System.out.println("hwmqt");
		System.out.println("iyd = " + iyd);
		System.out.println("sec = " + sec);
		System.out.println("alt = " + alt);
		System.out.println("glat = " + glat);
		System.out.println("glon = " + glon);
		System.out.println("stl = " + stl);
		*/

		// Local Variables
		double u, v;

		double cs, ss, cm, sm, cl, sl;
		double cmcs, smcs, cmss, smss;
		double clcs, slcs, clss, slss;
		double AA, BB, CC;
		double vb, wb;
		double theta, sc;
		double sccs, scss;

		int c, d;

		int amaxs, amaxn;
		int pmaxm, pmaxs, pmaxn;
		int tmaxl, tmaxs, tmaxn;
		
		input[0] = (iyd % 1000);
		input[1] = sec;
		input[2] = glon;
		input[3] = glat;
		input[4] = alt;
		Arrays.fill(refresh, false);
		double twoPi = 2.0 * Math.PI;
		double deg2rad = twoPi / 360.0;

		//System.out.println("previous = " + Arrays.toString(previous));
		//System.out.println("input = " + Arrays.toString(input));
		
		// Seasonal Variations
		if (input[0] != previous[0])
		{
			AA = input[0] * twoPi / 365.25;

			for (int s = 0; s <= hwm14_data.maxs; s++)
			{
				BB = s * AA;
				fs0[s] = Math.cos(BB);
				fs1[s] = Math.sin(BB);
			}
			Arrays.fill(refresh, true);
			previous[0] = input[0];
		}

		// Hourly time changes, tidal variations
		if ((input[1] != previous[1]) || (input[2] != previous[2]))
		{
			AA = (input[1] / 3600.0 + input[2] / 15.0 + 48.0) % (24.0);
			BB = AA * twoPi / 24.0;
			for (int l = 0; l <= hwm14_data.maxl; l++)
			{
				CC = l * BB;
				fl0[l] = Math.cos(CC);
				fl1[l] = Math.sin(CC);
			}
			refresh[2] = true;
			previous[1] = input[1];
		}

		// Longitudinal variations, planetary waves
		if (input[2] != previous[2])
		{
			AA = input[2] * deg2rad;
			for (int m = 0; m <= hwm14_data.maxm; m++)
			{
				BB = m * AA;
				fm0[m] = Math.cos(BB);
				fm1[m] = Math.sin(BB);
			}
			refresh[1] = true;
			previous[2] = input[2];
		}

		// Latitude
		theta = (90.0 - input[3]) * deg2rad;
		if (input[3] != alf.glatalf)
		{
			AA = (90.0 - input[3]) * deg2rad; // theta = colatitude in radians
			alf.ALFBasisGBar(AA);
			Arrays.fill(refresh, 0, 4, true);
			alf.glatalf = input[3];
			previous[3] = input[3];
		}

		// Altitude
		if (input[4] != previous[4])
		{
			lev = vertwght(input[4], zwght);
			previous[4] = input[4];
		}
		
		//System.out.println("refresh = " + Arrays.toString(refresh));
		//System.out.println("zwght = " + Arrays.toString(zwght));

		// Calculate the VSH functions
		u = 0.0f;
		v = 0.0f;

		for (int b = 0; b <= hwm14_data.p; b++)
		{
			//System.out.println("b = " + b);
			
			if (zwght[b] == 0.0)
				continue;

			d = b + lev;

			if (priornb != hwm14_data.nb[d])
				Arrays.fill(refresh, true);
			priornb = hwm14_data.nb[d];

			if (!(refresh[0] || refresh[1] || refresh[2] || refresh[3] || refresh[4]))
			{
				c = hwm14_data.nb[d];
				if (component[0])
					u += zwght[b] * mathutil.dot_product(bz, hwm14_data.mparm[d], c);
				if (component[1])
					v += zwght[b] * mathutil.dot_product(bz, hwm14_data.tparm[d], c);
				continue;
			}

			int[] order = hwm14_data.order[d];

			amaxs = order[0];
			amaxn = order[1];
			pmaxm = order[2];
			pmaxs = order[3];
			pmaxn = order[4];
			tmaxl = order[5];
			tmaxs = order[6];
			tmaxn = order[7];

			c = 0; // value of 0 because java indicies start at 0

			/*************************************************************
			 * Seasonal - Zonal average (m = 0)
			 *************************************************************/
			if (refresh[0] && content[0])
			{
				//  Pre-compute the sine terms
				if ( hwmqt_sin == null || hwmqt_sin.length != amaxn+1)
					hwmqt_sin = new double[amaxn+1];

				for (int n = 1; n <= amaxn; n++)
				{
					hwmqt_sin[n] = Math.sin(n*theta);
					
					bz[c++] = -hwmqt_sin[n];
					bz[c++] = hwmqt_sin[n];
				}

				for (int s = 1; s <= amaxs; s++)
				{
					cs = fs0[s];
					ss = fs1[s];
					
					for (int n = 1; n <= amaxn; n++)
					{
						sc = hwmqt_sin[n];//Math.sin(n * theta);
						
						sccs = sc * cs;
						scss = sc * ss;

						bz[c++] = -sccs;// sc * cs;
						bz[c++] = scss;//sc * ss;
						bz[c++] = sccs;//sc * cs;
						bz[c++] = -scss;//sc * ss;
					}
				}
				cseason = c;
				//System.out.println("Seasonal bz = " + Arrays.toString(bz));
			}
			else
			{
				c = cseason;
			}

			/*************************************************************
			 * Stationary Planetary Waves
			 *************************************************************/
			if (refresh[1] && content[1])
			{
				for (int m = 1; m <= pmaxm; m++)
				{
					double[] gvbar_m = alf.gvbar[m];
					double[] gwbar_m = alf.gwbar[m];
					
					cm = fm0[m] * hwm14_data.wavefactor[m];
					sm = fm1[m] * hwm14_data.wavefactor[m];

					for (int n = m; n <= pmaxn; n++)
					{
						vb = gvbar_m[n];
						wb = gwbar_m[n];

						bz[c++] = -vb * cm;
						bz[c++] = vb * sm;
						bz[c++] = -wb * sm;
						bz[c++] = -wb * cm;
					}

					for (int s = 1; s <= pmaxs; s++)
					{
						cs = fs0[s];
						ss = fs1[s];
						
						cmcs = cm * cs;
						smcs = sm * cs;
						cmss = cm * ss;
						smss = sm * ss;

						for (int n = m; n <= pmaxn; n++)
						{
							vb = gvbar_m[n];
							wb = gwbar_m[n];

							bz[c++] = -vb * cmcs;//cm * cs;
							bz[c++] = vb * smcs;//sm * cs;
							bz[c++] = -wb * smcs;//sm * cs;
							bz[c++] = -wb * cmcs;//cm * cs;
							bz[c++] = -vb * cmss;//cm * ss;
							bz[c++] = vb * smss;//sm * ss;
							bz[c++] = -wb * smss;//sm * ss;
							bz[c++] = -wb * cmss;//cm * ss;
						}
					}
					cwave = c;
				}
				//System.out.println("Stationary bz = " + Arrays.toString(bz));
			}
			else
			{
				c = cwave;
			}

			/*************************************************************
			 * Migrating Solar Tides
			 *************************************************************/
			if (refresh[2] && content[2])
			{
				for (int l = 1; l <= tmaxl; l++)
				{
					double[] gvbar_l = alf.gvbar[l];
					double[] gwbar_l = alf.gwbar[l];
					
					cl = fl0[l] * hwm14_data.tidefactor[l];
					sl = fl1[l] * hwm14_data.tidefactor[l];

					for (int n = l; n <= tmaxn; n++)
					{
						vb = gvbar_l[n];
						wb = gwbar_l[n];

						bz[c++] = -vb * cl;
						bz[c++] = vb * sl;
						bz[c++] = -wb * sl;
						bz[c++] = -wb * cl;
					}

					for (int s = 1; s <= tmaxs; s++)
					{
						cs = fs0[s];
						ss = fs1[s];
						
						clcs = cl * cs;
						slcs = sl * cs;
						clss = cl * ss;
						slss = sl * ss;

						for (int n = l; n <= tmaxn; n++)
						{
							vb = gvbar_l[n];
							wb = gwbar_l[n];

							bz[c++] = -vb * clcs;//cl * cs;
							bz[c++] = vb * slcs;//sl * cs;
							bz[c++] = -wb * slcs;//sl * cs;
							bz[c++] = -wb * clcs;//cl * cs;
							bz[c++] = -vb * clss;//cl * ss;
							bz[c++] = vb * slss;//sl * ss;
							bz[c++] = -wb * slss;//sl * ss;
							bz[c++] = -wb * clss;//cl * ss;
						}
					}
					ctide = c;
				}
				//System.out.println("Solar Tide bz = " + Arrays.toString(bz));
			}
			else
			{
				c = ctide;
			}

			/*************************************************************
			 * Non-Migrating Solar Tides
			 *************************************************************/
			// TBD

			/*************************************************************
			 * Calculate the wind components
			 *************************************************************/

			/*
			 * Debugging statements
			System.out.println("Total Wind bz = " + Arrays.toString(bz));
			System.out.println("Total Wind mparm = " + Arrays.toString(hwm14_data.mparm[d]));
			System.out.println("Total Wind tparm = " + Arrays.toString(hwm14_data.tparm[d]));
			System.out.println("c = " + c);
			System.out.println("Zwght = " + zwght[b]);
			*/
			
			if (component[0])
				u += zwght[b] * mathutil.dot_product(bz, hwm14_data.mparm[d], c);
			if (component[1])
				v += zwght[b] * mathutil.dot_product(bz, hwm14_data.tparm[d], c);
		}

		w[0] = v;
		w[1] = u;
	}

}
