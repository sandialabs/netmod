/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import gov.sandia.gnem.netmod.io.IOUtility;

/**
 * Container used for HWM information that is static between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class HWM14_Data
{
    // Member Variables from module HWM
    public int nmaxhwm = 0; // maximum degree hwmqt
    public int omaxhwm = 0; // maximum order hwmqt
    public int nmaxdwm = 0; // maximum degree hwmqt
    public int mmaxdwm = 0; // maximum order hwmqt
    public int nmaxqdc = 0; // maximum degree of coordinate coversion
    public int mmaxqdc = 0; // maximum order of coordinate coversion
    public int nmaxgeo = 0; // maximum of nmaxhwm, nmaxqd
    public int mmaxgeo = 0; // maximum of omaxhwm, nmaxqd
    
    //  Member variables from module QWM
    public int nbf;              // Count of basis terms per model level
    public int maxn;             // latitude
    public int maxs,maxm,maxl;   // seasonal,stationary,migrating
    public int maxo;

    public int p;                // B-splines order, p=4 cubic, p=3 quadratic
    public int nlev;             // e.g. Number of B-spline nodes
    public int nnode;            // nlev + p

    public double alttns;           // Transition 1
    public double altsym;           // Transition 2
    public double altiso;           // Constant Limit
    public double[] e1 = new double[5];
    public double[] e2 = new double[5];
    public double H = 60.0;

    public int[] nb;            // total number of basis functions @ level
    public int[][] order;         // spectral content @ level
    public double[] vnode;      // Vertical Altitude Nodes
    public double[][] mparm;      // Model Parameters
    public double[][] tparm;      // Model Parameters

    public String qwmdefault = "/gov/sandia/gnem/netmod/infra/path/wind/hwm14/hwm123114.bin";

    public double[] wavefactor = new double[]{ 1.0, 1.0, 1.0, 1.0 };
    public double[] tidefactor = new double[]{ 1.0, 1.0, 1.0, 1.0 };
    

    private static HWM14_Data _instance = null;

    final public static HWM14_Data getInstance()
    {
        if (_instance == null)
            _instance = new HWM14_Data();

        return _instance;
    }

    private HWM14_Data()
    {
    	initqwm(qwmdefault);
    }
    
    private void initqwm(String filename)
    {
        int ncomp;
        InputStream in = null;
        DataInputStream data = null;

        try
        {
        	//  Note:  This file is stored as a fortran stream which does not
        	//  include the standard fortran start/stop bytes around each record
            in = HWM14_Data.class.getResourceAsStream(filename);
            data = new DataInputStream(in);
            
            nbf = FortranDataReader.readInt(data);
            maxs = FortranDataReader.readInt(data);
            maxm = FortranDataReader.readInt(data);
            maxl = FortranDataReader.readInt(data);
            maxn = FortranDataReader.readInt(data);
            ncomp = FortranDataReader.readInt(data);
            nlev = FortranDataReader.readInt(data);
            p = FortranDataReader.readInt(data);

            nnode = nlev + p;
            
            // Initialize some variables
            nb = new int[nnode + 1];
            order = new int[nnode + 1][ncomp];
            vnode = new double[nnode + 1];

            FortranDataReader.readDoubleArray(data,  vnode, 0, vnode.length);
            vnode[2] = 0.0;
            
            mparm = new double[nlev + 1][nbf];
            
            for (int i=0; i<=nlev-p+1-2; i++)
            {
            	FortranDataReader.readIntArray(data, order[i], 0, ncomp);
            	nb[i] = FortranDataReader.readInt(data);
            	FortranDataReader.readDoubleArray(data, mparm[i], 0, nbf);
            }
            
            //  Read e1, e2
            FortranDataReader.readDoubleArray(data, e1, 0, e1.length);
            FortranDataReader.readDoubleArray(data, e2, 0, e2.length);

            /*
             * Debugging statements
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("initqwm");
            System.out.println("nbf = " + nbf);
            System.out.println("maxs = " + maxs);
            System.out.println("maxm = " + maxm);
            System.out.println("maxl = " + maxl);
            System.out.println("maxn = " + maxn);
            System.out.println("ncomp = " + ncomp);
            System.out.println("nlev = " + nlev);
            System.out.println("p = " + p);
            System.out.println("nnode = " + nnode);
            System.out.println("vnode = " + Arrays.toString(vnode));
            System.out.println("order = " );
            for (int i=0; i<=nlev-p+1-2; i++)
            	System.out.println(Arrays.toString(order[i]));
            System.out.println("nb = " + Arrays.toString(nb));
            System.out.println("mparm before parity = " );
            for (int i=0; i<=nlev-p+1-2; i++)
            	System.out.println(Arrays.toString(mparm[i]));
            
            System.out.println("e1 = " + Arrays.toString(e1));
            System.out.println("e2 = " + Arrays.toString(e2));
            */
            
            //  Calculate the parity relationship permutations
            tparm = new double[nlev + 1][nbf];
            for (int i=0; i<=nlev-p+1-2; i++)
            	parity(order[i], nb[i], mparm[i], tparm[i]);

            // Set transition levels

            alttns = vnode[nlev-2];
            altsym = vnode[nlev-1];
            altiso = vnode[nlev];

            /*
             * Debugging statements
            System.out.println("mparm after parity = " );
            for (int i=0; i<=nlev-p+1-2; i++)
            	System.out.println(Arrays.toString(mparm[i]));
            System.out.println("tparm = " );
            for (int i=0; i<=nlev-p+1-2; i++)
            	System.out.println(Arrays.toString(tparm[i]));
            System.out.println("alttns = " + alttns);
            System.out.println("altsym = " + altsym);
            System.out.println("altiso = " + altiso);
             */

            // Allocate the global store of quasi-static parameters

            maxo = Math.max(maxs,Math.max(maxm,maxl));
            omaxhwm = maxo;
            nmaxhwm = maxn;
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
        	if ( data != null )
        		IOUtility.safeClose(data);
        	if ( in != null )
        		IOUtility.safeClose(in);
        }
    }
    
    private static void parity(int[] order, int nb, double[] mparm, double[] tparm)
    {
        int amaxs, amaxn;
        int pmaxm, pmaxs, pmaxn;
        int tmaxl, tmaxs, tmaxn;
        int c;

        amaxs = order[0];
        amaxn = order[1];
        pmaxm = order[2];
        pmaxs = order[3];
        pmaxn = order[4];
        tmaxl = order[5];
        tmaxs = order[6];
        tmaxn = order[7];

        //  Not c=1 due to indexing difference between fortran and java
        c = 0;
        
        for (int n = 1; n <= amaxn; n++)
        {
            tparm[c] = 0.0;
            tparm[c + 1] = -mparm[c+1];
            mparm[c + 1] = 0.0;
            c += 2;
        }
        for (int s = 1; s <= amaxs; s++)
        {
            for (int n = 1; n <= amaxn; n++)
            {
                tparm[c] = 0.0;
                tparm[c+1] = 0.0;
                tparm[c+2] = -mparm[c+2];
                tparm[c+3] = -mparm[c+3];
                mparm[c+2] = 0.0;
                mparm[c+3] = 0.0;
                c += 4;
            }
        }
        
        for (int m = 1; m <= pmaxm; m++)
        {
            for (int n = m; n <= pmaxn; n++)
            {
                tparm[c] = mparm[c+2];
                tparm[c+1] = mparm[c+3];
                tparm[c+2] = -mparm[c];
                tparm[c+3] = -mparm[c+1];
                c += 4;
            }

            for (int s = 1; s <= pmaxs; s++)
            {
                for (int n = m; n <= pmaxn; n++)
                {
                    tparm[c] = mparm[c+2];
                    tparm[c+1] = mparm[c+3];
                    tparm[c+2] = -mparm[c];
                    tparm[c+3] = -mparm[c+1];
                    tparm[c+4] = mparm[c+6];
                    tparm[c+5] = mparm[c+7];
                    tparm[c+6] = -mparm[c+4];
                    tparm[c+7] = -mparm[c+5];
                    c += 8;
                }
            }
        }

        for (int l = 1; l <= tmaxl; l++)
        {
            for (int n = l; n <= tmaxn; n++)
            {
                tparm[c] = mparm[c+2];
                tparm[c+1] = mparm[c+3];
                tparm[c+2] = -mparm[c];
                tparm[c+3] = -mparm[c+1];
                c += 4;
            }
            for (int s = 1; s <= tmaxs; s++)
            {
                for (int n = l; n <= tmaxn; n++)
                {
                    tparm[c] = mparm[c+2];
                    tparm[c+1] = mparm[c+3];
                    tparm[c+2] = -mparm[c];
                    tparm[c+3] = -mparm[c+1];
                    tparm[c+4] = mparm[c+6];
                    tparm[c+5] = mparm[c+7];
                    tparm[c+6] = -mparm[c+4];
                    tparm[c+7] = -mparm[c+5];
                    c += 8;
                }
            }
        }

        return;
    }
}
