/**
 * 
 */
package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.numeric.Complex;

/**
 * Container for magnitudes
 * 
 * @author bjmerch
 *
 */
public class Magnitude
{
    private double _magnitude;
    private MagnitudeType _magnitudeType;
    private double _moment;
    
    public Magnitude(double moment)
    {
        _magnitude = moment;
        _magnitudeType = null;
        _moment = moment;
    }
    
    public Magnitude(double magnitude, MagnitudeType magnitudeType, double a, double b)
    {
        _magnitude = magnitude;
        _magnitudeType = magnitudeType;
        _moment = magnitudeType.convert(magnitude, a, b);
    }
    
    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (!(o instanceof Magnitude))
            return false;

        Magnitude m = (Magnitude) o;
        
        return m._magnitude == _magnitude && 
        		m._magnitudeType == _magnitudeType && 
        		m._moment == _moment;
    }

    /**
     * @return the magnitude
     */
    public double getMagnitude()
    {
        return _magnitude;
    }

    /**
     * @return the magnitudeType
     */
    public MagnitudeType getMagnitudeType()
    {
        return _magnitudeType;
    }

    /**
     * @return the moment
     */
    public double getMoment()
    {
        return _moment;
    }
    
    @Override
    public int hashCode()
    {
        return Float.floatToIntBits((float) getMoment());
    }
    
    @Override
    public String toString()
    {
        return GUIUtility.format(getMoment());
    }
}
