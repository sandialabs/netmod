/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.infra.simulation;

import gov.sandia.gnem.netmod.detection.NetworkDetection;
import gov.sandia.gnem.netmod.detection.NetworkDetectionPlugin;
import gov.sandia.gnem.netmod.infra.path.Paths;
import gov.sandia.gnem.netmod.infra.signal.InfraSignalAmplitudePlugin;
import gov.sandia.gnem.netmod.infra.source.Sources;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.SimulTechnology;
import gov.sandia.gnem.netmod.noise.NoiseAmplitudePlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectra;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectraPlugin;
import gov.sandia.gnem.netmod.simulation.AbstractSimulation;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.simulation.SimulationMethodPlugin;
import gov.sandia.gnem.netmod.simulation.SimulationPlugin;
import gov.sandia.gnem.netmod.simulation.SimulationTypePlugin;

import java.io.File;
import java.net.URL;
import java.util.List;

/**
 * Populate a simulation with all of the infrasound specific modules.
 * 
 * @author bjmerch
 *
 */
public class InfraSimulation extends AbstractSimulation
{
    private static String _type = "Infrasound Simulation";
    static
    {
        SimulationPlugin.getPlugin().registerComponent(_type, InfraSimulation.class);
    }
    
    public InfraSimulation(NetModComponent parent)
    {
        super(parent, _type, SimulationMethodPlugin.getPlugin(), SimulationTypePlugin.getPlugin(), InfraSignalAmplitudePlugin.getPlugin(),
                NoiseAmplitudePlugin.getPlugin(), NetworkDetectionPlugin.getPlugin());

        //  Override the default source and path objects
        _sources = new Sources(this, getPhases());
        _paths = new Paths(this, getPhases());
        _receivers = new Receivers(this, getPhases());
        
        //  Initialize default network detection rules
        NetworkDetection detection = getNetworkDetection();
        detection.getDetectionRules().put("2I", "I/2");
        detection.setDetectionRule("2I");
        
        initializeNoiseModels();
    }
    
    @Override
    public List<? extends MagnitudeType> getMagnitudeTypes()
    {
        return InfraMagnitudeType.getValuesList();
    }

    @Override
    public Paths getPaths()
    {
        return (Paths) _paths;
    }

    @Override
    public List<? extends Phase> getPhases()
    {
        return InfraPhase.getValuesList();
    }

    @Override
    public Sources getSources()
    {
        return (Sources) _sources;
    }

    @Override
    public String getTechnology()
    {
        return SimulTechnology.INFRA.toString();
    }

    @Override
    public boolean isFor(Object o)
    {
        NetSimParameters nsp = getNSP(o);

        //  If no valid object, return false
        if (nsp == null)
            return false;

        //  Verify that this is a hydro detection simulation
        if (nsp.isDefined(NetSimParameters.simulTechnology) && nsp.get(NetSimParameters.simulTechnology) == SimulTechnology.INFRA)
            return true;

        return false;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        //  Verify that this is a hydro simulation
        if (parameters.get(NetSimParameters.simulTechnology) != SimulTechnology.INFRA)
            return;

        super.load(parameters);
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(NetSimParameters.simulTechnology, SimulTechnology.INFRA);
    }

    /**
     * Initialize the noise models used for comparing against individiual site noises
     */
    private void initializeNoiseModels()
    {
        List<NoiseSpectra> noiseModels = NoiseSpectraPlugin.getNoiseModels(getTechnology());
        noiseModels.clear();
        
        //  Register the infrasound noise models
        {
            URL url = getClass().getResource("/gov/sandia/gnem/netmod/infra/simulation/bowman95.noi");
            File file = IOUtility.writeTmpFile(url, "bowman95.noi");
            NoiseSpectra noiseModel = NoiseSpectraPlugin.getPlugin().getComponentFor(null, file);
            if ( noiseModel != null )
            {
            	noiseModel.setFilename(file.getPath());
            	noiseModel.getFrequencies();
            	noiseModel.setName("Bowman 95%");

            	noiseModels.add(noiseModel);
            }
        }
        
        {
            URL url = getClass().getResource("/gov/sandia/gnem/netmod/infra/simulation/bowman50.noi");
            File file = IOUtility.writeTmpFile(url, "bowman50.noi");
            NoiseSpectra noiseModel = NoiseSpectraPlugin.getPlugin().getComponentFor(null, file);
            if ( noiseModel != null )
            {
            	noiseModel.setFilename(file.getPath());
            	noiseModel.getFrequencies();
            	noiseModel.setName("Bowman Median");

            	noiseModels.add(noiseModel);
            }
        }
        
        {
            URL url = getClass().getResource("/gov/sandia/gnem/netmod/infra/simulation/bowman5.noi");
            File file = IOUtility.writeTmpFile(url, "bowman5.noi");
            NoiseSpectra noiseModel = NoiseSpectraPlugin.getPlugin().getComponentFor(null, file);
            if ( noiseModel != null )
            {
            	noiseModel.setFilename(file.getPath());
            	noiseModel.getFrequencies();
            	noiseModel.setName("Bowman 5%");

            	noiseModels.add(noiseModel);
            }
        }
    }
}
