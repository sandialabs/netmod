/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.output;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.io.File;
import java.util.*;

/**
 * Hierarchical container for organizing the output components
 * within a simulation.
 * 
 * @author bjmerch
 *
 */
public class Outputs extends AbstractNetModComponent
{
    private String _outputDir = "";
    private List<Output> _outputs = new ArrayList<Output>();

    private transient OutputsViewer _viewer = null;

    public Outputs(NetModComponent parent)
    {
        super(parent);
        setName("Outputs");
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof Output);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.addAll(getOutputs());

        return children;
    }

    /**
     * @return the outputDir
     */
    public String getOutputDir()
    {
        return _outputDir;
    }

    public List<Output> getOutputs()
    {
        //  Organize the existing outputs
        Map<String, Output> outputMap = new HashMap<String, Output>();
        for (Output output : _outputs)
            outputMap.put(output.getOutputFile(), output);

        //  Refresh the existing outputs
        TreeMap<String, Output> newOutputMap = new TreeMap<String, Output>();

        File parent = IOUtility.openFile(getOutputDir());
        if (parent.list() != null)
        {
            for (File file : parent.listFiles())
            {
                String name = stripExtension(file.getName());

                File simulGridFile = IOUtility.openFile(parent, name + Output.simulGrid);
                if (simulGridFile.exists())
                {
                    String outputName = IOUtility.openFile(parent, name).getPath();

                    Output output = outputMap.get(outputName);
                    if (output == null)
                    {
                        output = new Output(this);
                        output.setName(name);
                        output.setOutputFile(IOUtility.openFile(parent, name).getPath());
                    }

                    newOutputMap.put(outputName, output);
                }
            }
        }

        //  Get the sorted list of outputs
        _outputs = new ArrayList<Output>(newOutputMap.values());

        //  Return a copy of the list
        return _outputs;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        if (_viewer == null)
            _viewer = new OutputsViewer(this);

        return _viewer;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        _outputs.clear();

        for (NetModComponent child : children)
        {
            if (child instanceof Output)
                _outputs.add((Output) child);
        }

        clearCache();
    }

    /**
     * @param outputDir the outputDir to set
     */
    public void setOutputDir(String outputDir)
    {
        if (_outputDir.equals(outputDir))
            return;

        _outputDir = outputDir;
        clearCache();
    }

    private String stripExtension(String name)
    {
        int index = name.indexOf(".");
        if (index < 0)
            return name;

        return name.substring(0, index);
    }
}
