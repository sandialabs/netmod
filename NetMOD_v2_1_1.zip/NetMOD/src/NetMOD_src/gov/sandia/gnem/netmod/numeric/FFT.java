/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

import java.util.Arrays;

/**
 * FFT - Fast Fourier Transform
 *
 * Implements a Cooley-Tukey decimination-in-time radix-2 FFT algorithm. The
 * code explicitly pre-calculates all of the twiddle factors for each stage so
 * that look-up tables can be used in each of the transformations. This allows
 * the FFT to be applied to multiple waveform time series with a reduced
 * computational cost.
 *
 * Derived from examples provided at
 * http://www.nauticom.net/www/jdtaft/papers.htm and in Numerical Recipies.
 *
 * @author bjmerch
 */
public class FFT
{
    /**
     * Compute the next power of 2 greater than or equal to N.
     *
     * @param N
     * @return power of 2
     */
    public static int nextPow2(int N)
    {
        double pow2 = StrictMath.ceil(StrictMath.log(N) / StrictMath.log(2));

        return (int) StrictMath.pow(2, pow2);
    }

    private int _n = 0;
    private ComplexArray[] u_fft;
    private ComplexArray[] u_ifft;

    /**
     * Construct an FFT object for performing forward and reverse Fourier
     * Transforms.
     * <p>
     * The size of the FFT must be a power of 2.
     *
     * @param n
     *            The size of the FFT
     */
    public FFT(int n)
    {
        _n = nextPow2(n);

        computeTwiddles();
    }

    /**
     * Compute a 1-D FFT on a real sequence.  The FFT may be performed in place
     * if the real array has the correct length.  Returns the results
     *
     * @param data
     * @return
     */
    public ComplexArray fft(double[] data)
    {
        if ( data.length != _n )
            data = Arrays.copyOf(data, _n);

        ComplexArray c = new ComplexArray(data);
        fft(c);

        return c;
    }

    /**
     * Compute a 1-D FFT on a complex sequence. The FFT is performed in place on
     * the provided data.
     *
     * @param data
     */
    public void fft(ComplexArray data)
    {
        generic_fft(data, u_fft);
    }

    /**
     * Get the size of the FFT
     *
     * @return
     */
    public int getN()
    {
        return _n;
    }

    /**
     * Compute a 1-D inverse FFT on a complex sequence. The IFFT is performed in
     * place on the provided data.
     *
     * @param data
     */
    public void ifft(ComplexArray data)
    {
        generic_fft(data, u_ifft);

        // Scale the result by N
        data.multiply(1.0 / getN());
    }

    /**
     * Pre-compute the twiddle factors for a length n FFT
     *
     * @param n
     *            Number of elements in the FFT
     */
    private void computeTwiddles()
    {
        int i, j, j_1;

        // Compute the number of stages
        int ln = (int) (StrictMath.log((double) _n) / StrictMath.log(2) + 0.5);

        double w_r;
        double w_i;

        u_fft = new ComplexArray[ln];
        u_ifft = new ComplexArray[ln];

        // Loop over each of the stages
        for (i = 0; i < ln; i++)
        {
            // Compute the size of this stage
            int le = (int) (StrictMath.exp((i + 1) * StrictMath.log(2)) + 0.5);
            int le1 = le / 2;

            w_r = StrictMath.cos(StrictMath.PI / le1);
            w_i = StrictMath.sin(StrictMath.PI / le1);

            // Compute u_r and u_i
            u_fft[i] = new ComplexArray(le1);
            u_ifft[i] = new ComplexArray(le1);

            double[] u_i_fft = u_fft[i].getImaginary();
            double[] u_r_fft = u_fft[i].getReal();

            double[] u_i_ifft = u_ifft[i].getImaginary();
            double[] u_r_ifft = u_ifft[i].getReal();

            u_r_fft[0] = 1;
            u_i_fft[0] = 0;
            u_r_ifft[0] = 1;
            u_i_ifft[0] = 0;

            for (j = 1; j < le1; j++)
            {
                j_1 = j - 1;

                // fft
                double u_r = u_r_fft[j_1];
                double u_i = u_i_fft[j_1];

                u_r_fft[j] = w_r * u_r + w_i * u_i;
                u_i_fft[j] = w_r * u_i - w_i * u_r;

                // ifft
                u_r = u_r_ifft[j_1];
                u_i = u_i_ifft[j_1];

                u_r_ifft[j] = w_r * u_r - w_i * u_i;
                u_i_ifft[j] = w_r * u_i + w_i * u_r;
            }
        }
    }

    /**
     * Generic FFT algorithm capable of performing fft or ifft depending on
     * twiddles passed in.
     *
     * @param data
     * @param u
     */
    private final static void generic_fft(ComplexArray data, ComplexArray[] u)
    {
        //  First four variables are the most accessed
        int j, k;

        //  Remaining numeric values
        int i;
        int n = (int) StrictMath.pow(2.0, u.length);

        double[] data_r = data.getReal();
        double[] data_i = data.getImaginary();

        //  Reorder the data
        int n_1 = n - 1;
        int nv2 = n / 2;
        for (i = 0, j = 0; i < n_1; i++)
        {
            if (i < j)
            {
                //  Swap the real portion
                double tmp = data_r[i];
                data_r[i] = data_r[j];
                data_r[j] = tmp;

                //  Swap the imaginary portion
                tmp = data_i[i];
                data_i[i] = data_i[j];
                data_i[j] = tmp;
            }
            k = nv2;
            while (k <= j)
            {
                j = j - k;
                k = k >> 1;
            }
            j += k;
        }

        // loops through stages
        int n_stages = u.length;
        for (int l = 0; l < n_stages; l++)
        {
            double[] u_r_l = u[l].getReal();
            double[] u_i_l = u[l].getImaginary();

            int le1 = u_r_l.length;
            int le = le1 * 2;

            // loops through 1/2 twiddle values per stage
            for (i = 0; i < le1; i++)
            {
                double u_r_l_i = u_r_l[i];
                double u_i_l_i = u_i_l[i];

                // loops through points per 1/2 twiddle
                for (j = i, k = i + le1; j < n; j += le, k += le)
                {
                    //  Extract the data values from the array
                    double data_r_ip = data_r[k];
                    double data_i_ip = data_i[k];

                    //  Compute the real change
                    double tmp1 = data_r_ip * u_r_l_i - data_i_ip * u_i_l_i;
                    double tmp2 = data_r[j];
                    data_r[k] = tmp2 - tmp1;
                    data_r[j] = tmp2 + tmp1;

                    //  Compute the imaginary change
                    tmp1 = data_i_ip * u_r_l_i + data_r_ip * u_i_l_i;
                    tmp2 = data_i[j];
                    data_i[k] = tmp2 - tmp1;
                    data_i[j] = tmp2 + tmp1;
                }
            }
        }
    }
}
