/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.attenuation;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ScrollPaneConstants;

import gov.sandia.gnem.netmod.geometry.Point;
import org.jfree.chart.plot.XYPlot;

import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetMODTable;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.AbstractVisibleXYDataset;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;

/**
 * @author bjmerch
 *
 */
public class AmplitudeAttenuationTextFileViewer extends NetModComponentViewer<AmplitudeAttenuationTextFile>
{
    private class AttenuationDataset extends AbstractVisibleXYDataset
    {
        int N = 100;
        Frequency _frequency;
        Point.Double _start = null;
        Point.Double _end = null;
        private AmplitudeAttenuationTextFile _attenuation = null;

        @Override
        public int getItemCount(int series)
        {
            if (!isVisible())
                return 0;

            if (series == 0)
                return (_attenuation == null ? 0 : _attenuation.getDistances().length);
            else
                return (_attenuation == null ? 0 : N * (_attenuation.getDistances().length - 1) + 1);
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return "Frequency = " + _frequency + " Hz";
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _attenuation.getDistances()[item];
            else
            {
                int index = item / N;
                double[] d = _attenuation.getDistances();

                if (index == d.length - 1)
                    return d[index];

                return Interpolation.linear(index * N, (index + 1) * N, d[index], d[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            return _attenuation.getAttenuation(_start, _end, new Distance(getX(series, item).doubleValue()), _frequency).getFrequencyValue(_frequency.getCentralFrequency());
        }

        public void setAttenuation(AmplitudeAttenuationTextFile attenuation, Frequency frequency)
        {
            _attenuation = attenuation;
            _frequency = frequency;
            fireDatasetChanged();
        }
    }

    private class AttenuationTableModel extends NetMODTableModel
    {
        private AmplitudeAttenuationTextFile _attenuation = null;
        Point.Double _start = null;
        Point.Double _end = null;

        @Override
        public int getColumnCount()
        {
            if (_attenuation == null)
                return 1;

            return _attenuation.getFrequencies().length + 1;
        }

        public String getColumnName(int column)
        {
            if (column == 0)
                return "<html>Distance<br>(degrees)</html>";
            else
                return Double.toString(_attenuation.getFrequencies()[column - 1]) + " Hz";
        }

        @Override
        public int getRowCount()
        {
            return (_attenuation == null ? 0 : _attenuation.getDistances().length) + 10;
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_attenuation == null || row >= _attenuation.getDistances().length || column > _attenuation.getFrequencies().length)
                return "";

            double d = _attenuation.getDistances()[row];

            if (column == 0)
                return d;
            else
            {
                double f = _attenuation.getFrequencies()[column - 1];
                return _attenuation.getAttenuation(_start, _end, new Distance(d), new DiscreteFrequency(f));
            }
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return true;
        }

        public void setAttenuation(AmplitudeAttenuationTextFile attenuation)
        {
            _attenuation = attenuation;
            fireTableStructureChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
            if (aValue == null || _attenuation == null)
                return;

            try
            {
                double d = 0;

                //  Set value for an existing row
                if (row < _attenuation.getDistances().length)
                    d = _attenuation.getDistances()[row];

                //  Update the column
                if (column == 0)
                {
                    //  Get the attenuations for this distance
                    double[] frequencies = _attenuation.getFrequencies();
                    double[] attenuations = new double[frequencies.length];
                    for (int i = 0; i < frequencies.length; i++)
                        attenuations[i] = _attenuation.getAttenuation(_start, _end, new Distance(d), new DiscreteFrequency(frequencies[i])).getFrequencyValue(frequencies[i]);

                    _attenuation.removeAttenuationDistance(d);
                    d = Double.parseDouble(aValue.toString());

                    for (int i = 0; i < frequencies.length; i++)
                        _attenuation.setAttenuation(d, frequencies[i], attenuations[i]);
                }
                else
                {
                    double f = _attenuation.getFrequencies()[column - 1];
                    double a = Double.parseDouble(aValue.toString());
                    _attenuation.setAttenuation(d, f, a);
                }

                fireTableDataChanged();

                //  Keep row selected
                int index = _attenuation.findIndex(_attenuation.getDistances(), d);
                _table.getSelectionModel().setSelectionInterval(index, index);
                _table.scrollRectToVisible(_table.getCellRect(index, 0, true));
            }
            catch (Exception e)
            {
            }
        }

        @Override
        public void remove(int[] rows)
        {
            for (int row : rows)
            {
                double d = _attenuation.getDistances()[row];
                _attenuation.removeAttenuationDistance(d);
            }
        }
    }

    private ChartViewer _chartViewer = new ChartViewer();
    private AttenuationTableModel _tableModel = new AttenuationTableModel();
    private NetMODTable _table = new NetMODTable(_tableModel);

    public AmplitudeAttenuationTextFileViewer(AmplitudeAttenuationTextFile nmc)
    {
        super(nmc, false, false, false);

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Update the viewer
        reset(nmc);
    }

    @Override
    public void apply(AmplitudeAttenuationTextFile nmc)
    {
    };

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Configure the chart viewer
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Epicentral Distance (degrees)");
            plot.getRangeAxis().setLabel("B(delta) log(m^-1)");

            //  Setup the table
            _table.addKeyListener(new KeyAdapter()
            {
                public void keyReleased(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                    {
                        // Get selected rows
                        int[] rows = _table.getSelectedRows();

                        double[] distances = _nmc.getDistances();
                        for (int i = 0; i < rows.length; i++)
                            _nmc.removeAttenuationDistance(distances[rows[i]]);

                        reset(_nmc);
                    }
                }
            });

            JScrollPane sp = new JScrollPane(_table);
            sp.setCorner(ScrollPaneConstants.UPPER_RIGHT_CORNER, createAddFrequencyButton());
            sp.getVerticalScrollBar().setPreferredSize(new Dimension(Math.max(20, Icons.ADD.getIcon().getIconWidth()), 0));

            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.CENTER, sp);
            spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            spPanel.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(spPanel);

            //  Setup the panel
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    };

    @Override
    public void reset(AmplitudeAttenuationTextFile nmc)
    {
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the datasets
        XYPlot plot = (XYPlot) _chartViewer.getChart().getPlot();
        for (int i = 0; i < 100; i++)
            plot.setDataset(i, null);
        double[] f = nmc.getFrequencies();
        for (int i = 0; i < f.length; i++)
        {
            AttenuationDataset dataset = new AttenuationDataset();
            dataset.setAttenuation(nmc, new DiscreteFrequency(f[i]));
            plot.setDataset(i, dataset);
        }

        //  Update the table
        _tableModel.setAttenuation(nmc);
    }

    private JButton createAddFrequencyButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Add Frequency");
        button.setMargin(new Insets(0, 0, 0, 0));
        button.setBorder(null);
        button.setContentAreaFilled(false);

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                String value = JOptionPane.showInputDialog(AmplitudeAttenuationTextFileViewer.this, "Frequency (Hz) :");
                if (value == null)
                    return;

                double frequency = Double.parseDouble(value);
                _nmc.setAttenuation(_nmc.getDistances()[0], frequency, 0);
                refresh();
            }
        });

        return button;
    }
}
