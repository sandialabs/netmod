/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.hydro.signal;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.cursors.ObjectCursor;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.hydro.io.HydroDetectionParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.media.PathMediaType;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * Extend signal amplitudes for hydro acoustics that require
 * that all signal amplitudes are computed regionally.
 * Any path that intersects a blocked media type
 * is completely attenuated
 * 
 * @author bjmerch
 *
 */
public class HydroBlockedSignalAmplitude extends HydroAttenuatedSignalAmplitude
{
    public static final String TYPE = "NetSim";
    static
    {
        HydroSignalAmplitudePlugin.getPlugin().registerComponent(TYPE, HydroBlockedSignalAmplitude.class);
    }

    private String _blockage = "blocked";

    public HydroBlockedSignalAmplitude(NetModComponent parent)
    {
        super(parent, TYPE, "Blocked Hydroacoustic Signal Amplitude ");
    }

    /**
     * @return the blockage
     */
    public String getBlockage()
    {
        return _blockage;
    }

    /**
     * @param blockage the blockage to set
     */
    public void setBlockage(String blockage)
    {
        _blockage = blockage;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new HydroBlockedSignalAmplitudeViewer(this);
    }

    @Override
    public Spectra getPathAttenuation(Sources sources, Paths paths, Point.Double epicenter, Station station, Distance distance, Phase phase, Frequency frequency, boolean minor)
    {
        //  Get the path media type that is blocked
        PathMediaType blockage = paths.getPathMedia().getMediaType(getBlockage());
        
        startIntrospection();
        recordIntrospection("Checking great circle path: ", (minor ? "Minor" : "Major") );

        //  Check if the path intersects that media type
        ObjectDoubleMap<PathMediaType> mediaWeights = paths.getPathMedia().getMediaWeights(distance, minor);
        if (mediaWeights.get(blockage) > 0)
        {
            if (isIntrospection())
            {
                recordIntrospection("Path blocked");
                for (ObjectCursor<PathMediaType> entry : mediaWeights.keys())
                {
                    PathMediaType pathMediaType = entry.value;
                    if (pathMediaType == null)
                        continue;

                    double bin_weight = mediaWeights.get(pathMediaType);
                    if (bin_weight <= 0)
                        continue;

                    startIntrospection();
                    recordIntrospection("Path MediaType: ", pathMediaType);
                    recordIntrospection("Bin Weight: ", bin_weight);
                    stopIntrospection();
                }
                stopIntrospection();
            }
            
            return SpectraPDF.NEGATIVE_999;
        }

        //  Otherwise, revert to the normal path-weighted attenuation
        Spectra attenuation = super.getPathAttenuation(sources, paths, epicenter, station, distance, phase, frequency, minor);
        recordIntrospection("Path attenuation: ", attenuation);

        stopIntrospection();

        return attenuation;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setBlockage(parameters.get(HydroDetectionParameters.pathModelBlockage));
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(HydroDetectionParameters.pathModelBlockage, getBlockage());
    }
}
