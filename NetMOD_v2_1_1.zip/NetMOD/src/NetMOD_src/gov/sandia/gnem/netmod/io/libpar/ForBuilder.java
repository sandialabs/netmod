/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io.libpar;

import gov.sandia.gnem.netmod.io.libpar.ParLoader.ParException;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * A class for building and executing loops.
 *   This means the {@code iterator} ({@link #setIterationVar(String)})
 * will take one the values of the {@code iterables} ({@link #setIterables(String)}) one by one.  For each
 * value that the {@code iterator} takes on each String of the {@code body}
 *  ({@link #addBodyStatement(String)})
 * will have all instances of {@code "$(<iterator>)"} replaced with the current iteration value and
 * then {@literal "executed"} in terms of a .par file.
 */
public class ForBuilder
{

    private static final Object DQ_MARK = new Object();

    private String iterator;
    private String[] iterables;
    private List<String> body;

    /**
     * Creates a ForBuilder instance with no iterator, iterables, or body.
     */
    public ForBuilder()
    {
        iterator = null;
        iterables = null;
        body = new ArrayList<String>();
    }

    /**
     * Adds a statement to be executed during the loop.
     * @param line - The statement to add.
     */
    public void addBodyStatement(String line)
    {
        body.add(line);
    }

    /**
     * Executes the loop.  This means the {@code iterator} ({@link #setIterationVar(String)})
     * will take one the values of the {@code iterables} ({@link #setIterables(String)}) one by one.  For each
     * value that the {@code iterator} takes on each String of the {@code body}
     *  ({@link #addBodyStatement(String)})
     * will have all instances of {@code "$(<iterator>)"} replaced with the current iteration value and
     * then {@literal "executed"} in terms of a .par file.
     * @param p - The Parameters instance to store into and resolve with.
     * @param location - The file in which this par data is coming from.
     * @throws ParException If a syntax exception occurs.
     * @throws IOException If an IOException occurs.
     * @throws IllegalStateException If an {@code iterator} has not been set yet.
     * @throws IllegalStateException If {@code iterables} have not been set yet.
     */
    public void executeLoop(LibParParameters p, File location) throws ParException, IOException
    {
        if (iterator == null)
            throw new IllegalStateException("No iterator name set.");
        if (iterables == null)
            throw new IllegalStateException("No iterables set.");
        if ((iterables.length == 1 && iterables[0].equals("")) || iterables.length == 0)
            return;
        for (String val : iterables)
        {
            List<String> currBody = mapReplaceAll(iterator, val, body);
            for (int index = 0; index < currBody.size(); index++)
            {
                String line = currBody.get(index);
                if (line.startsWith(ParLoader.TABLE_BEGIN))
                {
                    index = handleTable(currBody, index, line, p, location);
                }
                else if (line.startsWith(ParLoader.FOR_BEGIN))
                {
                    index = handleFor(currBody, index, line, p, location);
                }
                else
                    ParLoader.handleKeyValue(p, line, location);
            }
        }
    }

    /**
     * Sets the values in which the iterator will take on in the loop.  Also defines how many
     * iterations will occur when the loop is executed.  The given String should contain one or more
     * values in a comma delimited list.  Trailing and leading whitespace is ignored on each element.
     * The number of iterations is equal to the number of elements in the list.
     * @param values - The values of loop iterations.
     * @throws NullPointerException If {@code values} is {@code null}.
     */
    public void setIterables(String values)
    {
        if (values == null)
            throw new NullPointerException();
        iterables = values.split(ParTable.DELIM);
    }

    /**
     * Sets the name of the variable that will take on the values of the iterables.
     * For example, if this is set to {@code var}, then all instances of {@code $(var)}
     * in the body of the loop will be replaced with the value for the current loop iteration.
     * @param it - The name of the variable to use in the loop.
     * @throws NullPointerException If {@code it} is {@code null}.
     */
    public void setIterationVar(String it)
    {
        if (it == null)
            throw new NullPointerException();
        iterator = it;
    }

    private int getForEnd(List<String> currBody, int start, String line)
    {
        Deque<Object> nested = new LinkedList<Object>();
        List<String> subList = currBody.subList(start, currBody.size());
        int end = -1;
        int index = 0;
        Iterator<String> it = subList.iterator();
        while (it.hasNext())
        {
            String temp = it.next();
            if (temp.startsWith(ParLoader.FOR_BEGIN))
                nested.push(DQ_MARK);
            if (temp.startsWith(ParLoader.FOR_END))
            {
                nested.pop();
                if (nested.isEmpty())
                {
                    end = index;
                    break;
                }
            }
            index++;
        }
        return end + start;
    }

    private int getNextString(List<String> ls, int start, String toFind)
    {
        int end = start;
        while (!ls.get(end).startsWith(ParLoader.FOR_END))
        {
            end++;
            if (ls.size() <= end)
            {
                return -1;
            }
        }
        return end;
    }

    private int handleFor(List<String> currBody, int start, String line, LibParParameters p, File location) throws ParException, IOException
    {
        int end = getForEnd(currBody, start, line);
        if (end == -1)
            throw new ParException("No end to for loop found");
        end++;//Since subList is not inclusive on the end.
        //Make the reader pointing to the start of the loop, not the whole body.
        List<String> sub = currBody.subList(start + 1, end);
        BufferedReader br = makeReaderFromList(sub);
        ParLoader.handleFor(br, line, p, location);
        return end;
    }

    private int handleTable(List<String> currBody, int start, String line, LibParParameters p, File location) throws ParException, IOException
    {
        //Search till the end is found
        int end = getNextString(currBody, start, ParLoader.TABLE_END);
        if (end == -1)
            throw new ParException("No end to table found");
        end++;//Since subList is not inclusive on the end.
        //Make the reader pointing to the start of the table, not the whole body.
        BufferedReader br = makeReaderFromList(currBody.subList(start + 1, end));
        ParLoader.handleTable(br, line, p, location);
        return end;
    }

    private BufferedReader makeReaderFromList(List<String> ls)
    {
        return new BufferedReader(new ListReader(ls, true));
    }

    private List<String> mapReplaceAll(String iterator, String value, List<String> ls)
    {
        List<String> ret = new LinkedList<String>();
        for (String s : ls)
            ret.add(s.replace(ParLoader.EVAL_ID + iterator + ParLoader.EVAL_END, value));

        return ret;
    }

}
