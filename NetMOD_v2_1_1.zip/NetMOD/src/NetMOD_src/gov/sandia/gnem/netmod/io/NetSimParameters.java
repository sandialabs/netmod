/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import gov.sandia.gnem.netmod.detection.StationDetection.FrequencyType;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.io.libpar.ParLoader;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.simulation.Simulation;

import java.io.File;
import java.util.*;

/**
 * Collection of NetSIM style parameters
 * 
 * @author bjmerch
 *
 */
public class NetSimParameters extends AbstractNetModComponent
{
    
    /**
     * Parameter definition
     * 
     * @author bjmerch
     *
     * @param <O>
     */
    public static class ParameterDef<O extends Object> implements Comparable<ParameterDef<O>>
    {
        /**
         *  Maintain a static set of the parameter definitions.  This allows
         *  sub-classes to extend AbstractNetSimParameters and to maintain
         *  the set of parameters that are to be loaded.
         */
        private static Set<ParameterDef<Object>> _parameterDefinitionSet = new TreeSet<ParameterDef<Object>>();
        
        private ParameterFolder _folder;
        private String _name;
        private O _value;
        private O[] _values;

        /**
         * Construct a new parameter definition with the
         * provided name and default value
         * 
         * @param name parameter name
         * @param value default value
         */
        public ParameterDef(ParameterFolder folder, String name, O value)
        {
            this(folder, name, value, null);
        }

        public ParameterDef(ParameterFolder folder, String name, O value, O[] values)
        {
            _folder = folder;
            _name = name;
            _value = value;
            _values = values;

            //  Register this definition
            _parameterDefinitionSet.add((ParameterDef<Object>) this);
        }

        /**
         * @return the value
         */
        public O getDefaultValue()
        {
            return _value;
        }
        
        /**
         * @return the folder
         */
        public ParameterFolder getFolder()
        {
            return _folder;
        }

        /**
         * @return the name
         */
        public String getName()
        {
            return _name;
        }

        /**
         * @return
         */
        public Object[] getValues()
        {
            return _values;
        }
        
        @Override
        public int compareTo(ParameterDef<O> p)
        {
            return getName().compareTo(p.getName());
        }
        
        @Override
        public String toString()
        {
            return getName();
        }
    }

    /*
     * Enumerations of variables
     */
    public static enum RunType
    {
        DETECTION, LOCATION
    }

    public static enum SimulTechnology
    {
        SEISMIC, HYDRO, INFRA
    }

    public static enum SizeType
    {
        KT("KT"), MB("mb"), MS("Ms"), MBLG("mlg"), ML("ML"), MOMENT("ML"), MW("Mw"), PA("Pa");

        private String _name = "";

        SizeType(String name)
        {
            _name = name;
        }

        public String getName()
        {
            return _name;
        }
    };

    public static enum SubType
    {
        THRESHOLD, PROBABILITY
    };

    public static enum WindMode
    {
        NONE("No wind"), STA("Station Location"), SOURCE("Source Location"), SOURCE_STA("Source and Station Location Average"), PATH("Path Average");
        
        private String _name = "";

        WindMode(String name)
        {
            _name = name;
        }

        public String getName()
        {
            return _name;
        }
    };

    public static enum ExplosionType
    {
        CHEMICAL, NUCLEAR
    };

    private static String _type = "NetSim Parameters";
    
    /**
     * Parameter controlling the hierarchy of the parameters
     * 
     * @author bjmerch
     *
     */
    public static class ParameterFolder 
    {
        private static Set<ParameterFolder> _folders = new HashSet<ParameterFolder>();
        
        public static final ParameterFolder GENERAL = new ParameterFolder("", "");
        public static final ParameterFolder SOURCE = new ParameterFolder("source", "source.par");
        public static final ParameterFolder PATH = new ParameterFolder("path", "path.par");
        public static final ParameterFolder RECEIVER = new ParameterFolder("receiver", "receiver.par");
        
        private String _folder;
        private String _parfile;
        
        /**
         * Create a new parameter folder with the provided folder and parfile names
         * 
         * @param folder
         * @param parfile
         */
        public ParameterFolder(String folder, String parfile)
        {
            _folder = folder;
            _parfile = parfile;
            
            //  Register this folder
            _folders.add(this);
        }
        
        public String getFolder()
        {
            return _folder;
        }
        
        public String getParfile()
        {
            return _parfile;
        }

        /**
         * @return
         */
        public static Set<ParameterFolder> values()
        {
            return _folders;
        }
        
        @Override
        public boolean equals(Object o)
        {
        	if ( o == null )
        		return false;
        	
            if ( !(o instanceof ParameterFolder) )
                return false;
            
            ParameterFolder pf = (ParameterFolder) o;
            
            return getFolder().equals(pf.getFolder()) && getParfile().equals(pf.getParfile());
        }
        
        @Override
        public int hashCode()
        {
        	return _folder.hashCode();
        }
    };

    /*
     * NetSIM Control parameters
     */
    public final static ParameterDef<String> title = new ParameterDef<String>(ParameterFolder.GENERAL, "title", "Detection");
    public final static ParameterDef<String> outputDir = new ParameterDef<String>(ParameterFolder.GENERAL, "Output-Dir", "");
    public final static ParameterDef<RunType> runType = new ParameterDef<RunType>(ParameterFolder.GENERAL, "Run-Type", RunType.DETECTION, RunType.values());
    public final static ParameterDef<SubType> subType = new ParameterDef<SubType>(ParameterFolder.GENERAL, "Sub-Type", SubType.THRESHOLD, SubType.values());
    public final static ParameterDef<SimulTechnology> simulTechnology = new ParameterDef<SimulTechnology>(ParameterFolder.GENERAL, "Simul-Technology", SimulTechnology.SEISMIC,
            SimulTechnology.values());
    public final static ParameterDef<String> simulBaseline = new ParameterDef<String>(ParameterFolder.GENERAL, "Simul-Baseline", "");
    public final static ParameterDef<String> eventDetectionCriteria = new ParameterDef<String>(ParameterFolder.GENERAL, "Event-Detection-Criteria", "");
    public final static ParameterDef<String> EDCConversionFile = new ParameterDef<String>(ParameterFolder.GENERAL, "EDC-Conversion-File", "");
    public final static ParameterDef<SizeType> sizeType = new ParameterDef<SizeType>(ParameterFolder.GENERAL, "Size-Type", SizeType.MB, SizeType.values());
    public final static ParameterDef<Double> eventSize = new ParameterDef<Double>(ParameterFolder.GENERAL, "Event-Size", 3.0);
    public final static ParameterDef<Double> minEventSize = new ParameterDef<Double>(ParameterFolder.GENERAL, "Min-Event-Size", 0.0);
    public final static ParameterDef<Double> maxEventSize = new ParameterDef<Double>(ParameterFolder.GENERAL, "Max-Event-Size", 5.0);
    public final static ParameterDef<Double> conf = new ParameterDef<Double>(ParameterFolder.GENERAL, "conf", 0.9);
    public final static ParameterDef<Double> lowProbCutoff = new ParameterDef<Double>(ParameterFolder.GENERAL, "Low-Prob-Cutoff", 0.2);
    public final static ParameterDef<Double> regionalXoverDistance = new ParameterDef<Double>(ParameterFolder.GENERAL, "Regional-Xover-Distance", 20.0);
    public final static ParameterDef<Double> regionalBlendingDistance = new ParameterDef<Double>(ParameterFolder.GENERAL, "Regional-Blending-Distance", 2.0);
    public final static ParameterDef<Integer> numMonteCarloIter = new ParameterDef<Integer>(ParameterFolder.GENERAL, "Num-MonteCarlo-Iter", 1);
    public final static ParameterDef<Integer> monteCarloSeed = new ParameterDef<Integer>(ParameterFolder.GENERAL, "MonteCarlo-Seed", -1);
    public final static ParameterDef<Double> pctLo = new ParameterDef<Double>(ParameterFolder.GENERAL, "Pct-Lo", 0.5);
    public final static ParameterDef<Double> pctHi = new ParameterDef<Double>(ParameterFolder.GENERAL, "Pct-Hi", 0.9);
    public final static ParameterDef<Boolean> depthFixed = new ParameterDef<Boolean>(ParameterFolder.GENERAL, "Depth-Fixed", true);
    //public final static ParameterDef<Double> eventDepth = new ParameterDef<Double>(ParameterFolder.GENERAL, "Event-Depth", 0.0);
    public final static ParameterDef<String> freqSampling = new ParameterDef<String>(ParameterFolder.GENERAL, "Freq-Sampling", "1.0");
    public final static ParameterDef<Integer> verboseLevel = new ParameterDef<Integer>(ParameterFolder.GENERAL, "Verbose-Level", 0);
    public final static ParameterDef<ExplosionType> explosionType = new ParameterDef<ExplosionType>(ParameterFolder.GENERAL, "Explosion-Type", ExplosionType.CHEMICAL, ExplosionType.values());
    public final static ParameterDef<WindMode> windMode = new ParameterDef<WindMode>(ParameterFolder.GENERAL, "Wind-Mode", WindMode.NONE, WindMode.values());
    public final static ParameterDef<String> windModel = new ParameterDef<String>(ParameterFolder.GENERAL, "Wind-Model", "HWM");
    public final static ParameterDef<Integer> windDayOfYear = new ParameterDef<Integer>(ParameterFolder.GENERAL, "Wind-Day-Of-Year", -1); //  Day of year, 1-366
    public final static ParameterDef<Integer> windTimeOfDay = new ParameterDef<Integer>(ParameterFolder.GENERAL, "Wind-Time-Of-Day", -1); //  Hour of Day, 0-23
    public final static ParameterDef<String> noiseModel = new ParameterDef<String>(ParameterFolder.GENERAL, "Noise-Model", "");

    /*
     * NetMOD parameter extensions
     */
    public final static ParameterDef<String> signalAmplitude = new ParameterDef<String>(ParameterFolder.GENERAL, "Signal-Amplitude", "NetSim");
    public final static ParameterDef<String> noiseAmplitude = new ParameterDef<String>(ParameterFolder.GENERAL, "Noise-Amplitude", "NetSim");
    public final static ParameterDef<String> freqType = new ParameterDef<String>(ParameterFolder.GENERAL, "Freq-Type", FrequencyType.HIGH.toString());
    
    public final static String EDC_LABEL = "label";
    public final static String EDC_RULE = "rule";
    public final static ParameterDef<ParTable> edcTable = new ParameterDef<ParTable>(ParameterFolder.GENERAL, "EDC", new ParTable("EDC", Arrays.asList(
    		EDC_LABEL, EDC_RULE)));
    
    /*
     * NetSIM Control Tables 
     */
    public final static String BASELINEDESC_TECH = "tech";
    public final static String BASELINEDESC_BASELINE = "baseline";
    public final static String BASELINEDESC_NET = "net";
    public final static String BASELINEDESC_SIZETYPE = "sizetype";
    public final static String BASELINEDESC_DEFAULT = "default";
    public final static ParameterDef<ParTable> baselineDescTable = new ParameterDef<ParTable>(ParameterFolder.GENERAL, "BaselineDesc", new ParTable("BaselineDesc", Arrays.asList(
            BASELINEDESC_TECH, BASELINEDESC_BASELINE, BASELINEDESC_NET, BASELINEDESC_SIZETYPE, BASELINEDESC_DEFAULT)));

    public final static String EVENTSIZEDESC_TYPE = "type";
    public final static String EVENTSIZEDESC_SIZE = "size";
    public final static String EVENTSIZEDESC_MIN_SIMUL = "Min-Simul";
    public final static String EVENTSIZEDESC_MAX_SIMUL = "Max-Simul";
    public final static String EVENTSIZEDESC_MIN_GUI = "Min-GUI";
    public final static String EVENTSIZEDESC_MAX_GUI = "Max-GUI";
    public final static ParameterDef<ParTable> eventSizeDescTable = new ParameterDef<ParTable>(ParameterFolder.GENERAL, "EventSizeDesc", new ParTable("EventSizeDesc", Arrays.asList(
            EVENTSIZEDESC_TYPE, EVENTSIZEDESC_SIZE, EVENTSIZEDESC_MIN_SIMUL, EVENTSIZEDESC_MAX_SIMUL, EVENTSIZEDESC_MIN_GUI, EVENTSIZEDESC_MAX_GUI)));

    /*
     * NetSIM Source Parameters
     */
    public final static ParameterDef<String> epiModel = new ParameterDef<String>(ParameterFolder.SOURCE, "Epi-Model", "");
    public final static ParameterDef<String> sourceMediaDescFile = new ParameterDef<String>(ParameterFolder.SOURCE, "Source-Media-Desc-File", "");
    public final static ParameterDef<String> sourceGridFile = new ParameterDef<String>(ParameterFolder.SOURCE, "Source-Grid-File", "");

    /*
     * NetSIM Source TABLES
     */
    public final static String EPISOURCE_REGION = "Region";
    public final static String EPISOURCE_MIN_LAT = "Min_Lat";
    public final static String EPISOURCE_MAX_LAT = "Max_Lat";
    public final static String EPISOURCE_MIN_LON = "Min_Lon";
    public final static String EPISOURCE_MAX_LON = "Max_Lon";
    public final static String EPISOURCE_DEL_LAT = "Del_Lat";
    public final static String EPISOURCE_DEL_LON = "Del_Lon";
    public final static String EPISOURCE_DEPTH = "Depth";
    public final static String NETMOD_EPISOURCE_REGULAR = "Regular";
    public final static ParameterDef<ParTable> epiSource = new ParameterDef<ParTable>(ParameterFolder.SOURCE, "EpiSource", new ParTable("EpiSource", Arrays.asList(EPISOURCE_REGION,
            EPISOURCE_MIN_LAT, EPISOURCE_MAX_LAT, EPISOURCE_MIN_LON, EPISOURCE_MAX_LON, EPISOURCE_DEL_LAT, EPISOURCE_DEL_LON, NETMOD_EPISOURCE_REGULAR, EPISOURCE_DEPTH)));
    
    /*
     * NetSIM Propagation Parameters
     */
    public final static ParameterDef<String> pathMediaDescFile = new ParameterDef<String>(ParameterFolder.PATH, "Path-Media-Desc-File", "");
    public final static ParameterDef<String> pathGridFile = new ParameterDef<String>(ParameterFolder.PATH, "Path-Grid-File", "");
    public final static ParameterDef<String> windModelFile = new ParameterDef<String>(ParameterFolder.PATH, "Wind-Model-File", "");

    /*
     * NetSIM Propagation Tables 
     */
    public final static String PHASESPEC_PHASE = "phase";
    public final static String PHASESPEC_TECH = "tech";
    public final static String PHASESPEC_TIME_W = "TimeW";
    public final static String PHASESPEC_GVEL1 = "GVel1";
    public final static String PHASESPEC_GVEL2 = "GVel2";
    public final static String PHASESPEC_LOG_AMP_CORR = "LogAmpCorr";
    public final static String PHASESPEC_LOG_AMP_CORR_SD = "LogAmpCorrSD";
    public final static String PHASESPEC_SNR_THRESH = "SnrThresh";
    public final static String PHASESPEC_DELTIM = "deltim";
    public final static String PHASESPEC_DELAZ = "delaz";
    public final static String PHASESPEC_VELOCITY = "velocity";
    public final static String PHASESPEC_BEAM = "beam";
    public final static String PHASESPEC_PREV_PHASE = "PrevPhase";
    public final static String PHASESPEC_NF_FILE = "NF_file";
    public final static String PHASESPEC_TT_ME_FILE = "TT_ME_file";
    public final static ParameterDef<ParTable> phaseSpec = new ParameterDef<ParTable>(ParameterFolder.PATH, "PhaseSpec", new ParTable("PhaseSpec", Arrays.asList(PHASESPEC_PHASE,
            PHASESPEC_TECH, PHASESPEC_TIME_W, PHASESPEC_GVEL1, PHASESPEC_GVEL2, PHASESPEC_LOG_AMP_CORR, PHASESPEC_LOG_AMP_CORR_SD, PHASESPEC_SNR_THRESH,
            PHASESPEC_DELTIM, PHASESPEC_DELAZ, PHASESPEC_VELOCITY, PHASESPEC_BEAM, PHASESPEC_PREV_PHASE, PHASESPEC_NF_FILE, PHASESPEC_TT_ME_FILE)));

    public final static String STAPHASESPEC_STA = "sta";
    public final static String STAPHASESPEC_PHASE = "phase";
    public final static String STAPHASESPEC_LOG_AMP_CORR = "LogAmpCorr";
    public final static String STAPHASESPEC_LOG_AMP_CORR_SD = "LogAmpCorrSD";
    public final static String STAPHASESPEC_SNR_THRESH = "SnrThresh";
    public final static String STAPHASESPEC_DELTIM = "deltim";
    public final static String STAPHASESPEC_DELAZ = "delaz";
    public final static String STAPHASESPEC_VELOCITY = "velocity";
    public final static String STAPHASESPEC_RESPONSE = "response";
    public final static String STAPHASESPEC_ATTENUATION = "attenuation";
    public final static ParameterDef<ParTable> staPhaseSpec = new ParameterDef<ParTable>(ParameterFolder.RECEIVER, "StaPhaseSpec", new ParTable("StaPhaseSpec", Arrays.asList(
            STAPHASESPEC_STA, STAPHASESPEC_PHASE, STAPHASESPEC_LOG_AMP_CORR, STAPHASESPEC_LOG_AMP_CORR_SD, STAPHASESPEC_SNR_THRESH, STAPHASESPEC_DELTIM,
            STAPHASESPEC_DELAZ, STAPHASESPEC_VELOCITY, STAPHASESPEC_RESPONSE, STAPHASESPEC_ATTENUATION)));

    /*
     * NetSIM Receiver Parameters 
     */
    public final static ParameterDef<String> net = new ParameterDef<String>(ParameterFolder.RECEIVER, "net", "");
    public final static ParameterDef<String> listOfStations = new ParameterDef<String>(ParameterFolder.RECEIVER, "list-of-stations", "");

    /*
     * NetSIM Receiver Tables 
     */
    public final static String STANET_NET = "net";
    public final static String STANET_LIST_OF_NETWORK_STATIONS = "list-of-network-stations";
    public final static ParameterDef<ParTable> staNet = new ParameterDef<ParTable>(ParameterFolder.RECEIVER, "StaNet", new ParTable("StaNet", Arrays.asList(STANET_NET,
            STANET_LIST_OF_NETWORK_STATIONS)));

    public final static ParameterDef<Double> defaultStationDensity = new ParameterDef<Double>(ParameterFolder.RECEIVER, "default-station-density", 2500.0);
    public final static ParameterDef<Double> defaultStationRely = new ParameterDef<Double>(ParameterFolder.RECEIVER, "default-station-rely", 0.98);
    public final static ParameterDef<Double> defaultStationElev = new ParameterDef<Double>(ParameterFolder.RECEIVER, "default-station-elev", 0.0);
    public final static ParameterDef<String> defaultResponseModel = new ParameterDef<String>(ParameterFolder.RECEIVER, "default-RspModel", "");

    public final static String STASPEC_STA = "sta";
    public final static String STASPEC_GROUP = "group";
    public final static String STASPEC_LAT = "lat";
    public final static String STASPEC_LON = "lon";
    public final static String STASPEC_ELEV = "elev";
    public final static String STASPEC_TECH = "tech";
    public final static String STASPEC_STATYPE = "statype";
    public final static String STASPEC_NCHAN = "nchan";
    public final static String STASPEC_RELY = "rely";
    public final static String STASPEC_DENSITY = "density";
    public final static ParameterDef<ParTable> staSpec = new ParameterDef<ParTable>(ParameterFolder.RECEIVER, "StaSpec", new ParTable("StaSpec", Arrays.asList(STASPEC_STA, STASPEC_GROUP, STASPEC_LAT,
            STASPEC_LON, STASPEC_ELEV, STASPEC_TECH, STASPEC_STATYPE, STASPEC_NCHAN, STASPEC_RELY, STASPEC_DENSITY)));

    public final static String RSPSPEC_RSP_MODEL = "RspModel";
    public final static String RSPSPEC_STATYPE = "statype";
    public final static String RSPSPEC_NCHAN = "nchan";
    public final static String RSPSPEC_BEAM = "beam";
    public final static String RSPSPEC_RSP_FILE = "file";
    public final static ParameterDef<ParTable> rspSpec = new ParameterDef<ParTable>(ParameterFolder.RECEIVER, "RspSpec", new ParTable("RspSpec", Arrays.asList(RSPSPEC_RSP_MODEL,
            RSPSPEC_STATYPE, RSPSPEC_NCHAN, RSPSPEC_BEAM, RSPSPEC_RSP_FILE)));

    public final static String NOISESPEC_STA = "sta";
    public final static String NOISESPEC_LOG_NOISE_SD = "logNoiseSD";
    public final static String NOISESPEC_SURG_TYPE = "surg_type";
    public final static String NOISESPEC_DISPLAY_NAME = "display_name";
    public final static String NOISESPEC_NOISE_FILE = "file";
    public final static ParameterDef<ParTable> noiseSpec = new ParameterDef<ParTable>(ParameterFolder.RECEIVER, "NoiseSpec", new ParTable("NoiseSpec", Arrays.asList(NOISESPEC_STA,
            NOISESPEC_LOG_NOISE_SD, NOISESPEC_SURG_TYPE, NOISESPEC_DISPLAY_NAME, NOISESPEC_NOISE_FILE)));

    public final static ParameterDef<Boolean> forceLinearPlot = new ParameterDef<Boolean>(ParameterFolder.GENERAL, "force-linear-plot", false, new Boolean[] { Boolean.TRUE,
            Boolean.FALSE });
    public final static ParameterDef<Boolean> forceLogPlot = new ParameterDef<Boolean>(ParameterFolder.GENERAL, "force-linear-plot", false,
            new Boolean[] { Boolean.TRUE, Boolean.FALSE });
    public final static ParameterDef<Double> fixedScaleMin = new ParameterDef<Double>(ParameterFolder.GENERAL, "fixed-scale-min", Double.NEGATIVE_INFINITY);
    public final static ParameterDef<Double> fixedScaleMax = new ParameterDef<Double>(ParameterFolder.GENERAL, "fixed-scale-max", Double.POSITIVE_INFINITY);
    public final static ParameterDef<Double> fixedDiffScaleMin = new ParameterDef<Double>(ParameterFolder.GENERAL, "fixed-diff-scale-min", Double.NEGATIVE_INFINITY);
    public final static ParameterDef<Double> fixedDiffScaleMax = new ParameterDef<Double>(ParameterFolder.GENERAL, "fixed-diff-scale-max", Double.POSITIVE_INFINITY);
    public final static ParameterDef<Boolean> reverseColorOrder = new ParameterDef<Boolean>(ParameterFolder.GENERAL, "reverse-color-order", false, new Boolean[] { Boolean.TRUE,
            Boolean.FALSE });
    public final static ParameterDef<Double> globalCenterLon = new ParameterDef<Double>(ParameterFolder.GENERAL, "global-center-lon", 0.0);

    /*
     * NetSIM GUI Tables
     */
    public final static String NOISESITES_DISPLAY_NAME = "display_name";
    public final static String NOISESITES_STA = "sta";
    public final static ParameterDef<ParTable> noiseSites = new ParameterDef<ParTable>(ParameterFolder.GENERAL, "NoiseSites", new ParTable("NoiseSites", Arrays.asList(
            NOISESITES_DISPLAY_NAME, NOISESITES_STA)));
    public final static String WINDORDINALDAY_TIMEOFYEAR = "time-of-year";
    public final static String WINDORDINALDAY_DAY = "day";
    public final static ParameterDef<ParTable> windOrdinalDay = new ParameterDef<ParTable>(ParameterFolder.GENERAL, "Wind_Ordinal_Day", new ParTable("Wind_Ordinal_Day", Arrays.asList(
            WINDORDINALDAY_TIMEOFYEAR, WINDORDINALDAY_DAY)));

    //  Maintain a list of the parameters for ease of access
    private Map<ParameterDef<Object>, Object> _parameters = new HashMap<ParameterDef<Object>, Object>();

    private String _ns_config = null; 
    private LibParParameters _libParParameters = null;

    public NetSimParameters()
    {
        super(null, _type);
        
        //  Create a default LibParParameters
        _libParParameters = new LibParParameters();
    }

    public NetSimParameters(LibParParameters parameters)
    {
        super(null, _type);

        read(parameters);
    }
    
    public Collection<ParameterDef<Object>> getParameters()
    {
    	return _parameters.keySet();
    }

    /**
     * Get the value of the provided parameter
     * 
     * @param p
     * @return
     */
    public <O extends Object> O get(ParameterDef<O> p)
    {
        O value = (O) _parameters.get(p);

        if (value == null)
        {
            value = p.getDefaultValue();
            
            //  Create a new table seeded from the default
            if ( value instanceof ParTable )
            {
                ParTable defaultTable = (ParTable) value;
                ParTable table = new ParTable(defaultTable.getName(), _libParParameters, defaultTable.getColumnNames());
                
                value = (O) table;
            }
            
            _parameters.put((ParameterDef<Object>) p, value);
        }

        return value;
    }

    /**
     * Check whether the provided parameter is defined
     * 
     * @param p
     * @return
     */
    public <O extends Object> boolean isDefined(ParameterDef<O> p)
    {
        return _parameters.get(p) != null;
    }

    /**
     * @param simulation
     */
    public void load(Simulation simulation)
    {

    }

    /**
     * Read the control parameters from the provided
     * parameters object
     * 
     * @param parameters
     * @return
     */
    public boolean read(LibParParameters parameters)
    {
        _libParParameters = parameters;

        for (ParameterDef<Object> p : ParameterDef._parameterDefinitionSet)
        {
            //  Check for a par table
            if (p.getDefaultValue() instanceof ParTable)
            {
                set(p, parameters.getTable(p.getName()));
            }
            //  Check for an intrinsic type, not an enumeration
            else if (p.getValues() == null)
            {
                set(p, parameters.getAsWithDefault(p.getName(), p.getDefaultValue().getClass(), p.getDefaultValue()));
            }
            // Scan the enumeration to find a match
            else
            {
                String str = parameters.get(p.getName());
                for (Object o : p.getValues())
                    if (o.toString().equalsIgnoreCase(str))
                    {
                        set(p, o);
                        break;
                    }
            }
        }

        return true;
    }

    public boolean read(File file)
    {
        //  Determine the object type
        LibParParameters parameters = new LibParParameters();
        parameters.set("NS_CONFIG", file.getParent());
        try
        {
            parameters = ParLoader.load(file, parameters);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }

        //  If no valid object, return false
        if (parameters == null)
            return false;

        //  Load the parameters
        read(parameters);

        //  Verify that this is a seismic detection simulation
        if (isDefined(simulTechnology) && get(simulTechnology) == SimulTechnology.SEISMIC && isDefined(runType) && get(runType) == RunType.DETECTION)
            return true;

        return false;
    }

    /**
     * Set the value of the provided parameter
     * 
     * @param p
     * @param value
     */
    public <O extends Object> void set(ParameterDef<O> p, O value)
    {
        _parameters.put((ParameterDef<Object>) p, (Object) value);
    }

    /**
     * Read the control parameters from the provided
     * parameters object.  Only write the parameters that go in the designated folder.
     * 
     * @param folder 
     * @param parameters
     * @return
     */
    public boolean write(ParameterFolder folder, LibParParameters parameters)
    {
        for (ParameterDef<Object> p : _parameters.keySet())
        {
            if ( p.getFolder() != folder )
                continue;
            
            Object value = _parameters.get(p);

            if (p.getDefaultValue() instanceof ParTable)
                parameters.addTable((ParTable) value);
            else
                parameters.set(p.getName(), (value == null ? "" : value.toString()));
        }

        return true;

    }

    /**
     * @param string
     * @return
     */
    public String getLibPar(String string)
    {
        if ( _libParParameters == null )
            return "";
        
        return _libParParameters.get(string);
    }

    /**
     * @return
     */
    public String getNS_CONFIG()
    {
        //  If not override, get from libpar
        if ( _ns_config == null )
            return getLibPar("NS_CONFIG");
        
        return _ns_config;
    }

    /**
     * @param value
     */
    public void setNS_CONFIG(String value)
    {
        _ns_config = value;
    }
}
