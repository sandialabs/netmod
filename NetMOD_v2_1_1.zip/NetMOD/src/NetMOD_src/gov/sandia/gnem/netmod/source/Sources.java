/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import gov.sandia.gnem.netmod.source.media.*;

import java.io.File;
import java.util.*;

/**
 * Hierarchical container for organizing the source components
 * within a simulation.
 * 
 * @author bjmerch
 *
 */
public class Sources extends AbstractNetModComponent
{
    private Source _sourceType;
    private SourceMedia _sourceMedia;
    private Set<EpicenterGrid> _epicenterGrids = new TreeSet<EpicenterGrid>();
    private String _epicenterGrid = "";

    private String _sourceGridFile = "";
    private String _sourceMediaFile = "";
    
    private Collection<? extends Phase> _phases;

    public Sources(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent, "Sources");
        
        _phases = phases;
        _sourceType = SourcePlugin.getPlugin().getDefaultComponent(this);
        
        //  Setup a default epicenter grid
        setEpicenterGrid(new EpicenterGrid(this));
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof Source) || (component instanceof NetSimSourceMedia) || (component instanceof EpicenterGrid) || (component instanceof NetSimSourceMediaScaledDepth);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getSourceType());
        children.add(getSourceMedia());
        children.addAll(getEpicenterGrids());

        return children;
    }

    public EpicenterGrid getEpicenterGrid()
    {
        for (EpicenterGrid eg : _epicenterGrids)
            if (eg.getName().equals(_epicenterGrid) || _epicenterGrid == null || _epicenterGrid.isEmpty())
                return eg;

        for (EpicenterGrid eg : _epicenterGrids)
            return eg;

        return null;
    }

    /**
     * @return
     */
    public Set<EpicenterGrid> getEpicenterGrids()
    {
        return _epicenterGrids;
    }

    /**
     * @return the sourceGridFile
     */
    public String getSourceGridFile()
    {
        return _sourceGridFile;
    }

    public SourceMedia getSourceMedia()
    {
        if ( _sourceMedia == null )
        {
            _sourceMedia = SourceMediaPlugin.getPlugin().getComponentFor(this, getSourceMediaFile());
            
            if (_sourceMedia != null )
            {
            	_sourceMedia.setPhases(_phases);
            	_sourceMedia.setSourceMediaFile(getSourceMediaFile());
            	_sourceMedia.setSourceGridFile(getSourceGridFile());
            }
        }
        
        return _sourceMedia;
    }

    /**
     * @return the sourceMediaFile
     */
    public String getSourceMediaFile()
    {
        return _sourceMediaFile;
    }

    public Source getSourceType()
    {
        return _sourceType;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new SourcesViewer(this);
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);

        //  Construct the epicenter grids
        ParTable epiSourceTable = parameters.get(NetSimParameters.epiSource);
        if (epiSourceTable == null)
            return;

        Set<String> rowNames = epiSourceTable.getRowNames();
        if (epiSourceTable.getRowCount() > 0)
            getEpicenterGrids().clear();
        
        String selectedEpiModel = parameters.get(NetSimParameters.epiModel);

        for (String rowName : rowNames)
        {
            //  Get the correct type of EpicenterGrid
            EpicenterGrid eg = new EpicenterGrid(this);
            
            eg.setName(epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_REGION));
            eg.setLatitude(epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_MIN_LAT, -80),
                    epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_MAX_LAT, 80),
                    epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_DEL_LAT, 10));
            eg.setLongitude(epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_MIN_LON, -175),
                    epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_MAX_LON, 175),
                    epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_DEL_LON, 10));
            eg.setElevation(epiSourceTable.getTableValue(rowName, NetSimParameters.EPISOURCE_DEPTH, -999));
            eg.setRegular(!epiSourceTable.getTableValue(rowName, SeismicDetectionParameters.NETMOD_EPISOURCE_REGULAR).equals("false"));

            getEpicenterGrids().add(eg);

            //  Register the selected epicenter grid
            if (eg.getName().equals(selectedEpiModel))
                setEpicenterGrid(eg);
        }

        //  Construct the source media, media file followed by grid file
        setSourceMediaFile(IOUtility.openFile(IOUtility.fixPathSeparator(parameters.get(NetSimParameters.sourceMediaDescFile))).getCanonicalPath());
        setSourceGridFile(IOUtility.openFile(IOUtility.fixPathSeparator(parameters.get(NetSimParameters.sourceGridFile))).getCanonicalPath());
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);

        //  Save the epicenter grids
        ParTable epiSourceTable = parameters.get(NetSimParameters.epiSource);
        
        for (EpicenterGrid grid : getEpicenterGrids())
        {
            String row = grid.getName();
            
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_REGION, row);
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_MIN_LAT, Double.toString(grid.getLatitudeStart()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_MAX_LAT, Double.toString(grid.getLatitudeEnd()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_DEL_LAT, Double.toString(grid.getLatitudeDelta()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_MIN_LON, Double.toString(grid.getLongitudeStart()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_MAX_LON, Double.toString(grid.getLongitudeEnd()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_DEL_LON, Double.toString(grid.getLongitudeDelta()));
            epiSourceTable.setTableValue(row, SeismicDetectionParameters.NETMOD_EPISOURCE_REGULAR, Boolean.toString(grid.getRegular()));
            epiSourceTable.setTableValue(row, NetSimParameters.EPISOURCE_DEPTH, Double.toString(grid.getElevation()));
        }
        parameters.set(NetSimParameters.epiModel, getEpicenterGrid().getName());
        
        if ( files )
        {
            if ( reset )
            {
                File sourceParent = IOUtility.openFile(parameters.getNS_CONFIG(), NetSimParameters.ParameterFolder.SOURCE.getFolder());
                
                for (SourceMediaType smt : getSourceMedia().getMediaTypes())
                {
                    //  Ensure the existing file is read in
                    smt.getSourceSpectra().getFrequencies();
                    
                    String filename = IOUtility.openFile(smt.getSourceSpectraFile()).getName();
                    
                    if ( filename == null || !IOUtility.openFile(smt.getSourceSpectraFile()).exists() )
                        smt.setSourceSpectraFile("");
                    else
                        smt.setSourceSpectraFile(IOUtility.fixPathSeparator(IOUtility.openFile(sourceParent, filename).getPath()));
                }

                //  Define destination source grid and media files
                String sourceGridFilename = IOUtility.openFile(getSourceGridFile()).getName();
                if ( sourceGridFilename == null || sourceGridFilename.isEmpty())
                    sourceGridFilename = "source_grid.sgr";
                File srcGridFile = IOUtility.openFile(sourceParent, sourceGridFilename);
                
                String sourceMediaFilename = IOUtility.openFile(getSourceMediaFile()).getName();
                if ( sourceMediaFilename == null || sourceMediaFilename.isEmpty())
                    sourceMediaFilename = "source_media.smd";
                File srcMediaFile = IOUtility.openFile(sourceParent, sourceMediaFilename);
                
                //  Delete any existing files to force write
                srcGridFile.delete();
                srcMediaFile.delete();
                
                setSourceGridFile(IOUtility.fixPathSeparator(srcGridFile.getPath()));
                setSourceMediaFile(IOUtility.fixPathSeparator(srcMediaFile.getPath()));
            }
            
            getSourceMedia().write();
        }
        
        parameters.set(NetSimParameters.sourceMediaDescFile, IOUtility.fixPathSeparator(getSourceMediaFile()));
        parameters.set(NetSimParameters.sourceGridFile, IOUtility.fixPathSeparator(getSourceGridFile()));
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof Source)
                _sourceType = (Source) child;
            else if (child instanceof NetSimSourceMedia)
                _sourceMedia = (SourceMedia) child;
            else if (child instanceof NetSimSourceMediaScaledDepth)
                _sourceMedia = (SourceMedia) child;
            else if (child instanceof EpicenterGrid)
                _epicenterGrids.add((EpicenterGrid) child);
        }

        clearCache();
    }


    public void setEpicenterGrid(EpicenterGrid epicenterGrid)
    {
        if (epicenterGrid == null)
        {
            _epicenterGrid = "";
            return;
        }

        _epicenterGrid = epicenterGrid.getName();
        _epicenterGrids.add(epicenterGrid);
    }

    /**
     * @param sourceGridFile the sourceGridFile to set
     */
    public void setSourceGridFile(String sourceGridFile)
    {
        if ( _sourceGridFile.equals(sourceGridFile) )
            return;
        
        //  If file exists, load it
        if ( IOUtility.openFile(sourceGridFile).exists() )
        {
            _sourceGridFile = sourceGridFile;
            setSourceMedia(null);
        }
        //  Otherwise, save to it
        else
        {
            SourceMedia sourceMedia = getSourceMedia();
            sourceMedia.setSourceGridFile(sourceGridFile);
            _sourceGridFile = sourceMedia.getSourceGridFile();
        }
    }

    public void setSourceMedia(SourceMedia sourceMedia)
    {
        if ( sourceMedia != null )
        {
            _sourceGridFile = sourceMedia.getSourceGridFile();
            _sourceMediaFile = sourceMedia.getSourceMediaFile();
        }
        
        _sourceMedia = sourceMedia;
    }
    
    /**
     * @param sourceMediaFile the sourceMediaFile to set
     */
    public void setSourceMediaFile(String sourceMediaFile)
    {
        if ( _sourceMediaFile.equals(sourceMediaFile) )
            return;
        
        //  If file exists, load it
        if ( IOUtility.openFile(sourceMediaFile).exists() )
        {
            _sourceMediaFile = sourceMediaFile;
            setSourceMedia(null);
        }
        //  Otherwise, save to it
        else
        {
            SourceMedia sourceMedia = getSourceMedia();
            sourceMedia.setSourceMediaFile(sourceMediaFile);
            _sourceMediaFile = sourceMedia.getSourceMediaFile();
        }
    }

    public void setSourceType(Source sourceType)
    {
        _sourceType = sourceType;

        clearCache();
    }
}
