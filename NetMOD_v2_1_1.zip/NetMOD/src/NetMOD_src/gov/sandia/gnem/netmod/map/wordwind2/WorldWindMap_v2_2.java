/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.BasicFactory;
import gov.nasa.worldwind.BasicModel;
import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.avlist.AVList;
import gov.nasa.worldwind.avlist.AVListImpl;
import gov.nasa.worldwind.awt.AWTInputHandler;
import gov.nasa.worldwind.awt.AbstractViewInputHandler;
import gov.nasa.worldwind.awt.WorldWindowGLCanvas;
import gov.nasa.worldwind.awt.WorldWindowGLJPanel;
import gov.nasa.worldwind.cache.FileStore;
import gov.nasa.worldwind.data.TiledImageProducer;
import gov.nasa.worldwind.event.SelectListener;
import gov.nasa.worldwind.formats.shapefile.Shapefile;
import gov.nasa.worldwind.formats.shapefile.ShapefileRecord;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable;
import gov.nasa.worldwind.formats.worldfile.WorldFile;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.globes.EarthFlat;
import gov.nasa.worldwind.layers.LayerList;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.layers.ScalebarLayer;
import gov.nasa.worldwind.layers.SkyColorLayer;
import gov.nasa.worldwind.layers.SurfaceImageLayer;
import gov.nasa.worldwind.layers.ViewControlsLayer;
import gov.nasa.worldwind.layers.ViewControlsSelectListener;
import gov.nasa.worldwind.layers.WorldMapLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.SurfaceImage;
import gov.nasa.worldwind.util.Logging;
import gov.nasa.worldwind.util.StatusBar;
import gov.nasa.worldwind.util.WWIO;
import gov.nasa.worldwind.util.layertree.LayerTree;
import gov.nasa.worldwindx.examples.dataimport.DataInstallUtil;
import gov.nasa.worldwindx.examples.layermanager.LayerManagerPanel;
import gov.nasa.worldwindx.examples.util.HotSpotController;
import gov.nasa.worldwindx.examples.util.LayerManagerLayer;
import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.*;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.w3c.dom.Document;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author bjmerch
 *
 */
public class WorldWindMap_v2_2 extends AbstractNetModComponent implements Map
{
    /**  
     * light wrapper around the map to visualize it within a JPanel
     * and implement the NetModComponentViewer interface
     * 
     * @author bjmerch
     *
     */
    private class MapViewer extends NetModComponentViewer<WorldWindMap_v2_2>
    {
        
        MapViewer(WorldWindMap_v2_2 map)
        {
            super(map);
            setLayout(new BorderLayout());

            wwd.getView().getViewInputHandler().setEnableSmoothing(false);
            wwd.getView().getViewInputHandler().setLockHeading(true);

            //  Override the default input handler to work around a bug that prevents initial navigation over picked layers
            wwd.setInputHandler(new AWTInputHandler()
            {
                @Override
                public void mousePressed(MouseEvent mouseEvent)
                {
                    if (wwd.getView().getViewInputHandler() instanceof AbstractViewInputHandler)
                    {
                        AbstractViewInputHandler avih = (AbstractViewInputHandler) wwd.getView().getViewInputHandler();
                        if (avih.getMouseDownPoint() == null)
                            avih.setMouseDownPoint(mouseEvent.getPoint());
                    }

                    super.mousePressed(mouseEvent);
                }
            });
            
            wwd.setModel(new BasicModel(new EarthFlat(), new LayerList()));
            
            //  Default to a flat globe
            ProjectionTool.setProjection(wwd, ProjectionTool.rectangular);
            
            // Create and install the view controls layer and register a controller for it with the World Window.
            ViewControlsLayer viewControlsLayer = new ViewControlsLayer();
            wwd.getModel().getLayers().add(0,  viewControlsLayer);
            wwd.addSelectListener(new ViewControlsSelectListener(wwd, viewControlsLayer));
            
            //  Setup the map
            add((Component) wwd, BorderLayout.CENTER);
            
            //  Setup the top toolbar
            add(createToolBar(), BorderLayout.NORTH);
            
            //  Setup a status bar
            StatusBar statusBar = new StatusBar();
            statusBar.setEventSource(wwd);
            statusBar.setShowNetworkStatus(false);
            add(statusBar, BorderLayout.SOUTH);
            
            //  Load the base layers
            wwd.getModel().setLayers(baseLayers(wwd.getModel().getLayers()));
            
            //  Reset the map buttons that are enabled
            MapUtility.resetMapButtons();
        }
        
        @Override
        public void apply(WorldWindMap_v2_2 nmc)
        {}
        
        @Override
        public JPanel getExpandedPanel()
        {
            return new JPanel();
        }
        
        @Override
        public void reset(WorldWindMap_v2_2 nmc)
        {}

        /**
         * Load the base layers within the map
         */
        private LayerList baseLayers(LayerList layers)
        {
            if ( layers == null )
                layers = new LayerList();
            
            //  Add a layer manager
            NetMODLayerManagerLayer managerLayer = new NetMODLayerManagerLayer(wwd); 
            managerLayer.setPosition(AVKey.NORTHWEST);
            managerLayer.setMinOpacity(0.75);
            layers.add(managerLayer);
            
            //  Add a sky layer with the desired background color
            SkyColorLayer skyLayer = new SkyColorLayer();
            skyLayer.setName("Background");
            skyLayer.setSkyColor(Property.MAP_BACKGROUND_COLOR.getColorValue());
            skyLayer.setFadeBottomAltitude(Double.MIN_VALUE);
            skyLayer.setFadeTopAltitude(Double.MAX_VALUE);
            layers.add(skyLayer);
            
            //  Add an overview map
            WorldMapLayer overviewLayer = new WorldMapLayer();
            overviewLayer.setPosition(AVKey.NORTHEAST);
            layers.add(overviewLayer);
            
            //  Add a scale bar
            ScalebarLayer scalebarLayer = new ScalebarLayer();
            layers.add(scalebarLayer);
            
            //  Add topography layer
            try
            {
                //  Get the topography file
                File file = IOUtility.findFile(IOUtility.openFile(Property.MAP_TOPOGRAPHY.getValue()));    

                //  Load the file, if it exists
                if (file.exists())
                {
                    if ( _topo == null || !file.getPath().equals(_topo.getImageSource()) )
                    {
                        _topo = new SurfaceImage(file.getPath(), Sector.fromDegrees(-90, 90, -180, 180));
                        _topo.setValue("Filename", file);
                        _topo.setValue("Bounds", _topo.getSector());
                        
                        _topoLayer = new SurfaceImageLayer();
                        _topoLayer.setName("Topography");
                        _topoLayer.addRenderable(_topo);
                    }
                    
                    layers.add(_topoLayer);
                }
            }
            catch (Exception e)
            {
                System.out.println("Error adding topography to map..." + e.getMessage());
                e.printStackTrace();
            }

            //  Add political boundaries layer   
            try
            {
                //  Get the map boundaries
                File file = IOUtility.findFile(IOUtility.openFile(Property.MAP_BOUNDARIES.getValue()));    

                //  Load the file, if it exists
                if (file.exists())
                {
                    if (file.getPath().endsWith(".shp") || file.getPath().endsWith(".SHP"))
                    {
                        if (_boundaryPath == null || !_boundaryPath.equals(file.getPath()))
                        {
                            _boundaryPath = file.getPath();

                            //  Load shapefile and override polygon attributes
                            ShapefileRenderable.AttributeDelegate delegate = new ShapefileRenderable.AttributeDelegate()
                            {
                            	private BasicShapeAttributes _land_attributes = new BasicShapeAttributes()
                                {
                                    @Override
                                    public Material getInteriorMaterial()
                                    {
                                        return new Material(Property.MAP_BOUNDARIES_FILL_LAND_COLOR.getColorValue());
                                    }
                                    
                                    @Override
                                    public Material getOutlineMaterial()
                                    {
                                        return new Material(Property.MAP_BOUNDARIES_LINE_COLOR.getColorValue());
                                    }
                                    
                                    @Override
                                    public double getOutlineWidth()
                                    {
                                        return Property.MAP_BOUNDARIES_LINE_WIDTH.getFloatValue();
                                    }
                                    
                                    @Override
                                    public boolean isDrawInterior()
                                    {
                                        return Property.MAP_BOUNDARIES_FILL.getBooleanValue();
                                    }
                                    
                                    @Override
                                    public boolean isDrawOutline()
                                    {
                                        return Property.MAP_BOUNDARIES_LINE.getBooleanValue();
                                    }
                                    
                                };
                                private BasicShapeAttributes _ocean_attributes = new BasicShapeAttributes()
                                {
                                    @Override
                                    public Material getInteriorMaterial()
                                    {
                                        return new Material(Property.MAP_BOUNDARIES_FILL_WATER_COLOR.getColorValue());
                                    }
                                    
                                    @Override
                                    public Material getOutlineMaterial()
                                    {
                                        return new Material(Property.MAP_BOUNDARIES_LINE_COLOR.getColorValue());
                                    }
                                    
                                    @Override
                                    public double getOutlineWidth()
                                    {
                                        return Property.MAP_BOUNDARIES_LINE_WIDTH.getFloatValue();
                                    }
                                    
                                    @Override
                                    public boolean isDrawInterior()
                                    {
                                        return Property.MAP_BOUNDARIES_FILL.getBooleanValue();
                                    }
                                    
                                    @Override
                                    public boolean isDrawOutline()
                                    {
                                        return Property.MAP_BOUNDARIES_LINE.getBooleanValue();
                                    }
                                    
                                };
                            	
                                @Override
                                public void assignAttributes(ShapefileRecord shapefileRecord, ShapefileRenderable.Record renderableRecord)
                                {
                                	String colormap = "1";
                                	try
                                	{
                                		colormap = shapefileRecord.getAttributes().getStringValue("COLOR_MAP");
                                	}
                                	catch (Exception e)
                                	{}
                            	
                            	
                                	if ( colormap.equals("1") )
                                		renderableRecord.setAttributes(_land_attributes);
                                	else
                                		renderableRecord.setAttributes(_ocean_attributes);
                                }
                            };
                            
                            _boundaryLayer = ShapefileLoader.load(file, delegate);
                        }

                        layers.add(_boundaryLayer);
                    }
                }
            }
            catch (Exception e)
            {
                System.out.println("Error adding political boundaries to map..." + e.getMessage());
                e.printStackTrace();
            }
            
            return layers;
        }

        private JComponent createToolBar()
        {            
            //  Snapshot
            JButton snapshot = GUIUtility.createButton(Icons.CAMERA.getIcon());
            snapshot.setToolTipText("Save a screen shot");
            snapshot.addActionListener(new SnapshotTool(wwd));
            
            JButton copyClipboard = GUIUtility.createButton(Icons.EDIT.getIcon());
            copyClipboard.setToolTipText("Copy image to clipboard");
            copyClipboard.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                	BufferedImage result = GUIUtility.makeImage((Component) wwd, false);
                	
                    GUIUtility.copyToClipboard(result);
                }
            });            
            
            //  Open Shapefile
            JButton openFile = GUIUtility.createButton(Icons.OPEN.getIcon());
            openFile.setToolTipText("Open Shapefile");
			openFile.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent arg0)
				{
	                File[] files = GUIUtility.showOpenDialog(MapViewer.this, null, "Open Shapefile", JFileChooser.FILES_ONLY, false, null, null);
	                if ( files == null )
	                    return;
	                
	                File file = files[0];
	                
	                gov.nasa.worldwind.layers.Layer layer = ShapefileLoader.load(file);
	                wwd.getModel().getLayers().add(layer);
				}
			});            
            
            //  Open KML/KMZ
            JButton openKMLFile = GUIUtility.createButton(Icons.OPEN.getIcon());
            openKMLFile.setToolTipText("Open KML/KMZ File");
            openKMLFile.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent arg0)
				{
	                File[] files = GUIUtility.showOpenDialog(MapViewer.this, null, "Open KML/KMZ", JFileChooser.FILES_ONLY, false, null, null);
	                if ( files == null )
	                    return;
	                
	                File file = files[0];
	                
	                gov.nasa.worldwind.layers.Layer layer = KMLLayerLoader.load(file);
	                wwd.getModel().getLayers().add(layer);
				}
			});            
            
            //  Save KML/KMZ
            JButton saveKMLFile = GUIUtility.createButton(Icons.SAVE.getIcon());
            saveKMLFile.setToolTipText("Save KML/KMZ File");
            saveKMLFile.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent arg0)
				{
	                File file = GUIUtility.showSaveDialog(MapViewer.this, null, "Save KML/KMZ", JFileChooser.FILES_ONLY, null, null);
	                if ( file == null )
	                    return;
	                
//	                gov.nasa.worldwind.layers.Layer layer = KMLLayerLoader.save(file, layer);
//	                wwd.getModel().getLayers().add(layer);
				}
			});
            
            //  Projection
            JButton projection = GUIUtility.createButton(Icons.MAP.getIcon());
            projection.setToolTipText("Set map projection");
            projection.addActionListener(new ProjectionTool(wwd));
            
            //  Measure
            JToggleButton measure = GUIUtility.createToggleButton(Icons.MEASURE.getIcon());
            measure.setToolTipText("Measure distance");
            measure.addActionListener(new MeasureTool(wwd));

            JComponent toolBar = GUIUtility.createToolBar();
            toolBar.add(openFile);
            //toolBar.add(openKMLFile);
            toolBar.add(saveKMLFile);
            toolBar.add(new JToolBar.Separator());
            toolBar.add(snapshot);
            toolBar.add(copyClipboard);
            toolBar.add(new JToolBar.Separator());
            toolBar.add(projection);
            toolBar.add(measure);

            return toolBar;
        }
    }
    
    static String _type = "WorldWind 2.2";

    static
    {
    	MapPlugin.getPlugin().registerComponent(_type,  WorldWindMap_v2_2.class, true);
    }
    //  Cache topography image for faster map reloads
    private static SurfaceImage _topo = null;
    
    private static SurfaceImageLayer _topoLayer = null;
    //  Cache boundary for faster map reloads
    private static String _boundaryPath = null;
    
    private static gov.nasa.worldwind.layers.Layer _boundaryLayer = null; 
    
    private WorldWindow wwd;

    //  Cache layer references
    private Layer<EpicenterGrid> _epicenterLayer = null;
    private Layer _mediaGridLayer = null;
    private Layer<Output> _outputLayer = null;
    private Layer<Receivers> _stationLayer = null;
    private Layer<WindModel> _windModelLayer = null;
    
    /**
     * Construct and configure a WorldWind Map
     */
    public WorldWindMap_v2_2(NetModComponent parent)
    {
        super(parent, _type);
        
        //  Disable downloading data over network
        WorldWind.setOfflineMode(true);

        String weight = Property.MAP_WEIGHT.getValue();
        
        if ( weight.equalsIgnoreCase("light") )
        {
            wwd = new WorldWindowGLJPanel();
        }
        else if ( weight.equalsIgnoreCase("heavy") )
        {
            wwd = new WorldWindowGLCanvas();
        }
        else
        {
            wwd = new WorldWindowGLJPanel();
        }
        
        // Turn off logging
        Logger logger = Logger.getLogger("gov.nasa.worldwind");
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.OFF);
        
        logger = Logging.logger();
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.OFF);
    }
    
    @Override
    public void addLayer(Layer<?> layer)
    {
        if (layer instanceof gov.nasa.worldwind.layers.Layer)
        {
            LayerList layers = wwd.getModel().getLayers();
            layers.add((gov.nasa.worldwind.layers.Layer) layer);
            
            if ( layer instanceof SelectListener )
                wwd.addSelectListener((SelectListener) layer);
        }
    }
    
    @Override
    public boolean contains(Layer<?> layer)
    {
        LayerList layers = wwd.getModel().getLayers();
        return layers.contains(layer);
    }
    
    @Override
    public Layer<EpicenterGrid> createEpicenterLayer(EpicenterGrid epicenterGrid)
    {
        if ( _epicenterLayer == null )
            _epicenterLayer = new EpicenterLayer(epicenterGrid);
        
        _epicenterLayer.setNMC(epicenterGrid);

        return _epicenterLayer;
    }
    
    @Override
    public <TYPE extends NetModComponent> Layer<MediaGrid<TYPE>> createMediaGridLayer(MediaGrid<TYPE> mediaGrid)
    {
        if ( _mediaGridLayer == null )
            _mediaGridLayer = new MediaGridLayer(wwd, mediaGrid);
        
        _mediaGridLayer.setNMC(mediaGrid);
        
        return (Layer<MediaGrid<TYPE>>) _mediaGridLayer;
    }
    
    @Override
    public <TYPE extends NetModComponent> Action createMediaGridSelectionTool(MediaGrid<TYPE> mediaGrid)
    {
        return new MediaGridSelectionTool(wwd, (MediaGrid<NetModComponent>) mediaGrid);
    }
    
    @Override
    public Layer<Output> createOutputLayer(Output output)
    {
        if (_outputLayer == null )
            _outputLayer = new OutputLayer(wwd, output);
        
        _outputLayer.setNMC(output);
        
        return _outputLayer;
    }
    
    @Override
    public Layer<Receivers> createStationLayer(Receivers receivers)
    {
        if ( _stationLayer == null )
            _stationLayer = new StationLayer(receivers);
        
        _stationLayer.setNMC(receivers);
        
        return _stationLayer;
    }

    @Override
    public Action createStationSelectionTool(Receivers receivers)
    {
        return new StationSelectionTool(wwd, receivers);
    }

    @Override
    public Action createSourceSelectionTool(Sources sources)
    {
        return new SourceSelectionTool(wwd, sources);
    }
    
    @Override
    public Layer<WindModel> createWindModelLayer(WindModel windModel)
    {
        if ( _windModelLayer == null )
            _windModelLayer = new WindModelLayer(windModel);
        
        _windModelLayer.setNMC(windModel);
        
        return _windModelLayer;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new MapViewer(this);
    }
    
    
    @Override
    public void refresh()
    {
        refreshLayers(wwd.getModel().getLayers());
        wwd.redraw();
    }

    @Override
    public void remove(Layer<?> layer)
    {
        LayerList layers = wwd.getModel().getLayers();
        layers.remove(layer);
        
        //  Remove any layers that are select listeners
        if ( layer instanceof SelectListener )
            wwd.removeSelectListener((SelectListener) layer);
    }

    private void refreshLayers(LayerList layers)
    {
        int N =  layers.size();
        for (int i=0; i<N; i++)
        {
            gov.nasa.worldwind.layers.Layer layer = layers.get(i);

            if ( layer instanceof LayerList )
            {
                refreshLayers((LayerList) layer);
            }
            else if ( layer instanceof gov.sandia.gnem.netmod.map.Layer )
            {
                ((gov.sandia.gnem.netmod.map.Layer) layer).setNMC(((gov.sandia.gnem.netmod.map.Layer) layer).getNMC());
            }
        }
    }
}

