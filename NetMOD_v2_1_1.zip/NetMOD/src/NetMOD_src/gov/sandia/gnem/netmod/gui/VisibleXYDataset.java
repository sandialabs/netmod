/**
 * 
 */
package gov.sandia.gnem.netmod.gui;

import org.jfree.data.xy.XYDataset;

/**
 * @author bjmerch
 *
 */
public interface VisibleXYDataset extends XYDataset
{

    
    /**
     * Get the visibility
     * 
     * @return
     */
    public boolean isVisible();
    
    /**
     * Set the visibility
     * 
     * @param visible
     */
    public void setVisible(boolean visible);
}
