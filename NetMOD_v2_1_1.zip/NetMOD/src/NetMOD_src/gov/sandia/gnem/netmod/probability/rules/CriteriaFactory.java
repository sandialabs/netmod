/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Factory for parsing a criteria string into a criteria object
 * 
 * @author bjmerch
 *
 */
public class CriteriaFactory
{
    //  Populate the regular expression used to split detection criteria
    private static String split_regex;
    static
    {
        Set<String> splitSet = new HashSet<String>();
        splitSet.add(Criteria.PAREN_OPEN);
        splitSet.add(Criteria.PAREN_CLOSE);
        splitSet.add(NCriteria.N_OBS);
        splitSet.add(AndCriteria.AND);
        splitSet.add(OrCriteria.OR);

        splitSet.add(SubCriteria.PAREN_OPEN);
        splitSet.add(SubCriteria.PAREN_CLOSE);
        splitSet.add(AndSubCriteria.AND);
        splitSet.add(OrSubCriteria.OR);
        
        //  Concatenate everything into a single expression
        StringBuffer str = new StringBuffer();
        str.append("\\s*([");
        for (String pattern : splitSet)
            str.append(pattern);
        
        //  Alphabetic characters, numeric characters
        str.append("]|[a-zA-Z]+|\\d+");

        str.append(")\\s*");
        
        split_regex = str.toString();
    }
    
    public static Criteria createCriteria(List<? extends Phase> phases, String criteria_string)
    {
        // split into one string for each detection criteria
        List<String> criteria_tokens = new ArrayList<String>();
        Pattern p = Pattern.compile(split_regex);
        Matcher m = p.matcher(criteria_string);
        
        while (m.find())
            criteria_tokens.add(m.group(1));
        
        try
        {
            return Criteria.parse(phases, criteria_tokens);
        }
        catch (CriteriaParseException e)
        {
            GUIUtility.showExceptionDialog(null, "Detection Criteria Parse Error", e.getMessage(), e);
        }
        
        return null;
    }
}
