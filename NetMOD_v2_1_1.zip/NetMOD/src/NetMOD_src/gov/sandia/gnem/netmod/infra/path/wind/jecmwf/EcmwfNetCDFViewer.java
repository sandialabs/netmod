package gov.sandia.gnem.netmod.infra.path.wind.jecmwf;

import gov.sandia.gnem.netmod.gui.FileField;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import java.awt.*;

public class EcmwfNetCDFViewer extends NetModComponentViewer<EcmwfNetCDF>
{
	private FileField _windModelFile = new FileField("Wind Model File");

	EcmwfNetCDFViewer(EcmwfNetCDF nmc)
	{
		super(nmc, true, false);
		setExpanded(true);
		registerControls(_windModelFile);
	}

	@Override
	public void apply(EcmwfNetCDF nmc)
	{
		super.apply(nmc);
		nmc.setFilename(_windModelFile.getText());
	}

	@Override
	public JPanel getExpandedPanel()
	{
		if (_expandedPanel == null)
		{
			JPanel panel = new JPanel(new GridBagLayout());

			GUIUtility.addRow(panel, new JLabel("Wind Model File "), _windModelFile);

			_expandedPanel = panel;
		}

		return _expandedPanel;
	}

	@Override
	public void reset(EcmwfNetCDF nmc)
	{
		_windModelFile.setText(nmc.getFilename());
	}
}
