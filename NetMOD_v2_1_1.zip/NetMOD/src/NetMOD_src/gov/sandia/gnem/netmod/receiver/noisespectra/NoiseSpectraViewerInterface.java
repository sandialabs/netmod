/**
 * 
 */
package gov.sandia.gnem.netmod.receiver.noisespectra;

import java.util.List;

/**
 * Interface to allow noise models to be overlaid on a power spectra
 * 
 * @author bjmerch
 *
 */
public interface NoiseSpectraViewerInterface
{
    /**
     * Add the provided noise models to overlay on the noise spectra
     * within this viewer
     * 
     * @param noiseModels
     */
    public void addNoiseModels(List<NoiseSpectra> noiseModels);

}
