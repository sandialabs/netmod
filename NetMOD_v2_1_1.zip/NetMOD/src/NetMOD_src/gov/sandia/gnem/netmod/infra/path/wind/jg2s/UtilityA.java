package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

public class UtilityA {

  /*
   * ! ################################################################## ! !
   * Calculate the cubic spline interpolation value ! xa,ya: arrays of
   * tabulated function in ascending order by x ! y2a: array of second
   * derivatives ! n: size of arrays xa,ya,y2a ! x: abscissa for interpolation
   * ! y: output value ! ! Adapted from Numerical Recipes, Press et al. ! !
   * ###################################################################
   */
  public static float splint_nr(float[] xa, float[] ya, float[] y2a, int n, float x) {
    /*
     * implicit none integer :: n real :: x,y real :: xa(n),y2a(n),ya(n)
     * integer :: k,khi,klo real :: a,b,h
     */
    int klo = 0;
    int khi = n - 1;
    while (khi - klo > 1) {
      int k = (khi + klo) / 2;
      if (xa[k] > x) {
        khi = k;
      } else {
        klo = k;
      }
    }

    float h = xa[khi] - xa[klo];
    if (h == 0.0f) {
      System.err.println("bad xa input in splint");
      return 0;
    }

    float a = (xa[khi] - x) / h;
    float b = (x - xa[klo]) / h;
    float y = a * ya[klo] + b * ya[khi]
        + ((a * a * a - a) * y2a[klo] + (b * b * b - b) * y2a[khi]) * (h * h) / 6.0f;
    return y;
  }

  /*
   * spline_nr : spline function from numerical recipes
   * !============================================================= !
   * Determines the components of the scalar spherical harmonics ! of orders M
   * and degrees N as a function of latitude.
   * !=============================================================
   */

  static void spline_nr(float[] x, float[] y, int n, float[] y2) {
    y2[0] = 0.0f;
    int nm1 = n - 1;
    float[] u = new float[n];

    for (int i = 1; i < nm1; i++) {
      int ip1 = i + 1;
      int im1 = i - 1;

      float sig = (x[i] - x[im1]) / (x[ip1] - x[im1]);
      float p = sig * y2[im1] + 2.0f;
      y2[i] = (sig - 1.0f) / p;
      u[i] =
          (6.0f * ((y[ip1] - y[i]) / (x[ip1] - x[i]) - (y[i] - y[im1]) / (x[i] - x[im1])) / (x[ip1]
              - x[im1]) - sig * u[im1]) / p;
    }

    y2[nm1] = 0.0f;

    for (int k = n - 2; k >= 0; k--) {
      y2[k] = y2[k] * y2[k + 1] + u[k];
    }
  }
}
