/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.seismic.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;
import gov.sandia.gnem.netmod.signal.RegionalBodywave;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.signal.TeleseismicBodywave;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.ArrayList;
import java.util.List;

import static cern.clhep.PhysicalConstants.pi;

/**
 * @author bjmerch
 *
 */
public class SeismicSignalAmplitude extends AbstractNetModComponent implements SignalAmplitude
{
	public static final String TYPE = "NetSim";
	static
	{
		SeismicSignalAmplitudePlugin.getPlugin().registerComponent(TYPE, SeismicSignalAmplitude.class);
	}

	private double _regionalBlending = 2;
	private double _distanceThreshold = 20;

	protected SignalAmplitude _regional;
	protected SignalAmplitude _teleseismic;

	/**
	 * Create a new bodywave amplitude calculation
	 */
	public SeismicSignalAmplitude(NetModComponent parent)
	{
		this(parent, TYPE, "Seismic Signal Amplitude");
	}

	/**
	 * Create a new seismic bodywave signal amplitude calculation
	 * 
	 * @param parent
	 * @param type
	 * @param name
	 */
	protected SeismicSignalAmplitude(NetModComponent parent, String type, String name)
	{
		super(parent, type, name);

		_regional = new RegionalBodywave(this, "", "Regional ");
		_teleseismic = new TeleseismicBodywave(this, "", "Teleseismic ");
	}

	/**
	 * Create a new bodywave amplitude calculation with a different type
	 * 
	 * @param type
	 */
	protected SeismicSignalAmplitude(NetModComponent parent, String type)
	{
		super(parent, type);
	}

	@Override
    public Spectra generateAmplitude(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency,
            Time time, int N, PRNG prng)
    {
        startIntrospection();
        
        Spectra result;
        if (distance.getDistance() >= (_distanceThreshold + _regionalBlending)) 
        {
            result = getTeleseismic().generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            recordIntrospection("Signal Amplitude (log10 Amplitude): ", result);
        }
        else if (distance.getDistance() < (_distanceThreshold - _regionalBlending)) 
        {
            result = getRegional().generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            recordIntrospection("Signal Amplitude (log10 Amplitude): ", result);
        } 
        else 
        {
            double ratio = 0.5 * (1 - Math.cos(2 * pi * (distance.getDistance() - (_distanceThreshold - _regionalBlending)) / (4.0 * _regionalBlending)));

            Spectra regional = getRegional().generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            Spectra teleseismic = getTeleseismic().generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            
            result = new SpectraPDF(regional, 0.0).scale(1.0 - ratio);
            result.addScaled(ratio, teleseismic);
            
            recordIntrospection("Signal Amplitude (log10 Amplitude): ", result);
            recordIntrospection("Regional Blending Ratio: ", 1.0 - ratio);
            recordIntrospection("Regional Blending Distance (deg): ", _regionalBlending);
        }

        recordIntrospection("Distance (deg): ", distance);
        recordIntrospection("Distance Threshold (deg): ", _distanceThreshold);
        stopIntrospection();

        return result;
    }

	@Override
	public List<NetModComponent> getChildren()
	{
		List<NetModComponent> children = new ArrayList<NetModComponent>();
		children.add(_regional);
		children.add(_teleseismic);

		return children;
	}

	/**
	 * @return the regional
	 */
	public SignalAmplitude getRegional()
	{
		return _regional;
	}

	public double getRegionalDistance()
	{
		return _distanceThreshold;
	}

	public double getRegionalBlending()
	{
		return _regionalBlending;
	}

	/**
	 * @return the teleseismic
	 */
	public SignalAmplitude getTeleseismic()
	{
		return _teleseismic;
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		return new SeismicSignalAmplitudeViewer(this);
	}

	@Override
	public boolean isLeaf()
	{
		return true;
	}

	@Override
	public void load(NetSimParameters parameters) throws Exception
	{
		super.load(parameters);

		setRegionalDistance(parameters.get(NetSimParameters.regionalXoverDistance));
		setRegionalBlending(parameters.get(NetSimParameters.regionalBlendingDistance));

		getRegional().load(parameters);
		getTeleseismic().load(parameters);
	}

	@Override
	public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
	{
		super.save(parameters, files, reset);

		getRegional().save(parameters, files, reset);
		getTeleseismic().save(parameters, files, reset);

		parameters.set(NetSimParameters.regionalBlendingDistance, getRegionalBlending());
		parameters.set(SeismicDetectionParameters.signalAmplitude, getType());
		parameters.set(NetSimParameters.regionalXoverDistance, getRegionalDistance());
		parameters.set(SeismicDetectionParameters.signalAmplitude, getType());
	}

	@Override
	public void setChildren(List<NetModComponent> children)
	{
		for (NetModComponent child : children)
		{
			if (child instanceof RegionalBodywave)
				_regional = (RegionalBodywave) child;
			else if (child instanceof TeleseismicBodywave)
				_teleseismic = (TeleseismicBodywave) child;
		}

		clearCache();
	}

	public void setRegionalDistance(double value)
	{
		_distanceThreshold = value;
	}

	public void setRegionalBlending(double value)
	{
		_regionalBlending = value;
	}
}
