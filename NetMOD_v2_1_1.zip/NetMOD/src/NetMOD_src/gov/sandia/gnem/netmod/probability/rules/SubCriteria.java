/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * SubCriteria which may be composed of:
 * 
 *   Phase [ op SubCriteria ]
 *   "(" SubCriteria ")"
 *   
 *   in which [ ... ] is optional
 * 
 * 
 * @author bjmerch
 *
 */
abstract public class SubCriteria extends AbstractNetModComponent
{
    public static final String PAREN_OPEN = "(";
    public static final String PAREN_CLOSE = ")";

    /**
     * Parse SubCriteria from the provided criteria strings.
     * 
     * SubCriteria are defined as:
     *      Phase [ op SubCriteria ]
     *      "(" SubCriteria ")"
     * 
     * Where Phase is a string phase identifier (i.e. "P" or "Pg"), op is an operator (i.e. "*" or "+"),
     * elements within square brackets (i.e. [ ... ]) are optional, and SubCriteria may
     * be contained within parenthesis.
     * 
     * @param phases
     * @param criteria_str
     * @return
     * @throws CriteriaParseException 
     */
    protected static SubCriteria parse(List<? extends Phase> phases, List<String> criteria_str) throws CriteriaParseException
    {
        if ( criteria_str.isEmpty() || phases.isEmpty() )
            return new NullSubCriteria();
        
        //  Check for a phase
        String first = criteria_str.get(0);
        for (Phase phase : phases)
        {
            if ( first.equalsIgnoreCase(phase.toString()) )
            {
                //  Remove the identified criteria from the list
                criteria_str.remove(0);
                
                //  Create a criteria for this phase
                SubCriteria criteria = new PhaseSubCriteria(phase);
                
                //  Check for an optional OR or AND operator
                String next = "";
                if ( criteria_str.size() > 0 )
                    next = criteria_str.get(0);
                
                if ( next.equals(OrSubCriteria.OR) )
                {
                    //  Remove the identified criteria from the list
                    criteria_str.remove(0);
                    
                    criteria = new OrSubCriteria(criteria, parse(phases, criteria_str));
                }
                else if ( next.equals(AndSubCriteria.AND) )
                {
                    //  Remove the identified criteria from the list
                    criteria_str.remove(0);
                    
                    criteria = new AndSubCriteria(criteria, parse(phases, criteria_str));
                }
                
                return criteria;
            }
        }
        
        //  Check for a parenthesis
        if ( first.equals(PAREN_OPEN) )
        {
            //  Remove the open parenthesis from the list
            criteria_str.remove(0);
            
            SubCriteria criteria = parse(phases, criteria_str);
            
            //  Confirm a close parenthesis
            if ( criteria_str.size() == 0 || !criteria_str.get(0).equals(PAREN_CLOSE))
                throw new CriteriaParseException("Unbalanced parenthesis");
            
            //  Remove the close parenthesis from the list
            criteria_str.remove(0);
            
            return criteria;
        }
        
        //  Couldn't find anything
        throw new CriteriaParseException("Unrecognized SubCriteria: " + criteria_str);
    }
    
    protected SubCriteria()
    {
        super(null);
    }
    
    /**
     * Get the phases used by this SubCriteria
     * 
     * @return
     */
    abstract public Set<Phase> getPhases();
    
    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    abstract public ObjectDoubleMap<String> getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities);
}
