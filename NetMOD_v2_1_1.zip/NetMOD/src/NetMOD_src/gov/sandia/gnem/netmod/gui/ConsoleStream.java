/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * ConsoleStream is an output stream that diverts a copy of the
 * content passed it to the provided output stream, StringBuilder,
 * and JTextArea.
 * 
 * It is used for displaying an in-application console window
 * and for accumulating output (i.e. for a simulation run).
 * 
 * @author bjmerch
 *
 */
public class ConsoleStream extends OutputStream
{  
    private static ConsoleStream _ConsoleErr = new ConsoleStream(System.err);
    private static ConsoleStream _ConsoleOut = new ConsoleStream(System.out);

    static
    {
//        System.setOut(new PrintStream(_ConsoleOut));
//        System.setErr(new PrintStream(_ConsoleErr));
    }

    /**
     * Get the error output stream
     * 
     * @return
     */
    static public ConsoleStream getErrConsoleStream()
    {
        return _ConsoleErr;
    }

    /**
     * Get the console output stream
     * 
     * @return
     */
    static public ConsoleStream getOutConsoleStream()
    {
        return _ConsoleOut;
    }
    
    //  StringBuilder to temporarily accumulate output
    private StringBuilder _builder = null;
    
    private OutputStream _out = null;
    
    //  Text area to display the ouput
    private JTextArea _textArea = null;
    
    public ConsoleStream(OutputStream out)
    {
        _out = out;
    }

    @Override
    public void close() throws IOException
    {
        _out.close();
    }
    
    @Override
    public void flush() throws IOException
    {
        _out.flush();
    }
    
    /**
     * Set the string builder used to accumulate output
     * 
     * @param builder
     */
    public void setStringBuilder(StringBuilder builder)
    {
        _builder = builder;
    }
    
    /**
     * Set the text area used to accumulate output
     * 
     * @param textArea
     */
    public void setTextArea(JTextArea textArea)
    {
        _textArea = textArea;
    }

    @Override
    public void write(byte[] b) throws IOException
    {
        _out.write(b);
        
        append(new String(b, StandardCharsets.UTF_8));
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException
    {
        _out.write(b, off, len);
        
        append(new String(b, off, len, StandardCharsets.UTF_8));
    }

    @Override
    public void write(int b) throws IOException
    {
        _out.write(b);

        append(new String(new byte[]{ (byte) b }, StandardCharsets.UTF_8));
    }
    
    private void append(final String str)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                if ( _builder != null )
                {
                    _builder.append(str);

                    //  Limit the length in the builder
                    if ( _builder.length() > 100000 )
                        _builder.delete(0,  _builder.length() - 100000 );
                }
                
                if ( _textArea != null )
                {
                    _textArea.append(str);
                    
                    //  Limit the length in the text area
                    String text = _textArea.getText();
                    if ( text.length() > 100000 )
                        _textArea.setText(text.substring(text.length()-100000));
                }
            }
        });
    }
}
