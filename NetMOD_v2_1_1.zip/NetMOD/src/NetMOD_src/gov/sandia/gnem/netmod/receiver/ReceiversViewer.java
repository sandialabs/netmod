/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.Layer.DISPLAY;
import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.response.SiteResponse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author bjmerch
 *
 */
public class ReceiversViewer extends NetModComponentViewer<Receivers>
{
    private JFormattedTextField _defaultElevation = new JFormattedTextField(new DoubleRangeFormatter());
    private JFormattedTextField _defaultReliability = new JFormattedTextField(new DoubleRangeFormatter(0.0, 1.0));
    private JFormattedTextField _defaultDensity = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private FileField _defaultSiteResponse = new FileField("Default Site Response File", createViewResponseButton());
    private NetModComboBox _networks = new NetModComboBox(null, createAddNeworkButton(), createRemoveNetworkButton(),
            createDisplayOnMapButton(MapUtility.StationButtonGroup), createSelectStationButton());

    //  Keep a list of stations for the networks to select from
    private List<String> _stations = new ArrayList<String>();

    public ReceiversViewer(Receivers nmc)
    {
        super(nmc, true, true);

        //  Register the controls that are monitored after updating
        registerControls(_defaultElevation, _defaultReliability, _defaultDensity, _defaultSiteResponse, _networks);
    }

    @Override
    public void apply(Receivers nmc)
    {
        nmc.setDefaultElevation(((Number) _defaultElevation.getValue()).doubleValue());
        nmc.setDefaultReliability(((Number) _defaultReliability.getValue()).doubleValue());
        nmc.setDefaultDensity(((Number) _defaultDensity.getValue()).doubleValue());
        nmc.setDefaultSiteResponseFile(_defaultSiteResponse.getText());

        nmc.setNetworks((Set<Network>) _networks.getItems());
        nmc.setNetwork((Network) _networks.getSelectedItem());
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            _defaultElevation.setToolTipText("Default Station Elevation (meters)");
            _defaultReliability.setToolTipText("Default Station Reliability [0..1]");
            _defaultDensity.setToolTipText("Default Station Meda Density (kg/m^3)");

            //  Setup the phase parameters
            GUIUtility.addRow(panel, _nmc.getPhaseParameters().getViewer());

            GUIUtility.addRow(panel, new JLabel("Elevation: "), _defaultElevation);
            GUIUtility.addRow(panel, new JLabel("Reliability: "), _defaultReliability);
            GUIUtility.addRow(panel, new JLabel("Media Density: "), _defaultDensity);
            GUIUtility.addRow(panel, new JLabel("Site Response: "), _defaultSiteResponse);

            //  Setup the networks
            GUIUtility.addRow(panel, new JLabel("Network: "), _networks);

            //  Setup the stations
            GUIUtility.addRow(panel, new JLabel("Stations: "), _nmc.getStations().getViewer());

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(Receivers nmc)
    {
        //  Update the list of stations
        _stations.clear();
        for (Station station : _nmc.getStations().getStations())
            _stations.add(station.getName());

        //  Update the networks
        _networks.setItems(_nmc.getNetworks());
        _networks.setSelectedItem(nmc.getNetwork());

        _defaultElevation.setValue(nmc.getDefaultElevation());
        _defaultReliability.setValue(nmc.getDefaultReliability());
        _defaultDensity.setValue(nmc.getDefaultDensity());
        _defaultSiteResponse.setText(nmc.getDefaultSiteResponseFile());

    }

    private JButton createAddNeworkButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Create new network");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Get the name of the new epicenter grid
                String name = JOptionPane.showInputDialog(_networks, "Name: ", "Create new network", JOptionPane.INFORMATION_MESSAGE);
                if (name == null)
                    return;

                //  Don't allow empty names
                name = name.trim();
                if (name.isEmpty())
                    return;
                
                //  Create the network
                Network network = new Network(_nmc, _nmc.getStations());
                network.setName(name);
                
                //  Transfer existing stations to the new network
                network.setStations(_nmc.getNetwork().getStationsList());

                //  Add the network as the selected one
                _nmc.setNetwork(network);

                _networks.addNetModComponent(network);
                _networks.setSelectedItem(network);
            }
        });

        return button;
    }
    
    private JButton createRemoveNetworkButton()
    {
        JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
        button.setToolTipText("Remove current network");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Get the current epicenter Grid
                Network network = _nmc.getNetwork();
                if (network == null || _nmc.getNetworks().size() <= 1)
                    return;

                //  Remove the epicenter Grid
                _nmc.getNetworks().remove(network);
                _networks.removeNetModComponent(network);

                //  Set the next grid as the selected
                _nmc.setNetwork(_nmc.getNetwork());
            }
        });

        return button;
    }

    private JToggleButton createSelectStationButton()
    {
        JToggleButton button = GUIUtility.createToggleButton(Icons.SELECT.getIcon());
        MapUtility.SelectButtonGroup.add(button);
        button.setAction(new AbstractAction()
        {
            private Map _map = null;
            private Action _selectAction = null;
            private boolean _updating = false;

            {
                putValue(SHORT_DESCRIPTION, "Select stations");
                putValue(SELECTED_KEY, Boolean.FALSE);
                putValue(SMALL_ICON, Icons.SELECT.getIcon());
            }

            @Override
            public void actionPerformed(ActionEvent e)
            {
                getSelectAction().actionPerformed(e);
            }
            
            @Override
            public void putValue(String str, Object o)
            {
                if (!_updating)
                {
                    _updating = true;
                    super.putValue(str, o);

                    Action action = getSelectAction();
                    if (action != null)
                        action.putValue(str, o);
                    _updating = false;
                }
            }

            private Action getSelectAction()
            {
                //  Reset the selection action if the map changes
                if (_map != NetMOD.getMap())
                {
                    _map = NetMOD.getMap();
                    if (_map == null)
                        _selectAction = null;
                    else
                    {
                        _selectAction = _map.createStationSelectionTool(_nmc);
                        _selectAction.addPropertyChangeListener(new PropertyChangeListener()
                        {
                            @Override
                            public void propertyChange(PropertyChangeEvent pce)
                            {
                                putValue(pce.getPropertyName(), pce.getNewValue());
                            }
                        });
                    }
                }

                return _selectAction;
            }
        });

        return button;
    }

    private JButton createViewResponseButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Response");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                //  Get the object
                SiteResponse siteResponse = _nmc.getDefaultSiteResponse();
                if (siteResponse == null)
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) siteResponse.getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Site Response - " + siteResponse.getName());
            }
        });

        return button;
    }
    
    /**
     *  Extend display button to show a popup that allows the users to control
     *  which stations (all, selected, unselected) are visible.
     *  
     * @param group
     * @return
     */
    @Override
    protected AbstractButton createDisplayOnMapButton(final NetModComponent nmc, ButtonGroup group)
    {
        final AbstractButton button = super.createDisplayOnMapButton(nmc, group);
        
        button.addActionListener(new ActionListener()
        {
            JPopupMenu popupMenu = null;
            JMenuItem allItem;
            JMenuItem selectedItem;
            JMenuItem notselectedItem;
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if ( !button.isSelected() )
                    return;
                
                if ( popupMenu == null )
                    popupMenu = createPopupMenu();
                
                Layer<?> layer = nmc.getMapLayer();
                if ( layer == null )
                    return;
                
                DISPLAY display = layer.getDisplay();

                allItem.setSelected(display == DISPLAY.ALL);
                selectedItem.setSelected(display == DISPLAY.SELECTED);
                notselectedItem.setSelected(display == DISPLAY.NOT_SELECTED);
                
                popupMenu.show((JComponent) e.getSource(), 0, ((JComponent) e.getSource()).getHeight());
            }
            
            public JPopupMenu createPopupMenu()
            {
                JPopupMenu popupMenu = new JPopupMenu();
                
                allItem = new JRadioButtonMenuItem("All");
                allItem.setToolTipText("Display all stations");
                allItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        Layer<?> layer = nmc.getMapLayer();
                        if ( layer == null )
                            return;
                        
                        layer.setDisplay(DISPLAY.ALL);
                        NetMOD.refresh(nmc);
                    }
                });
                
                selectedItem = new JRadioButtonMenuItem("Selected Stations");
                selectedItem.setToolTipText("Display selected stations");
                selectedItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        Layer<?> layer = nmc.getMapLayer();
                        if ( layer == null )
                            return;
                        
                        layer.setDisplay(DISPLAY.SELECTED);
                        NetMOD.refresh(nmc);
                    }
                });
                
                notselectedItem = new JRadioButtonMenuItem("Unselected Stations");
                notselectedItem.setToolTipText("Display unselected stations");
                notselectedItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        Layer<?> layer = nmc.getMapLayer();
                        if ( layer == null )
                            return;
                        
                        layer.setDisplay(DISPLAY.NOT_SELECTED);
                        NetMOD.refresh(nmc);
                    }
                });
                
                popupMenu.add(allItem);
                popupMenu.add(selectedItem);
                popupMenu.add(notselectedItem);
                
                return popupMenu;
            }
            
        });
        

        return button;
    }
}
