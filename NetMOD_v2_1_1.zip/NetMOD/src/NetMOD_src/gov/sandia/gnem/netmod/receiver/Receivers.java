/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.receiver.response.SiteResponse;
import gov.sandia.gnem.netmod.receiver.response.SiteResponsePlugin;
import gov.sandia.gnem.netmod.simulation.DetectionPhase;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.*;

/**
 * Hierarchical container for organizing the receiver components
 * within a simulation.
 * 
 * @author bjmerch
 *
 */
public class Receivers extends AbstractNetModComponent
{
    private SiteResponse _defaultSiteResponse = null;

    private double _defaultElevation = 0;
    private double _defaultReliability = 0.95;
    private double _defaultDensity = 2500;
    private String _defaultSiteResponseFile = "";

    private PhaseParameters<ReceiverPhaseParameter> _phaseParameters;
    private Set<Network> _networks = new TreeSet<Network>();
    private String _networkName = "";
    private Stations _stations;

    public Receivers(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent);
        
        setName("Receivers");
        
        _stations = new Stations(parent, phases);

        //  Initialize the set of phases
        _phaseParameters = new PhaseParameters<ReceiverPhaseParameter>(this);
        for (Phase phase : phases)
            _phaseParameters.addParameter(new ReceiverPhaseParameter(_phaseParameters, phase));
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof Station || component instanceof ReceiverPhaseParameter);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getPhaseParameters());
        children.add(getDefaultSiteResponse());
        children.addAll(getNetworks());
        children.add(getStations());

        return children;
    }

    /**
     * @return the defaultDensity
     */
    public double getDefaultDensity()
    {
        return _defaultDensity;
    }

    /**
     * @return the defaultElevation
     */
    public double getDefaultElevation()
    {
        return _defaultElevation;
    }

    /**
     * @return the defaultReliability
     */
    public double getDefaultReliability()
    {
        return _defaultReliability;
    }

    /**
     * @return the siteResponse
     */
    public SiteResponse getDefaultSiteResponse()
    {
        if (_defaultSiteResponse == null)
        {
            _defaultSiteResponse = SiteResponsePlugin.getPlugin().getComponentFor(this, getDefaultSiteResponseFile());
            if ( _defaultSiteResponse != null )
            	_defaultSiteResponse.setFilename(getDefaultSiteResponseFile());
        }

        return _defaultSiteResponse;
    }

    /**
     * @return the siteResponseFile
     */
    public String getDefaultSiteResponseFile()
    {
        return _defaultSiteResponseFile;
    }

    @Override
    public Layer<?> getMapLayer()
    {
        if ( NetMOD.getMap() == null )
            return null;
        
        return NetMOD.getMap().createStationLayer(this);
    }

    /**
     * @return the network
     */
    public Network getNetwork()
    {
        //  Get the selected network name
        String name = getNetworkName();

        //  Search for the network with a matching name
        for (Network network : getNetworks())
            if (network.getName().equals(name))
                return network;

        //  Otherwise, return the first network
        for (Network network : getNetworks())
            return network;

        return null;
    }

    /**
     * @return the networkName
     */
    public String getNetworkName()
    {
        return _networkName;
    }

    /**
     * @return the networks
     */
    public Set<Network> getNetworks()
    {
        //  Just to force network initialization
        if (_networks.size() == 0)
        {
            //  Otherwise, create a new network
            Network network = new Network(this, getStations());
            network.setName("default");

            //  Network includes all enabled stations
            network.setStations(getStations().getStations());
            addNetwork(network);
        }

        return _networks;
    }

    /**
     * Get the generic receiver phase parameters
     * 
     * @return
     */
    public PhaseParameters<ReceiverPhaseParameter> getPhaseParameters()
    {
        return _phaseParameters;
    }

    /**
     * Get the selected stations
     * 
     * @return
     */
    public Set<Station> getSelectedStations()
    {
    	return getNetwork().getStations();
    }

    /**
     * Get the defined stations
     * 
     * @return
     */
    public Stations getStations()
    {
        return _stations;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new ReceiversViewer(this);
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        //  Load the default parameters
        setDefaultElevation(parameters.get(NetSimParameters.defaultStationElev));
        setDefaultReliability(parameters.get(NetSimParameters.defaultStationRely));
        setDefaultDensity(parameters.get(NetSimParameters.defaultStationDensity));

        //  Load stations
        Stations stations = getStations();
        Map<String, Station> stationsMap = new TreeMap<String, Station>();
        ParTable staSpecTable = parameters.get(NetSimParameters.staSpec);
        for (String row : staSpecTable.getRowNames())
        {
            //  Get the station name
            String staName = staSpecTable.getTableValue(row, NetSimParameters.STASPEC_STA);
            if (staName == null)
                continue;

            //  Get the station
            Station station = stationsMap.get(staName);

            //  Create a new station
            if (station == null)
            {
                station = new Station(stations, _phaseParameters.getPhases());
                station.setName(staName);
                
                String group = staSpecTable.getTableValue(row, NetSimParameters.STASPEC_GROUP);
                if ( group == null || group.isEmpty())
                    group = staName;
                
                station.setGroup(group);
                stationsMap.put(staName, station);
            }

            //  Load the station attributes
            station.setLatitude(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_LAT, 0));
            station.setLongitude(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_LON, 0));
            station.setStationType(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_STATYPE));
            station.setTechnology(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_TECH));
            station.setNumberChannels((int) staSpecTable.getTableValue(row, NetSimParameters.STASPEC_NCHAN, 1));
            station.setElevation(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_ELEV, 0));
            station.setReliability(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_RELY, 0));
            station.setMediaDensity(staSpecTable.getTableValue(row, NetSimParameters.STASPEC_DENSITY, 0));
        }
        stations.addAll(stationsMap.values());

        //  Load the phase parameters
        ParTable phaseSpecTable = parameters.get(NetSimParameters.phaseSpec);
        for (String row : phaseSpecTable.getRowNames())
        {
            ReceiverPhaseParameter p = getPhaseParameters().getPhaseParameter(DetectionPhase.valueOfIgnoreCase(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_PHASE)));

            if (p != null)
            {
                //  Set a default log amplitude correction, if specified
                p.setLogAmplitudeCorrection(new NormalPDF(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_LOG_AMP_CORR, 0), phaseSpecTable
                        .getTableValue(row, NetSimParameters.PHASESPEC_LOG_AMP_CORR_SD, 0)));

                //  Set a default SNR threshold, if specified
                p.setSnrThreshold(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_SNR_THRESH, 0));

                //  Set a default source velocity, if specified
                p.setReceiverMediaVelocity(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_VELOCITY, 0));
            }
        }

        //  Load the station phase parameters
        ParTable staPhaseSpecTable = parameters.get(NetSimParameters.staPhaseSpec);
        for (String row : staPhaseSpecTable.getRowNames())
        {
            //  Get the station for this entry
            String sta = staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_STA);
            Station station = stationsMap.get(sta);
            if (station == null)
                continue;

            StationPhaseParameter p = station.getPhaseParameters().getPhaseParameter(DetectionPhase.valueOfIgnoreCase(staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_PHASE)));

            if (p != null)
            {
                p.setLogAmplitudeCorrection(new NormalPDF(staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_LOG_AMP_CORR, 0),
                        staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_LOG_AMP_CORR_SD, 0)));
                p.setReceiverMediaVelocity(staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_VELOCITY, 0));
                p.setSnrThreshold(staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_SNR_THRESH, 0));

				// Set the site response file
				{
					String value = staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_RESPONSE);

					if (value != null && !value.isEmpty())
					{
						File file = IOUtility.openFile(IOUtility.fixPathSeparator(value));
						p.setSiteResponseFile(file.getCanonicalPath());
					}
				}
                
                //  Set the site attenuation file
				{
					String value = staPhaseSpecTable.getTableValue(row, NetSimParameters.STAPHASESPEC_ATTENUATION);

					if (value != null && !value.isEmpty())
					{
						File file = IOUtility.openFile(IOUtility.fixPathSeparator(value));
						p.setStationAttenuationFile(file.getCanonicalPath());
					}
				}
                
            }
        }

        //  Load the response models
        ParTable rspSpecTable = parameters.get(NetSimParameters.rspSpec);
        for (Station station : stationsMap.values())
        {
            //  Check for a matching station
            String sta = station.getName();
            boolean found = false;
            for (String row : rspSpecTable.getRowNames())
            {
                //  get the response file
                String responseFile = rspSpecTable.getTableValue(row, NetSimParameters.RSPSPEC_RSP_FILE);
                if (responseFile == null)
                    continue;

                String respModel = rspSpecTable.getTableValue(row, NetSimParameters.RSPSPEC_RSP_MODEL);
                if (respModel.equalsIgnoreCase(sta))
                {
                    File file = IOUtility.openFile(IOUtility.fixPathSeparator(responseFile));
                    
                    for ( StationPhaseParameter p : station.getPhaseParameters().getParameters())
                        if ( p.getSiteResponseFile().isEmpty() )
                            p.setSiteResponseFile(file.getCanonicalPath());

                    found = true;
                    break;
                }
            }

            //  Check for matching number of channels and station type
            if (!found)
                for (String row : rspSpecTable.getRowNames())
                {
                    //  get the response file
                    String responseFile = rspSpecTable.getTableValue(row, NetSimParameters.RSPSPEC_RSP_FILE);
                    if (responseFile == null)
                        continue;
                    
                    File file = IOUtility.openFile(IOUtility.fixPathSeparator(responseFile));

                    String statype = rspSpecTable.getTableValue(row, NetSimParameters.RSPSPEC_STATYPE);
                    int nchan = (int) rspSpecTable.getTableValue(row, NetSimParameters.RSPSPEC_NCHAN, 1);

                    if (station.getNumberChannels() == nchan && station.getStationType().equalsIgnoreCase(statype))
                        for ( StationPhaseParameter p : station.getPhaseParameters().getParameters())
                            if ( p.getSiteResponseFile().isEmpty() )
                                p.setSiteResponseFile(file.getCanonicalPath());
                }
        }

        //  Load the default response model
        setDefaultSiteResponseFile(rspSpecTable.getTableValue(parameters.get(NetSimParameters.defaultResponseModel), NetSimParameters.RSPSPEC_RSP_FILE));

        //  Load the site noise
        ParTable noiseSpecTable = parameters.get(NetSimParameters.noiseSpec);
        for (String row : noiseSpecTable.getRowNames())
        {
            String sta = noiseSpecTable.getTableValue(row, NetSimParameters.NOISESPEC_STA);
            Station station = stationsMap.get(sta);
            if (station == null)
                continue;

            //  Set the noise spectra file
            String rowName = getSurrogateRowName(noiseSpecTable, row);
            String value = noiseSpecTable.getTableValue(rowName, NetSimParameters.NOISESPEC_NOISE_FILE);

            if (value != null)
            {
                File file = IOUtility.openFile(IOUtility.fixPathSeparator(value));
                station.setNoiseSpectraFile(file.getCanonicalPath());
            }

            //  Set the default noise SD
            station.setNoiseSpectraSD(noiseSpecTable.getTableValue(rowName, NetSimParameters.NOISESPEC_LOG_NOISE_SD, 0));
        }

        // Load the network definitions
        ParTable networkTable = parameters.get(NetSimParameters.staNet);
        for (String row : networkTable.getRowNames())
        {
            Network network = new Network(this, getStations());
            network.setName(networkTable.getTableValue(row, NetSimParameters.STANET_NET));

            String listOfStations = networkTable.getTableValue(row, NetSimParameters.STANET_LIST_OF_NETWORK_STATIONS);

            //  Check if the listOfStations is a variable name, which is commonly done
            if (parameters.getLibPar(listOfStations) != null)
                listOfStations = parameters.getLibPar(listOfStations);

            network.setStations(listOfStations);
            addNetwork(network);
        }

        //  Set the current network
        String net = parameters.get(NetSimParameters.net);
        setNetworkName(net);
        
        //  Create a new default network if the names don't match up
        Network network = getNetwork();
        if ( network == null || (!network.getName().equals(net) && !net.isEmpty())  )
        {
            network = new Network(this, getStations());
            network.setName(net);
            addNetwork(network);
        }
        
        //  Set the default station list, if not empty.
        if ( !parameters.get(NetSimParameters.listOfStations).isEmpty() )
            network.setStations(parameters.get(NetSimParameters.listOfStations));
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        //  Save the default parameters
        parameters.set(NetSimParameters.defaultStationElev, getDefaultElevation());
        parameters.set(NetSimParameters.defaultStationRely, getDefaultReliability());
        parameters.set(NetSimParameters.defaultStationDensity, getDefaultDensity());

        //  Save stations
        ParTable staSpecTable = parameters.get(NetSimParameters.staSpec);
        for (Station station : getStations().getStations())
        {
            String row = station.getName();

            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_STA, row);
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_GROUP, station.getGroup());
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_LAT, Double.toString(station.getLatitude()));
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_LON, Double.toString(station.getLongitude()));
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_STATYPE, station.getStationType());
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_TECH, station.getTechnology());
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_NCHAN, Integer.toString(station.getNumberChannels()));
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_ELEV, Double.toString(station.getElevation()));
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_RELY, Double.toString(station.getReliability()));
            staSpecTable.setTableValue(row, NetSimParameters.STASPEC_DENSITY, Double.toString(station.getMediaDensity()));
        }

        //  Save the phase parameters
        PhaseParameters<ReceiverPhaseParameter> pp = getPhaseParameters();
        ParTable phaseSpecTable = parameters.get(NetSimParameters.phaseSpec);
        for (Phase phase : pp.getPhases())
        {
            ReceiverPhaseParameter p = pp.getPhaseParameter(phase);
            String row = p.toString();

            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_PHASE, row);
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_TECH, "S");
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_LOG_AMP_CORR, Double.toString(p.getLogAmplitudeCorrection().getMean()));
            phaseSpecTable
                    .setTableValue(row, NetSimParameters.PHASESPEC_LOG_AMP_CORR_SD, Double.toString(p.getLogAmplitudeCorrection().getStandardDeviation()));
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_SNR_THRESH, Double.toString(p.getSnrThreshold()));
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_VELOCITY, Double.toString(p.getReceiverMediaVelocity()));
            
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_TT_ME_FILE, "-");
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_DELTIM, "-1");
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_DELAZ, "-1");
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_BEAM, "-");
        }

        //  Save the station phase parameters
        File receiverFile = IOUtility.openFile(parameters.getNS_CONFIG(), NetSimParameters.ParameterFolder.RECEIVER.getFolder());
        ParTable staPhaseSpecTable = parameters.get(NetSimParameters.staPhaseSpec);
        for (Station station : getStations().getStations())
        {
            for (StationPhaseParameter p : station.getPhaseParameters().getParameters())
            {
                String row = station.getName() + "_" + p.getPhase();

                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_PHASE, p.getPhase().toString());
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_STA, station.getName());
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_LOG_AMP_CORR, Double.toString(p.getLogAmplitudeCorrection().getMean()));
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_LOG_AMP_CORR_SD,
                        Double.toString(p.getLogAmplitudeCorrection().getStandardDeviation()));
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_VELOCITY, Double.toString(p.getReceiverMediaVelocity()));
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_SNR_THRESH, Double.toString(p.getSnrThreshold()));
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_DELTIM, "0.0");
                staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_DELAZ, "0.0");

				// Save the site response for this station / phase
				{
					String filename = p.getSiteResponseFile();
					if (files)
					{
						if (reset && filename != null && filename.trim().length() != 0)
						{
							// Ensure the existing file is read in
							p.getSiteResponse().getFrequencies();

							File responseParent = IOUtility.openFile(receiverFile.getPath(), "response");

							filename = IOUtility.openFile(responseParent.getPath(), IOUtility.openFile(p.getSiteResponseFile()).getName()).getPath();
							p.setSiteResponseFile(IOUtility.fixPathSeparator(filename));
						}

						p.getSiteResponse().write();
					}

					staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_RESPONSE,
							IOUtility.fixPathSeparator(filename));
				}
				
				//  Save the site attenuation for this station / phase
				{
					String filename = p.getStationAttenuationFile();
					if (files)
					{
						if (reset && filename != null && filename.trim().length() != 0)
						{
							// Ensure the existing file is read in
							p.getStationAttenuation().getFrequencies();

							File responseParent = IOUtility.openFile(receiverFile, "attenuation");

							filename = IOUtility.openFile(responseParent, IOUtility.openFile(p.getSiteResponseFile()).getName()).getPath();
							p.setStationAttenuationFile(IOUtility.fixPathSeparator(filename));
						}

						p.getSiteResponse().write();
					}

					staPhaseSpecTable.setTableValue(row, NetSimParameters.STAPHASESPEC_ATTENUATION,
							IOUtility.fixPathSeparator(filename));
				}
            }
        }

        //  Save the default response model
        {
            String filename = getDefaultSiteResponseFile();
            if (files)
            {
                if (reset && filename != null && filename.trim().length() != 0)
                {
                    //  Ensure the existing file is read in
                    getDefaultSiteResponse().getFrequencies();
                    
                    File responseParent = IOUtility.openFile(receiverFile, "response");

                    filename = IOUtility.openFile(responseParent, IOUtility.openFile(getDefaultSiteResponseFile()).getName()).getPath();
                    setDefaultSiteResponseFile(IOUtility.fixPathSeparator(filename));
                }
                
                getDefaultSiteResponse().write();
            }
            
            parameters.set(NetSimParameters.defaultResponseModel, IOUtility.fixPathSeparator(filename));
        }

        //  Save the site noise
        ParTable noiseSpecTable = parameters.get(NetSimParameters.noiseSpec);
        for (Station station : getStations().getStations())
        {
            String row = station.getName();

            noiseSpecTable.setTableValue(row, NetSimParameters.NOISESPEC_STA, row);
            noiseSpecTable.setTableValue(row, NetSimParameters.NOISESPEC_LOG_NOISE_SD, Double.toString(station.getNoiseSpectraSD()));
            noiseSpecTable.setTableValue(row, NetSimParameters.NOISESPEC_SURG_TYPE, "None");
            noiseSpecTable.setTableValue(row, NetSimParameters.NOISESPEC_DISPLAY_NAME, row);

            String filename = station.getNoiseSpectraFile();
            if (files)
            {
                if (reset && filename != null && filename.trim().length() != 0)
                {
                    //  Ensure the existing file is read in
                    station.getNoiseSpectra().getFrequencies();
                    
                    File noiseParent = IOUtility.openFile(receiverFile, "noise");

                    filename = IOUtility.openFile(noiseParent, IOUtility.openFile(filename).getName()).getPath();
                    station.setNoiseSpectraFile(IOUtility.fixPathSeparator(filename));
                }
                station.getNoiseSpectra().write();
            }

            noiseSpecTable.setTableValue(row, NetSimParameters.NOISESPEC_NOISE_FILE, IOUtility.fixPathSeparator(filename));
        }

        // Save the network definitions
        ParTable networkTable = parameters.get(NetSimParameters.staNet);
        for (Network network : getNetworks())
        {
            String row = network.getName();

            networkTable.setTableValue(row, NetSimParameters.STANET_NET, network.getName());
            networkTable.setTableValue(row, NetSimParameters.STANET_LIST_OF_NETWORK_STATIONS, network.getStationsList());
        }

        //  Set the current network
        Network network = getNetwork();
        parameters.set(NetSimParameters.net, network.getName());
        parameters.set(NetSimParameters.listOfStations, network.getStationsList());
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof Stations)
                _stations = (Stations) child;
            else if (child instanceof PhaseParameters)
                _phaseParameters = (PhaseParameters) child;
        }

        clearCache();
    }

    /**
     * @param defaultDensity the defaultDensity to set
     */
    public void setDefaultDensity(double defaultDensity)
    {
        _defaultDensity = defaultDensity;
    }

    /**
     * @param defaultElevation the defaultElevation to set
     */
    public void setDefaultElevation(double defaultElevation)
    {
        _defaultElevation = defaultElevation;
    }

    /**
     * @param defaultReliability the defaultReliability to set
     */
    public void setDefaultReliability(double defaultReliability)
    {
        _defaultReliability = defaultReliability;
    }

    /**
     * @param siteResponse the siteResponse to set
     */
    public void setDefaultSiteResponse(SiteResponse siteResponse)
    {
        if (siteResponse != null)
            _defaultSiteResponseFile = siteResponse.getFilename();

        _defaultSiteResponse = siteResponse;
    }

    /**
     * @param siteResponseFile the siteResponseFile to set
     */
    public void setDefaultSiteResponseFile(String siteResponseFile)
    {
        if (_defaultSiteResponseFile.equals(siteResponseFile))
            return;

        //  If file exists, load it
        if (IOUtility.openFile(siteResponseFile).exists())
        {
            _defaultSiteResponseFile = siteResponseFile;
            setDefaultSiteResponse(null);
        }
        //  Otherwise, save to it
        else
        {
            SiteResponse siteResponse = getDefaultSiteResponse();
            siteResponse.read();
            siteResponse.setFilename(siteResponseFile);
            siteResponse.write();
            _defaultSiteResponseFile = siteResponse.getFilename();
        }
    }

    /**
     * @param network the network to set
     */
    public void setNetwork(Network network)
    {
        addNetwork(network);
        setNetworkName(network.getName());
    }

    /**
     * @param networkName the networkName to set
     */
    public void setNetworkName(String networkName)
    {
        _networkName = networkName;
    }

    /**
     * @param networks the networks to set
     */
    public void setNetworks(Set<Network> networks)
    {
        for (Network network : networks)
            addNetwork(network);
    }

    /**
     * Add the network to the set
     * 
     * @param network
     */
    private void addNetwork(Network network)
    {
        _networks.add(network);
    }

    /**
     * Get the row name of the appropriate surrogate for for the noise spec file 
     * 
     * @param noiseRowName
     * @return
     */
    private String getSurrogateRowName(ParTable noiseSpecTable, String noiseRowName)
    {
        //  Check for a surrogate station
        String surrogate = noiseSpecTable.getTableValue(noiseRowName, NetSimParameters.NOISESPEC_SURG_TYPE);

        //  Search for the surrogate station
        if (surrogate != null && !surrogate.equalsIgnoreCase("none"))
        {
            for (String noiseRowName2 : noiseSpecTable.getRowNames())
            {
                String sta = noiseSpecTable.getTableValue(noiseRowName2, NetSimParameters.NOISESPEC_STA);

                if (surrogate.equalsIgnoreCase(sta))
                    return getSurrogateRowName(noiseSpecTable, noiseRowName2);
            }
        }

        return noiseRowName;
    }
}
