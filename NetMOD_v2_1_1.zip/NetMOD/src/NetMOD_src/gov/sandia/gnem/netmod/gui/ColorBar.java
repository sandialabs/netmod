/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.Range;
import org.jfree.ui.RectangleInsets;

import javax.swing.*;
import java.awt.*;
import java.awt.image.IndexColorModel;
import java.awt.image.MemoryImageSource;
import java.text.DecimalFormat;

/**
 * Display a color model within a color bar
 * 
 * @author bjmerch
 *
 */
public class ColorBar extends JPanel
{
    private XYPlot scalebarPlot;
    private JFreeChart scalebarChart;

    private byte[] buf = new byte[256];

    public ColorBar()
    {
        super(new BorderLayout());

        // Initialize the color bar
        for (int i = 0; i < 256; i++)
            buf[255 - i] = (byte) i;

        // Create the scalebar plot
        scalebarPlot = new XYPlot(null, new NumberAxis(""), new NumberAxis(""), new StandardXYItemRenderer());
        scalebarPlot.setDomainGridlinesVisible(false);
        scalebarPlot.setRangeGridlinesVisible(false);
        scalebarPlot.setRangeAxisLocation(AxisLocation.TOP_OR_RIGHT);
        
        int size = Property.FONT_SIZE.getIntegerValue();
        Font font = new Font(Font.SANS_SERIF, Font.PLAIN, size);

        ValueAxis domain = scalebarPlot.getDomainAxis();
        domain.setVisible(false);

        NumberAxis range = (NumberAxis) scalebarPlot.getRangeAxis();
        range.setAutoRange(false);
        range.setTickLabelFont(font);
        range.setNumberFormatOverride(new DecimalFormat("##0.000"));

        scalebarChart = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, scalebarPlot, false);
        scalebarChart.setAntiAlias(false);
        scalebarChart.setPadding(new RectangleInsets(0, 0, 3, 0));
        
        // Turn on anti-aliasing for text
        RenderingHints renderhints = scalebarChart.getRenderingHints();
        renderhints.add(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON));

        ChartPanel scalebarChartPanel = new ChartPanel(scalebarChart, false, false, false, false, true);
        scalebarChartPanel.setMinimumDrawWidth(80);
        scalebarChartPanel.setMaximumSize(new Dimension(80, 100));
        scalebarChartPanel.setMinimumSize(new Dimension(80, 100));
        scalebarChartPanel.setPreferredSize(new Dimension(80, 100));
        scalebarChartPanel.setMaximumDrawHeight(3000);
        scalebarChartPanel.setMaximumDrawWidth(3000);
        
        // Set anti-aliasing
        boolean on = Property.CHART_VIEWER_ANTI_ALIASING.getBooleanValue();
        scalebarChartPanel.getChart().setAntiAlias(on);

        add(scalebarChartPanel, BorderLayout.WEST);
        setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
    }

    /**
     * Set the color model and the data range.
     * 
     * @param colorModel
     * @param transparency
     * @param min Minimum data range.
     * @param max Maximum data range.
     */
    public void setColorModel(IndexColorModel colorModel, float transparency, double min, double max)
    {
        Image image = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(1, 256, colorModel, buf, 0, 1));

        NumberAxis range = (NumberAxis) scalebarPlot.getRangeAxis();
        
        scalebarPlot.setBackgroundImage(image);
        scalebarPlot.setBackgroundImageAlpha(transparency);

        //  Force min < max
        if ( min >= max )
        {
        	double min_tmp = Math.min(min, max);
        	double max_tmp = Math.max(min, max);
        	
        	min = min_tmp;
        	max = max_tmp;
        }
        	
        //  Set a lower bound for log axis
        if ( range instanceof FrequencyLogAxis )
        {
            if ( min <= 0 )
                min = Math.ulp(1);
            ((FrequencyLogAxis) range).setMinTickValue(min);
        }
        
        max = Math.max(max, min + Math.ulp(min));
        
        range.setRange(min, max);
    }

    /**
     * Set the title displayed at the top of the color bar
     * 
     * @param value
     */
    public void setTitle(String value)
    {
        scalebarChart.setTitle(value);
    }
    
    /**
     * Control whether the Y Axis is linear or log
     * 
     * @param log true if log, false if linear
     */
    public void setYAxisLog(boolean log)
    {
        Range oldRange = scalebarPlot.getRangeAxis().getRange();
        
        NumberAxis range;
        
        if ( log )
        {
            range = new FrequencyLogAxis("");
            ((FrequencyLogAxis) range).setMaxTickCount(5);
        }
        else
        {
            range = new NumberAxis("");
        }
        
        int size = Property.FONT_SIZE.getIntegerValue();
        Font font = new Font(Font.SANS_SERIF, Font.PLAIN, size);

        range.setAutoRange(false);
        range.setTickLabelFont(font);
        range.setNumberFormatOverride(new DecimalFormat("##0.000"));
        range.setRange(oldRange);
        
        scalebarPlot.setRangeAxis(range);
    }
}
