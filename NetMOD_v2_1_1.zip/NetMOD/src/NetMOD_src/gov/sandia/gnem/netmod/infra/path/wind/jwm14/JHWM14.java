/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.path.wind.WindModelPlugin;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Simulation;

import java.util.Calendar;
import java.util.Map;
import java.util.WeakHashMap;


public class JHWM14 extends AbstractNetModComponent implements WindModel {

  private static final String _type = "HWM14";

  //  Register the plugin
  static {
    WindModelPlugin.getPlugin().registerComponent(_type, JHWM14.class, true);
  }

  private Map<Thread, HWM14> _threadMap = new WeakHashMap<Thread, HWM14>();

  private double[] ap;

  public JHWM14(NetModComponent parent) {
    super(parent, _type, "Horizontal Wind Model (2014)");

    ap = new double[]{0.0, 0.0};
  }

  public Layer<?> getMapLayer() {
    if (NetMOD.getMap() == null) {
      return null;
    }

    return NetMOD.getMap().createWindModelLayer(this);
  }

  @Override
  public Complex getWindVelocity(Time time, double altitude, Point.Double location) {
    Calendar cal = time.getCalendar();
    int iyd = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR);
    double ut = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60
        + cal.get(Calendar.SECOND) / 3600 + cal.get(Calendar.MILLISECOND) / 3600000;
    double sec = ut * 3600.0;

    double[] w = new double[2];

    // Construct the wind model inside the call so that it is thread safe
    HWM14 windModel;
    synchronized (this) {
      windModel = _threadMap.get(Thread.currentThread());
      if (windModel == null) {
        windModel = new HWM14();
        _threadMap.put(Thread.currentThread(), windModel);
      }
    }

    try {
      double stl = ((ut + location.getLongitude() / 15.0) % 24);
      windModel.simulation(iyd, sec, altitude, location.getLatitude(), location.getLongitude(), stl,
          0.0f, 0.0f, ap, w);
    } catch (Exception e) {
      e.printStackTrace();
    }

    return new Complex(w[1], w[0]);
  }

  @Override
  public Complex getWindVelocity(double altitude, Point.Double location) {
    Time time = new Time(0);

    //  Get the simulation time (Simulation -> Path -> JWHM)
    NetModComponent parent = getParent();
    if (parent instanceof Paths) {
      NetModComponent grandparent = parent.getParent();
      if (grandparent instanceof Simulation) {
        time = ((Simulation) grandparent).getSimulationTime();
      }
    }

    return getWindVelocity(time, altitude, location);
  }
}
