/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.XYPlot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * @author bjmerch
 *
 */
public class JFreeChartSourceSelectionTool extends AbstractAction
{
    private Sources _sources;
    private ChartViewer _chartViewer;

    public JFreeChartSourceSelectionTool(ChartViewer chartViewer, Sources sources)
    {
        _chartViewer = chartViewer;
        _sources = sources;
    }

    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        boolean selected = (Boolean) getValue(SELECTED_KEY);

        if (!selected)
        {
            _chartViewer.setListeners(null, null, null, null);
        }
        else
        {
            //  Create a listener for the chart
            MouseAdapter selectListener = new MouseAdapter()
            {
                private Point _startPoint = null;
                private Rectangle2D _selectRectangle = null;

                /**
                 * Mouse button has been pushed and held and is now being moved (dragged) 
                 * across the screen.
                 */
                @Override
                public void mouseDragged(MouseEvent e)
                {
                    // Only draw zoom rectangles on a left mouse button click
                    if (SwingUtilities.isLeftMouseButton(e))
                    {
                        ChartPanel chartPanel = (ChartPanel) e.getSource();
                        Graphics2D g2 = (Graphics2D) chartPanel.getGraphics();

                        // Erase the previous rectangle (if any)
                        g2.setXORMode(java.awt.Color.gray);
                        if (_selectRectangle != null)
                            g2.draw(_selectRectangle);

                        if (_startPoint == null)
                            return;

                        // Draw the new zoom rectangle
                        _selectRectangle = new Rectangle2D.Double(_startPoint.getX(), _startPoint.getY(), 0, 0);
                        _selectRectangle.add(e.getPoint());

                        g2.draw(_selectRectangle);
                        g2.dispose();
                    }
                }

                /**
                 * Initial press-and-hold prior to zooming.
                 */
                @Override
                public void mousePressed(MouseEvent e)
                {
                    _startPoint = e.getPoint();

                    // Add a key listener to the ChartPanel to cancel a zoom operation when
                    // the ESCAPE key is pressed.
                    final ChartPanel chartPanel = (ChartPanel) e.getSource();
                    for (KeyListener kl : chartPanel.getKeyListeners())
                    {
                        chartPanel.removeKeyListener(kl);
                    }
                    chartPanel.setFocusable(true);
                    chartPanel.requestFocusInWindow();
                    chartPanel.addKeyListener(new KeyAdapter()
                    {
                        public void keyPressed(KeyEvent e)
                        {
                            if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
                            { // cancel zoom operation
                                SwingUtilities.updateComponentTreeUI(chartPanel);
                                _startPoint = null;
                                _selectRectangle = null;
                            }
                        }
                    });
                }

                /**
                 * Mouse released after dragging.
                 */
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    ChartPanel chartPanel = (ChartPanel) e.getSource();
                    if (chartPanel == null)
                        return;

                    // Complete the zooming drag box
                    if (_selectRectangle != null && SwingUtilities.isLeftMouseButton(e))
                    {
                        //  Convert the select rectangle from screen coordinates
                        XYPlot plot = _chartViewer.getPlot();

                        Point2D p1 = chartPanel.translateScreenToJava2D(new Point((int) _selectRectangle.getMinX(), (int) _selectRectangle.getMaxY()));
                        Point2D p2 = chartPanel.translateScreenToJava2D(new Point((int) _selectRectangle.getMaxX(), (int) _selectRectangle.getMinY()));

                        double minLon = plot.getDomainAxis().java2DToValue(p1.getX(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
                        double maxLon = plot.getDomainAxis().java2DToValue(p2.getX(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
                        double minLat = plot.getRangeAxis().java2DToValue(p1.getY(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
                        double maxLat = plot.getRangeAxis().java2DToValue(p2.getY(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());

                        //  Get the current epicenter grid
                        EpicenterGrid grid = _sources.getEpicenterGrid();

                        //  Get the defined deltas
                        double deltaLat = grid.getLatitudeDelta();
                        double deltaLon = grid.getLongitudeDelta();

                        //  Resample the current grid onto the selected region
                        int minLatIndex = (int) Math.ceil((minLat - grid.getLatitudeStart()) / deltaLat);
                        int minLonIndex = (int) Math.ceil((minLon - grid.getLongitudeStart()) / deltaLon);
                        int maxLatIndex = (int) Math.floor((maxLat - grid.getLatitudeStart()) / deltaLat);
                        int maxLonIndex = (int) Math.floor((maxLon - grid.getLongitudeStart()) / deltaLon);

                        //  insert the new values
                        grid.setLatitude(grid.getLatitudeStart() + minLatIndex * deltaLat, grid.getLatitudeStart() + maxLatIndex * deltaLat, deltaLat);
                        grid.setLongitude(grid.getLongitudeStart() + minLonIndex * deltaLon, grid.getLongitudeStart() + maxLonIndex * deltaLon, deltaLon);

                        //  Refresh
                        NetMOD.refresh(grid);
                        grid.getViewer().refresh();
                    }

                    _startPoint = null;
                    _selectRectangle = null;
                }
            };

            //  Add the listener
            _chartViewer.setListeners(null, selectListener, selectListener, Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
        }
    }
}
