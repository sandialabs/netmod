/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.infra.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.NetSimParameters.ExplosionType;
import gov.sandia.gnem.netmod.io.TripleCacheMap;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * Extend signal amplitudes for infrasound using LANL's equations
 * Whitaker (2003)
 * Green and Bowers (2010)
 * 
 * @author bjmerch
 *
 */
public class LANLInfraSignalAmplitude extends AbstractInfrasoundSignalAmplitude
{
    public static final String TYPE = "LANL";
    static
    {
        InfraSignalAmplitudePlugin.getPlugin().registerComponent(TYPE, LANLInfraSignalAmplitude.class);
    }

    //  Cache wind velocities based upon epicenter and station location
    private double _cacheTime = 0;
    private TupleCacheMap<Point.Double, Point.Double, Complex> _velocityCache = new TupleCacheMap<Point.Double, Point.Double, Complex>(null,
            CacheMap.CACHE_SOURCE, CacheMap.CACHE_RECEIVER);

    //  Cache source spectra
    //  Include the epicenter location just to reduce number of map collisions.
    private TripleCacheMap<Frequency, Point.Double, Magnitude, SpectraDouble> _sourceCache = new TripleCacheMap<Frequency, Point.Double, Magnitude, SpectraDouble>(
            null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_SOURCE, CacheMap.CACHE_MAGNITUDE);

    /**
     * @param parent
     */
    public LANLInfraSignalAmplitude(NetModComponent parent)
    {
        super(parent, TYPE, "LANL / Green & Bowers (2010) ");
    }

    @Override
    public void clearCache()
    {
        super.clearCache();

        _velocityCache.clear();
        _sourceCache.clear();
    }

    @Override
    protected SpectraPDF computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        //  Compute the range in kilometers
        double R = distance.getDistanceMeters() / 1000.0;

        //  Check cache
        if (_cacheTime != time.getTimeSeconds())
        {
            _velocityCache.clear();
            _cacheTime = time.getTimeSeconds();
        }

        //  Compute wind velocity
        double velocity = computeWindVelocity(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, WindModel.ALTITUDE_KM,
                _velocityCache);

        //  Compute the wind correction
        double windCorrection = 0.018 * velocity;

        double mean_log10 = -1.4072 * Math.log10(R) + windCorrection;
        double std_log10 = 0.16;

        NormalPDF attenuation = new NormalPDF(mean_log10, std_log10);

        recordIntrospection("Path Attenuation (log10 Amplitude): ", attenuation);
        recordIntrospection("Distance (km): ", R);
        recordIntrospection("Wind Correction (log10 Amplitude): ", windCorrection);
        stopIntrospection();

        return new SpectraPDF(attenuation);
    }

    @Override
    protected SpectraDouble computeLogSourceSpectra(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();
        SpectraDouble a = _sourceCache.get(frequency, epicenter, magnitude);

        //  Handle yield in KT
        if (magnitude.getMagnitudeType() == MagnitudeType.KT)
        {
            //  Get the yield in KT
            double yield_kt = magnitude.getMagnitude();
			if ( yield_kt == 0 )
				a = SpectraDouble.NEGATIVE_999;
            
			ExplosionType explosionType = ((gov.sandia.gnem.netmod.infra.source.Sources) sources).getExplosionType();
			double explosionCorrection = 1.0;
            if ( explosionType == ExplosionType.CHEMICAL )
            {
            	explosionCorrection = 2.0;
            }
            else if ( explosionType == ExplosionType.NUCLEAR )
            {
            	explosionCorrection = 1.0;
            }

            //  Determine the dominant frequency around which 90% of amplitude is within +/- an octave
            double dominant_freq = 1.0 / (5.92 * Math.pow(explosionCorrection * yield_kt / 2.0, 1 / 3.34));

            if (a == null)
            {
                //  Get the amplitude peak-to-peak in pascals +/- an octave around the dominant frequency at 1 km distance
                double amplitude_pp_ubar = 59500 * Math.pow(1 / Math.sqrt(explosionCorrection * yield_kt), -1.4072);
                double amplitude_pp_pa = amplitude_pp_ubar / 10;

                //  Convert the peak-to-peak amplitude to an RMS amplitude
                //  Assumed factor of 6, Green & Bower (2010)
                double amplitude_rms_pa = amplitude_pp_pa / 6;

                //  Create a distribution describing how 90% of amplitude is distributed across +/- an octave of frequency.
                //  Assume distribution is normal normal wrt log-frequency with the mean of the distribution at the log dominant frequency
                //  and the standard deviation scaled to include 90% of the amplitudes.
                double std = Math.log10(2) / 1.645;
                double mean = Math.log10(dominant_freq);
                NormalPDF amplitude_distribution = new NormalPDF(mean, std);

                //  Determine the frequencies to evaluate
                double[] f = frequency.getFrequencySamples();

                a = new SpectraDouble(f.length);
                for (int i = 0; i < f.length; i++)
                {
                	double value = Math.log10(amplitude_rms_pa * amplitude_distribution.computeProbabilityDensity(Math.log10(f[i])));
                	value = Math.max(-999, value);
                	
                    a.setValue(i, f[i], value);
                }
            }

            recordIntrospection("Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Explosion: " + explosionType);
            recordIntrospection("Yield (kT): ", yield_kt);
            recordIntrospection("Dominant Frequency (Hz): ", dominant_freq);
        }
        else if (magnitude.getMagnitudeType() == MagnitudeType.Pa)
        {
            if (a == null)
                a = new SpectraDouble(magnitude.getMoment());

            recordIntrospection("Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Magnitude (log10 Magnitude): ", magnitude);
        }
        else
        {
            if (a == null)
                a = new SpectraDouble(0);

            recordIntrospection("Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Magnitude (log10 Magnitude): ", magnitude);
        }

        _sourceCache.put(frequency, epicenter, magnitude, a);

        stopIntrospection();

        return a;
    }
}
