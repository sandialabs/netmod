/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

import com.carrotsearch.hppc.DoubleObjectOpenHashMap;
import gov.sandia.gnem.netmod.probability.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A Spectra of PDF values
 * Assumes that the frequencies are arranged in a monotonically increasing order.
 * 
 * @author bjmerch
 *
 */
public class SpectraPDF extends Spectra
{
    public static final SpectraPDF NEGATIVE_999 = new SpectraPDF(NormalPDF.NEGATIVE_999);
    public static final SpectraPDF ZERO = new SpectraPDF(NormalPDF.ZERO);
    
    private PDF[] _values;
   
    //  Cache of requested PDF values for specific frequencies
    private transient DoubleObjectOpenHashMap<PDF> _cache = new DoubleObjectOpenHashMap<PDF>();

    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param pdf
     */
    public SpectraPDF(double f, PDF pdf)
    {
        this(1);
        _frequencies[0] = f;
        _values[0] = pdf;
    }
    
    /**
     * Construct a new spectra object with N frequencies
     * 
     * @param N
     */
    public SpectraPDF(int N)
    {
    	super(N);
        _values = new PDF[N];
    }
    
    /**
     * Construct a new spectra object with the frequencies
     * 
     * @param N
     */
    public SpectraPDF(double[] freqs)
    {
    	super(freqs);
        _values = new PDF[getLength()];
    }
    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param pdf
     */
    public SpectraPDF(PDF pdf)
    {
        this(0.0, pdf);
    }
    
    /**
     * Create a copy of the provided spectra with the optional standard deviation 
     * 
     * @param spectra
     * @param std Standard deviation value to use if there is none defined in spectra
     */
    public SpectraPDF(Spectra spectra, double std)
	{
    	this(spectra.getFrequencies());

		int N = spectra.getLength();
		
    	if ( spectra instanceof SpectraPDF )
    	{
    		for (int i=0; i<N; i++)
    		{
    			double f = spectra.getFrequency(i);
    			PDF pdf = ((SpectraPDF) spectra).getValue(i);
    			
    			if ( pdf.getStandardDeviation() > 0 )
    				setValue(i, f, pdf);
    			else
    				setValue(i, f, new NormalPDF(pdf.getMean(), std));
    		}
    	}
    	else if ( spectra instanceof SpectraDouble )
    	{
    		for (int i=0; i<N; i++)
    		{
    			double f = spectra.getFrequency(i);
    			double mean = ((SpectraDouble) spectra).getValue(i);
    			
    			setValue(i, f, new NormalPDF(mean, std));
    		}
    	}
	}
    
    
    /**
     * Create a PDF spectra from the provided double spectra mean
     * and a standard deviation
     * 
     * @param mean
     * @param stddev
     */
    public SpectraPDF(SpectraDouble mean, double stddev)
    {
        this(mean.getLength());
        
        int N = getLength();
        for (int i=0; i<N; i++)
            setValue(i, mean.getFrequency(i), new NormalPDF(mean.getValue(i), stddev));
    }
    
    /**
     * Create a Spectra of PDF values from the provided mean and standard deviations
     * 
     * @param mean
     * @param sd
     */
    public SpectraPDF(SpectraDouble mean, SpectraDouble sd)
    {
        this(mean.getLength());
        
        int N = getLength();
        for (int i=0; i<N; i++)
        {
            double f = mean.getFrequency(i);
            double mu = mean.getValue(i);
            
            if ( Double.isNaN(mu) || Double.isInfinite(mu) )
                mu = 999;
            
            if ( sd == null )
                setValue(i, f, new NormalPDF(mu, 0));
            else
            {
                double sigma = sd.getFrequencyValue(f);
                if ( Double.isNaN(sigma) )
                    sigma = 0;
                else if ( Double.isInfinite(sigma) )
                    sigma = 999;
                
                setValue(i, f, new NormalPDF(mu, sigma));
            }
        }
    }

    /**
     * Construct a new spectra that is a copy of the provided spectra
     * 
     * @param spectra
     */
    public SpectraPDF(SpectraPDF spectra)
    {
    	this(spectra.getLength());
        set(spectra);
    }

	@Override
    public SpectraPDF add(double value)
    {
        if ( value == 0 )
            return this;
        
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(value);
        
        return this;
    }

    @Override
	public SpectraPDF add(double value, PDF pdf)
	{
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(value, pdf);
        
        return this;
	}
    
    @Override
	public SpectraPDF add(double value, PDF pdf, SpectraDouble spectra)
	{
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(value + spectra.getFrequencyValue(getFrequency(i)), pdf);
        
        return this;
	}
    
    @Override
	public SpectraPDF add(int index, double value)
	{
        _cache.clear();
        
        _values[index] = _values[index].add(value);
        
        return this;
	}

	public SpectraPDF add(PDF pdf)
    {
        _cache.clear();

        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(pdf);
        
        return this;
    }

    @Override
	public SpectraPDF add(PDF pdf, SpectraPDF spectra)
	{
        _cache.clear();
        
        int N = getLength();
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(pdf, spectra.getFrequencyValue(getFrequency(i)));
        
        return this;
	}

    @Override
	public Spectra add(Spectra spectra)
	{
        _cache.clear();
        
        int N = getLength();

    	if ( spectra instanceof SpectraPDF )
    	{
    		for (int i=0; i<N; i++)
    			_values[i] = _values[i].add(((SpectraPDF) spectra).getFrequencyValue(getFrequency(i)));
    	}
    	else if ( spectra instanceof SpectraDouble )
    	{
    		for (int i=0; i<N; i++)
    			_values[i] = _values[i].add(((SpectraDouble) spectra).getFrequencyValue(getFrequency(i)));
    	}
        
        return this;
	}
    
    /**
     * Add the provided spectra to this spectra
     * Returns a reference to this object.
     * 
     * @param spectra
     * @return
     */
    public SpectraPDF add(SpectraDouble... spectras)
    {
        _cache.clear();

        int N = _values.length;
        int M = spectras.length;
        
        for (int i=0; i<N; i++)
        {
        	double sum = 0;
        	for (int j=0; j<M; j++)
        		sum += spectras[j].getFrequencyValue(_frequencies[i]);
        	
        	_values[i] = _values[i].add(sum);
        }
        
        return this;
    }
    
    /**
     * Add the provided spectra to this spectra
     * Return a reference to this object.
     * 
     * @param spectra
     * @return
     */
    public SpectraPDF add(SpectraPDF... spectras)
    {
        _cache.clear();

        int N = _values.length;
        int M = spectras.length;
        PDF[] pdfs = new PDF[M];
        
        for (int i=0; i<N; i++)
        {
        	for (int j=0; j<M; j++)
        		pdfs[j] = spectras[j].getFrequencyValue(_frequencies[i]);
        	
        	_values[i] = _values[i].add(pdfs);
        }
        
        return this;
    }

	/**
     * Add the provided spectra to this spectra
     * Return a reference to this object.
     * 
     * @param spectra
     * @return
     */
    public SpectraPDF add(SpectraPDF spectra)
    {
        _cache.clear();

        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].add(spectra.getFrequencyValue(_frequencies[i]));
        
        return this;
    }
    
    @Override
	public SpectraPDF addScaled(double scale, Spectra spectra)
	{
        _cache.clear();
        
        int N = _values.length;
        
        if ( spectra instanceof SpectraDouble )
        {
        	SpectraDouble sd = (SpectraDouble) spectra;
        	
        	for (int i=0; i<N; i++)
        		_values[i] = _values[i].add(scale * sd.getFrequencyValue(getFrequency(i)));
        }
        else if ( spectra instanceof SpectraPDF )
        {
        	SpectraPDF sp = (SpectraPDF) spectra;
        	
        	for (int i=0; i<N; i++)
        		_values[i] = _values[i].add(sp.getFrequencyValue(getFrequency(i)).scale(scale));
        }
        
        return this;
	}

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof SpectraPDF) )
            return false;
        
        SpectraPDF s = (SpectraPDF) o;

        return Arrays.equals(s._frequencies, _frequencies) && Arrays.deepEquals(s._values, _values);
    }
    
    @Override
    public int hashCode()
    {
    	return Arrays.hashCode(_frequencies);
    }

    /**
     * Get the frequency for the provided index
     * 
     * @param index
     * @return
     */
    public double getFrequency(int index)
    {
        return _frequencies[index];
    }

    /**
     * Get the value for the provided frequency
     * 
     * @param frequency
     * @return
     */
    public PDF getFrequencyValue(double frequency)
    {
        int N = getLength();
        if (N == 0)
            return NormalPDF.ZERO;
        else if (N == 1)
            return _values[0];

        PDF value = _cache.get(frequency);

        if (value == null)
        {
            int index = NumericUtility.findIndexAscending(_frequencies, frequency);

            if (_frequencies[index] == frequency)
                value = _values[index];
            else
            {
                int i1 = Math.max(0, Math.min(N - 2, index - 1));
                int i2 = Math.max(1, Math.min(N - 1, index));

                double f1 = _frequencies[i1];
                double f2 = _frequencies[i2];
                
                //  value = pdf1 + ( f - f1 ) / (f2 - f1) * (pdf2 - pdf1)
                //  Rearranged to minimize PDF addition / subtraction
                double df = (frequency - f1) / (f2 - f1);
                PDF pdf1 = _values[i1].scale(1.0 - df);
                PDF pdf2 = _values[i2].scale(df);

                value = pdf1.add(pdf2);
            }
            
            _cache.put(frequency, value);
        }
        
        return value;
    }

    /**
     * Get the length of the spectra
     * 
     * @return
     */
    public int getLength()
    {
        return _frequencies.length;
    }

    @Override
	public double getMean()
	{
        int N = getLength();
        if ( N == 0 )
            return 0.0;
        else if ( N == 1 )
            return _values[0].getMean();
        
        //  Get the minimum frequency
        double sum = _values[0].getMean() * ((_frequencies[1] - _frequencies[0]) / 2.0);
        
        //  Get the middle frequencies
        for (int i=1; i<N-1; i++)
        {
            double df = (_frequencies[i+1] - _frequencies[i-1]) / 2.0;
            
            sum += _values[i].getMean() * df;
        }
        
        //  Get the maximum frequency
        sum += _values[N-1].getMean() * ((_frequencies[N-1] - _frequencies[N-2]) / 2.0);
        
        double mean = sum / (_frequencies[N-1] - _frequencies[0]);
        
        return mean;
	}

    @Override
	public double getMean(int i)
	{
		return getValue(i).getMean();
	}

    /**
     * Get the mean value, accounting for the frequency spacing.
     * Assume that the values are log10.
     * 
     * @return
     */
    public double getMeanLog()
    {
        int N = getLength();
        if ( N == 0 )
            return 0.0;
        else if ( N == 1 )
            return _values[0].getMean();
        
        //  Get the minimum frequency
        double sum = _values[0].getMean() * ((_frequencies[1] - _frequencies[0]) / 2.0);
        
        //  Get the middle frequencies
        for (int i=1; i<N-1; i++)
        {
            double df = _frequencies[i+1] - _frequencies[i-1] / 2.0;
            
            sum += _values[i].getMean() * df;
        }
        
        //  Get the maximum frequency
        sum += _values[N-1].getMean() * ((_frequencies[N-1] - _frequencies[N-2]) / 2.0);
        
        double mean = sum / (_frequencies[N-1] - _frequencies[0]);
        
        return mean;
    }
    
    /**
     * Get the mean PDF, accounting for the frequency spacing.
     * Treat the PDF as if it is a log variable
     * 
     * @return
     */
    public PDF getMeanLogPDF()
    {
        int N = getLength();
        if ( N == 0 )
            return NormalPDF.ZERO;
        else if ( N == 1 )
            return _values[0];
        
        List<PDF> sum = new ArrayList<PDF>();
        
        //  Get the minimum frequency
        sum.add(_values[0].scale((_frequencies[1] - _frequencies[0]) / 2.0));
        
        //  Get the middle frequencies
        for (int i=1; i<N-1; i++)
            sum.add(_values[i].scale((_frequencies[i+1] - _frequencies[i-1]) / 2.0));
        
        //  Get the maximum frequency
        sum.add(_values[N-1].scale((_frequencies[N-1] - _frequencies[N-2]) / 2.0));
        
        return AbstractPDF.sum(sum).scale(1.0 / (_frequencies[N-1] - _frequencies[0]));
    }
    
    /**
     * Get the mean values
     * 
     * @return
     */
    public SpectraDouble getMeanSpectra()
    {
        int N = getLength();
        
        SpectraDouble mean = new SpectraDouble(N);
        
        for (int i=0; i<N; i++)
            mean.setValue(i, getFrequency(i), getValue(i).getMean());
        
        return mean;
    }

    /**
     * Get the standard deviation
     * 
     * @return
     */
    public SpectraDouble getStandardDeviation()
    {
        int N = getLength();
        
        SpectraDouble mean = new SpectraDouble(N);
        
        for (int i=0; i<N; i++)
            mean.setValue(i, getFrequency(i), getValue(i).getStandardDeviation());
        
        return mean;
    }

    @Override
	public double getStandardDeviation(int i)
	{
		return getValue(i).getStandardDeviation();
	}

	@Override
	public SpectraDouble getStandardDeviationSpectra()
	{
        int N = getLength();
        
        SpectraDouble std = new SpectraDouble(N);
        
        for (int i=0; i<N; i++)
            std.setValue(i, getFrequency(i), getValue(i).getStandardDeviation());
        
        return std;
	}

	@Override
    public PDF getValue(int index)
    {
        return _values[index];
    }

	@Override
	public PDF[] getValues()
	{
		return _values;
	}

	@Override
    public SpectraPDF log10()
    {
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].log10();
        
        return this;
    }
	
	/**
     * Compute the difference (subtraction) between this SpectraPDF and the provided SpectraPDF
     * 
     * @param spectra
     * @return
     */
    public SpectraPDF minus(SpectraPDF spectra)
    {
        int N = getLength();
        SpectraPDF newSpectra = new SpectraPDF(N);
        
        for (int i=0; i<N; i++)
            newSpectra.setValue(i, getFrequency(i), getValue(i).minus(spectra.getFrequencyValue(getFrequency(i))));
        
        return newSpectra;
    }

    @Override
    public SpectraPDF pow10()
    {
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].pow10();
        
        return this;
    }

    @Override
    public SpectraPDF scale(double value)
    {
        return scale(value, 0);
    }

	@Override
    public SpectraPDF scale(double a, double b)
    {
        if ( a == 1 && b == 0 )
            return this;
        
        _cache.clear();
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] = _values[i].scale(a, b);
        
        return this;
    }

	@Override
	public Spectra scale(double value, Spectra... spectras)
	{
		int N = getLength();
		
		for (int i=0; i<N; i++)
		{
			double f = getFrequency(i);
			PDF pdf = getValue(i);
			
			double x = value;
			
			for (Spectra s : spectras)
			{
				if ( s instanceof SpectraDouble )
					x *= ((SpectraDouble) s).getFrequencyValue(f);
				else if ( s instanceof SpectraPDF )
					x *= ((SpectraPDF) s).getFrequencyValue(f).getMean();	
			}
			
			setValue(i, pdf.scale(x));
		}
		
		return this;
	}

	public void setValue(int index, double frequency, PDF value)
    {
        _cache.clear();
        
        _frequencies[index] = frequency;
        _values[index] = value;
    }

	public void setValue(int index, PDF value)
    {
        _cache.clear();
        
        _values[index] = value;
    }

	/**
	 * Convert the underlying PDF objects to Monte Carlo PDF realizations if N is > 1
	 * 
	 * @param prng
	 * @param n
	 * @return
	 */
	public SpectraPDF toMonteCarlo(PRNG prng, int N)
    {
		int M = getLength();
		
		if ( N <= 1 )
		{
			//  Check if any of the PDFs are NonParametricCDF
			for (int i=0; i<M; i++)
				if ( getValue(i) instanceof NonParametricCDF )
					return toSimplePDF();
			
			return this;
		}
		
		SpectraPDF spectraPDF = new SpectraPDF(M);
		
		for (int i=0; i<M; i++)
			spectraPDF.setValue(i, getFrequency(i), getValue(i).toMonteCarlo(prng, N));
		
		return spectraPDF;
    }

	/**
	 * Convert the underlying PDF objects to simple (not NonParametricCDF) realizations
	 * 
	 * @return
	 */
	private SpectraPDF toSimplePDF()
    {
		int M = getLength();
		SpectraPDF spectraPDF = new SpectraPDF(M);
		
		for (int i=0; i<M; i++)
			spectraPDF.setValue(i, getFrequency(i), getValue(i).toSimplePDF());
		
		return spectraPDF;
    }

	@Override
	public Spectra set(Spectra spectra)
	{
		if (spectra == this)
			return this;

		int N = spectra.getLength();
		_frequencies = Arrays.copyOf(spectra._frequencies, N);

		_values = new PDF[N];
		if ( spectra instanceof SpectraDouble )
		{
			for (int i=0; i<N; i++)
				_values[i] = new NormalPDF(((SpectraDouble) spectra).getValues()[i], 0.0);
		}
		else if ( spectra instanceof SpectraPDF )
		{
			for (int i=0; i<N; i++)
				_values[i] = ((SpectraPDF) spectra).getValue(i);
		}

		return this;
	}
}
