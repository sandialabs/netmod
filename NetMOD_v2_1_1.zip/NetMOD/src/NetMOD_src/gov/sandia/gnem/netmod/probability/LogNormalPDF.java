/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.numeric.NumericUtility;

/**
 * A log-normally distributed Probability Density Function
 * 
 * @author bjmerch
 *
 */
public class LogNormalPDF extends AbstractPDF
{
    public static final LogNormalPDF ZERO = new LogNormalPDF(0,0);
    public static final LogNormalPDF NEGATIVE_999 =  new LogNormalPDF(-999,0);
    public static final LogNormalPDF NEGATIVE_INFINITY = new LogNormalPDF(Double.NEGATIVE_INFINITY, 0);
    
    private double _mean;
    private double _std;

    /**
     * Construct a LogNormal distribution using
     * the mean and standard deviation values from 
     * the corresponding Normal distribution.
     * 
     * @param mean
     * @param std
     */
    public LogNormalPDF(double mean, double std)
    {
        _mean = mean;
        _std = std;
    }

    @Override
    public PDF add(double x, PDF... pdfs)
    {
        //  Check if any aren't a log normal PDF
        for (PDF pdf : pdfs)
            if (!(pdf instanceof LogNormalPDF))
                return super.add(x, pdfs);

        /* 
         * Sum the provided Log Normal PDFs
         * using the Fenton-Wilkinson approximation
         */

        int N = pdfs.length;
        if (N == 0)
            return this;

        //  Extract the mean and std from the variables and convert from log10 to natural log
        double[] mean = new double[N + 1];
        double[] std = new double[N + 1];

        mean[0] = getMean() * _log10Conversion;
        std[0] = getStandardDeviation() * _log10Conversion;
        for (int i = 0; i < N; i++)
        {
            mean[i + 1] = pdfs[i].getMean() * _log10Conversion;
            std[i + 1] = pdfs[i].getStandardDeviation() * _log10Conversion;
        }

        //  Compute the mean and variances of the equivalent log-normal distribution
        double[] var_log = new double[N+1];
        double[] mean_log = new double[N+1];
        for (int i = 0; i < N+1; i++)
        {
            double var = std[i] * std[i];

            var_log[i] = Math.exp(2 * mean[i] + var) * (Math.exp(var) - 1);
            mean_log[i] = Math.exp(mean[i] + 0.5 * var);
        }

        //  Sum the mean and variance
        double sum_var = Math.log(NumericUtility.sum(var_log) / Math.pow(NumericUtility.sum(mean_log), 2) + 1);
        if ( Double.isInfinite(sum_var) || Double.isNaN(sum_var) )
            sum_var = 0;
        
        double sum_mean = Math.log(NumericUtility.sum(mean_log)) - sum_var / 2;
        if ( Double.isInfinite(sum_mean) || Double.isNaN(sum_mean) )
            sum_mean = NumericUtility.sum(mean);

        //  Convert from natural log back to log10
        double sum_std = Math.sqrt(sum_var) / _log10Conversion;
        sum_mean = sum_mean / _log10Conversion;

        return new LogNormalPDF(sum_mean + x, sum_std);
    }

    @Override
    public double computeCumulativeDistribution(double x)
    {
        double mean = getMean();
        double std = getStandardDeviation();

        //  Change of variables from log10 to log
        mean = mean * NormalPDF._log10Conversion;
        std = std * NormalPDF._log10Conversion;

        double logX = Math.log(x);

        return 0.5 * (1 + erf((logX - mean) / (Math.sqrt(2) * std)));
    }

    @Override
    public double computeProbabilityDensity(double x)
    {
        double mean = getMean();
        double std = getStandardDeviation();
        
        //  Change of variables from log10 to log
        mean = mean * NormalPDF._log10Conversion;
        std = std * NormalPDF._log10Conversion;

        double logX = Math.log(x);

        return 1.0 / (x * std * Math.sqrt(2 * Math.PI)) * Math.exp(-(logX - mean) * (logX - mean) / (2.0 * std * std));
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof LogNormalPDF) )
            return false;
        
        LogNormalPDF pdf = (LogNormalPDF) o;
        
        return NumericUtility.equals(_mean, pdf._mean, 1e-6) && NumericUtility.equals(_std, pdf._std, 1e-6);
    }

    @Override
    public String getDescription()
    {
        return "Log-Normal";
    }

    @Override
    public double getMax()
    {
        double mean = getMean();
        double sd = getStandardDeviation();

        //  Inverse of the CDF to include 99.999 % of value
        double p = 0.99999;

        return Math.exp(erf_inverse((p - 0.5) * 2) * Math.sqrt(2) * sd + mean);
    }

    /**
     * @return the mean
     */
    @Override
    public double getMean()
    {
        return _mean;
    }

    @Override
    public double getMin()
    {
        return _mean;
    }

    /**
     * @return the standardDeviation
     */
    @Override
    public double getStandardDeviation()
    {
        return _std;
    }

    /**
     * @return the variance
     */
    @Override
    public double getVariance()
    {
        return _std * _std;
    }

    @Override
    public int hashCode()
    {
		return (int) (Double.doubleToLongBits(getMean()) + Double.doubleToLongBits(getStandardDeviation()));
    }

    @Override
    public PDF log10()
    {
        return new NormalPDF(getMean(), getStandardDeviation());
    }

    @Override
    public PDF scale(double a, double b)
    {
        if ( a == 1 && b == 0 )
            return this;
        
        return new LogNormalPDF(Math.log(a) / _log10Conversion + getMean() + b, getStandardDeviation());
    }

	@Override
    public MonteCarloPDF toMonteCarlo(PRNG prng, int n)
    {
        //  Declare early for optimization
        int i;
        
		MonteCarloPDF pdf = new MonteCarloPDF(prng, n);
        double[] values = pdf.getValues();
        
        //  Generate a uniform random values [0..1]
        prng.nextNormals(values, _mean, _std);

        //  Transform the random variable using the inverse CDF
        int N = values.length;
        for (i = 0; i < N; i++)
            values[i] = Math.pow(10, values[i]);
        
        return pdf;
    }

	@Override
    public PDF toSimplePDF()
    {
		return this;
    }

	@Override
    public String toString()
    {
        return "Log-Normal(" + GUIUtility.format(getMean()) + ", " + GUIUtility.format(getStandardDeviation()) + ")";
    }
}
