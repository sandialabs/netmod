/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.introspection;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.IOUtility;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 * Viewer for displaying an introspection object
 * 
 * @author bjmerch
 *
 */
public class IntrospectionViewer extends JDialog
{
    private class CustomTreeUI extends BasicTreeUI
    {
//        private Icon expandedIcon = Icons.DOWN.getIcon();
//        private Icon collapsedIcon = Icons.RIGHT.getIcon();

        //        @Override
        //        protected AbstractLayoutCache.NodeDimensions createNodeDimensions()
        //        {
        //            return new NodeDimensionsHandler()
        //            {
        //                @Override
        //                public Rectangle getNodeDimensions(Object value, int row, int depth, boolean expanded, Rectangle size)
        //                {
        //                    Rectangle dimensions = super.getNodeDimensions(value, row, depth, expanded, size);
        //                    dimensions.width = 300 - getRowX(row, depth);
        //                    return dimensions;
        //                }
        //            };
        //        }

        //  Prevent horizontal lines from being drawn

//        @Override
//        public Icon getCollapsedIcon()
//        {
//            return collapsedIcon;
//        }
//
//        @Override
//        public Icon getExpandedIcon()
//        {
//            return expandedIcon;
//        }

        @Override
        protected void paintExpandControl(Graphics g, Rectangle clipBounds, Insets insets, Rectangle bounds, TreePath path, int row, boolean isExpanded,
                boolean hasBeenExpanded, boolean isLeaf)
        {
            boolean leftToRight = true;
            Object value = path.getLastPathComponent();

            // Draw icons if not a leaf and either hasn't been loaded,
            // or the model child count is > 0.
            if (!isLeaf && (!hasBeenExpanded || treeModel.getChildCount(value) > 0))
            {
                int middleXOfKnob;
                if (leftToRight)
                {
                    middleXOfKnob = bounds.x - (getRightChildIndent() - 1);
                }
                else
                {
                    middleXOfKnob = bounds.x + bounds.width + getRightChildIndent();
                }
                //int middleYOfKnob = bounds.y + (bounds.height / 2);

                Icon icon = (isExpanded ? getExpandedIcon() : getCollapsedIcon());
                if ( icon != null )
                {
                    int middleYOfKnob = bounds.y + icon.getIconHeight();
                    drawCentered(tree, g, icon, middleXOfKnob, middleYOfKnob);
                    
                }
            }
        }

        
        /* 
         * Override horizontal leg to position leg at top of node and not at the middle
         */
        protected void paintHorizontalPartOfLeg(Graphics g, Rectangle clipBounds, Insets insets, Rectangle bounds, TreePath path, int row, boolean isExpanded,
                boolean hasBeenExpanded, boolean isLeaf)
        {
            // Don't paint the legs for the root'ish node if the
            int depth = path.getPathCount() - 1;
            if ((depth == 0 || (depth == 1 && !isRootVisible())) && !getShowsRootHandles())
            {
                return;
            }

            int clipLeft = clipBounds.x;
            int clipRight = clipBounds.x + (clipBounds.width - 1);
            int clipTop = clipBounds.y;
            int clipBottom = clipBounds.y + (clipBounds.height - 1);
            
            int lineY = bounds.y;// + bounds.height / 2;
            
            Icon icon = (isExpanded ? getExpandedIcon() : getCollapsedIcon());
            if ( icon != null )
                lineY += icon.getIconHeight();
                
            // Offset leftX from parents indent.

            int leftX = bounds.x - getRightChildIndent();
            int nodeX = bounds.x - getHorizontalLegBuffer();

            if (lineY >= clipTop && lineY <= clipBottom && nodeX >= clipLeft && leftX <= clipRight)
            {
                leftX = Math.max(Math.max(insets.left, leftX), clipLeft);
                nodeX = Math.min(Math.max(insets.left, nodeX), clipRight);

                if (leftX != nodeX)
                {
                    g.setColor(getHashColor());
                    paintHorizontalLine(g, tree, lineY, leftX, nodeX);
                }
            }
        }
        
        /* 
         * Override vertical leg to position leg at top of node and not at the middle
         */
        protected void paintVerticalPartOfLeg(Graphics g, Rectangle clipBounds, Insets insets, TreePath path)
        {

            int depth = path.getPathCount() - 1;
            if (depth == 0 && !getShowsRootHandles() && !isRootVisible())
            {
                return;
            }
            int lineX = getRowX(-1, depth + 1);
            lineX = lineX - getRightChildIndent() + insets.left;

            int clipLeft = clipBounds.x;
            int clipRight = clipBounds.x + (clipBounds.width - 1);
            
            Icon icon = (treeState.isExpanded(path) ? getExpandedIcon() : getCollapsedIcon());

            if (lineX >= clipLeft && lineX <= clipRight)
            {
                int clipTop = clipBounds.y;
                int clipBottom = clipBounds.y + clipBounds.height;
                Rectangle parentBounds = getPathBounds(tree, path);
                Rectangle lastChildBounds = getPathBounds(tree, getLastChildPath(path));

                if (lastChildBounds == null)
                    // This shouldn't happen, but if the model is modified
                    // in another thread it is possible for this to happen.
                    // Swing isn't multithreaded, but I'll add this check in
                    // anyway.
                    return;

                int top;

                if (parentBounds == null)
                    top = Math.max(insets.top + getVerticalLegBuffer(), clipTop);
                else
                {
                    top = parentBounds.y + StatusType.GOOD.getIcon().getIconHeight() + 2 * getVerticalLegBuffer();
                    top = Math.max(top, clipTop);
                    
                    //top = Math.max(parentBounds.y + parentBounds.height + getVerticalLegBuffer(), clipTop);
                }
                
                if (depth == 0 && !isRootVisible())
                {
                    TreeModel model = getModel();

                    if (model != null)
                    {
                        Object root = model.getRoot();

                        if (model.getChildCount(root) > 0)
                        {
                            parentBounds = getPathBounds(tree, path.pathByAddingChild(model.getChild(root, 0)));
                            if (parentBounds != null)
                                top = Math.max(insets.top + getVerticalLegBuffer(), parentBounds.y + parentBounds.height / 2);
                        }
                    }
                }

                int bottom = lastChildBounds.y;
                if ( icon != null )
                    bottom += icon.getIconHeight();
                bottom = Math.min(bottom, clipBottom);

                if (top <= bottom)
                {
                    g.setColor(getHashColor());
                    paintVerticalLine(g, tree, lineX, top, bottom);
                }
            }
        }
        
//
//        @Override
//        protected void paintVerticalPartOfLeg(Graphics g, Rectangle clipBounds, Insets insets, TreePath path)
//        {
//            // do nothing.
//        }
    }
    
    /**
     * Count the number of nodes within the tree
     * 
     * @param root
     * @return
     */
    private static int countTree(IntrospectionNode node)
    {
        int count = 1;
        
        if ( node.getChildren() != null )
            for (IntrospectionNode child : node.getChildren())
                count += countTree(child);
        
        return count;
    }

    /**
     * Low-level method for write an introspection node and all of its descendants
     * to the provided print stream.
     * 
     * @param ps
     * @param tab
     * @param node
     */
    public static void createXMLTree(PrintStream ps, String tab, IntrospectionNode node)
    {
        if ( ProgressDialog.getProgressDialog().incrementMainProgressBar() )
            return;
        
        //  Output the start of the node header
        ps.print(tab);
        ps.print("<node status=\"");
        ps.print(node.getStatus().toString());
        ps.println("\">");
        
        String child_tab = "  " + tab;
        
        //  Print the notes
        for (Object[] notes : node.getNotes())
        {
            if ( notes == null )
                continue;
            
            ps.print(child_tab);
            ps.print("<note>");
            for (Object note : notes)
                ps.print(note);
            ps.println("</note>");
        }
        
        //  Print the children
        if (node.getChildren() != null)
            for (IntrospectionNode child : node.getChildren())
                createXMLTree(ps, child_tab, child);
        
        //  Output the end of the node
        ps.print(tab);
        ps.println("</node>");
    }
    
    public static IntrospectionNode createIntrospectionTree(IntrospectionNode parent, Node el)
    {
        IntrospectionNode node = new IntrospectionNode(parent);

        //  Set the status
        NamedNodeMap attributes = el.getAttributes();
        node.setStatus(StatusType.valueOf(attributes.getNamedItem("status").getNodeValue().toUpperCase()));
        
        //  Parse children
        NodeList children = el.getChildNodes();
        if ( children != null )
            for (int i=0; i<children.getLength(); i++)
            {
                //  Check for cancel
                if ( ProgressDialog.getProgressDialog().isCanceled() )
                    return node;
                
                Node child = children.item(i);
                String name = child.getNodeName();
                
                //  Parse notes
                if ( name.equalsIgnoreCase("note") )
                    node.addNote(new Object[]{ child.getTextContent() });
                //  Parse nodes
                else if ( name.equalsIgnoreCase("node") )
                    node.addChild(createIntrospectionTree(node, child));  
            }
        
        return node;
    }

    /**
     * Write the provided introspection model to the provided output stream.
     * Display a progress dialog.
     * 
     * @param os
     * @param model
     * @throws ParserConfigurationException
     * @throws TransformerException
     */
    public static void toXml(OutputStream os, IntrospectionModel model) throws ParserConfigurationException, TransformerException
    {
        //  Count the number of nodes for the progress dialog
        IntrospectionNode rootNode = (IntrospectionNode) model.getRoot();
        int N = countTree(rootNode);
        ProgressDialog pd = ProgressDialog.initProgressDialog(null, "Exporting introspection");
        pd.setMainValues(0, N, 0);
        
        createXMLTree(new PrintStream(os), "", rootNode);
        
        pd.close();
    }

    public static void fromXml(InputStream is, IntrospectionModel model) throws ParserConfigurationException, SAXException, IOException
    {
        ProgressDialog pd = ProgressDialog.initProgressDialog(null, "Importing introspection");
        pd.setMainIndeterminate(true);
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        DocumentBuilder docBuilder = dbf.newDocumentBuilder();
        Document doc = docBuilder.parse(is);
        IntrospectionNode root = createIntrospectionTree(null, doc.getDocumentElement());
        
        model.setRoot(root);
        
        pd.close();
    }

    private Introspection _introspection;

    private IntrospectionModel _introspectionModel;
    private JTree _tree;

    public IntrospectionViewer(Introspection introspection)
    {
        super(NetMOD.getFrame(), false);
        _introspection = introspection;

        setTitle("Introspection - " + introspection);

        _introspectionModel = new IntrospectionModel(introspection);
        _tree = new JTree(_introspectionModel);
        _tree.setUI(new CustomTreeUI());
        // Miscellaneous tree attributes
        _tree.setLargeModel(true);
        _tree.setRootVisible(true);
        _tree.setExpandsSelectedPaths(true);
        _tree.setEditable(false);
        _tree.setInvokesStopCellEditing(true);
        _tree.setDragEnabled(true);
        _tree.setTransferHandler(new IntrospectionTransferHandler());

        _tree.setRowHeight(0);
        _tree.setCellRenderer(new IntrospectionTreeCellRenderer());

        //  Wrap the tree in a scroll pane
        JScrollPane tocScrollPane = new JScrollPane(_tree);
        tocScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        tocScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        tocScrollPane.getViewport().setScrollMode(JViewport.BLIT_SCROLL_MODE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(createToolBar(), BorderLayout.NORTH);
        panel.add(tocScrollPane, BorderLayout.CENTER);

        setContentPane(panel);

        //  Set the size and position
        setSize(640, 480);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private JButton createBrowseButton()
    {
        JButton button = GUIUtility.createButton(Icons.OPEN.getIcon());
        button.setToolTipText("Import introspection file");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                new SwingWorker<Void, Void>()
                {
                    @Override
                    protected Void doInBackground() throws Exception
                    {
                        File[] files = GUIUtility.showOpenDialog(IntrospectionViewer.this, "", "Open file", JFileChooser.FILES_ONLY, false, null, null);
                        if (files == null)
                            return null;

                        File file = files[0];
                        FileInputStream fis = null;
                        BufferedInputStream bis = null;
                        try
                        {
                        	fis = new FileInputStream(file);
                        	bis = new BufferedInputStream(fis);
                        	
                            fromXml(bis, _introspectionModel);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                        finally
                        {
                        	if ( bis != null )
                        		IOUtility.safeClose(bis);
                        	if ( fis != null )
                        		IOUtility.safeClose(fis);
                        }

                        return null;
                    }
                }.execute();
            }
        });

        return button;
    }

    private JButton createSaveButton()
    {
        JButton button = GUIUtility.createButton(Icons.SAVE.getIcon());
        button.setToolTipText("Export introspection file");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                new SwingWorker<Void, Void>()
                {
                    @Override
                    protected Void doInBackground() throws Exception
                    {
                        
                        File file = GUIUtility.showSaveDialog(IntrospectionViewer.this, "", "Save file", JFileChooser.FILES_ONLY, null, null);
                        if (file == null)
                            return null;
                        
                       FileOutputStream fos = null;
                       BufferedOutputStream bos = null;
                    		   
                        try
                        {
                        	fos = new FileOutputStream(file);
                        	bos = new BufferedOutputStream(bos);
                        	
                            toXml(bos, _introspectionModel);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                        finally
                        {
                        	if ( bos != null )
                        		IOUtility.safeClose(bos);
                        	if ( fos != null )
                        		IOUtility.safeClose(fos);
                        }
                        
                        return null;
                    }
                }.execute();
            }
        });

        return button;
    }

    private JComponent createToolBar()
    {
        JComponent toolBar = GUIUtility.createToolBar();

        toolBar.add(createBrowseButton());
        toolBar.add(createSaveButton());

        return toolBar;
    }
}
