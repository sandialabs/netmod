package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import static java.lang.Math.*;

public class VshLib {

  static double geopot2alt(double gph, double glat) {
    double rlat = glat * 3.14159265359 / 180.;
    double a = 1.57e-7 * .99995 * (1. - .00259 * cos(2. * rlat));
    double b = -.99995 * (1. - .00259 * cos(2. * rlat));
    double c = gph;
    // System.out.println("gph "+ gph);
    double[] roots = new double[2];

    roots = quad_equation(a, b, c, roots);

    double NewAlt = min(roots[0], roots[1]);

    return NewAlt;
  }

  private static double[] quad_equation(double a, double b, double c, double[] roots) {
    double arg = pow(b, 2) - 4. * a * c;
    if (arg > 0.) {
      roots[0] = (-b + sqrt(arg)) / (2. * a);
      roots[1] = (-b - sqrt(arg)) / (2. * a);
      return roots;
    } else {
      System.out.println("Error in quadratic equation, complex root");
    }
    return roots;

  }


  public static void scalar_basis(int mmax, int nmax, double theta, double[][] pbar) {
    //System.out.println("");
    //System.out.println("scalar_basis: ");
    //System.out.println("mmax: " + mmax + " nmax: " + nmax + " theta: " + theta);
    double[] pb = new double[nmax + 1];

    // ! Save time by using memory
    int maxorder = 122;  //  Not 121 as in fortran code, appears to be a bug in original fortran

    double[][][] factor = new double[maxorder][5][maxorder];
    int lastmax = 0;

    // ! Calculate the static coeffiecents
    if (mmax * nmax != lastmax) {
      for (int m = 0; m <= mmax; m++) {
        lfnc(0, m, nmax + 1, theta, pb, factor[m]);
//				System.out.println("m: " + m);
//				System.out.println("pb: " + Arrays.toString(pb));
//				System.out.println("factor1: " + Arrays.toString(factor[m][0]));
//				System.out.println("factor2: " + Arrays.toString(factor[m][1]));
//				System.out.println("factor3: " + Arrays.toString(factor[m][2]));
//				System.out.println("factor4: " + Arrays.toString(factor[m][3]));
//				System.out.println("factor5: " + Arrays.toString(factor[m][4]));
      }
    }

    // ! Generate the legendre polynomials
    //System.out.println("init = 1");
    for (int m = 0; m < mmax; m++) {
      lfnc(1, m, nmax + 1, theta, pb, factor[m]);
      //System.out.println("m: " + m);
      //System.out.println("pb: " + Arrays.toString(pb));
      for (int n = m; n <= nmax; n++) {
        double tmp = pb[n];
        pbar[m][n] = tmp;
      }
      //System.out.println("pbar[m]: " + Arrays.toString(pbar[m]));
    }
  }

  /*
   * calculate the associated legendre functions
   *
   * from D.Drob's vshlib.f90 comments: purpose: routines lfna and lfnc both
   * calculate single precision, normalized associated legendre functions
   * pbar(n,m,theta) for n=m,...,l-1 subroutine lfnc differs from lfna in that
   * theta is user specified rather than equally spaced
   *
   * inputs: integers: init - flag. 0 = initialization, no pbar computed 1 =
   * compute pbar. 0 should be used on the first call or if l,m,w values
   * change. m - non-negative integer, lt l, specifying the order of pbar
   *
   * l - maximum value of n+1
   *
   * doubles : theta - colatitude, in radians, for pbar(n,m,theta) w(5*l) -
   * single precision array containing values which must not be destroyed
   * until the call differs in value of input parameter l or m
   *
   * output: doubles: pb(l+1) - single precision array storing pbar(n,m,theta)
   * w(5*l) - single precision array containing values which must not be
   * destroyed until the call differs in value of input parameter l or m
   *
   * converted by: Kimberly Schramm, May 2015
   */
  public static void lfnc(int init, int m, int l, double theta, double[] pb, double[][] w) {
    lfnc1(init, m, l, theta, pb, w[0], w[1], w[2], w[3], w[4]);
  }

  /*
   * primary routine for calculating Legendre polynomials
   *
   * inputs: integers: init - flag. 0 = initialization, no pbar computed 1 =
   * compute pbar. 0 should be used on the first call or if l,m,w values
   * change. m - non-negative integer, lt l, specifying the order of pbar
   *
   * l - maximum value of n+1
   *
   * doubles : theta - colatitude, in radians, for pbar(n,m,theta)
   *
   * pb(l+1)- pbar values
   *
   * pz(l) - w in the lfnc call - but is this correct?
   *
   * i think these are coefficents, but Drob doesn't p1(l) - go into details
   * explaining all of these things. a(l) - in the fortran code these are
   * arrays here, but b(l) - are passed back as singles. I have renamed them
   * and reset them accordingly. w(l) - another single here, double above. has
   * been renamed.
   *
   *
   * ported to java by Kimberly Schramm
   */
  public static void lfnc1(int init, int m, int l, double theta, double[] pb, double[] pz,
      double[] p1, double[] a, double[] b, double[] w) {
    //System.out.println("");
    //System.out.println("lfnc1");
    //System.out.println("init: " + init + " m: " + m + " l: " + l);
    for (int n = 0; n < l; n++) {
      pb[n] = 0.0; // initialize pb to zero every call.
    }

    int lm1 = l - 1;
    int lm2 = l - 2;
    int lmm = l - m;

    // System.out.println("lp2,lm1,lm2,lmm,m: "+lp2+" "+lm1+" "+lm2+" "+lmm+" "+m);

    if (init == 0) { // when init is zero, we are initializing variables.

      alfk(lm2, m, p1);

      // System.out.println("length p1: "+p1.length);

      alfk(lm1, m, pz); // using llm2 so that it is iterating the correct
      // number of times.
      int n = l - 1;
      double fnmm = n - m + 1;
      double fnpn = n + n + 1;
      double fnpm = n + m + 1;

      // System.out.println("fnmm: "+fnmm+" fnpn: "+fnpn+" fnpm: "+fnpm);
      // System.out.println("n: "+n+" m:"+m);

      int k = 0;
      while (n > m) {
        fnmm = fnmm - 1.0;
        fnpn = fnpn - 2.0;
        fnpm = fnpm - 1.0;

        b[k] = sqrt(fnmm * fnpm / (fnpn * (fnpn + 2.0)));
        k = k + 1; // switching this after b[k] in java so that 0 is the
        // first index.
        n = n - 1;
      }

      return;
    }

    //System.out.println("");
    //System.out.println("lfnc1");
    //System.out.println("init: " + init + " m: " + m + " l: " + l);

    double pzi = lfpt(lm1, m, theta, pz);
    pb[l - 1] = pzi;

    //System.out.println("lm1: " + lm1 + " pzi: " + pzi);

    if (l == 1) {
      return;
    }

    double p1i = lfpt(lm2, m, theta, p1);
    //System.out.println("p1i: " + p1i);

    if (lmm - 2 <= -1) { // replacing the select case, which replaced an arithmetic if.
      return;
    } else if (lmm - 2 == 0) {
      pb[l - 2] = p1i;
      return;
    }

    double cost = cos(theta);
    for (int k = 0; k < lmm; k++) {
      pb[k] = -cost;
      a[k] = b[k];
    }
    //System.out.println("cost: " + cost);

    //System.out.println("a: " + Arrays.toString(a));
    //System.out.println("pb: " + Arrays.toString(pb));

    if (abs(pzi) >= abs(p1i)) {
      pb[0] = pzi;
      double r = -a[0] * pb[0];
      trih(lmm - 1, a, 0, pb, 1, a, 1, r);
    } else {
      pb[0] = pzi;
      pb[1] = p1i;
      if (lmm != 1) {
        double r = -a[1] * pb[1];
        trih(lmm - 2, a, 1, pb, 2, a, 2, r);
      }
    }

    //System.out.println("pb: " + Arrays.toString(pb));

    int ndo = (l + 1) / 2;
    for (int n = 1; n <= ndo; n++) {
      int n1 = l - n;
      double phold = pb[n1];
      pb[n1] = pb[n - 1];
      pb[n - 1] = phold;
    }

    //System.out.println("pb: " + Arrays.toString(pb));

    return;
  }

  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
  /*
   * alfk - the associated legendre polynomials
   *
   * from Paul Swartztraubers SpherePack, which seems to be the basis of this
   * subroutine (method): purpose routine alfk computes single precision
   * fourier coefficients in the trigonometric series representation of the
   * normalized associated legendre function pbar(n,m,theta) for use by
   * routines lfp and lfpt in calculating single precision pbar(n,m,theta).
   * inputs : integers: n - nonnegative integer specifying the degree of
   * pbar(n,m,theta) m - is the order of pbar(n,m,theta). m can be any integer
   * however cp is computed such that pbar(n,m,theta) = 0 if abs(m) is greater
   * than n and pbar(n,m,theta) = (-1)**m* pbar(n,-m,theta) for negative m.
   *
   * outputs: doubles : cp - single precision array of length (n/2)+1 which
   * contains the fourier coefficients in the trigonometric series
   * representation of pbar(n,m,theta)
   *
   * converted by: Kimberly Schramm, May 2015
   */
  public static void alfk(int n, int m, double cp[]) {
    //System.out.println("");
    //System.out.println("alkf");
    //System.out.println("N: " + n + " M: " + m);
    cp[0] = 0;

    int ma = abs(m);
    if (ma > n) {
      return;
    }

    if (n <= 0) {
      cp[0] = sqrt(2.0);
      return;
    }
    if (n == 1) {
      if (ma == 0) {
        cp[0] = sqrt(1.5);
      } else {
        cp[0] = sqrt(0.75);

        if (m == -1) {
          cp[0] = -cp[0];
        }
      }
      return;
    }

    //System.out.println("CP1: " + Arrays.toString(cp));

    int nmms2 = 0;
    double fnum = 0;
    double fnmh = 0;
    double pm1 = 0;
    int npma = n + ma;
    int remainder = (npma % 2);

    if ((remainder) == 0) {
      nmms2 = (n - ma) / 2;
      fnum = n + ma + 1;
      fnmh = n - ma + 1;
      pm1 = 1.;
    } else {
      nmms2 = (n - ma - 1) / 2;
      fnum = n + ma + 2;
      fnmh = n - ma + 2;
      pm1 = -1.;
    }

    //System.out.println("nmms2: " + nmms2 + " fnum: " + fnum + " fnmh: " + fnmh + " pm1: " + pm1);

    double t1 = 1.;
    double t2 = 1.;

    if (nmms2 >= 1) {
      double fden = 2.;
      for (int i = 0; i < nmms2; i++) {
        t1 = fnum * t1 / fden;
        fnum = fnum + 2.0;
        fden = fden + 2.0;
      }
    }

    //System.out.println("t1: " + t1);

    if (ma != 0) {
      for (int i = 0; i < ma; i++) {
        t2 = fnmh * t2 / (fnmh + pm1);
        fnmh = fnmh + 2.0;
      }
    }

    //System.out.println("t2: " + t2 + " fnmh: " + fnmh);

    if (((ma / 2) % 2) != 0) {
      t1 = -t1;
    }

    double cp2 = t1 * sqrt((n + .5) * t2) / pow(2.0, (n - 1));
    double fnnp1 = n * (n + 1);
    double fnmsq = fnnp1 - 2. * ma * ma;
    int l = (n + 1) / 2;

    //  Reduce l by one to transition from Fortran to Java
    l--;

    //System.out.println("cp2: " + cp2 + " fnnp1: " + fnnp1 + " fnmsq: " + fnmsq + " l: " + l);

    if ((n % 2) == 0 && (ma % 2) == 0) {
      l = l + 1;
    }
    cp[l] = cp2;
    if (m < 0 && (ma % 2) != 0) {
      cp[l] = -cp[l];
    }

    if (l <= 1) {
      return;
    }

    double fk = n;
    double a1 = (fk - 2.) * (fk - 1.) - fnnp1;
    double b1 = 2. * (fk * fk - fnmsq);
    cp[l - 1] = b1 * cp[l] / a1;
    l = l - 1;
    while (l > 0) {
      //System.out.println("fk: " +  fk + " a1: " + a1 + " b1: " + b1 + " l: " + l);
      fk = fk - 2.;
      a1 = (fk - 2.) * (fk - 1.) - fnnp1;
      b1 = -2. * (fk * fk - fnmsq);
      double c1 = (fk + 1.) * (fk + 2.) - fnnp1;
      cp[l - 1] = -(b1 * cp[l] + c1 * cp[l + 1]) / a1;
      l = l - 1;
    }
    //System.out.println("cp: " + Arrays.toString(cp));
  }

  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
  //
  // ========================================================================
  // Uses a recursion to produce the Legendre polynomial given their values
  // for N=0 and N=1
  // -- kas -- can java do recursion?
  // ========================================================================

  public static double lfpt(int n, int m, double theta, double[] cp) {
    //System.out.println("");
    //System.out.println("lfpt");
    //System.out.println("n: " + n + " m: " + m + " theta: " + theta);
    //System.out.println("cp: " + Arrays.toString(cp));
    double pb = 0;

    int ma = abs(m);

    if (ma > n) {
      return ma;
    }

    if (n <= 0 && ma <= 0) {
      pb = sqrt(.50);
      return pb;
    }

    int nmod = (n % 2);
    int mmod = (ma % 2);
    double cdt = cos(theta + theta);
    double sdt = sin(theta + theta);
    double sum;
    if (nmod <= 0) {
      double ct = 1.;
      double st = 0.;
      if (mmod <= 0) {
        int kdo = n / 2 + 1;
        sum = .5 * cp[0];
        for (int kp1 = 1; kp1 < kdo; kp1++) {
          double cth = cdt * ct - sdt * st;
          st = sdt * ct + cdt * st;
          ct = cth;
          sum = sum + cp[kp1] * ct;
        }
      } else {
        int kdo = n / 2;
        sum = 0.;
        for (int kp1 = 0; kp1 < kdo; kp1++) {
          double cth = cdt * ct - sdt * st;
          st = sdt * ct + cdt * st;
          ct = cth;
          sum = sum + cp[kp1] * st;
        }
      }
    } else {
      int kdo = (n + 1) / 2;
      double ct = cos(theta);
      double st = -sin(theta);
      sum = 0.;
      double cth;
      if (mmod <= 0) {
        for (int k = 0; k < kdo; k++) {
          cth = cdt * ct - sdt * st;
          st = sdt * ct + cdt * st;
          ct = cth;
          sum = sum + cp[k] * ct;
        }
      } else {
        for (int k = 0; k < kdo; k++) {
          cth = cdt * ct - sdt * st;
          st = sdt * ct + cdt * st;
          ct = cth;
          sum = sum + cp[k] * st;
        }
      }
    }
    pb = sum;

    //System.out.println("pb: " + pb);
    return pb;
  }

  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
  /*
   * ============================================================= A
   * tri-diagonal matrix solver
   * =============================================================
   */
  public static void trih(int n, double[] a, int a_start, double[] b, int b_start, double[] c,
      int c_start, double r) {
    //System.out.println("");
    //System.out.println("trih");
    //System.out.println("n: " + n + " r: " + r);
    //System.out.println("a start: " + a_start);
    //System.out.println("a: " + Arrays.toString(a));
    //System.out.println("b start: " + b_start);
    //System.out.println("b: " + Arrays.toString(b));
    //System.out.println("c start: " + c_start);
    //System.out.println("c: " + Arrays.toString(c));
    double qih;
    double bih;

    // replacing select case with ifs
    if (n <= 0) {
      return;
    } else if (n == 1) {
      b[b_start] = r / b[b_start];
      return;
    } else if (n == 2) {
      qih = a[a_start + 1];
      bih = b[b_start + 1];
    } else {
      qih = a[a_start + n - 1];
      bih = b[b_start + n - 1];
      for (int ido = 3; ido <= n; ido++) {
        int i = n - ido + 2;
        i--; //  Minus 1 to convert from fortran to java

        if (abs(bih) >= abs(c[c_start + i])) {
          double ratio = c[c_start + i] / bih;
          c[c_start + i] = 0.;
          b[b_start + i + 1] = qih / bih;
          bih = b[b_start + i] - ratio * qih;
          qih = a[a_start + i];
        } else {
          b[b_start + i + 1] = b[b_start + i] / c[c_start + i];
          c[c_start + i] = a[a_start + i] / c[c_start + i];
          double bih1 = qih - bih * b[b_start + i + 1];
          qih = -bih * c[c_start + i];
          bih = bih1;
        }
      }
    }
    //System.out.println("qih: " + qih + " bih: " + bih);
    //System.out.println("a: " + Arrays.toString(a));
    //System.out.println("b: " + Arrays.toString(b));
    //System.out.println("c: " + Arrays.toString(c));

    if (abs(bih) >= abs(c[c_start])) {
      double q2 = qih / bih;
      bih = b[b_start] - c[c_start] / bih * qih;
      b[b_start] = r / bih;
      b[b_start + 1] = -q2 * b[b_start];
    } else {
      double ratio = bih / c[c_start];
      bih = qih - ratio * b[b_start];
      double rih = -ratio * r;
      double b1 = rih / bih;
      b[b_start + 1] = (r - b[b_start] * b1) / c[c_start];
      b[b_start] = b1;
    }

    if (n - 3 >= 0) {
      for (int i = 2; i < n; i++) {
        b[b_start + i] =
            -b[b_start + i] * b[b_start + i - 1] - c[c_start + i - 1] * b[b_start + i - 2];
      }
    }
    //System.out.println("b: " + Arrays.toString(b));
  }

  /*
   * !============================================================= !
   * Determines the components of the vector spherical harmonics ! of orders M
   * and degrees N as a function of latitude.
   * !=============================================================
   */
  public static void vector_basis(int mmax, int nmax, double[][] pbar, double[][] vbar,
      double[][] wbar) {

    /*
     * integer :: mmax,nmax real(8) :: pbar(mmax+1,nmax+1) real(8) ::
     * vbar(mmax+1,nmax+1) real(8) :: wbar(mmax+1,nmax+1)
     *
     * ! internal variables
     *
     * real(8) :: npm real(8) :: nmm
     *
     * integer :: n,np1,m,mp1,mp2
     *
     * ! Static variables, utilize memory to save time
     *
     * integer,parameter :: maxorder = 121 real(8) :: nfac1,nfac2
     * real(8),save :: a(maxorder,maxorder),b(maxorder,maxorder)
     * real(8),save :: c(maxorder,maxorder),d(maxorder,maxorder)
     * integer,save :: lastmax = 0
     */

    // ! --------------------------------------------------------
    // ! Calculate vector basis functions (vbar and wbar):
    // ! vbar= dp/dlat, wbar = p*m/sin(colatitude)
    // ! --------------------------------------------------------

    int maxorder = 121;
    double[][] a = new double[maxorder][maxorder];
    double[][] b = new double[maxorder][maxorder];
    double[][] c = new double[maxorder][maxorder];
    double[][] d = new double[maxorder][maxorder];
    int lastmax = 0;
		
		/*
	    ! --------------------------------------------------------
	    !  Calculate vector basis functions (vbar and wbar):
	    !  vbar= dp/dlat, wbar = p*m/sin(colatitude)
	    ! --------------------------------------------------------

	    ! special case m = 0, first column
		 */

    for (int n = 0; n < nmax; n++) {
      vbar[0][n] = -pbar[1][n];
      wbar[0][n] = 0.0;
    }
		
		/*
		 * ! the rest of the lower triangular matrix n = 1..N, m = 1..n
           !	vbar(mp1,np1) = (dsqrt(dble(npm*nmm+npm))*pbar(m,np1)
           !			- dsqrt(dble(nmm*npm+nmm))*pbar(m+2,np1))/nfac1  
           !	wbar(mp1,np1) = nfac2*(dsqrt(dble(npm*npm-npm))*pbar(m,n)
           !			+ dsqrt(dble(nmm*nmm-nmm))*pbar(m+2,n))/nfac1
		 */

    if (nmax * mmax != lastmax) {
      for (int np1 = 2; np1 < maxorder; np1++) {
        int n = np1 - 1;
        double nfac1 = 2.0 * sqrt(n * (n + 1.0));
        double nfac2 = sqrt((2.0 * n + 1.0) / (2.0 * n - 1.0));

        for (int mp1 = 2; mp1 <= np1; mp1++) {
          int m = mp1 - 1;
          double npm = (n + m);
          double nmm = (n - m);
          a[m][n] = sqrt((npm * nmm + npm)) / nfac1;
          b[m][n] = -sqrt((nmm * npm + nmm)) / nfac1;
          c[m][n] = nfac2 * sqrt((npm * npm - npm)) / nfac1;
          d[m][n] = nfac2 * sqrt((nmm * nmm - nmm)) / nfac1;
        }
      }
      lastmax = nmax * mmax;
    }

//		System.out.println("a:");
//		for (int i=0; i<a.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(a[i]));
//		System.out.println("");
//		System.out.println("b:");
//		for (int i=0; i<b.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(b[i]));
//		System.out.println("");
//		System.out.println("c:");
//		for (int i=0; i<c.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(c[i]));
//		System.out.println("");
//		System.out.println("d:");
//		for (int i=0; i<d.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(d[i]));
//		System.out.println("");

    for (int np1 = 2; np1 <= nmax; np1++) {
      int n = np1 - 1;
      for (int mp1 = 2; mp1 <= np1; mp1++) {
        int m = mp1 - 1;
        int mp2 = mp1 + 1;
        vbar[m][n] = a[m][n] * pbar[m - 1][n] + b[m][n] * pbar[mp1][n];
        wbar[m][n] = c[m][n] * pbar[m - 1][n - 1] + d[m][n] * pbar[mp1][n - 1];
      }
    }

//		System.out.println("vbar:");
//		for (int i=0; i<vbar.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(vbar[i]));
//		System.out.println("");
//		System.out.println("wbar:");
//		for (int i=0; i<wbar.length; i++)
//			System.out.println("m: " + i + " " + Arrays.toString(wbar[i]));

    return;
  }

}
