/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.signal;

import com.carrotsearch.hppc.ObjectDoubleMap;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuation;
import gov.sandia.gnem.netmod.path.media.PathMediaPhaseParameter;
import gov.sandia.gnem.netmod.path.media.PathMediaType;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * RegionalBodywave implements the SignalAmplitude interface.
 * However, it does not register itself with as a Plugin as it
 * is used within higher level signal amplitude routines
 * 
 * @author bjmerch
 *
 */
public class RegionalBodywave extends AbstractNetSimBodywave
{
    /**
     *  Cache the requests for media weights
     *
     *  Use a synchronized map since the cache may be accessed in a multi-threaded environment
     */
    transient private CacheMap<Distance, ObjectDoubleMap> _cacheMinor = new CacheMap<Distance, ObjectDoubleMap>(
            CacheMap.CACHE_SOURCE * CacheMap.CACHE_RECEIVER);
    transient private CacheMap<Distance, ObjectDoubleMap> _cacheMajor = new CacheMap<Distance, ObjectDoubleMap>(
            CacheMap.CACHE_SOURCE * CacheMap.CACHE_RECEIVER);

    public RegionalBodywave(NetModComponent parent, String type, String name)
    {
        super(parent, type, name);
    }

    @Override
    public Spectra computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        //  Look up Bk
        Spectra attenuation = getPathAttenuation(sources, paths, epicenter, station, distance, phase, frequency, true);

        //  Generate Monte Carlo iterations, if desired
        if ( N > 1 )
        	attenuation = attenuation.toMonteCarlo(prng, N);
        
        recordIntrospection(this, "Path Attenuation (log10 Amplitude): ", attenuation);
        stopIntrospection();
                
        return attenuation;
    }

    /**
     * Get the path attenuation between the provided epicenter, station, phase, and frequency
     * 
     * @param sources
     * @param epicenter
     * @param station
     * @param phase
     * @param frequency
     * @param minor if true, follow the minor arc.  If false, follow the major arc.
     * @return
     */
    public Spectra getPathAttenuation(Sources sources, Paths paths, Point.Double epicenter, Station station, Distance distance, Phase phase, Frequency frequency, boolean minor)
    {
    	ObjectDoubleMap<Point.Double> distances = paths.getPathMedia().getAttenuationPoints(distance, minor);
        Point.Double[] points = Distance.sortPoints(distances);

        int N = points.length;
        double total_distance = 0;
        
        if ( N < 2 )
        	return SpectraPDF.NEGATIVE_999;
        
        //  Lump adjacent regional grid points of the same type into the same call
        Point.Double p_start = points[0];
        PathMediaType type = paths.getPathMedia().getMediaType(points[0], points[1]);
        
        int Nregions = 0;
        double[] std = new double[N-1];
        double[] weights = new double[N-1];
        Spectra[] spectra = new Spectra[N-1];

        for (int i = 1; i < N; i++)
        {        	
            Point.Double p = points[i];

            //  Check the media type of the next segment to see if we can skip this segment
            if ( i < N-1 )
            {
            	PathMediaType type_next = paths.getPathMedia().getMediaType(p, points[i+1]);
            	if ( type_next == type )
            		continue;
            }         

            startIntrospection();

            PathMediaPhaseParameter pp = type.getPhaseParameters().getPhaseParameter(phase);
            AmplitudeAttenuation amplitudeAttenuation = pp.getAmplitudeAttenuation();

            Spectra a = amplitudeAttenuation.getAttenuation(p_start, p, distance, frequency);
            double a_sd = pp.getStddevAttenuation();
            double dist = Math.abs(distances.get(p) - distances.get(p_start));
            total_distance += dist;

            //  Accumulate the attenuation in this bin
            weights[Nregions] = dist;
            std[Nregions] = a_sd;
            spectra[Nregions] = a;

            recordIntrospection("Attenuation (log10): ", a);
            recordIntrospection("Media Type: ", type);
            recordIntrospection("Standard Deviation: ", a_sd);
            recordIntrospection("Start Location: ", p_start);
            recordIntrospection("End Location: ", p);
            recordIntrospection("Segment Distance (deg): ", dist);
            stopIntrospection();
            
            //   Start tracking a new media type segment
            p_start = p;
            if ( i < N-1 )
            	type = paths.getPathMedia().getMediaType(p, points[i+1]);
            Nregions++;
        }
        
        //  Adjust the weights to scale by the total distance
        for (int i=0; i<Nregions; i++)
        	weights[i] = weights[i] / total_distance;
        
        Spectra attenuation = Spectra.sum(spectra, weights, std, Nregions);

        return attenuation;
    }
}
