/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.media;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;
import gov.sandia.gnem.netmod.simulation.Simulation;

import java.util.Arrays;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class EventSizeConversion extends AbstractNetModComponent
{
    private MagnitudeType[] _magnitudes;
    private double[] _slopes;
    private double[] _yintercepts;
    
    private boolean _dirty = false;
    
    /**
     * @param parent
     */
    public EventSizeConversion(NetModComponent parent)
    {
        super(parent);
        setName("Event Size Conversion");
        
        //  Populate defaults
        
        if ( parent != null && parent.getParent() != null && parent.getParent().getParent() != null &&
                parent.getParent().getParent().getParent() instanceof Simulation )
        {
            List<? extends MagnitudeType> mags = ((Simulation) parent.getParent().getParent().getParent()).getMagnitudeTypes();
            _magnitudes = mags.toArray(new MagnitudeType[mags.size()]);   
        }
        else
            _magnitudes = MagnitudeType.values();

        _slopes = new double[_magnitudes.length];
        _yintercepts = new double[_magnitudes.length];
    }

    /**
     * Convert the provided magnitude and type to a moment value
     * 
     * @param value
     * @param type
     * @return
     */
    public Magnitude convertToMoment(double value, MagnitudeType type)
    {
        startIntrospection();
        
        int index = indexOf(type);
        if ( index < 0 )
        {
            recordIntrospection("Unable to identify conversion parameters");
            statusIntrospection(StatusType.ERROR);
            stopIntrospection();
            return null;
        }
        
        double a = getSlope(index);
        double b = getYIntercept(index);
        
        Magnitude magnitude = new Magnitude(value, type, a, b);
        
        //  Check if the coefficients aren't set
        if ( a == 0 && b == 0 )
        {
            recordIntrospection("Conversion coefficients appear suspect");
            statusIntrospection(StatusType.ERROR);
        }

        recordIntrospection("Amplitude (log10 Amplitude): ", magnitude.getMoment());
        recordIntrospection("Magnitude: ", value);
        recordIntrospection("Magnitude Type: ", type);
        recordIntrospection("Slope: ", a );
        recordIntrospection("Intercept: ", b);
        stopIntrospection();
        
        return magnitude;
    }

    /**
     * Convert the provided magnitude and type to a moment value
     * 
     * @param value
     * @param type
     * @return
     */
    public double convertFromMoment(double value, MagnitudeType type)
    {
        startIntrospection();
        
        recordIntrospection("Moment: ", value);
        int index = indexOf(type);
        if ( index < 0 )
        {
            recordIntrospection("Unable to identify conversion parameters");
            statusIntrospection(StatusType.ERROR);
            stopIntrospection();
            return value;
        }
        
        double a = getSlope(index);
        double b = getYIntercept(index);
        
        double magnitude = type.unconvert(value, a, b);
        
        //  Check if the coefficients aren't set
        if ( a == 0 && b == 0 )
        {
            recordIntrospection("Conversion coefficients appear suspect");
            statusIntrospection(StatusType.ERROR);
        }

        recordIntrospection("Magnitude Type: ", type);
        recordIntrospection("Magnitude: ", magnitude);
        recordIntrospection("Slope: ", a );
        recordIntrospection("Intercept: ", b);
        stopIntrospection();
        
        return magnitude;
    }

    public int getConversionCount()
    {
        return _magnitudes.length;
    }
    
    /**
     * @return the dirty
     */
    public boolean getDirty()
    {
        return _dirty;
    }
    
    public MagnitudeType getMagnitudeType(int index)
    {
        return _magnitudes[index];
    }
    
    public double getSlope(int index)
    {
        return _slopes[index];
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new EventSizeConversionViewer(this);
    }
    
    public double getYIntercept(int index)
    {
        return _yintercepts[index];
    }
    
    /**
     * Get the index of the provided magnitude type
     * 
     * @param magnitudeType
     * @return
     */
    public int indexOf(MagnitudeType magnitudeType)
    {
        return Arrays.binarySearch(_magnitudes, magnitudeType);
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }
    
    /**
     * @param magnitude
     * @param slope
     * @param intercept
     */
    public void set(MagnitudeType magnitude, double slope, double intercept)
    {
        int index = indexOf(magnitude);
        
        setSlope(index, slope);
        setYIntercept(index, intercept);
    }
    
    /**
     * @param dirty the dirty to set
     */
    public void setDirty(boolean dirty)
    {
        _dirty = dirty;
    }
    
    public void setSlope(int index, double value)
    {
        if ( _slopes[index] == value )
            return;
        
        _slopes[index] = value;
        setDirty(true);
    }

    public void setYIntercept(int index, double value)
    {
        if ( _yintercepts[index] == value )
            return;
        
        _yintercepts[index] = value;
        setDirty(true);
    }
}
