/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io.libpar;

import java.util.*;
import java.util.Map.Entry;

/**
 * The Parameters class defines an Object that holds all of the loaded key-value pairs from a .par file.
 *
 */
public class LibParParameters
{

    /**
     * Represents the different types that a Parameters object can convert its values
     * to before returning them through the {@link LibParParameters#getAs(String, ConvType)} method.
     *
     */
    private static enum ConvType
    {

        /**
         * Represents the conversion to {@link Integer}.
         * See {@link Integer#parseInt(String)}.
         */
        INTEGER(int.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Integer.parseInt(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                int[] is = new int[size];
                for (int i = 0; i < size; i++)
                    is[i] = (Integer) convert(ss[i]);
                return is;
            }
        },
        INTEGER2(Integer.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Integer.parseInt(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                int[] is = new int[size];
                for (int i = 0; i < size; i++)
                    is[i] = (Integer) convert(ss[i]);
                return is;
            }
        },
        /**
         * Represents the conversion to {@link Double}.
         * See {@link Double#parseDouble(String)}.
         */
        DOUBLE(double.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Double.parseDouble(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                double[] ds = new double[size];
                for (int i = 0; i < size; i++)
                    ds[i] = (Double) convert(ss[i]);
                return ds;
            }
        },
        /**
         * Represents the conversion to {@link Double}.
         * See {@link Double#parseDouble(String)}.
         */
        DOUBLE2(Double.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Double.parseDouble(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                double[] ds = new double[size];
                for (int i = 0; i < size; i++)
                    ds[i] = (Double) convert(ss[i]);
                return ds;
            }
        },
        /**
         * Represents the conversion to {@link Float}.
         * See {@link Float#parseFloat(String)}.
         */
        FLOAT(float.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Float.parseFloat(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                float[] fs = new float[size];
                for (int i = 0; i < size; i++)
                    fs[i] = (Float) convert(ss[i]);
                return fs;
            }
        },
        /**
         * Represents the conversion to {@link Float}.
         * See {@link Float#parseFloat(String)}.
         */
        FLOAT2(Float.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Float.parseFloat(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                float[] fs = new float[size];
                for (int i = 0; i < size; i++)
                    fs[i] = (Float) convert(ss[i]);
                return fs;
            }
        },
        /**
         * Represents the conversion to {@link Boolean}.
         * See {@link Boolean#parseBoolean(String)}.
         */
        BOOLEAN(boolean.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Boolean.parseBoolean(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                boolean[] bs = new boolean[size];
                for (int i = 0; i < size; i++)
                    bs[i] = (Boolean) convert(ss[i]);
                return bs;
            }
        },
        /**
         * Represents the conversion to {@link Boolean}.
         * See {@link Boolean#parseBoolean(String)}.
         */
        BOOLEAN2(Boolean.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Boolean.parseBoolean(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                boolean[] bs = new boolean[size];
                for (int i = 0; i < size; i++)
                    bs[i] = (Boolean) convert(ss[i]);
                return bs;
            }
        },
        /**
         * Represents the conversion to {@link Byte}.
         * See {@link Byte#parseByte(String)}.
         */
        BYTE(byte.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Byte.parseByte(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                byte[] bs = new byte[size];
                for (int i = 0; i < size; i++)
                    bs[i] = (Byte) convert(ss[i]);
                return bs;
            }
        },
        /**
         * Represents the conversion to {@link Byte}.
         * See {@link Byte#parseByte(String)}.
         */
        BYTE2(Byte.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Byte.parseByte(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                byte[] bs = new byte[size];
                for (int i = 0; i < size; i++)
                    bs[i] = (Byte) convert(ss[i]);
                return bs;
            }
        },
        /**
         * Represents the conversion to {@link Character}.  If the given string has length 0, then
         * {@code null} is returned.  If The String has 1 or more length, then the first char is returned.
         */
        CHAR(char.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return s.length() == 0 ? null : s.charAt(0);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                char[] cs = new char[size];
                for (int i = 0; i < size; i++)
                    cs[i] = (Character) convert(ss[i]);
                return cs;
            }
        },
        /**
         * Represents the conversion to {@link Long}.
         * See {@link Long#parseLong(String)}.
         */
        LONG(long.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Long.parseLong(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                long[] ls = new long[size];
                for (int i = 0; i < size; i++)
                    ls[i] = (Long) convert(ss[i]);
                return ls;
            }
        },
        /**
         * Represents the conversion to {@link Long}.
         * See {@link Long#parseLong(String)}.
         */
        LONG2(Long.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Long.parseLong(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                long[] ls = new long[size];
                for (int i = 0; i < size; i++)
                    ls[i] = (Long) convert(ss[i]);
                return ls;
            }
        },
        /**
         * Represents the conversion to {@link Short}.
         * See {@link Short#parseShort(String)}.
         */
        SHORT(short.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Short.parseShort(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                short[] shs = new short[size];
                for (int i = 0; i < size; i++)
                    shs[i] = (Short) convert(ss[i]);
                return shs;
            }
        },
        /**
         * Represents the conversion to {@link Short}.
         * See {@link Short#parseShort(String)}.
         */
        SHORT2(Short.class)
        {
            @Override
            public Object convert(String s)
            {
                if (s == null)
                    return s;
                return Short.parseShort(s);
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                short[] shs = new short[size];
                for (int i = 0; i < size; i++)
                    shs[i] = (Short) convert(ss[i]);
                return shs;
            }
        },
        /**
         * This does not convert anything, and just simply returns the value as-is (it is provided as a String).
         */
        STRING(String.class)
        {
            @Override
            public Object convert(String s)
            {
                return s;
            }

            @Override
            public Object convertArray(String[] ss)
            {
                int size = ss.length;
                String[] sts = new String[size];
                for (int i = 0; i < size; i++)
                    sts[i] = (String) convert(ss[i]);
                return sts;
            }

        };

        /**
         * The delimiters used to break up a list into an array:
         * <ul>
         * <li>comma ","</li>
         * <li>space " "</li>
         * <li>tab "\t"</li>
         * </ul>
         */
        private final static String DELIMS = ", \t";

        private final Class<?> c;

        private ConvType(Class<?> convertingToClass)
        {
            c = convertingToClass;
        }

        /**
         * Converts the given String value to an instance of the class this {@code ConvType} represents.
         * @param s - The String to convert.
         * @return The converted value, or {@code null} if {@code s} was {@code null}.
         */
        public abstract Object convert(String s);

        public abstract Object convertArray(String[] ss);

        private Class<?> getConversionClass()
        {
            return c;
        }
    }

    private static final Map<Class<?>, ConvType> converters;

    static
    {
        converters = new HashMap<Class<?>, ConvType>();
        for (ConvType t : ConvType.values())
        {
            converters.put(t.getConversionClass(), t);
        }
    }

    private final Map<String, String> props;
    private final List<String> pars;
    private final Map<String, ParTable> builders;
    private final static String REGEX_DELIM = "[" + ConvType.DELIMS + "]";

    /**
     * Takes the given String {@code value} and converts it to an instance of the class
     * {@code c}.  If {@code value} is {@code null}, then {@code null} is returned.
     * The supported classes are:<br />
     * <ul>
     * <li>java.lang.String</li>
     * <li>java.lang.Byte</li>
     * <li>java.lang.Integer</li>
     * <li>java.lang.Long</li>
     * <li>java.lang.Short</li>
     * <li>java.lang.Float</li>
     * <li>java.lang.Double</li>
     * <li>java.lang.Boolean</li>
     * <li>java.lang.Character</li>
     * </ul>
     * Arrays of any of these types is also valid.
     * @param <E> - The return type, should be the same as the value of {@code c}.
     * @param value - The String value to convert.
     * @param c - The class type to convert to, should be the same as {@code E}.
     * @return The converted value, or {@code null}.
     * @throws NullPointerException If {@code c} is {@code null}.
     * @throws NumberFormatException If any conversion to a subclass of Number fails.
     * @throws IllegalArgumentException If anything but the listed classes is used.
     */
    @SuppressWarnings("unchecked")
    public static <E> E convertTo(String value, Class<? extends E> c)
    {
        if (c == null)
            throw new NullPointerException("Class argument was null");
        if (c.isArray())
            return convertArray(value, c);
        ConvType t = converters.get(c);
        if (t == null)
            throw new IllegalArgumentException("Cannot convert to class " + c);
        return (E) t.convert(value);
    }

    @SuppressWarnings("unchecked")
    private static <E> E convertArray(String value, Class<? extends E> c)
    {
    	if ( c == null )
    		return null;
    	
        Class<?> elementType = c.getComponentType();
        ConvType ct = converters.get(elementType);
        if (ct == null)
            throw new IllegalArgumentException("Cannot convert to array of component type " + elementType);
        return (E) ct.convertArray(value.split(REGEX_DELIM));
    }

    /**
     * Makes a new Parameters instantiated with no values.
     */
    public LibParParameters()
    {
        props = new HashMap<String, String>();
        pars = new ArrayList<String>();
        builders = new HashMap<String, ParTable>();
    }

    /**
     * Add a parfile reference to this parameter set
     * 
     * @param parfile
     */
    public void addParameterFile(String parfile)
    {
        pars.add(parfile);
    }

    /**
     * Adds a TableBuilder to the cache of builders in this instance.
     * @param tb - The TableBuilder to add.
     */
    public void addTable(ParTable tb)
    {
        if ( tb == null )
            return;
        
        builders.put(tb.getName(), tb);
    }

    /**
     * Returns the value associated with the given key, or null if
     * the key isn't registered or there is no value for the key.  
     * 
     * @param key - The key to get the value for.
     * @return The value, or null.
     */
    public String get(String key)
    {
        return props.get(key);
    }

    /**
     * Converts the value of {@code key} as per {@link #convertTo(String, Class)}.
     * @param <E> - The type to convert to.
     * @param key - The key associated with the value to convert.
     * @param c - The class to convert to.
     * @return The converted value.
     */
    public <E> E getAs(String key, Class<? extends E> c)
    {
        return convertTo(props.get(key), c);
    }

    /**
     * Converts the value of {@code key} as per {@link #convertTo(String, Class)}.
     * If there is no value associated with {@code key}, then {@code def} is returned.
     * @param <E> - The type to convert to.
     * @param key - The key associated with the value to convert.
     * @param c - The class to convert to.
     * @param def - The value to return if no value for {@code key} was found.
     * @return The converted value.
     */
    public <E> E getAsWithDefault(String key, Class<? extends E> c, E def)
    {
        String val = props.get(key);
        if (val == null)
            return def;
        return convertTo(val, c);
    }

    /**
     * Get the parameter files
     * 
     * @return 
     * 
     */
    public List<String> getParameterFiles()
    {
        return pars;
    }

    /**
     * Get the parameter names
     * 
     * @return
     */
    public Set<String> getParameterNames()
    {
        return new TreeSet<String>(props.keySet());
    }

    /**
     * Returns the TableBuilder associated with the given Table name.
     * @param tableName - The name of the table.
     * @return the TableBuilder associated with the given Table name.
     */
    public ParTable getTable(String tableName)
    {
        return builders.get(tableName);
    }

    /**
     * Get the table names
     * 
     * @return 
     * @return
     */
    public Set<String> getTableNames()
    {
        return builders.keySet();
    }

    /**
     * Get the parameter tables that are referenced by tables
     * 
     * @return
     */
    public Set<String> getTableParameterNames()
    {
        TreeSet<String> names = new TreeSet<String>();

        for (String tableName : getTableNames())
        {
            ParTable table = getTable(tableName);

            names.addAll(table.getParameterNames());
        }

        return names;
    }

    /**
     * Get the property values
     * 
     * @return
     */
    public Collection<String> getValues()
    {
        return props.values();
    }

    /**
     * Replace all instances of "find" with "replace"
     * 
     * @param find
     * @param replace
     */
    public void replace(String find, String replace)
    {
        //  Replace all parameters
        for (String key : getParameterNames())
        {
            String value = get(key);

            if (value.contains(find))
                set(key, value.replace(find, replace));
        }
        
        //  Replace all parameter tables
        for (String tableName : getTableNames())
        {
            ParTable table = getTable(tableName);
            
            for ( String column : table.getColumnNames())
                for ( String row : table.getRowNames() )
                {
                    String value = table.getTableValue(row, column);
                    if (value.contains(find))
                        table.setTableValue(row, column, value.replace(find, replace));
                }
        }

        //  Replace referenced par files
        for (int i=0; i<pars.size(); i++)
        {
            String value = pars.get(i);

            if (value.contains(find))
                pars.set(i, value.replace(find, replace));
        }
    }

    /**
     * Set all of the provided parameters into this parameter set
     * 
     * @param parameters
     */
    public void set(LibParParameters parameters)
    {
        for (String key : parameters.getParameterNames())
            set(key, parameters.get(key));
    }

    /**
     * Sets the key-value pair.  If the key is {@code null} a {@code NullPointerException} will be thrown.
     * If the value is {@code null}, then the key won't have any value associated with it.
     * @param key - They Key.
     * @param value - The Value.
     * @throws NullPointerException If {@code key} is {@code null}.
     */
    public void set(String key, String value)
    {
        props.put(key, value);
    }
    
    /**
     * Returns the number of set key-value pairs in this Parameters instance.  This does not count tables.
     * @return The number of registered key-value pairs.
     */
    public int size()
    {
        return props.size();
    }

    /**
     * Takes all of the parameters stored in the given Parameters instance and adds it to this
     * instance.
     * @param p - The Parameters instance to assimilate.
     */
    void assimilate(LibParParameters p)
    {
        for (Entry<String, String> e : p.props.entrySet())
        {
            props.put(e.getKey(), e.getValue());
        }
    }
}
