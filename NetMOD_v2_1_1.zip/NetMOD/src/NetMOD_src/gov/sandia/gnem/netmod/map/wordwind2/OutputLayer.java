/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.event.SelectEvent;
import gov.nasa.worldwind.event.SelectListener;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.pick.PickedObject;
import gov.nasa.worldwind.render.*;
import gov.nasa.worldwind.util.VecBufferBlocks;
import gov.nasa.worldwindx.examples.analytics.AnalyticSurface;
import gov.nasa.worldwindx.examples.analytics.AnalyticSurface.GridPointAttributes;
import gov.nasa.worldwindx.examples.analytics.AnalyticSurfaceAttributes;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.map.ShadingType;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.output.Output.COLOR_SCALING;

import javax.swing.*;
import java.awt.*;
import java.awt.image.IndexColorModel;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.List;
import java.util.*;

/**
 * @author bjmerch
 *
 */
class OutputLayer extends RenderableLayer implements Layer<Output>, SelectListener
{
    /**
     * Display a grid point with a value and a color
     * 
     * @author bjmerch
     *
     */
    private class OutputAttributes implements GridPointAttributes
    {
        private double _value;
        private double _min;
        private double _max;

        public OutputAttributes(double value, double min, double max)
        {
            _value = value;
            _min = min;
            _max = max;
        }

        @Override
        public Color getColor()
        {
            //  Get the color model
            IndexColorModel colorModel = _output.getSurfaceColorModel().getColorModel();
            
            //  Convert the scaled value to an index
            int index = Math.max(0, Math.min(255, (int) ((getValue() - _min) * 255 / (_max - _min))));

            //  Lookup the color for this index
            return new Color(colorModel.getRGB(index));
        }

        @Override
        public double getValue()
        {
            return _value;
        }
    }
    private Output _output;
    private GlobeAnnotation _tooltip;

    private WorldWindow _wwd;

    protected OutputLayer(WorldWindow wwd, Output data)
    {
        _wwd = wwd;

        //  Initialize the tooltip
        _tooltip = new GlobeAnnotation("", Position.fromDegrees(0, 0, 0));
        _tooltip.getAttributes().setFont(new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue()));
        _tooltip.getAttributes().setDistanceMinOpacity(1);
        _tooltip.getAttributes().setDistanceMaxScale(1);
        _tooltip.getAttributes().setVisible(false);
        _tooltip.getAttributes().setAdjustWidthToText(AVKey.SIZE_FIT_TEXT);
        _tooltip.getAttributes().setLeaderGapWidth(20);
        _tooltip.setAlwaysOnTop(true);

        //  Set the data
        setNMC(data);
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public String getName()
    {
        return _output.getName();
    }

    @Override
    public Output getNMC()
    {
        return _output;
    }

    @Override
    public void selected(SelectEvent event)
    {
        if (event.isConsumed())
            return;

        if (event.getEventAction().equals(SelectEvent.ROLLOVER))
        {
            PickedObject object = event.getTopPickedObject();
            if (object != null && object.getParentLayer() == this)
            {
                Position position = object.getPosition();
                if (position != null)
                {
                    int displayIndex = _output.getSurfaceIndex();
                    if ( displayIndex < 0 )
                    {
                        _tooltip.getAttributes().setVisible(false);
                        return;
                    }
                    int index = _output.getNearestEpicenter(position.getLatitude().getDegrees(), position.getLongitude().getDegrees());

                    _tooltip.setPosition(position);
                    
                    String label = Float.toString((float) _output.getEpicenterValue(index, displayIndex));
                    if ( displayIndex == Output.SIMULGRID_SIZE)
                        label = label + " " + _output.getSimulKeyValue(Output.SIMULKEY_SIZE_TYPE);
                    
                    _tooltip.setText(label);
                    _tooltip.getAttributes().setVisible(true);

                    event.consume();
                }
            }
            else
                _tooltip.getAttributes().setVisible(false);
        }

    }
    
    @Override
    public void setDisplay(DISPLAY display)
    {
        
    }

    @Override
    public void setNMC(Output data)
    {
        _output = data;

        setPickEnabled(true);

        //  Remove all renderables
        removeAllRenderables();

        //  Add the surface
        ShadingType type = ShadingType.valueOf(Property.MAP_OUTPUT_SHADING.getValue().toLowerCase());
        if (type == ShadingType.flat)
            addRenderables(generateSurfacePolygons(data));
        else if (type == ShadingType.bilinear)
        {
            AnalyticSurface surface = generateSurface(data);
            if ( surface != null )
                addRenderable(surface);
        }

        //  Add contour lines
        addRenderables(generateContours(data));

        //  Add the tooltip
        addRenderable(_tooltip);

        //  Add a legend
        //addRenderable(new OutputLegend());
    }

    @Override
    public void setVisible(boolean value)
    {
        setEnabled(value);
    }

    private List<Renderable> generateContours(Output output)
    {
        ArrayList<Renderable> lines = new ArrayList<Renderable>();
        
        int index = output.getContourIndex();
        if ( index < 0 )
            return lines;

        //  Assemble the data to be displayed
        int Ntotal = output.getNumberEpicenters();
        Map<Point.Double, List<Double>> values = new TreeMap<Point.Double, List<Double>>();
        for (int i = 0; i < Ntotal; i++)
        {
            List<Double> row = new ArrayList<Double>();
            row.add(output.getEpicenterValue(i, index));

            values.put(new Point.Double(output.getEpicenterValue(i, Output.SIMULGRID_LAT), output.getEpicenterValue(i, Output.SIMULGRID_LON)), row);
        }

        //  Ensure the data is a regular grid
        values = MapUtility.interpolateIfNecessary(values);

        //  Sort the points to ensure correct ordering
        List<Point.Double> points = new ArrayList<Point.Double>(values.keySet());
        Collections.sort(points);
        Ntotal = points.size();

        //  Determine the extent of the grid
        double minLat = Double.POSITIVE_INFINITY;
        double maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY;
        double maxLon = Double.NEGATIVE_INFINITY;

        for (int i = 0; i < Ntotal; i++)
        {
            Point.Double p = points.get(i);

            minLat = Math.min(minLat, p.getLatitude());
            maxLat = Math.max(maxLat, p.getLatitude());
            minLon = Math.min(minLon, p.getLongitude());
            maxLon = Math.max(maxLon, p.getLongitude());
        }

        Sector sector = Sector.fromDegrees(minLat, maxLat, minLon, maxLon);

        //  Determine the dimensions of the grid
        int tmp;
        for (tmp = 1; tmp < Ntotal; tmp++)
            if (points.get(tmp).getLatitude() != points.get(tmp - 1).getLatitude())
                break;

        int M = tmp;
        int N = points.size() / M;

        //  Extract the data
        int count = 0;
        double[][] data = new double[M][N];
        for (int j = 0; j < N; j++)
            for (int i = 0; i < M; i++)
                data[i][j] = values.get(points.get(count++)).get(0);

        //  Define the latitudes and longitudes
        double[] latitudes = new double[N];
        double[] longitudes = new double[M];

        double dLat = (maxLat - minLat) / (N - 1);
        for (int i = 0; i < N; i++)
            latitudes[i] = minLat + i * dLat;

        double dLon = (maxLon - minLon) / (M - 1);
        for (int i = 0; i < M; i++)
            longitudes[i] = minLon + i * dLon;

        //  Define the line appearance
        BasicShapeAttributes lineAttributes = new BasicShapeAttributes();
        lineAttributes.setEnableAntialiasing(true);
        lineAttributes.setOutlineMaterial(new Material(Property.MAP_OUTPUT_CONTOUR_COLOR.getColorValue()));
        lineAttributes.setOutlineWidth(Property.MAP_OUTPUT_CONTOUR_WIDTH.getFloatValue());
        lineAttributes.setDrawInterior(false);
        lineAttributes.setDrawOutline(true);
        
        //  Define the label appearance
        int size = 10;
        AnnotationAttributes rendererAttributes = new AnnotationAttributes();
        rendererAttributes.setLeader(AVKey.SHAPE_TRIANGLE);
        rendererAttributes.setImageOffset(new java.awt.Point(size, 0));
        rendererAttributes.setInsets(new Insets(0, 2 * size, 0, 0));
        rendererAttributes.setAdjustWidthToText(AVKey.SIZE_FIT_TEXT);
        rendererAttributes.setBorderWidth(0);
        rendererAttributes.setCornerRadius(0);
        rendererAttributes.setBackgroundColor(new Color(0,0,0,0));
        rendererAttributes.setTextColor(Property.MAP_OUTPUT_CONTOUR_COLOR.getColorValue());
        rendererAttributes.setScale(1); 
        rendererAttributes.setImageRepeat(AVKey.REPEAT_NONE);       
        rendererAttributes.setFont(new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue()));
        rendererAttributes.setDrawOffset(new java.awt.Point(size,-2*size));
        rendererAttributes.setImageSource(null);

        for (double contourLevel : output.getContourLevels())
        {
            //  Compute the contours
            Collection<List<Point.Double>> contourLines = MapUtility.generateContours(latitudes, longitudes, data, contourLevel);
            
            //  Generate lines for each of the contours
            for (List<Point.Double> linePoints : contourLines)
            {
                //  Convert the points to LatLon objects
                List<LatLon> points2 = new ArrayList<LatLon>();
                for (Point.Double p : linePoints)
                    points2.add(LatLon.fromDegrees(p.getLatitude(), p.getLongitude()));
                
                //  Build the polyline
                lines.add(new SurfacePolyline(lineAttributes, points2));
                
                //  Identify the position with the lowest latitude
                LatLon p = points2.get(0);
                for (LatLon p_next : points2)
                    if ( p_next.getLatitude().getDegrees() <= p.getLatitude().getDegrees() )
                        p = p_next;

                lines.add(new GlobeAnnotation(String.format("%6.3f", contourLevel), new Position(p, 0), rendererAttributes));                
            }
        }

        return lines;
    }

    /**
     * Generate a surface that represents the provided output
     * 
     * @param output
     * @return
     */
    private AnalyticSurface generateSurface(Output output)
    {
        int index = output.getSurfaceIndex();
        if ( index < 0 )
            return null;

        //  Assemble the data to be displayed
        int Ntotal = output.getNumberEpicenters();
        Map<Point.Double, List<Double>> values = new TreeMap<Point.Double, List<Double>>();
        for (int i = 0; i < Ntotal; i++)
        {
            List<Double> row = new ArrayList<Double>();
            row.add(output.getEpicenterValue(i, index));

            values.put(new Point.Double(output.getEpicenterValue(i, Output.SIMULGRID_LAT), output.getEpicenterValue(i, Output.SIMULGRID_LON)), row);
        }

        //  Ensure the data is a regular grid
        values = MapUtility.interpolateIfNecessary(values);

        //  Sort the points to ensure correct ordering
        List<Point.Double> points = new ArrayList<Point.Double>(values.keySet());
        Collections.sort(points);
        Ntotal = points.size();

        //  Determine the extent of the grid
        double minLat = Double.POSITIVE_INFINITY;
        double maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY;
        double maxLon = Double.NEGATIVE_INFINITY;

        for (int i = 0; i < Ntotal; i++)
        {
            Point.Double p = points.get(i);

            minLat = Math.min(minLat, p.getLatitude());
            maxLat = Math.max(maxLat, p.getLatitude());
            minLon = Math.min(minLon, p.getLongitude());
            maxLon = Math.max(maxLon, p.getLongitude());
        }

        Sector sector = Sector.fromDegrees(minLat, maxLat, minLon, maxLon);

        //  Determine the dimensions of the grid
        int tmp;
        for (tmp = 1; tmp < Ntotal; tmp++)
            if (points.get(tmp).getLatitude() != points.get(tmp - 1).getLatitude())
                break;

        int M = tmp;
        int N = points.size() / M;

        //  Extract the data
        int count = 0;
        double[][] data = new double[N][M];
        for (int i = N; --i >= 0;)
            for (int j = 0; j < M; j++)
                data[i][j] = values.get(points.get(count++)).get(0);
        
        double min = _output.getSurfaceMin();
        double max = _output.getSurfaceMax();

        //  Control log scaling
        boolean log = _output.getColorScaling() == COLOR_SCALING.LOG;
        
        if ( log )
        {
            min = Math.log10(min);
            max = Math.log10(max);

            for (int i = N; --i >= 0;)
                for (int j = 0; j < M; j++)
                    data[i][j] = Math.log10(data[i][j]);
        }

        // Generate the attributes list
        count = 0;
        List<GridPointAttributes> attributes = new ArrayList<GridPointAttributes>();
        for (int i = 0; i < N; i++)
            for (int j = 0; j < M; j++)
                attributes.add(new OutputAttributes(data[i][j], min, max));

        //  Create the surface
        AnalyticSurface surface = new AnalyticSurface(sector, 0.0, M, N, attributes);

        surface.setAltitude(0);
        surface.setAltitudeMode(WorldWind.CLAMP_TO_GROUND);
        surface.setClientLayer(this);

        //  Set the surface attributes
        AnalyticSurfaceAttributes attr = new AnalyticSurfaceAttributes();
        attr.setDrawShadow(false);
        attr.setInteriorOpacity(_output.getSurfaceTransparency());
        attr.setOutlineWidth(1);
        surface.setSurfaceAttributes(attr);

        return surface;
    }

    private List<SurfacePolygons> generateSurfacePolygons(Output output)
    {
        List<SurfacePolygons> polygons = new ArrayList<SurfacePolygons>();

        int index = output.getSurfaceIndex();
        if ( index < 0 )
            return polygons;

        //  Assemble the data to be displayed
        int Ntotal = output.getNumberEpicenters();
        Map<Point.Double, List<Double>> values = new TreeMap<Point.Double, List<Double>>();
        for (int i = 0; i < Ntotal; i++)
        {
            List<Double> row = new ArrayList<Double>();
            row.add(output.getEpicenterValue(i, index));

            values.put(new Point.Double(output.getEpicenterValue(i, Output.SIMULGRID_LAT), output.getEpicenterValue(i, Output.SIMULGRID_LON)), row);
        }

        //  Ensure the data is a regular grid
        values = MapUtility.interpolateIfNecessary(values);

        //  Sort the points to ensure correct ordering
        List<Point.Double> points = new ArrayList<Point.Double>(values.keySet());
        Collections.sort(points);
        Ntotal = points.size();

        //  Determine the extent of the grid
        double minLat = Double.POSITIVE_INFINITY;
        double maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY;
        double maxLon = Double.NEGATIVE_INFINITY;

        for (int i = 0; i < Ntotal; i++)
        {
            Point.Double p = points.get(i);

            minLat = Math.min(minLat, p.getLatitude());
            maxLat = Math.max(maxLat, p.getLatitude());
            minLon = Math.min(minLon, p.getLongitude());
            maxLon = Math.max(maxLon, p.getLongitude());
        }

        //  Determine the dimensions of the grid
        int tmp;
        for (tmp = 1; tmp < Ntotal; tmp++)
            if (points.get(tmp).getLatitude() != points.get(tmp - 1).getLatitude())
                break;

        final int M = tmp;
        final int N = points.size() / M;

        //  Determine the latitude and longitude delta
        float dLat = (float) ((maxLat - minLat) / (N - 1));
        float dLon = (float) ((maxLon - minLon) / (M - 1));

        //  Build a bytebuffer containing the region coordinates
        int scale = java.lang.Float.SIZE / java.lang.Byte.SIZE * 2;
        byte[] bytes = new byte[5 * scale * N * M];
        FloatBuffer floatBuffer = ByteBuffer.wrap(bytes).asFloatBuffer();
        int Npoints = points.size();
        for (int count = 0; count < Npoints; count++)
        {
            float lon = (float) (points.get(count).getLongitude() - dLon / 2);
            float lat = (float) (points.get(count).getLatitude() - dLat / 2);

            floatBuffer.put(lon);
            floatBuffer.put(lat);

            floatBuffer.put(lon);
            floatBuffer.put(lat + dLat);

            floatBuffer.put(lon + dLon);
            floatBuffer.put(lat + dLat);

            floatBuffer.put(lon + dLon);
            floatBuffer.put(lat);

            floatBuffer.put(lon);
            floatBuffer.put(lat);
        }

        //  Create compound vector buffers for each color
        int Ncolors = 256;
        VecBufferBlocks[] buffers = new VecBufferBlocks[Ncolors];

        //  Get the color model
        IndexColorModel colorModel = _output.getSurfaceColorModel().getColorModel();
        double valueMin = _output.getSurfaceMin();
        double valueMax = _output.getSurfaceMax();
        
        //  Control log scaling
        boolean log = _output.getColorScaling() == COLOR_SCALING.LOG;
        
        if ( log )
        {
            valueMin = Math.log10(valueMin);
            valueMax = Math.log10(valueMax);
        }

        //  Assign each region to the appropriate vecbufferblock
        for (int count = 0; count < Npoints; count++)
        {
            //  Get the value
            double value = values.get(points.get(count)).get(0);
            
            if ( log )
                value = Math.log10(value);

            //  Convert the value to a color index
            int c_index = (int) Math.max(0, Math.min(Ncolors - 1, (value - valueMin) * (Ncolors - 1) / (valueMax - valueMin)));

            //  Add a polygon for this region
            if (buffers[c_index] == null)
                buffers[c_index] = new VecBufferBlocks(2, AVKey.FLOAT32, ByteBuffer.wrap(bytes));

            buffers[c_index].addBlock(count * 5 * scale, (count + 1) * 5 * scale - 1);
        }

        //  Create a SurfacePolygons object for each color
        Sector sector = Sector.fromDegrees(minLat, maxLat, minLon, maxLon);
        for (int i = 0; i < Ncolors; i++)
        {
            if (buffers[i] == null)
                continue;

            //  Define the attributes
            ShapeAttributes attrs = new BasicShapeAttributes();
            attrs.setInteriorOpacity(_output.getSurfaceTransparency());
            attrs.setInteriorMaterial(new Material(new Color(colorModel.getRGB((256 / Ncolors) * i))));
            attrs.setDrawOutline(false);
            attrs.setDrawInterior(true);

            //  Construct the polygons
            SurfacePolygons polygon = new SurfacePolygons(sector, buffers[i]);
            polygon.setAttributes(attrs);

            polygons.add(polygon);
        }

        return polygons;
    }
}
