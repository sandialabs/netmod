/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameter;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.receiver.attenuation.StationAttenuation;
import gov.sandia.gnem.netmod.receiver.attenuation.StationAttenuationPlugin;
import gov.sandia.gnem.netmod.receiver.response.SiteResponse;
import gov.sandia.gnem.netmod.receiver.response.SiteResponsePlugin;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class StationPhaseParameter extends PhaseParameter
{
    private NormalPDF _logAmplitudeCorrection = NormalPDF.ZERO;
    private double _snrThreshold;
    private double _receiverMediaVelocity;
    private String _siteResponseFile = "";
    private String _stationAttenuationFile = "";
    
    //  Cached objects
    transient private SiteResponse _siteResponse = null;
    transient private StationAttenuation _stationAttenuation = null;

    /**
     * @param phase
     */
    public StationPhaseParameter(NetModComponent parent, Phase phase)
    {
        super(parent, phase);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getSiteResponse());
        children.add(getStationAttenuation());

        return children;
    }

    /**
     * @return the correctionLogAmplitude
     */
    public NormalPDF getLogAmplitudeCorrection()
    {
        return _logAmplitudeCorrection;
    }

    /**
     * @return the receiverMediaVelocity
     */
    public double getReceiverMediaVelocity()
    {
        return _receiverMediaVelocity;
    }

    /**
     * @return the siteResponse
     */
    public SiteResponse getSiteResponse()
    {
        if ( _siteResponse == null )
        {
            _siteResponse = SiteResponsePlugin.getPlugin().getComponentFor(this, getSiteResponseFile());
            if ( _siteResponse != null )
            	_siteResponse.setFilename(getSiteResponseFile());
        }
        
        return _siteResponse;
    }

    /**
     * @return the siteResponseFile
     */
    public String getSiteResponseFile()
    {
        return _siteResponseFile;
    }

    /**
     * @return the site Transmission Loss File
     */
    public String getStationAttenuationFile()
    {
        return _stationAttenuationFile;
    }

    /**
     * @return the snrDetectionThreshold
     */
    public double getSnrThreshold()
    {
        return _snrThreshold;
    }

    @Override
    public StationPhaseParameterViewer getViewer()
    {
        return new StationPhaseParameterViewer(this);
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof SiteResponse)
                setSiteResponse((SiteResponse) child);
        }

        clearCache();
    }

    /**
     * @param correctionLogAmplitude the correctionLogAmplitude to set
     */
    public void setLogAmplitudeCorrection(NormalPDF correctionLogAmplitude)
    {
        _logAmplitudeCorrection = correctionLogAmplitude;
    }

    /**
     * @param receiverMediaVelocity the receiverMediaVelocity to set
     */
    public void setReceiverMediaVelocity(double receiverMediaVelocity)
    {
        _receiverMediaVelocity = receiverMediaVelocity;
    }

    /**
     * @param siteResponse the siteResponse to set
     */
    public void setSiteResponse(SiteResponse siteResponse)
    {
        if ( siteResponse != null )
            _siteResponseFile = siteResponse.getFilename();
        
        _siteResponse = siteResponse;
    }

    /**
     * @param siteResponseFile the siteResponseFile to set
     */
    public void setSiteResponseFile(String siteResponseFile)
    {
        if ( _siteResponseFile.equals(siteResponseFile) )
            return;
        
        //  If file exists, load it
        if ( _siteResponse == null || !getSiteResponse().isAvailable() || IOUtility.openFile(siteResponseFile).exists() )
        {
            _siteResponseFile = siteResponseFile;
            setSiteResponse(null);
        }
        //  Otherwise, save to it
        else
        {
            SiteResponse siteResponse = getSiteResponse();
            siteResponse.read();
            siteResponse.setFilename(siteResponseFile);
            siteResponse.write();
            _siteResponseFile = siteResponse.getFilename();
        }
    }

    /**
     * @param stationAttenuationFile the stationAttenuationFile to set
     */
    public void setStationAttenuationFile(String stationAttenuationFile)
    {
        if ( _stationAttenuationFile.equals(stationAttenuationFile) )
        {
            return;
        }
        
        //  If file doesn't exist, load new files
        if ( _stationAttenuationFile == null || getStationAttenuation() == null || !getStationAttenuation().isAvailable() || IOUtility.openFile(stationAttenuationFile).exists() )
        {
        	_stationAttenuationFile = stationAttenuationFile;
            setStationAttenuation(null);
        }
        //  Otherwise, save to it
        else
        {
            StationAttenuation stationAttenuation = getStationAttenuation();
            stationAttenuation.read();
            stationAttenuation.setFilename(stationAttenuationFile);
            stationAttenuation.write();
            _stationAttenuationFile = stationAttenuation.getFilename();
        }
    }

    /**
     * @param snrDetectionThreshold the snrDetectionThreshold to set
     */
    public void setSnrThreshold(double snrDetectionThreshold)
    {
        _snrThreshold = snrDetectionThreshold;
    }

    /**
     * @return the station attenuation
     */
    public StationAttenuation getStationAttenuation()
    {
        if ( _stationAttenuation == null )
        {
        	_stationAttenuation = StationAttenuationPlugin.getPlugin().getComponentFor(this, getStationAttenuationFile());
            if ( _stationAttenuation != null )
            	_stationAttenuation.setFilename(getStationAttenuationFile());
        }
        
        return _stationAttenuation;
    }

    /**
     * @param siteResponse the siteResponse to set
     */
    public void setStationAttenuation(StationAttenuation stationAttenuation)
    {
        if ( stationAttenuation != null )
        	_stationAttenuationFile = stationAttenuation.getFilename();
        
        _stationAttenuation = stationAttenuation;
    }
}
