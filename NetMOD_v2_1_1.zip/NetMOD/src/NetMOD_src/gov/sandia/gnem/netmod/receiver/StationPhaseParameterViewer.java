/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.plugin.PhaseParameterViewer;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.receiver.attenuation.StationAttenuation;
import gov.sandia.gnem.netmod.receiver.response.SiteResponse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 *
 */
public class StationPhaseParameterViewer extends PhaseParameterViewer<StationPhaseParameter>
{
	//  Multiple phase labels because each can only be contained once
    private JLabel _phase1 = new JLabel("P:");
    private JLabel _phase2 = new JLabel("P:");
    private JLabel _phase3 = new JLabel("P:");
    private JFormattedTextField _correctionLogAmplitude = new JFormattedTextField(new DoubleRangeFormatter());
    private JFormattedTextField _stddevLogAmplitude = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _snrDetectionThreshold = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _receiverMediaVelocity = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private FileField _responseFile = new FileField("Site Response File", createViewResponseButton());
    private FileField _attenuationFile = new FileField("Site Attenuation File", createViewStationAttenuationButton());

    public StationPhaseParameterViewer(StationPhaseParameter nmc)
    {
        super(nmc);

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored after updating
        registerControls(_correctionLogAmplitude, _stddevLogAmplitude, _snrDetectionThreshold, _receiverMediaVelocity, _responseFile, _attenuationFile);
    }

    @Override
    public void apply(StationPhaseParameter nmc)
    {
        nmc.setLogAmplitudeCorrection(new NormalPDF(((Number) _correctionLogAmplitude.getValue()).doubleValue(), ((Number) _stddevLogAmplitude.getValue())
                .doubleValue()));
        nmc.setReceiverMediaVelocity(((Number) _receiverMediaVelocity.getValue()).doubleValue());
        nmc.setSnrThreshold(((Number) _snrDetectionThreshold.getValue()).doubleValue());
        nmc.setSiteResponseFile(_responseFile.getText());
        nmc.setStationAttenuationFile(_attenuationFile.getText());
    }

    private JButton createViewResponseButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Response");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                //  Get the response object
                SiteResponse siteResponse = _nmc.getSiteResponse();
                if (siteResponse == null || !siteResponse.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) siteResponse
                        .getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Site Response - " + siteResponse.getName());
            }
        });

        return button;
    }

    private JButton createViewStationAttenuationButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Station Attenuation");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                //  Get the attenuation object
            	StationAttenuation siteAttenuation = _nmc.getStationAttenuation();
                if (siteAttenuation == null || !siteAttenuation.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) siteAttenuation
                        .getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Site Attenuation - " + siteAttenuation.getName());
            }
        });

        return button;
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            _correctionLogAmplitude.setToolTipText("Receiver Amplitude Correction (log10)");
            _stddevLogAmplitude.setToolTipText("Standard Deviation of Amplitude Correction (log10)");
            _receiverMediaVelocity.setToolTipText("Receiver Media Velocity (m/s)");
            _snrDetectionThreshold.setToolTipText("Detection SNR Threshold (ratio)");

            GUIUtility.addRow(panel, _phase1, _correctionLogAmplitude, _stddevLogAmplitude, _receiverMediaVelocity, _snrDetectionThreshold, _responseFile);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public JPanel getHeader()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "),
                new JLabel("<html>Amplitude Correction</html>"),
                new JLabel("<html>Standard Deviation</html>"),
                new JLabel("<html>Media Velocity</html>"),
                new JLabel("<html>Detection SNR</html>")
                );
        
        return panel;
    }

    @Override
    public JPanel getHeader1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "), 
                new JLabel("Site Response Files:"));
        
        return panel;
    }

    @Override
    public JPanel getHeader2()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "), 
                new JLabel("Site Transmission Loss Files:"));
        
        return panel;
    }

    @Override
    public JPanel getPanel1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        GUIUtility.addRow(panel, _phase2, _responseFile);
        
        return panel;
    }

    @Override
    public JPanel getPanel2()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        GUIUtility.addRow(panel, _phase3, _attenuationFile);
        
        return panel;
    }

    @Override
    public void reset(StationPhaseParameter nmc)
    {
        _phase1.setText(nmc.getPhase() + ":");
        _phase2.setText(nmc.getPhase() + ":");
        _phase3.setText(nmc.getPhase() + ":");
        _correctionLogAmplitude.setValue(nmc.getLogAmplitudeCorrection().getMean());
        _stddevLogAmplitude.setValue(nmc.getLogAmplitudeCorrection().getStandardDeviation());
        _receiverMediaVelocity.setValue(nmc.getReceiverMediaVelocity());
        _snrDetectionThreshold.setValue(nmc.getSnrThreshold());
        _responseFile.setText(nmc.getSiteResponseFile());
        _attenuationFile.setText(nmc.getStationAttenuationFile());
    }
}
