/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.plugin;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.introspection.Introspection;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.NumericUtility;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public abstract class AbstractNetModComponent implements NetModComponent, Comparable<NetModComponent>
{
    private static final DecimalFormat _decimalFormat = new DecimalFormat("####0.0####");
    private String _type = "";
    private String _name = "";
    protected Introspection _introspection = null;
    private NetModComponent _parent = null;

    /**
     * Create a new NetModComponent with empty string for a type and name
     */
    protected AbstractNetModComponent(NetModComponent parent)
    {
        this(parent, "");
    }

    /**
     * Create a new NetModComponent with the provided type serving as a name.
     * 
     * @param type
     */
    protected AbstractNetModComponent(NetModComponent parent, String type)
    {
        this(parent, type, type);
    }

    /**
     * Create a new NetModComponent with the provided type and name.
     * 
     * @param type
     * @param name
     */
    protected AbstractNetModComponent(NetModComponent parent, String type, String name)
    {
        _parent = parent;
        _type = type;
        setName(name);
    }

    /**
     * Add the component to the set of children
     * 
     * @param component
     * @return
     */
    public boolean add(NetModComponent component)
    {
        //  Check if the component can be added
        if (!canContain(component))
            return false;

        //  Add the component
        List<NetModComponent> children = getChildren();
        
        children.add(component);
        setChildren(children);

        //  Check if the component was accepted
        return getChildren().contains(component);
    }

    /**
     * Add the components to the set of children
     * 
     * @param components
     */
    public void addAll(Collection<? extends NetModComponent> components)
    {
        for (NetModComponent component : components)
            add(component);
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return false;
    }

    @Override
    public void clearCache()
    {
        for (NetModComponent nmc : getChildren())
            if ( nmc != null )
                nmc.clearCache();
    }

    @Override
    public Object clone()
    {
        try
        {
            return super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            GUIUtility.showExceptionDialog(null, "Error cloning database object", e.getMessage(), e);

            return null;
        }
    }

    @Override
    public int compareTo(NetModComponent nmc)
    {
        return getName().compareTo(nmc.getName());
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        return new ArrayList<NetModComponent>();
    }

    @Override
    public Icon getIcon()
    {
        return null;
    }

    @Override
    public Introspection getIntrospection()
    {
        return _introspection;
    }

    @Override
    public Layer<?> getMapLayer()
    {
        return null;
    }

    @Override
    public String getName()
    {
        return _name;
    }

    @Override
    public NetModComponent getParent()
    {
        return _parent;
    }

    @Override
    public String getType()
    {
        return _type;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new NetModComponentViewer<AbstractNetModComponent>(this, false, false, false)
        {
            @Override
            public JPanel getExpandedPanel()
            {
                return new JPanel();
            }
        };
    }

    @Override
    public boolean isFor(Object o)
    {
        return false;
    }

    @Override
    public boolean isLeaf()
    {
        return false;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
    }

    public boolean remove(NetModComponent component)
    {
        //  Check if the component can be added
        if (!canContain(component))
            return false;

        //  Add the component
        List<NetModComponent> children = getChildren();
        children.remove(component);
        setChildren(children);

        //  Check if the component was accepted
        return getChildren().contains(component);
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
    }

    @Override
    public void setParent(NetModComponent parent)
    {
        _parent = parent;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {}

    @Override
    public void setIntrospection(Introspection introspection)
    {
        //  Set the introspection object
        _introspection = introspection;

        //  Set for all children
        for (NetModComponent child : getChildren())
            if ( child != null )
                child.setIntrospection(introspection);
    }
    
    @Override
    public void setName(String name)
    {
        _name = name;
    }
    
    @Override
    public String toString()
    {
        return getName();
    }

    /**
     * Check whether introspection is being performed
     * 
     * @return
     */
    protected final boolean isIntrospection()
    {
        return _introspection != null;
    }
    
    /**
     * Record the following objects for introspection
     * 
     * @param notes
     */
    protected final void recordIntrospection(Object... notes)
    {
        if ( isIntrospection() )
        {
            int N = notes.length;
            if ( N == 0 )
                return;
            
            for (int i = 0; i < N; i++)
            {
                Object note = notes[i];

                if (i == N - 1)
                {
                    //  Convert a double array to a string
                    if (note instanceof double[])
                    {
                        notes[i] = null;
                        _introspection.addNote(notes);
                        recordIntrospectionArray((double[]) note);
                        return;
                    }
                    else if (note != null && note.getClass().isArray())
                    {
                        notes[i] = null;
                        _introspection.addNote(notes);
                        recordIntrospectionArray((Object[]) note);
                        return;
                    }
                }
                
                if (note instanceof Double)
                {
                    notes[i] = GUIUtility.format((Double) note);
                }
            }
            
            _introspection.addNote(notes);
        }
    }
    
    /**
     * Record the following note and double value for introspection.
     * This alternate method is provided to reduce call overhead
     * when introspection has been disabled.  It avoids the
     * creation of an arbitrary length array and the creation of a Double object.
     * 
     * @param note
     * @param value
     */
    protected final void recordIntrospection(String note, double value)
    {
        if ( isIntrospection() )
        {
            double absValue = Math.abs(value);
            if ( absValue > 0.001 && absValue < 100000)
                recordIntrospection(note, GUIUtility.format(value));
            else
                recordIntrospection(note, String.format("%7.4g", value));
        }
    }
    
    /**
     * Record the following note and double value for introspection.
     * This alternate method is provided to reduce call overhead
     * when introspection has been disabled.  It avoids the
     * creation of an arbitrary length array and the creation of a Double object.
     * 
     * @param note
     * @param value
     */
    protected final void recordIntrospection(String note1, String note2, double value)
    {
        if ( isIntrospection() )
        {
            double absValue = Math.abs(value);
            if ( absValue > 0.001 && absValue < 100000)
                recordIntrospection(note1, note2, GUIUtility.format(value));
            else
                recordIntrospection(note1, note2, String.format("%7.4g", value));
        }
    }
    
    /**
     * Record the following note and double values for introspection.
     * Provide formatting and mean/std statistics for the double array
     * 
     * @param note
     * @param values
     */
    protected final void recordIntrospection(String note, double[] values)
    {
        if ( isIntrospection() )
        {
            recordIntrospection(note);
            recordIntrospectionArray(values);
        }
    }
    
    private final void recordIntrospectionArray(Object[] values)
    {
        if ( isIntrospection() )
        {
            String tab = "\t";
            StringBuilder sb = new StringBuilder(tab);
            
            int N = values.length - 1;

            for (int i = 0; i < N; ++i)
            {
                if ( values[i] == null )
                    continue;
                
                sb.append(values[i].toString());
                
                //  Insert a comma separator between values
                sb.append(", ");

                //  Insert a line break every 10 values or 100 characters
                if ((i + 1) % 10 == 0 || sb.length() > 100)
                {
                    recordIntrospection(sb.toString());
                    sb.delete(0, sb.length());
                    sb.append(tab);
                }
            }
            
            if ( N >= 0 )
                sb.append(values[N].toString());
            
            recordIntrospection(sb.toString());
        }
    }
    
    private final void recordIntrospectionArray(double[] values)
    {
        if ( isIntrospection() )
        {
            String tab = "\t";
            StringBuilder sb = new StringBuilder(tab);
            
            int N = values.length - 1;

            for (int i = 0; i < N; ++i)
            {
                sb.append(GUIUtility.format(values[i]));
                
                //  Insert a comma separator between values
                sb.append(", ");

                //  Insert a line break every 10 values
                if ((i + 1) % 10 == 0)
                {
                    recordIntrospection(sb.toString());
                    sb.delete(0, sb.length());
                    sb.append(tab);
                }
            }
            
            if ( N >= 0 )
                sb.append(GUIUtility.format(values[N]));
            
            recordIntrospection(sb.toString());
            
            //  Record the mean and standard deviation
            double mean = NumericUtility.mean(values);
            double std = NumericUtility.std(values, mean);
            
            recordIntrospection(tab, "Mean: ", GUIUtility.format(mean));
            recordIntrospection(tab, "Std:  ", GUIUtility.format(std));
        }
    }
   
    
    /**
     * Record the following note and double value for introspection.
     * This alternate method is provided to reduce call overhead
     * when introspection has been disabled.  It avoids the
     * creation of an arbitrary length array and the creation of an Integer object.
     * 
     * @param note
     * @param value
     */
    protected final void recordIntrospection(String note, int value)
    {
        if ( isIntrospection() )
            recordIntrospection(note, Integer.toString(value));
    }

    /**
     * Reset the introspection
     */
    protected final void resetIntrospection()
    {
        if (_introspection == null)
            _introspection = new Introspection();
        
        setIntrospection(_introspection);
        
        _introspection.reset();
    }

    /**
     * Start recording introspection details for this NetModComponent
     */
    protected final void startIntrospection()
    {
        if ( isIntrospection() )
            _introspection.startNode();
    }
    
    /**
     * Set the introspection status type
     * 
     * @param status
     */
    protected final void statusIntrospection(StatusType status)
    {
        if ( isIntrospection() )
            _introspection.setStatus(status);
    }
    
    /**
     * Stop Recording introspection details for this NetModComponent
     * 
     */
    protected final void stopIntrospection()
    {
        if ( isIntrospection() )
            _introspection.endNode();
    }
}
