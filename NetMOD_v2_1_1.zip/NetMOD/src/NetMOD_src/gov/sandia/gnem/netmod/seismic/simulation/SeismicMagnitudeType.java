/**
 * 
 */
package gov.sandia.gnem.netmod.seismic.simulation;

import gov.sandia.gnem.netmod.simulation.MagnitudeType;

import java.util.Arrays;
import java.util.List;

/**
 * Magnitude types that are defined for seismic simulations
 * 
 * @author bjmerch
 *
 */
public class SeismicMagnitudeType
{
    static private MagnitudeType[] _magnitudeTypes = new MagnitudeType[]{ MagnitudeType.KT, MagnitudeType.mb, MagnitudeType.Ms, MagnitudeType.mlg, MagnitudeType.ML, MagnitudeType.Mw }; 
    static private List<? extends MagnitudeType> _magnitudeTypesList = Arrays.asList(_magnitudeTypes);
    
    static public MagnitudeType[] values()
    {
        return _magnitudeTypes;
    }
    
    static public List<? extends MagnitudeType> getValuesList()
    {
        return _magnitudeTypesList;
    }

}
