/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.Range;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Class used to control screen panning in a ChartPanel by shifting the axis 
 * boundaries to match the mouse movements.
 * 
 * @author bjmerch
 */
public final class ChartPanelPanListener extends MouseAdapter
{
    private Point _startPoint = null;
    private Range _startDomainRange = null;
    private Range _startRangeRange = null;

    /**
     * Panning action while the primary mouse button is held down.
     */
    @Override
    public void mouseDragged(MouseEvent e)
    {
        ChartPanel chartPanel = (ChartPanel) e.getSource();
        XYPlot plot = getPlot(e);

        Point endPoint = e.getPoint();

        //  Get the domain and range axis
        ValueAxis domain = plot.getDomainAxis();
        ValueAxis range = plot.getRangeAxis();

        //  Compute the screen positions of the start and end of the domain and range axis
        //  This is done for Axis that are not linear (such as a Log Axis)
        double x_start = domain.valueToJava2D(_startDomainRange.getLowerBound(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
        double x_end = domain.valueToJava2D(_startDomainRange.getUpperBound(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
        double y_start = range.valueToJava2D(_startRangeRange.getLowerBound(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
        double y_end = range.valueToJava2D(_startRangeRange.getUpperBound(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());

        //  Compute the shift in screen pixels
        double dx = _startPoint.getX() - endPoint.getX();
        double dy = _startPoint.getY() - endPoint.getY();

        //  Apply the shift to the screen positions
        x_start += dx;
        x_end += dx;
        y_start += dy;
        y_end += dy;

        //  Transform the updated screen positions back to the data range
        double X_start = domain.java2DToValue(x_start, chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
        double X_end = domain.java2DToValue(x_end, chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
        double Y_start = range.java2DToValue(y_start, chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
        double Y_end = range.java2DToValue(y_end, chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());

        //  Apply the new range
        domain.setRange(X_start, X_end);
        range.setRange(Y_start, Y_end);
    }

    /**
     * Initial press-and-hold prior to panning.
     */
    @Override
    public void mousePressed(MouseEvent e)
    {
        XYPlot plot = getPlot(e);
        
        _startPoint = e.getPoint();
        _startDomainRange = plot.getDomainAxis().getRange();
        _startRangeRange = plot.getRangeAxis().getRange();
    }

    /**
     * Primary mouse button released after panning.
     */
    @Override
    public void mouseReleased(MouseEvent e)
    {
        if (SwingUtilities.isMiddleMouseButton(e))
        {
            ChartPanel chartPanel = (ChartPanel) e.getSource();
            Object obj = chartPanel.getChart().getPlot();

            // Zoom Full (reset)
            if (obj instanceof CombinedDomainXYPlot)
            {
                CombinedDomainXYPlot plot = (CombinedDomainXYPlot) obj;

                List<XYPlot> plots = plot.getSubplots();
                XYPlot p1 = plots.get(0);
                XYPlot p2 = plots.get(1);

                NumberAxis domain = (NumberAxis) p1.getDomainAxis();
                domain.setAutoRangeIncludesZero(false);
                domain.setAutoRange(true);
                NumberAxis range = (NumberAxis) p1.getRangeAxis();
                range.setAutoRangeIncludesZero(false);
                range.setAutoRange(true);

                domain = (NumberAxis) p2.getDomainAxis();
                domain.setAutoRangeIncludesZero(false);
                domain.setAutoRange(true);
                range = (NumberAxis) p2.getRangeAxis();
                range.setAutoRangeIncludesZero(false);
                range.setAutoRange(true);
            }
            else
            {
                XYPlot plot = (XYPlot) obj;

                NumberAxis domain = (NumberAxis) plot.getDomainAxis();
                domain.setAutoRangeIncludesZero(false);
                domain.setAutoRange(true);
                NumberAxis range = (NumberAxis) plot.getRangeAxis();
                range.setAutoRangeIncludesZero(false);
                range.setAutoRange(true);
            }
        }
    }

    /**
     * Get the plot associated with the provided mouse event
     * 
     * @param e
     * @return
     */
    private XYPlot getPlot(MouseEvent e)
    {
        ChartPanel chartPanel = (ChartPanel) e.getSource();
        Object obj = chartPanel.getChart().getPlot();

        Point endPoint = e.getPoint();
        double middlePoint = (chartPanel.getHeight() / 2) - (chartPanel.getY() / 2);

        //  Get the plot
        XYPlot plot = null;

        if (obj instanceof CombinedDomainXYPlot)
        {
            List<XYPlot> plots = ((CombinedDomainXYPlot) obj).getSubplots();

            int plotNum = 0;
            if (endPoint.getY() < middlePoint)
                plotNum = 0;
            else
                plotNum = 1;
            plot = plots.get(plotNum);
        }
        else
        {
            plot = (XYPlot) obj;
        }
        
        return plot;
    }
}
