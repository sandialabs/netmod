package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

/**
 * Implementation of ASCII command-line output for a simulation.
 * 
 * @author bjmerch
 *
 */
public class SimulationOutputASCII extends AbstractNetModComponent implements SimulationOutput
{
    public static final String _type = "ASCII";
    static
    {
        SimulationOutputPlugin.getPlugin().registerComponent(_type, SimulationOutputASCII.class, true);
    }
    
	private Thread thread = null;

	public SimulationOutputASCII(NetModComponent parent)
	{
		super(parent);
	}

	@Override
	public void start(final ProgressDialog pd, final Output output, final EpicenterGrid epicenters)
	{
		thread = new Thread()
		{
			@Override
			public void run()
			{
				int N = epicenters.size();

				System.out.println(N);
				System.out.println("  epilon\t   epilat\titer\t  time(ms)\tepi_size\tnet_prob");
				long time = 0;
				int iterations = 0;
				long t1 = System.currentTimeMillis();

				for (int i = 0; i < N; i++)
				{
					Point.Double location = epicenters.get(i);
					pd.setMainLabel("Simulating Source: " + location);

					// Wait until the output is ready
					while (!output.getOutputSet(i) && !pd.isCanceled())
						pd.sleep(0.1);

					if (pd.isCanceled())
						return;

					// Output the results
					double value = output.getEpicenterValue(i, Output.SIMULGRID_SIZE);

					String format = "";
					if (Math.abs(value) > 0.001 && Math.abs(value) < 1000)
						format = "%10.5f\t%10.5f\t%2d\t%8d\t%8.4f\t%8.4f";
					else
						format = "%10.5f\t%10.5f\t%2d\t%8d\t%8.4e\t%8.4f";

					System.out.println(String.format(format, output.getEpicenterValue(i, Output.SIMULGRID_LON),
							output.getEpicenterValue(i, Output.SIMULGRID_LAT), output.getIterations(i), output.getTime(i),
							value, output.getEpicenterValue(i, Output.SIMULGRID_NETPROB)));

					time += output.getTime(i);
					iterations += output.getIterations(i);

					// Increment the progress bar
					pd.incrementMainProgressBar();
				}
				long t2 = System.currentTimeMillis();

				System.out.println("Iterations: " + iterations);
				System.out.println("Execution time (ms): " + time);
				System.out.println("Clock time (ms): " + (t2 - t1));
			}
		};
		thread.start();
	}

	@Override
	public void join()
	{
		try
		{
			thread.join();
		}
		catch (InterruptedException e)
		{}
	}
}
