/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.response;

import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @author bjmerch
 *
 */
public class SiteResponseTextFile extends AbstractNetModFile implements SiteResponse
{
    public static final Double NO_RESULT = -999.0;
    public static final SpectraDouble NO_RESULT_SPECTRA = new SpectraDouble(NO_RESULT);

    public static final Double ZERO = 0.0;
    public static final SpectraDouble ZERO_SPECTRA = new SpectraDouble(ZERO);
    private static final String _type = "Site Response Text File";

    //  Register the plugin
    static
    {
        SiteResponsePlugin.getPlugin().registerComponent(_type, SiteResponseTextFile.class);
    }

    private double[] _frequencies;
    private double[] _mean;

    /*
     * Cache requested response
     */
    private CacheMap<Frequency, SpectraDouble> _cache = new CacheMap<Frequency, SpectraDouble>(CacheMap.CACHE_FREQUENCY);

    public SiteResponseTextFile(NetModComponent parent)
    {
        super(parent, _type);
    }

    @Override
    public void clearCache()
    {
        super.clearCache();

        _frequencies = null;
        _mean = null;
        _cache.clear();
    }

    /**
     * Get the frequencies over which the noise spectra is defined
     * 
     * @return
     */
    @Override
    public double[] getFrequencies()
    {
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
				read();
		}

        return _frequencies;
    }

    @Override
    public SpectraDouble getResponse(Frequency frequency)
    {
        startIntrospection();
        recordIntrospection("Site Response from file: '", getFilename(), "'");
        recordIntrospection("at frequency: ", frequency);

        /*
         * Check for a cached value
         */
        SpectraDouble response = _cache.get(frequency);
        if (response != null)
        {
            recordIntrospection("Response (log10): ", response);
            stopIntrospection();
            return response;
        }

        /*
         * Check for no response defined
         */
        double[] frequencies = getFrequencies();
        if (frequencies == null || frequencies.length == 0)
        {
            response = ZERO_SPECTRA;
            
            recordIntrospection("No response defined");
            recordIntrospection("Response (log10): ", response);
            statusIntrospection(StatusType.WARNING);
            stopIntrospection();
            
            return response;
        }

        //  Identify the evaluation frequencies
        double[] f_eval = getEvaluationFrequencies(frequency, frequencies);
        int N = f_eval.length;
        
        if (N == 0)
        {
            response = NO_RESULT_SPECTRA;

            recordIntrospection("Frequency outside bounds, no response defined");
            recordIntrospection("Response (log10): ", response);
            statusIntrospection(StatusType.WARNING);
            stopIntrospection();
            
            return response;
        }

        response = new SpectraDouble(N);
        for (int i=0; i<N; i++)
            response.setValue(i,  f_eval[i], computeResponse(f_eval[i]));

        recordIntrospection("Response (log10): ", response);
        stopIntrospection();

        /*
         * Cache the results for the next call
         */
        _cache.put(frequency, response);

        return response;
    }
    
    /**
     * Low-level method for computing response at a particular frequency
     * 
     * @param frequency
     * @return
     */
    private double computeResponse(double frequency)
    {
        double response;
        
        //  Duplicate a change present in the partial C implementation of NetSim
        if (Property.NETSIM_C_INTERP.getBooleanValue())
        {
            response = Interpolation.interpolateLinear(_frequencies, _mean, frequency);
        }
        //  Older fortran method
        else
        {
            response = Interpolation.interpolateQuadratic(_frequencies, _mean, frequency);
        }
        
        return response;
    }

    @Override
    public SiteResponseTextFileViewer getViewer()
    {
        return new SiteResponseTextFileViewer(this);
    }

    @Override
    public boolean isFor(Object o)
    {
        //  Extract a file from the object
        File file = null;
        if (o instanceof File)
            file = (File) o;
        else if (o instanceof String)
            file = IOUtility.openFile((String) o);

        //  Check if the file exists
        if (file == null || !file.exists())
            return false;

        //  Site Response Text Files end with ".srs"
        return IOUtility.endsWith(file, ".srs");
    }

    @Override
    public boolean isAvailable()
    {
        return getFrequencies().length > 0;
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public boolean read()
    {
        boolean value = false;

        //  Synchronize on the type to prevent errors if simultaneously reading from the same file
        synchronized (_type)
        {
            FileInputStream fis = null;
            Scanner fin = null;
            
            try
            {
                // Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);
				
                setName(fin.nextLine());

                //  Skip comments
                skipComments(fin);

                // Read in and store all of the frequency/noise value pairs
                int numFrequencies = fin.nextInt();

				//  Skip comments
                skipComments(fin);
                
                _frequencies = new double[numFrequencies];
                _mean = new double[numFrequencies];
                for (int i = 0; i < numFrequencies; ++i)
                {
                    //  Read in the line and split on white space
                    String[] line = skipBlanksComments(fin).trim().split("\\s*(\\s|,)\\s*");

                    //  Skip blank lines
                    if (line.length < 2)
                    {
                        i--;
                        continue;
                    }

                    double frequency = Double.parseDouble(line[0]);
                    double psdValue = Double.parseDouble(line[1]);
                    double stdDevValue = 0;

                    if (line.length > 2)
                        stdDevValue = Double.parseDouble(line[2]);

                    _frequencies[i] = frequency;
                    _mean[i] = psdValue;
                }

                value = true;
                setDirty(false);
            }
            catch (Exception e)
            {
                if ( !getFilename().isEmpty() )
                {
                    System.out.println("Unable to read site response text file: '" + getFilename() + "'");
                    e.printStackTrace();
                }

                _frequencies = new double[0];
                _mean = new double[0];
            }
            finally
            {
    			if ( fin != null )
    				IOUtility.safeClose(fin);
    			if ( fis != null )
    				IOUtility.safeClose(fis);
            }
        }

        return value;
    }

    /**
     * Remove the response value at the provided frequency
     * 
     * @param frequency
     */
    public void removeResponse(double frequency)
    {
        //  Find the index of the existing noise
        int index = Arrays.binarySearch(getFrequencies(), frequency);
        if (index < 0)
            return;

        //  Create copies of the arrays, excluding the index
        _frequencies = removeIndex(_frequencies, index);
        _mean = removeIndex(_mean, index);

        _cache.clear();
        setDirty(true);
    }

    /**
     * Set the response value at the provided frequency
     * 
     * @param frequency
     * @param response
     */
    public void setResponse(double frequency, double response)
    {
        double[] frequencies = getFrequencies();
        int index = findIndex(frequencies, frequency);

        if (index < frequencies.length && frequencies[index] == frequency)
        {
            _mean[index] = response;
        }
        else
        {
            _frequencies = insertIndex(frequencies, index, frequency);
            _mean = insertIndex(_mean, index, response);
        }

        _cache.clear();
        setDirty(true);
    }

    @Override
    public boolean write()
    {
        // Get the File to write to
        File file = IOUtility.openFile(getFilename());

        //  Don't write if not needed
        if (!getDirty() && file.exists())
            return true;

        //  Test whether there is no file to write to
        if (isEmpty(file.getPath()))
            return true;

        PrintWriter fout = null;
		boolean value = true;
        try
        {
            // Get all frequencies used in the file and write how many are used
            double[] frequencies = getFrequencies();
            double[] mean = _mean;

            //  Ensure the path to the file exists
            file.getParentFile().mkdirs();

            // Open the file and write the title
            fout = new PrintWriter(new FileWriter(file));
            fout.println(getName());

            fout.println("# Number of Frequencies");
            fout.println(frequencies.length);
            fout.println("# Frequency	Log10 Response");
            
            // Write all frequencies and their associated response values
            int N = frequencies.length;
            for (int i = 0; i < N; i++)
            {
                fout.println(String.format("%8.3f\t%8.3f", frequencies[i], mean[i]));
            }

            setDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            value = false;
        }
        finally
        {
        	if ( fout != null )
        		IOUtility.safeClose(fout);
        }

        return value;
    }
}
