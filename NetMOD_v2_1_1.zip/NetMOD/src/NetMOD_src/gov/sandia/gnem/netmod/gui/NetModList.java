/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Group a list with to the right of it.
 * Switch between the viewers of the selected NetModComponent.
 * This construct is used often throughout the NetModComponentViewers
 * 
 * @author bjmerch
 *
 */
public class NetModList extends JPanel
{
    private JList _list = new JList(new DefaultListModel());
    private Map<NetModComponent, NetModComponentViewer> _viewers = new HashMap<NetModComponent, NetModComponentViewer>();

    public NetModList(Collection<? extends NetModComponent> objects, JComponent... components)
    {
        super(new BorderLayout());

        //  Add a listener to switch between the cards
        _list.addListSelectionListener(new ListSelectionListener()
        {
            @Override
            public void valueChanged(ListSelectionEvent lse)
            {
                //  Get the existing viewer
                NetModComponentViewer oldViewer = null;
                for (Component c : getComponents())
                    if (c instanceof NetModComponentViewer)
                    {
                        //  Get the expanded state of the previous component
                        oldViewer = (NetModComponentViewer) c;

                        //  Remove the existing components
                        NetModList.this.remove(c);
                    }

                //  Get the selected object
                NetModComponent nmc = (NetModComponent) _list.getSelectedValue();
                if ( nmc == null )
                    return;
                
                //  Get the new component
                NetModComponentViewer viewer = _viewers.get(nmc);
                if (viewer == null)
                {
                    viewer = nmc.getViewer();
                    _viewers.put(nmc, viewer);
                }

                //  Switch to the selected component
                if (viewer != null)
                {
                    //  Apply the expanded state to all of the items
                    setExpandedState(oldViewer, viewer);

                    NetModList.this.add(viewer, BorderLayout.CENTER);
                    NetModList.this.validate();
                    viewer.refresh();
                }
            }
        });

        JComponent toolBar = GUIUtility.createToolBar();
        if (components.length > 0)
        {

            for (JComponent c : components)
                toolBar.add(c);
            
            add(toolBar, BorderLayout.NORTH);
        }
        
        JScrollPane scrollPane = new JScrollPane(_list);
        scrollPane.setPreferredSize(toolBar.getPreferredSize());

        //  Group the combobox and card panels
        add(scrollPane, BorderLayout.WEST);

        setItems(objects);
    }

    /**
     * Add an item listener for changes in the combo box selection
     * 
     * @param il
     */
    public void addListSelectionListener(ListSelectionListener il)
    {
        _list.addListSelectionListener(il);
    }

    /**
     * Add the netmod component
     * 
     * @param nmc
     */
    public void addNetModComponent(NetModComponent nmc)
    {
        if (nmc == null)
            return;

        ((DefaultListModel) _list.getModel()).addElement(nmc);
    }

    /**
     * Get the items in the combo box
     * 
     * @return
     */
    public Collection<? extends NetModComponent> getItems()
    {
        Set<NetModComponent> components = new TreeSet<NetModComponent>();

        int N = _list.getModel().getSize();
        for (int i = 0; i < N; i++)
            if (_list.getModel().getElementAt(i) instanceof NetModComponent)
                components.add((NetModComponent) _list.getModel().getElementAt(i));

        return components;
    }

    /**
     * Get the selected netmod component
     * 
     * @return
     */
    public NetModComponent getSelectedItem()
    {
        return (NetModComponent) _list.getSelectedValue();
    }

    /**
     * Get the selected netmod component
     * 
     * @return
     */
    public List<NetModComponent> getSelectedItems()
    {
        List<NetModComponent> list = new ArrayList<NetModComponent>();

        for (Object o : _list.getSelectedValues())
            if ( o instanceof NetModComponent )
                list.add((NetModComponent) o);
        
        return list;
    }

    /**
     * Update the current viewer
     * 
     */
    public void refresh()
    {
        //  Get the current viewer
        NetModComponentViewer viewer = _viewers.get(_list.getSelectedValue());

        if (viewer != null)
            viewer.refresh();
    }

    /**
     * Remove the netmod component
     * 
     * @param nmc
     */
    public void removeNetModComponent(NetModComponent nmc)
    {
        if (nmc == null)
            return;

        //  Remove the component from the comboBox
        ((DefaultListModel) _list.getModel()).removeElement(nmc);
        _viewers.remove(nmc);
    }

    /**
     * Set the items displayed within the combo box
     * 
     * @param objects
     */
    public void setItems(Collection<? extends NetModComponent> objects)
    {
        //  Get the selected
        NetModComponent selected = getSelectedItem();

        //  Remove all existing items
        ((DefaultListModel) _list.getModel()).removeAllElements();
        _viewers.clear();

        //  add all of the items
        if (objects != null)
            for (NetModComponent nmc : objects)
                addNetModComponent(nmc);

        //  Set the selected item
        setSelectedItem(selected);
    }

    /**
     * Set the selected netmod component
     * 
     * @param nmc
     */
    public void setSelectedItem(NetModComponent nmc)
    {
        //  Select the corrected item
        _list.setSelectedValue(nmc, true);

        //  Ensure a valid selection was made
        if (_list.getSelectedIndex() < 0 && _list.getModel().getSize() > 0)
            _list.setSelectedIndex(0);
    }

    /**
     * Transfer the expanded state from viewer1 to viewer2
     * 
     * @param viewer1
     * @param viewer2
     */
    private void setExpandedState(NetModComponentViewer viewer1, NetModComponentViewer viewer2)
    {
        if (viewer1 == null || viewer2 == null)
            return;

        //  Transfer the expanded state
        viewer2.setExpanded(viewer1.isExpanded());

        //  Search for any sub-viewers
        if (viewer1.isExpanded())
        {
            JComponent panel1 = viewer1.getExpandedPanel();
            JComponent panel2 = viewer2.getExpandedPanel();

            int N = Math.min(panel1.getComponentCount(), panel2.getComponentCount());
            for (int i = 0; i < N; i++)
            {
                if (panel1.getComponent(i) instanceof NetModComponentViewer && panel2.getComponent(i) instanceof NetModComponentViewer)
                {
                    setExpandedState((NetModComponentViewer) panel1.getComponent(i), (NetModComponentViewer) panel2.getComponent(i));
                }
            }
        }
    }
}
