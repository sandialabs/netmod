/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 * 
 * Notice: This computer software was prepared by Sandia Corporation, 
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are 
 * reserved by DOE on behalf of the United States Government and the 
 * Contractor as provided in the Contract. You are authorized to use this 
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE 
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY 
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

/**
 * Container used for ALF information that is variable between HWM14 calls
 *  
 */
public class ALF
{
    public double[][] gpbar, gvbar, gwbar;
    public double[][] spbar, svbar, swbar;
	public double glatalf = Double.MAX_VALUE;

    public ALF()
    {
        GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();
        HWM14_Data hwm08_data = HWM14_Data.getInstance();

        int nmax_geo = Math.max(hwm08_data.maxn, gd2qd_data.nmax);
        int maxo = Math.max(Math.max(hwm08_data.maxs, hwm08_data.maxm), hwm08_data.maxl);
        
        int mmax_geo = Math.max(maxo, gd2qd_data.mmax);

        gpbar = new double[mmax_geo + 1][nmax_geo + 1];
        gvbar = new double[mmax_geo + 1][nmax_geo + 1];
        gwbar = new double[mmax_geo + 1][nmax_geo + 1];

        spbar = new double[mmax_geo + 1][nmax_geo + 1];
        svbar = new double[mmax_geo + 1][nmax_geo + 1];
        swbar = new double[mmax_geo + 1][nmax_geo + 1];
    }

    /**
     *  Concurrently computes the latitude-dependent portions of scalar and vector spherical
     *  harmonics.
     */
    public void ALFBasis(double theta, double[][] P, double[][] V, double[][] W)
    {
    	int nmax = P.length-1;
    	int mmax = P[0].length-1;
    	
        double x, y;
        double p00 = 0.70710678118654746;
        
        ALF_Data alf_data = ALF_Data.getInstance();

        P[0][0] = p00;
        x = Math.cos(theta);
        y = Math.sin(theta);

        for (int m = 1; m <= mmax; m++)
        {
            W[m][m] = alf_data.cm[m] * P[m - 1][m - 1];
            P[m][m] = y * alf_data.en[m] * W[m][m];

            for (int n = m + 1; n <= nmax; n++)
            {
                W[n][m] = alf_data.anm[n][m] * x * W[n - 1][m] - alf_data.bnm[n][m] * W[n - 2][m];
                P[n][m] = y * alf_data.en[n] * W[n][m];
                V[n][m] = n * x * W[n][m] - alf_data.dnm[n][m] * W[n - 1][m];
                W[n - 2][m] = m * W[n - 2][m];
            }

            W[nmax-1][m] *= m;
            W[nmax][m] *= m;
            V[m][m] = x * W[m][m];
        }

        P[1][0] = alf_data.anm[1][0] * x * P[0][0];
        V[1][0] = -P[1][1];

        for (int n = 2; n <= nmax; n++)
        {
            P[n][0] = alf_data.anm[n][0] * x * P[n - 1][0] - alf_data.bnm[n][0] * P[n - 2][0];
            V[n][0] = -P[n][1];
        }
    }

    /**
     *  Concurrently computes the latitude-dependent portions of scalar and vector spherical
     *  harmonics.
     */
    public void ALFBasisTranspose(double theta, double[][] P, double[][] V, double[][] W)
    {
    	int mmax = P.length-1;
    	int nmax = P[0].length-1;
    	
        double x, y;
        double p00 = 0.70710678118654746;
        
        ALF_Data alf_data = ALF_Data.getInstance();

        double[] P_0 = P[0];
        double[] P_1 = P[1];
        double[] V_0 = V[0];
        
        P[0][0] = p00;
        x = Math.cos(theta);
        y = Math.sin(theta);

        for (int m = 1; m <= mmax; m++)
        {
        	double[] P_m = P[m];
        	double[] V_m = V[m];
        	double[] W_m = W[m];
        	
        	W_m[m] = alf_data.cm[m] * P[m - 1][m - 1];
        	P_m[m] = y * alf_data.en[m] * W_m[m];

            for (int n = m + 1; n <= nmax; n++)
            {
            	W_m[n] = alf_data.anm[n][m] * x * W_m[n - 1] - alf_data.bnm[n][m] * W_m[n - 2];
            	P_m[n] = y * alf_data.en[n] * W_m[n];
            	V_m[n] = n * x * W_m[n] - alf_data.dnm[n][m] * W_m[n - 1];
                W_m[n - 2] = m * W_m[n - 2];
            }

            W_m[nmax-1] *= m;
            W_m[nmax] *= m;
            V_m[m] = x * W_m[m];
        }

        P_0[1] = alf_data.anm[1][0] * x * P_0[0];
        V[0][1] = -P[1][1];

        for (int n = 2; n <= nmax; n++)
        {
        	P_0[n] = alf_data.anm[n][0] * x * P_0[n - 1] - alf_data.bnm[n][0] * P_0[n - 2];
            V_0[n] = -P_1[n];
        }
    }

    public void ALFBasisGBar(double theta)
    {
        ALFBasisTranspose(theta, gpbar, gvbar, gwbar);
    }

    public void ALFBasisSBar(double theta)
    {
        ALFBasisTranspose(theta, spbar, svbar, swbar);
    }
}
