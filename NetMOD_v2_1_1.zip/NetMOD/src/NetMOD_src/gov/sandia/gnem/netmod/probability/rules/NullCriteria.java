/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Criteria that is empty
 * 
 * @author bjmerch
 *
 */
public class NullCriteria extends Criteria
{
    public NullCriteria()
    {
    }

    @Override
    public Set<Phase> getPhases()
    {
        return new TreeSet<Phase>();
    }

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    public double getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        return 0;
    }

    @Override
    public String toString()
    {
        return "";
    }
}
