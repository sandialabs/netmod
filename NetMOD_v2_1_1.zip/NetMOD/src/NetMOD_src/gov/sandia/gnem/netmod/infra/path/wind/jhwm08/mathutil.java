/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 *
 * Notice: This computer software was prepared by Sandia Corporation,
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are
 * reserved by DOE on behalf of the United States Government and the
 * Contractor as provided in the Contract. You are authorized to use this
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jhwm08;

/**
 * @author aceaste
 *
 */
public class mathutil {

  public static double dot_product(final double[] arr1, final double[] arr2, final int nterm2)
      throws Exception {
    double temp = 0;

    for (int i = 0; i < nterm2; i++) {
      temp += arr1[i] * arr2[i];
    }

    return temp;
  }

  public static double dotProduct(final double[] arr1, final double[] arr2) throws Exception {
    if (arr1.length != arr2.length) {
      throw new Exception();
    }

    double temp = 0;

    for (int i = 0; i < arr1.length; i++) {
      temp += arr1[i] * arr2[i];
    }

    return temp;
  }

  public static double dotProduct1Dby2DCol_Length(final double[] arr1, final double[][] arr2,
      final int len, final int index2) throws Exception {
    double temp = 0;

    for (int i = 0; i < len; i++) {
      temp += arr1[i] * arr2[i][index2];
    }

    return temp;
  }
}
