package gov.sandia.gnem.netmod.infra.path.wind.jecmwf;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.path.wind.WindModelPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Simulation;

public class EcmwfNetCDF extends AbstractNetModFile implements WindModel
{

	private static final String _type = "ECMWF";

	static
	{
		WindModelPlugin.getPlugin().registerComponent(_type, EcmwfNetCDF.class);
	}

	private Ecmwf _ecmwf = null;

	public EcmwfNetCDF(NetModComponent parent)
	{
		super(parent, _type);
	}

	public Layer<?> getMapLayer()
	{
		if (NetMOD.getMap() == null)
		{
			return null;
		}
		return NetMOD.getMap().createWindModelLayer(this);
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		return new EcmwfNetCDFViewer(this);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		System.out.println("ECMWF clearing cache");
		_ecmwf = null;
	}

	@Override
	public Complex getWindVelocity(Time time, double altitude, Point.Double location)
	{
		read();

		Complex w = _ecmwf.getWindVelocity(location, altitude * 1000);

		return w;
	}

	@Override
	public Complex getWindVelocity(double altitude, Point.Double location)
	{
		Time time = new Time(0);
		NetModComponent parent = getParent();
		if (parent instanceof Paths)
		{
			NetModComponent grandparent = parent.getParent();
			if (grandparent instanceof Simulation)
			{
				time = ((Simulation) grandparent).getSimulationTime();
			}
		}

		return getWindVelocity(time, altitude, location);
	}

	@Override
	public boolean read()
	{
		synchronized (_type)
		{
			if (_ecmwf == null )
				_ecmwf = new Ecmwf(getFilename());
			
			_ecmwf.read();
		}
		return true;
	}
	
	@Override
	public void setFilename(String filename)
	{
		//  Clear the ECMWF is the file changes
		if ( !getFilename().equals(filename) )
		{
			System.out.println("Clearing ECMWF object due to filename change");
			_ecmwf = null;
		}
		
		super.setFilename(filename);
	}

	@Override
	public boolean write()
	{
		return false;
	}

	@Override
	public boolean isAvailable()
	{
		return !getFilename().isEmpty();
	}

	@Override
	public void load(NetSimParameters parameters) throws Exception
	{
		super.load(parameters);

		setFilename(parameters.get(NetSimParameters.windModelFile));
	}

	@Override
	public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
	{
		super.save(parameters, files, reset);

		parameters.set(NetSimParameters.windModelFile, getFilename());
	}
}
