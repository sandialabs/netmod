/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

/**
 * @author bjmerch
 *
 */
public class Complex implements Comparable<Complex>
{
    public static final Complex ZERO = new Complex(0.0,0.0);
    public static final Complex ONE = new Complex(1.0,0.0);
    
    /**
     * Compute the magnitude for the complex number with the provided real and imaginary
     * components.
     * 
     * @param real
     * @param imaginary
     * @return
     */
    public static final double getMagnitude(double real, double imaginary)
    {
        return Math.sqrt(real * real + imaginary * imaginary);
    }
    
    /**
     * Compute the phase in radians for the complex number with the provided real and imaginary
     * components.
     * 
     * @param real
     * @param imaginary
     * @return
     */
    public static final double getPhase(double real, double imaginary)
    {
        return Math.atan2(imaginary, real);
    }
    
    /**
     * Compute the real cartesian component of the complex number represented by
     * the provided magnitude and phase
     * 
     * @param magnitude
     * @param phase
     * @return
     */
    public static double getReal(double magnitude, double phase)
    {
        return magnitude * Math.cos(phase);
    }
    
    /**
     * Compute the imaginary cartesian component of the complex number represented by
     * the provided magnitude and phase
     * 
     * @param magnitude
     * @param phase
     * @return
     */
    public static double getImaginary(double magnitude, double phase)
    {
        return magnitude * Math.sin(phase);
    }
    
    /**
     * Create a complex number from the polar definition of magnitude and
     * phase.
     * 
     * @param magnitude Magnitude of the complex number
     * @param phase Phase, in radians, of the complex number
     * @return
     */
    public static Complex polar(double magnitude, double phase)
    {
        return new Complex(getReal(magnitude, phase), getImaginary(magnitude, phase));
    }
    
    private double _real;
    private double _imaginary;
    
    private double _magnitude = Double.MAX_VALUE;
    private double _phase = Double.MAX_VALUE;
    
    /**
     * Create a new complex number from the provided real and imaginary components.
     * 
     * @param real
     * @param imaginary
     */
    public Complex(double real, double imaginary)
    {
        _real = real;
        _imaginary = imaginary;
    }

    /**
     * Compute the absolute value of the complex value
     * 
     * @return
     */
    public double abs()
    {
        return getMagnitude();
    }

    /**
     * Add the provided complex value and return the result
     * 
     * @param c
     * @return
     */
    public Complex add(Complex c)
    {
        double r = getReal() + c.getReal();
        double i = getImaginary() + c.getImaginary();
        
        return new Complex(r, i);
    }
    
    /**
     * Compute and return the conjugate of this complex value
     * 
     * @return
     */
    public Complex conjugate()
    {
        double r = getReal();
        double i = - getImaginary();

        return new Complex(r, i);
    }

    /**
     * Divide this complex number by the provided complex number and
     * return the resulting complex number.
     * 
     * http://en.wikipedia.org/wiki/Complex_number#Operations
     * 
     * @param c
     * @return
     */
    public Complex divide(Complex c)
    {
        double r2 = c.getReal();
        double i2 = c.getImaginary();
        double r1 = getReal();
        double i1 = getImaginary();
        
        double den = 1.0 / (r2 * r2 + i2 * i2);

        double r = (r1 * r2 + i1 * i2) * den;
        double i = (i1 * r2 - r1 * i2) * den;
        
        return new Complex(r, i);
    }

    /**
     * Divide this complex value by the provided number
     * 
     * @param d
     * @return
     */
    public Complex divide(double d)
    {
        return multiply(1.0/d);
    }
    
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (!(o instanceof Complex))
            return false;

        Complex c = (Complex) o;
        
        //return getReal() == c.getReal() && getImaginary() == c.getImaginary();
        return getDistance(c) < Math.ulp((float) (Math.max(getReal(), getImaginary())));
    }
    
    /**
     * Compute the exponential function of this complex number
     * 
     * @return
     */
    public Complex exp()
    {
        return exp(getReal(), getImaginary());
    }
    
    /**
     * Compute the exponent of the provided real and imaginary components
     * 
     * @param real
     * @param imag
     * @return
     */
    public static Complex exp(double real, double imag)
    {
        double d = Math.exp(real);
        
        double r = d * Math.cos(imag);
        double i = d * Math.sin(imag);
        
        return new Complex(r, i);
    }
    
    /**
     * Compute the euclidan distance between this and the provided
     * complex values.
     * 
     * @param c
     * @return
     */
    public double getDistance(Complex c)
    {
        return Math.hypot(getReal()-c.getReal(), getImaginary()-c.getImaginary());
    }
    
    /**
     * Get the imaginary component of the complex number
     * 
     * @return
     */
    final public double getImaginary()
    {
        return _imaginary;
    }
    
    /**
     * Compute the magnitude of this complex number
     * 
     * @return
     */
    public double getMagnitude()
    {
    	if ( _magnitude == Double.MAX_VALUE )
    		_magnitude = getMagnitude(getReal(), getImaginary());
    	
    	return _magnitude;
    }
    
    /**
     * Compute the magnitude of this complex number projected along the provided angle
     * in radians.
     * 
     * @return
     */
    public double getMagnitude(double angle)
    {
        return getReal(getMagnitude(), getPhase() - angle);
    }

    /**
     * Compute the phase angle of this complex number
     * 
     * @return
     */
    public double getPhase()
    {
    	if ( _phase == Double.MAX_VALUE )
    		_phase = getPhase(getReal(), getImaginary());
    	
    	return _phase;
    }
    
    /**
     * Get the real component of the complex number
     * 
     * @return
     */
    final public double getReal()
    {
        return _real;
    }

    @Override
    public int hashCode()
    {
    	//  Coarse hashcode as equals allows for small variability
    	return Integer.hashCode((int) getReal()) + Integer.hashCode((int) getImaginary());
    }
    
    /**
     * Compute and return the inverse of this complex value
     * 
     * http://en.wikipedia.org/wiki/Complex_number#The_field_of_complex_numbers
     * 
     * @return
     */
    public Complex inverse()
    {
        double r1 = getReal();
        double i1 = getImaginary();
        double divisor = ( r1 * r1 + i1 * i1 );
        
        double r =   r1 / divisor;
        double i = - i1 / divisor;
        
        return new Complex(r, i);
    }

	/**
	 * Check if the complex number is equal to 1.
	 * 
	 * @return
	 */
	public boolean isOne() 
	{
		return getReal() == 1 && getImaginary() == 0;
	}
	
    /**
     * Check if the complex number is equal to zero
     * 
     * @return
     */
    public boolean isZero()
    {
        return getReal() == 0 && getImaginary() == 0;
    }
    
    /**
     * Compute the log function of this complex value.
     * 
     * @return
     */
    public Complex log()
    {
        double r = Math.log(getMagnitude());
        double i = getPhase();
        
        return new Complex(r, i);
    }

    /**
     * Multiply by the provided complex value and return the result
     * 
     * @param c
     * @return
     */
    public Complex multiply(Complex c)
    {
        double r1 = getReal();
        double i1 = getImaginary();
        double r2 = c.getReal();
        double i2 = c.getImaginary();
        
        double r = r1 * r2 - i1 * i2;
        double i = r1 * i2 + i1 * r2;
        
        return new Complex(r,i);
    }
    
    /**
     * Multiply the provided real value and return the result
     * 
     * @param d
     * @return
     */
    public Complex multiply(double d)
    {
        double r1 = getReal();
        double i1 = getImaginary();
        
        return new Complex(r1 * d, i1 * d);
    }
    
    /**
     * Compute and return the negative of this complex value
     * 
     * @return
     */
    public Complex negative()
    {
        double r1 = getReal();
        double i1 = getImaginary();
        
        return new Complex(-r1, -i1);
    }

    /**
     * Compute the value of this complex number raised to the provided
     * complex number.
     * 
     * @param c
     * @return
     */
    public Complex pow(Complex c)
    {
        return log().multiply(c).exp();
    }
    
    /**
     * Compute the value of this complex number raised to the provided
     * number.
     * 
     * @param x
     * @return
     */
    public Complex pow(int x)
    {
        return pow(new Complex(x,0));
    }

    /**
     * Compute and return the square root of this complex value
     * <p>
     * http://en.wikipedia.org/wiki/Square_root#Square_roots_of_negative_and_complex_numbers
     * <p>
     * The square root is computed in polar form to simplify edge cases
     * 
     * @return
     */
    public Complex sqrt()
    {
        //  Get the polar magnitude and phase.
        double r = getMagnitude();
        double theta = getPhase();
        
        //  Polar form of the square root
        r = Math.sqrt( r );
        theta = theta / 2.0;
        
        //  Convert back to cartesian
        return polar(r, theta);
    }

    /**
     * Subtract the provided complex value and return the result
     * 
     * @param c
     * @return
     */
    public Complex subtract(Complex c)
    {
        double r1 = getReal();
        double i1 = getImaginary();
        double r2 = c.getReal();
        double i2 = c.getImaginary();
        
        double r = r1 - r2;
        double i = i1 - i2;
        
        return new Complex(r, i);
    }

    /**
     * @param d
     * @return
     */
    public Complex subtract(double d)
    {
        double r1 = getReal();
        double i1 = getImaginary();
        
        double r = r1 - d;
        
        return new Complex(r, i1);
    }

    public String toString()
    {
        return "(" + getReal() + ", " + getImaginary() + ")";
    }
    
    @Override
    public int compareTo(Complex c)
    {
        return Double.compare(getMagnitude(), c.getMagnitude());
    }
}
