/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.output;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.output.Output.COLOR_SCALING;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class OutputViewer extends NetModComponentViewer<Output>
{
    private class OutputInfoPanel extends JPanel
    {
        /**
         * Display simulation parameters in a table
         * 
         * @author bjmerch
         *
         */
        private class OutputParameterTableModel extends NetMODTableModel
        {
            List<String> _keys = new ArrayList<String>();
            
            @Override
            public int getColumnCount()
            {
                return 2;
            }

            public String getColumnName(int column)
            {
                switch (column)
                {
                case 0:
                    return "Parameter";
                case 1:
                    return "Value";
                }
                
                return "";
            }

            @Override
            public int getRowCount()
            {
                if ( _keys == null || _keys.size() != _nmc.getSimulKeyCount() )
                    _keys = new ArrayList<String>(_nmc.getSimulKeyKeys());
                    
                return _keys.size();
            }

            @Override
            public Object getValueAt(int row, int column)
            {
                String key = _keys.get(row);
                
                if ( column == 0 )
                    return key;
                else
                    return _nmc.getSimulKeyValue(key);
            }

            @Override
            public boolean isCellEditable(int r, int c)
            {
                return false;
            }

            @Override
            public void remove(int[] rows)
            {
            }
        }
        
        /**
         * Display station information in a table
         * 
         * @author bjmerch
         *
         */
        private class OutputStationTableModel extends NetMODTableModel
        {
            @Override
            public int getColumnCount()
            {
                return _nmc.SIMULSTA_COUNT;
            }

            public String getColumnName(int column)
            {
                switch (column)
                {
                case 0:
                    return "Station";
                case 1:
                    return "Technology";
                case 2:
                    return "Longitude";
                case 3:
                    return "Latitude";
                case 4:
                    return "Reliability";
                case 5:
                    return "Number Chan";
                case 6:
                    return "Type";
                }
                
                return "";
            }

            @Override
            public int getRowCount()
            {
                return _nmc.getNumberStations();
            }

            @Override
            public Object getValueAt(int row, int column)
            {
                return _nmc.getStationValue(row, column);
            }

            @Override
            public boolean isCellEditable(int r, int c)
            {
                return false;
            }

            @Override
            public void remove(int[] rows)
            {
            }
        }
        
        public OutputInfoPanel()
        {
            super(new BorderLayout());
            setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            
            // Organize the simulkeys
            JTable parameterTable = new NetMODTable(new OutputParameterTableModel());
            
            JPanel simulKeyPanel = new JPanel(new BorderLayout());
            simulKeyPanel.setBorder(BorderFactory.createTitledBorder("Simulation Parameters"));
            simulKeyPanel.add(new JScrollPane(parameterTable), BorderLayout.CENTER);
            
            //  Organize the stations
            JTable stationTable = new NetMODTable(new OutputStationTableModel());
            
            JPanel stationsPanel = new JPanel(new BorderLayout());
            stationsPanel.setBorder(BorderFactory.createTitledBorder("Stations"));
            stationsPanel.add(new JScrollPane(stationTable), BorderLayout.CENTER);
            
            //  Organize the high level panels
            add(simulKeyPanel, BorderLayout.NORTH);
            add(stationsPanel, BorderLayout.CENTER);
        }
    }
    
    
    private ColorBar _colorBar = new ColorBar();
    private AbstractButton _displayMapButton = createDisplayOnMapButton(MapUtility.OutputButtonGroup);
    private JTextField _name = new JTextField();
    private JComboBox _simulGridContourComboBox = new JComboBox(Output.SIMULGRID_LABELS);
    private JTextField _simulGridContourLevels = new JTextField();
    private JComboBox _simulGridSurfaceComboBox = new JComboBox(Output.SIMULGRID_LABELS);
    private JComboBox _colorModel = new JComboBox(ColorModel.values());
    private JComboBox _colorScaling = new JComboBox(Output.COLOR_SCALING.values());
    private JFormattedTextField _simulGridMin = new JFormattedTextField(new DoubleRangeFormatter());
    private JFormattedTextField _simulGridMax = new JFormattedTextField(new DoubleRangeFormatter());
    private TransparencySlider _transparency = new TransparencySlider();
    
    //  Add options for "None" to the parameter combo boxes
    {
        ((DefaultComboBoxModel) _simulGridContourComboBox.getModel()).insertElementAt("None", 0);
        ((DefaultComboBoxModel) _simulGridSurfaceComboBox.getModel()).insertElementAt("None", 0);
    }

    public OutputViewer(Output nmc)
    {
        super(nmc, false, true, true);

        addNetModPreControl(_displayMapButton);
        addNetModPreControl(createOutputInfoButton());
        addNetModPostControl(createDeleteOutputButton());

        //  Set the listener to reset the min/max on variable change
        _simulGridSurfaceComboBox.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                int parameter = _simulGridSurfaceComboBox.getSelectedIndex()-1;
                if (parameter == _nmc.getSurfaceIndex())
                    return;

                if (_updating)
                    return;

                _updating = true;

                _nmc.setSurfaceIndex(parameter);
                _nmc.resetDisplayMinMax();

                _updating = false;

                refresh();
            }
        });

        //  Register the controls that are monitored
        registerControls(_name, _simulGridContourComboBox, _simulGridContourLevels, _simulGridSurfaceComboBox, _colorModel, _colorScaling, _simulGridMin, _simulGridMax, _transparency);
    }

    @Override
    public void apply(Output nmc)
    {
        File file = IOUtility.openFile(nmc.getOutputFile());
        nmc.setOutputFile(IOUtility.openFile(file.getParent(), _name.getText()).getAbsolutePath());
        nmc.setContourIndex(_simulGridContourComboBox.getSelectedIndex()-1);
        nmc.setContourLevels(GUIUtility.parseDoubles(_simulGridContourLevels.getText()));
        nmc.setSurfaceIndex(_simulGridSurfaceComboBox.getSelectedIndex()-1);
        
        double min = ((Number) _simulGridMin.getValue()).doubleValue();
        double max = ((Number) _simulGridMax.getValue()).doubleValue();
        
        nmc.setSurfaceMin(Math.min(min, max));
        nmc.setSurfaceMax(Math.max(min, max));
        nmc.setSurfaceColorModel((ColorModel) _colorModel.getSelectedItem());
        nmc.setColorScaling((COLOR_SCALING) _colorScaling.getSelectedItem());
        nmc.setSurfaceTransparency(_transparency.getTransparency());
        
        //  Cause a refresh of the map layer
        if ( _displayMapButton.isSelected() )
            nmc.getMapLayer();
    }

    /**
     * Display the output on the map
     */
    public void displayMap()
    {
        _displayMapButton.doClick();
        if (!_displayMapButton.isSelected())
            _displayMapButton.doClick();
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new BorderLayout());

            JPanel controlsPanel = new JPanel(new GridBagLayout());
            
            _name.setToolTipText("Output Name");
            _simulGridContourComboBox.setToolTipText("Parameter to display with contours");
            _simulGridContourLevels.setToolTipText("Contour Levels");
            _simulGridSurfaceComboBox.setToolTipText("Parameter to display with a surface");
            _simulGridMin.setToolTipText("Minimum data range for the color model");
            _simulGridMax.setToolTipText("Maximum data range for the color model");
            _colorScaling.setToolTipText("Control whether color model is applied with a linear or log scale");

            GUIUtility.addRow(controlsPanel, new JLabel("Name: "), _name);
            GUIUtility.addRow(controlsPanel, new JLabel("Contours: "), _simulGridContourComboBox, _simulGridContourLevels);
            GUIUtility.addRow(controlsPanel, new JLabel("Surface: "), _simulGridSurfaceComboBox, _simulGridMin, _simulGridMax);
            GUIUtility.addRow(controlsPanel, new JLabel("Color Model: "), _colorModel);
            GUIUtility.addRow(controlsPanel, new JLabel("Color Scaling: "), _colorScaling);
            GUIUtility.addRow(controlsPanel, new JLabel("Transparency: "), _transparency);
            GUIUtility.addRow(controlsPanel, GridBagConstraints.REMAINDER, new JLabel(" "));

            panel.add(controlsPanel, BorderLayout.CENTER);
            panel.add(_colorBar, BorderLayout.EAST);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(Output nmc)
    {
        _name.setText(nmc.getName());
        _simulGridContourComboBox.setSelectedIndex(nmc.getContourIndex()+1);
        _simulGridContourLevels.setText(GUIUtility.formatDoublesReadable(nmc.getContourLevels(), ", "));
        _simulGridSurfaceComboBox.setSelectedIndex(nmc.getSurfaceIndex()+1);
        _simulGridMin.setValue(nmc.getSurfaceMin());
        _simulGridMax.setValue(nmc.getSurfaceMax());
        _transparency.setTransparency(nmc.getSurfaceTransparency());
        _colorModel.setSelectedItem(nmc.getSurfaceColorModel());
        _colorScaling.setSelectedItem(nmc.getColorScaling());
        _colorBar.setYAxisLog(nmc.getColorScaling() == COLOR_SCALING.LOG);
        _colorBar.setColorModel(nmc.getSurfaceColorModel().getColorModel(), (float) nmc.getSurfaceTransparency(),
                nmc.getSurfaceMin(), nmc.getSurfaceMax());
        
        if ( nmc.getSurfaceIndex() == Output.SIMULGRID_SIZE )
            _colorBar.setTitle(nmc.getSimulKeyValue(Output.SIMULKEY_SIZE_TYPE));
        else
            _colorBar.setTitle("");
    }

    private JButton createDeleteOutputButton()
    {
        JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
        button.setToolTipText("Delete this output");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Remove the output
                _nmc.remove();

                //  Remove from map
                GUIUtility.deselectToggleButtons(OutputViewer.this);

                //  Refresh the parent
                refreshParent();
            }
        });

        return button;
    }

    private JButton createOutputInfoButton()
    {
        JButton button = GUIUtility.createButton(Icons.DETAILS.getIcon());
        button.setToolTipText("Output Information");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                OutputInfoPanel viewer = new OutputInfoPanel();

                //  Display the viewer within a dialog
                GUIUtility.showDialog(null, viewer, "Output Parameters - " + _nmc.getName());
            }
        });

        return button;
    }

	public void sync(OutputViewer viewer)
    {
		_simulGridContourComboBox.setSelectedItem(viewer._simulGridContourComboBox.getSelectedItem());
		_simulGridContourLevels.setText(viewer._simulGridContourLevels.getText());
		_colorModel.setSelectedItem(viewer._colorModel.getSelectedItem());
		_colorScaling.setSelectedItem(viewer._colorScaling.getSelectedItem());
		_simulGridMin.setValue(viewer._simulGridMin.getValue());
		_simulGridMax.setValue(viewer._simulGridMax.getValue());
		_transparency.setValue(viewer._transparency.getValue());
    }
}
