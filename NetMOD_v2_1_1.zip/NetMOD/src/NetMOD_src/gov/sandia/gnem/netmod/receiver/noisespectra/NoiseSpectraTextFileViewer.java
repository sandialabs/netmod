/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.gui.ChartViewer.AxisScale;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.AbstractIntervalXYDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.List;

/**
 * Viewer of noise spectra text files
 * 
 * @author bjmerch
 *
 */
public class NoiseSpectraTextFileViewer extends NetModComponentViewer<NoiseSpectraTextFile> implements NoiseSpectraViewerInterface
{
    /**
     * Dataset to represent the noise spectra on a plot
     * 
     * @author bjmerch
     *
     */
    private class NoiseDataset extends AbstractIntervalXYDataset implements VisibleXYDataset
    {

        private boolean _visible = true;

        int N = 100;

        private NoiseSpectraTextFile _noise = null;

        private String _name = "Noise Spectra";

        public NoiseDataset()
        {
        }

        public NoiseDataset(NoiseSpectraTextFile noise)
        {
            _name = noise.getName();

            setNoise(noise);
        };

        @Override
        public Number getEndX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getEndY(int series, int item)
        {
            PDF pdf = getPDF(series, item);

            //  Only plot std-dev bars for the interpolated series
            if (series == 0)
                return pdf.getMean();
            else
                return pdf.getMean() + pdf.getStandardDeviation();
        }

        @Override
        public int getItemCount(int series)
        {
            if (!isVisible())
                return 0;

            if (series == 0)
                return (_noise == null ? 0 : _noise.getFrequencies().length);
            else
                return (_noise == null ? 0 : N * (_noise.getFrequencies().length - 1) + 1);
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return _name;
        }

        @Override
        public Number getStartX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getStartY(int series, int item)
        {
            PDF pdf = getPDF(series, item);

            //  Only plot std-dev bars for the interpolated series
            if (series == 0)
                return pdf.getMean();
            else
                return pdf.getMean() - pdf.getStandardDeviation();
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _noise.getFrequencies()[item];
            else
            {
                int index = item / N;
                double[] f = _noise.getFrequencies();

                if (index == f.length - 1)
                    return f[index];

                return Interpolation.linear(index * N, (index + 1) * N, f[index], f[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            return getPDF(series, item).getMean();
        }

        /**
         * Get the visibility
         * 
         * @return
         */
        @Override
        public boolean isVisible()
        {
            return _visible;
        }

        public void setNoise(NoiseSpectraTextFile noise)
        {
            _noise = noise;
            fireDatasetChanged();
        }

        /**
         * Set the visibility
         * 
         * @param visible
         * @return
         */
        @Override
        public void setVisible(boolean visible)
        {
            _visible = visible;

            fireDatasetChanged();
        }

        private PDF getPDF(int series, int item)
        {
            return _noise.getNoise(new DiscreteFrequency(getX(series, item).doubleValue()), time).getValue(0);
        }
    }

    private class NoiseTableModel extends NetMODTableModel
    {
        private NoiseSpectraTextFile _noise = null;

        @Override
        public int getColumnCount()
        {
            return 3;
        }

        public String getColumnName(int column)
        {
            if (column == 0)
                return "Frequency (Hz)";
            else if (column == 1)
                return "Mean (log10)";
            else
                return "S.D. (log10)";
        }

        @Override
        public int getRowCount()
        {
            return (_noise == null ? 0 : _noise.getFrequencies().length) + 10;
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_noise == null || row >= _noise.getFrequencies().length)
                return "";

            Frequency f = new DiscreteFrequency(_noise.getFrequencies()[row]);

            if (column == 0)
                return f;
            else if (column == 1)
                return _noise.getNoise(f, time).getValue(0).getMean();
            else if (column == 2)
                return _noise.getNoise(f, time).getValue(0).getStandardDeviation();

            return 0;
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return true;
        }

        @Override
        public void remove(int[] rows)
        {
            for (int row : rows)
            {
                double f = _noise.getFrequencies()[row];
                _noise.removeNoise(f);
            }
        }

        public void setNoise(NoiseSpectraTextFile noise)
        {
            _noise = noise;
            fireTableDataChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
            if (aValue == null || _noise == null)
                return;

            try
            {
                double f = 0;

                //  Set value for an existing row
                if (row < _noise.getFrequencies().length)
                    f = _noise.getFrequencies()[row];
                PDF pdf = _noise.getNoise(new DiscreteFrequency(f), time).getValue(0);

                //  Update the column
                if (column == 0)
                {
                    _noise.removeNoise(f);
                    f = Double.parseDouble(aValue.toString());
                }
                else if (column == 1)
                    pdf = new NormalPDF(Double.parseDouble(aValue.toString()), pdf.getStandardDeviation());
                else if (column == 2)
                    pdf = new NormalPDF(pdf.getMean(), Double.parseDouble(aValue.toString()));

                _noise.setNoise(f, pdf);

                fireTableDataChanged();
                if (_dataset != null)
                    _dataset.setNoise(_noise);

                //  Keep row selected
                int index = _noise.findIndex(_noise.getFrequencies(), f);
                _table.getSelectionModel().setSelectionInterval(index, index);
                _table.scrollRectToVisible(_table.getCellRect(index, 0, true));
            }
            catch (Exception e)
            {
            }
        }
    }

    private Time time = new Time(0);

    private ChartViewer _chartViewer = new ChartViewer();
    private NoiseDataset _dataset = new NoiseDataset();

    private NoiseTableModel _tableModel = new NoiseTableModel();

    private NetMODTable _table = new NetMODTable(_tableModel);

    public NoiseSpectraTextFileViewer(NoiseSpectraTextFile nmc)
    {
        super(nmc, false, false, false);

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Update the viewer
        reset(nmc);
    }

    @Override
    public void addNoiseModels(List<NoiseSpectra> noiseModels)
    {
        if (noiseModels == null)
            return;

        Color[] colors = new Color[] { Color.RED, Color.GREEN, Color.BLUE };

        XYPlot plot = _chartViewer.getPlot();

        for (int i = 0; i < noiseModels.size(); i++)
        {
            int count = plot.getDatasetCount();

            //  Configure the renderer
            StandardXYItemRenderer renderer = new StandardXYItemRenderer();
            renderer.setBaseShapesVisible(false);
            renderer.setSeriesVisible(0, false);
            renderer.setSeriesStroke(1, new BasicStroke(_chartViewer.getLineWidth() + 2));
            renderer.setSeriesPaint(1, colors[i % colors.length]);

            plot.setDataset(count, NoiseSpectraPlugin.createDataset(noiseModels.get(i)));
            plot.setRenderer(count, renderer);
        }
    }

    @Override
    public void apply(NoiseSpectraTextFile nmc)
    {
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            //  Configure the chart viewer
            _chartViewer.setXScale(AxisScale.LOG);
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Frequency (Hz)");
            plot.getRangeAxis().setLabel("Log10 Power Spectra Density");

            // Noise Dataset
            plot.setDataset(0, _dataset);

            //  Configure the renderer
            DeviationRenderer devRenderer = new DeviationRenderer(true, false);
            devRenderer.setAlpha(0.5f);
            devRenderer.setBaseToolTipGenerator(_chartViewer.getToolTipGenerator());

            devRenderer.setSeriesPaint(0, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesFillPaint(0, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesShape(0, new Ellipse2D.Double(-3, -3, 7, 7));
            devRenderer.setSeriesShapesVisible(0, true);
            devRenderer.setSeriesLinesVisible(0, false);
            devRenderer.setSeriesVisibleInLegend(0, false);

            devRenderer.setSeriesPaint(1, ((Color) _chartViewer.getLinePaint(0)));
            devRenderer.setSeriesFillPaint(1, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesStroke(1, new BasicStroke(_chartViewer.getLineWidth()));
            plot.setRenderer(0, devRenderer);

            //  Setup the table
            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.CENTER, new JScrollPane(_table));
            spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            spPanel.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(spPanel);

            JPanel panel = new JPanel(new GridBagLayout());
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(NoiseSpectraTextFile nmc)
    {
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the plot
        _dataset.setNoise(nmc);

        //  Update the table
        _tableModel.setNoise(nmc);
    }
}
