/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.plugin.Plugin;
import gov.sandia.gnem.netmod.probability.PDF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.data.xy.AbstractXYDataset;

/**
 * @author bjmerch
 *
 */
public class NoiseSpectraPlugin extends Plugin<NoiseSpectra>
{
    private static final Map<String, List<NoiseSpectra>> _noiseModels = new HashMap<String, List<NoiseSpectra>>();
    private static final NoiseSpectraPlugin _plugin = new NoiseSpectraPlugin();
    
    /**
     * Get the noise models for the provided technology string ('S', 'H', 'I')
     * 
     * @param technology
     * @return
     */
    public static final List<NoiseSpectra> getNoiseModels(String technology)
    {
        //  Limit technology indexing to the first character, upper case
        technology = technology.substring(0, 1).toUpperCase();
        
        List<NoiseSpectra> noiseModels = _noiseModels.get(technology);
        if ( noiseModels == null )
        {
            noiseModels = new ArrayList<NoiseSpectra>();
            _noiseModels.put(technology, noiseModels);
        }
        
        return noiseModels;
    }
    /**
     * Create the dataset that represents the noise spectra
     * 
     * @return
     */
    public static AbstractXYDataset createDataset(final NoiseSpectra _noise)
    {
        return new AbstractXYDataset()
        {
            int N = 100;

            @Override
            public int getItemCount(int series)
            {
                return (_noise == null ? 0 : N * (_noise.getFrequencies().length - 1) + 1);
            }

            @Override
            public int getSeriesCount()
            {
                return 1;
            }

            @Override
            public Comparable getSeriesKey(int series)
            {
                return _noise.getName();
            }

            @Override
            public Number getX(int series, int item)
            {
                int index = item / N;
                double[] f = _noise.getFrequencies();

                if (index == f.length - 1)
                    return f[index];

                return Interpolation.linear(index * N, (index + 1) * N, f[index], f[index + 1], item);
            }

            @Override
            public Number getY(int series, int item)
            {
                return _noise.getNoise(new DiscreteFrequency(getX(series, item).doubleValue()), new Time(0)).getMean(0);
            }
        };
    }
    
    /**
     * Get the plugin framework for Noise Spectra
     * 
     * @return
     */
    public static NoiseSpectraPlugin getPlugin()
    {
        return _plugin;
    }
}
