/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

/**
 * @author bjmerch
 *
 */
public final class FrequencyRange extends Frequency
{
    public FrequencyRange(double minValue, double maxValue)
    {
        super(minValue, maxValue);
    }
    
    @Override
    public String toString()
    {
        return Double.toString(getMinimumFrequency()) + "-" + Double.toString(getMaximumFrequency());
    }
}
