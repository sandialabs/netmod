/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.XYPlot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Set;


/**
 * @author bjmerch
 *
 */
public class JFreeChartStationSelectionTool extends AbstractAction
{
    private Receivers _receivers;
    private boolean _mapSelection = true;
    private ChartViewer _chartViewer;
    private MouseAdapter _selectListener;

    public JFreeChartStationSelectionTool(ChartViewer chartViewer, Receivers receivers)
    {
        _chartViewer = chartViewer;
        _receivers = receivers;

        _selectListener = new MouseAdapter()
        {
            private Point _startPoint = null;
            private Rectangle2D _selectRectangle = null;

            /**
             * Mouse button has been pushed and held and is now being moved (dragged) 
             * across the screen.
             */
            @Override
            public void mouseDragged(MouseEvent e)
            {
                // Only draw zoom rectangles on a left mouse button click
                if (SwingUtilities.isLeftMouseButton(e))
                {
                    ChartPanel chartPanel = (ChartPanel) e.getSource();
                    Graphics2D g2 = (Graphics2D) chartPanel.getGraphics();

                    // Erase the previous rectangle (if any)
                    g2.setXORMode(java.awt.Color.gray);
                    if (_selectRectangle != null)
                        g2.draw(_selectRectangle);

                    if (_startPoint == null)
                        return;

                    // Draw the new zoom rectangle
                    _selectRectangle = new Rectangle2D.Double(_startPoint.getX(), _startPoint.getY(), 0, 0);
                    _selectRectangle.add(e.getPoint());

                    g2.draw(_selectRectangle);
                    g2.dispose();
                }
            }

            /**
             * Initial press-and-hold prior to zooming.
             */
            @Override
            public void mousePressed(MouseEvent e)
            {
                _startPoint = e.getPoint();

                // Add a key listener to the ChartPanel to cancel a zoom operation when
                // the ESCAPE key is pressed.
                final ChartPanel chartPanel = (ChartPanel) e.getSource();
                for (KeyListener kl : chartPanel.getKeyListeners())
                {
                    chartPanel.removeKeyListener(kl);
                }
                chartPanel.setFocusable(true);
                chartPanel.requestFocusInWindow();
                chartPanel.addKeyListener(new KeyAdapter()
                {
                    public void keyPressed(KeyEvent e)
                    {
                        if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
                        { // cancel zoom operation
                            SwingUtilities.updateComponentTreeUI(chartPanel);
                            _startPoint = null;
                            _selectRectangle = null;
                        }
                    }
                });
            }

            /**
             * Mouse released after dragging.
             */
            @Override
            public void mouseReleased(MouseEvent e)
            {
                ChartPanel chartPanel = (ChartPanel) e.getSource();
                if (chartPanel == null)
                    return;

                // Complete the zooming drag box
                if (_selectRectangle != null && SwingUtilities.isLeftMouseButton(e))
                {
                    //  Convert the select rectangle from screen coordinates
                    XYPlot plot = _chartViewer.getPlot();

                    Point2D p1 = chartPanel.translateScreenToJava2D(new Point((int) _selectRectangle.getMinX(), (int) _selectRectangle.getMaxY()));
                    Point2D p2 = chartPanel.translateScreenToJava2D(new Point((int) _selectRectangle.getMaxX(), (int) _selectRectangle.getMinY()));

                    double minLon = plot.getDomainAxis().java2DToValue(p1.getX(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
                    double maxLon = plot.getDomainAxis().java2DToValue(p2.getX(), chartPanel.getScreenDataArea(), plot.getDomainAxisEdge());
                    double minLat = plot.getRangeAxis().java2DToValue(p1.getY(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
                    double maxLat = plot.getRangeAxis().java2DToValue(p2.getY(), chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
                    
                    Rectangle2D rect = new Rectangle2D.Double(minLon, minLat, maxLon-minLon, maxLat-minLat);

                    //  Get the set of selected station names
                    Set<Station> stations = _receivers.getNetwork().getStations();
                    
                    //  Iterate over all stations to determine which are inside the selection sector
                    for (Station station : _receivers.getStations().getStations())
                    {
                        if ( rect.contains(station.getLongitude(), station.getLatitude()) )
                        {
                            if ( _mapSelection )
                                stations.add(station);
                            else
                                stations.remove(station);
                        }
                    }
                    
                    //  Store the selected station names
                    _receivers.getNetwork().setStations(stations);
                    
                    //  Update the map
                    NetMOD.getMap().refresh();
                }

                _startPoint = null;
                _selectRectangle = null;
            }
        };
    }

    /**
     * Override the action performed method to display a JPopupMenu.
     */
    public void actionPerformed(ActionEvent e)
    {
        boolean selected = (Boolean) getValue(SELECTED_KEY);

        if (!selected)
        {
            _chartViewer.setListeners(null, null, null, null);
        }
        else
        {
            putValue(SELECTED_KEY, Boolean.FALSE);
            
            //  Only display the popup if it's selected
            createPopupMenu(getSelectedLayer()).show((JComponent) e.getSource(), 0, ((JComponent) e.getSource()).getHeight());
        }
    }

    /**
     * Create a popup menu that allows the user to change the media type for a region
     * 
     * @param layer
     */
    private JPopupMenu createPopupMenu(JFreeChartStationLayer layer)
    {
        JPopupMenu popupMenu = new JPopupMenu();

        if ( layer == null )
            return popupMenu;
        
        JMenuItem allItem = new JMenuItem("All");
        allItem.setToolTipText("Select all stations");
        allItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _receivers.getNetwork().setStations(_receivers.getStations().getStations());
                
                NetMOD.getMap().refresh();
                putValue(SELECTED_KEY, Boolean.FALSE);
            }
        });
        
        JMenuItem noneItem = new JMenuItem("None");
        noneItem.setToolTipText("Unselect all stations");
        noneItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	Set<Station> stations = _receivers.getNetwork().getStations();
            	stations.clear();
            	_receivers.getNetwork().setStations(stations);
                
                NetMOD.getMap().refresh();
                putValue(SELECTED_KEY, Boolean.FALSE);
            }
        });
        
        JMenuItem selectItem = new JMenuItem("Map Select");
        selectItem.setToolTipText("Select stations interatively on the map");
        selectItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _mapSelection = true;
                
                //  Add the listener
                _chartViewer.setListeners(null, _selectListener, _selectListener, Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                putValue(SELECTED_KEY, Boolean.TRUE);
            }
        });
        
        JMenuItem unselectItem = new JMenuItem("Map Unselect");
        unselectItem.setToolTipText("Unselect stations interatively on the map");
        unselectItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                _mapSelection = false;
                
                //  Add the listener
                _chartViewer.setListeners(null, _selectListener, _selectListener, Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                putValue(SELECTED_KEY, Boolean.TRUE);
            }
        });
        
        popupMenu.add(allItem);
        popupMenu.add(noneItem);
        popupMenu.addSeparator();
        popupMenu.add(selectItem);
        popupMenu.add(unselectItem);
        
        return popupMenu;
    }

    /**
     * Get the selected media grid layer from the map
     * 
     * @return
     */
    private JFreeChartStationLayer getSelectedLayer()
    {
        return (JFreeChartStationLayer) _receivers.getMapLayer();
    }
}
