/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *   * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *     this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.infra.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.NetSimParameters.ExplosionType;
import gov.sandia.gnem.netmod.io.TripleCacheMap;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.Arrays;

/**
 * Module for computing infrasound signal amplitudes at the receiver location
 * using Le Pichon's 2012 paper on path attenuation modeling.
 * 
 * JOURNAL OF GEOPHYSICAL RESEARCH, VOL. 117, D05121, doi:10.1029/2011JD016670, 2012
 * "Incorporating numerical modeling into estimates of the detection capability of the IMS infrasound network"
 * 
 * Explosive Shocks in Air, Second Edition
 * Gilbert F. Kinney, Kenneth J. Graham, 1985
 * 
 * @author bjmerch
 *
 */
public class LePichon2011InfrasoundSignalAmplitude extends AbstractInfrasoundSignalAmplitude
{
    public static final String TYPE = "LePichon2012";
    static
    {
        InfraSignalAmplitudePlugin.getPlugin().registerComponent(TYPE, LePichon2011InfrasoundSignalAmplitude.class);
    }
    
    /*
     * Terms defining the alpha coefficient which controls
     * the attenuation due to the dissipation of the direct wave.
     */
    private static double[] _alpha_freq = new double[]{ 0.1, 0.2, 0.4, 0.8, 1.6, 3.2};
    private static double[] _alpha_mean = new double[]{ -0.28, -0.33, -0.39, -0.47, -0.59, -0.69 };
    private static double[] _alpha_std = new double[]{ 0.05, 0.04, 0.03, 0.04, 0.06, 0.06 };
    
    /*
     * Terms defining the beta coefficent which controls
     * the geometric spreading and dissipation of stratospheric and thermospheric waves
     */
    private static double[] _beta_freq = new double[]{ 0.1, 0.2, 0.4, 0.8, 1.6, 3.2};
    private static double[] _beta_Veff = new double[]{ 0.85, 0.88, 0.91, 0.94, 1.0, 1.03, 1.06, 1.09, 1.12, 1.15, 1.18 };
    private static double[][] _beta_mean = new double[][]{
        new double[]{ -1.00, -1.00, -1.00, -1.00, -1.00, -0.90, -0.90, -0.85, -0.85, -0.85, -0.80, -0.80 },  //  f == 0.1
        new double[]{ -1.20, -1.20, -1.15, -1.10, -1.05, -0.95, -0.90, -0.85, -0.85, -0.85, -0.80, -0.80 },  //  f == 0.2
        new double[]{ -1.35, -1.40, -1.40, -1.35, -1.15, -1.00, -0.90, -0.90, -0.90, -0.85, -0.85, -0.85 },  //  f == 0.4
        new double[]{ -1.70, -1.60, -1.60, -1.55, -1.30, -1.05, -0.90, -0.90, -0.90, -0.90, -0.95, -0.90 },  //  f == 0.8
        new double[]{ -1.95, -1.95, -1.85, -1.75, -1.40, -1.15, -0.95, -0.95, -1.00, -1.00, -1.05, -1.05 },  //  f == 1.6
        new double[]{ -2.40, -2.30, -2.10, -1.85, -1.45, -1.20, -1.00, -1.00, -1.05, -1.10, -1.15, -1.20 }   //  f == 3.2
    };
    private static double[][] _beta_std = new double[][]{
        new double[]{ 0.10, 0.10, 0.10, 0.10, 0.15, 0.10, 0.05, 0.10, 0.10, 0.10, 0.10, 0.05 },  //  f == 0.1
        new double[]{ 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 },  //  f == 0.2
        new double[]{ 0.15, 0.15, 0.15, 0.15, 0.15, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 },  //  f == 0.4
        new double[]{ 0.15, 0.20, 0.15, 0.20, 0.15, 0.15, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 },  //  f == 0.8
        new double[]{ 0.30, 0.25, 0.20, 0.25, 0.20, 0.20, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 },  //  f == 1.6
        new double[]{ 0.45, 0.30, 0.25, 0.25, 0.25, 0.20, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 }   //  f == 3.2
    };
    
    /*
     * Terms defining the rho coefficent which controls
     * the strength of the attenuation in the shadow zone.
     */
    private static double[] _rho_freq = new double[]{ 0.1, 0.2, 0.4, 0.8, 1.6, 3.2};
    private static double[] _rho_mean = new double[]{ 79, 55, 43, 36, 27, 20 };
    private static double[] _rho_std = new double[]{ 22, 10, 4, 4, 7, 3 };
    
    /*
     * Terms defining the gamma coefficent which controls
     * the width of the shadow zone
     */
    private static double gamma_mean = 180;
    private static double gamma_std = 50;
    
    //  Cache wind velocities
    private double _cacheTime = 0;
    private TupleCacheMap<Point.Double, Point.Double, Complex> _0km_velocityCache = new TupleCacheMap<Point.Double, Point.Double, Complex>(null, CacheMap.CACHE_SOURCE, CacheMap.CACHE_RECEIVER);
    private TupleCacheMap<Point.Double, Point.Double, Complex> _50km_velocityCache = new TupleCacheMap<Point.Double, Point.Double, Complex>(null, CacheMap.CACHE_SOURCE, CacheMap.CACHE_RECEIVER);

    //  Cache path attenuation
    private TupleCacheMap<Frequency, Distance, SpectraPDF> _attenuationCache = new TupleCacheMap<Frequency, Distance, SpectraPDF>(null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_DISTANCE);
    
    //  Cache source spectra
    //  Include the epicenter location just to reduce number of map collisions.
    private CacheMap<Magnitude, SpectraDouble> _sourceSpectraCache = new CacheMap<Magnitude, SpectraDouble>(CacheMap.CACHE_MAGNITUDE);
    private TripleCacheMap<Frequency, Point.Double, Magnitude, SpectraDouble> _sourceCache = new TripleCacheMap<Frequency, Point.Double, Magnitude, SpectraDouble>(
            null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_SOURCE, CacheMap.CACHE_MAGNITUDE);

    @Override
    public void clearCache()
    {
        super.clearCache();

        _0km_velocityCache.clear();
        _50km_velocityCache.clear();
        _attenuationCache.clear();
        _sourceSpectraCache.clear();
        _sourceCache.clear();
    }
    
    /**
     * @param parent
     */
    public LePichon2011InfrasoundSignalAmplitude(NetModComponent parent)
    {
        super(parent, TYPE, "Le Pichon (2012) / Kinney & Graham (1985) ");
    }

    @Override
    protected SpectraPDF computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude,
            Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();
        
        SpectraPDF attenuation = _attenuationCache.get(frequency, distance);
        
        //  Compute the range in kilometers
        double R = distance.getDistanceKilometers(); 
        
        //  Compute Veff (the effective velocity ratio of the speed of sound at 50km and 0km)
        double Veff = 1.0;
        if ( attenuation == null || isIntrospection())
        {
            startIntrospection();
            double soundSpeed = 343.59;
            
            if ( _cacheTime != time.getTimeSeconds() )
            {
                _0km_velocityCache.clear();
                _50km_velocityCache.clear();
                
                _cacheTime = time.getTimeSeconds();
            }
            
            double windVelocity50km = computeWindVelocity(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, WindModel.ALTITUDE_KM, _50km_velocityCache);
            double windVelocity0km = computeWindVelocity(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, 0, _0km_velocityCache);
            
            Veff = ( soundSpeed + windVelocity50km ) / ( soundSpeed + windVelocity0km );
            
            recordIntrospection("Sound-Speed Ratio: ", Veff);
            recordIntrospection("Sound Speed (m/s): ", soundSpeed);
            recordIntrospection("50km wind velocity (m/s): ", windVelocity50km);
            recordIntrospection("0km wind velocity (m/s): ", windVelocity0km);
            
            stopIntrospection();
        }

        if (attenuation == null)
        {
            startIntrospection();
            double[] f_eval = frequency.getFrequencySamples();
            int Nfreq = f_eval.length;

            attenuation = new SpectraPDF(Nfreq);
            for (int i = 0; i < Nfreq; i++)
            {
                startIntrospection();
                double f = f_eval[i];

                //  Compute alpha
                double alpha_mean = Interpolation.interpolateQuadratic(_alpha_freq, _alpha_mean, f);
                double alpha_std = Interpolation.interpolateQuadratic(_alpha_freq, _alpha_std, f);

                //  Compute beta
                double beta_mean = Interpolation.interpolateBiquadratic(_beta_freq, _beta_Veff, _beta_mean, f, Veff);
                double beta_std = Interpolation.interpolateBiquadratic(_beta_freq, _beta_Veff, _beta_std, f, Veff);

                //  Compute rho
                double rho_mean = Interpolation.interpolateQuadratic(_rho_freq, _rho_mean, f);
                double rho_std = Interpolation.interpolateQuadratic(_rho_freq, _rho_std, f);

                //  Compute gamma

                //  Compute the log10 mean:  (1/R) * 10 ^ ( alpha * R / 20 ) + ( R ^ beta ) / ( 1 + 10 ^ ( (gamma - R) / rho ) )
                double a = alpha_mean;
                double b = beta_mean;
                double g = gamma_mean;
                double r = rho_mean;

                double mean_log10 = Math.log10((1 / R) * Math.pow(10, a * R / 20) + Math.pow(R, b) / (1 + Math.pow(10, (g - R) / r)));

                //  Compute the log10 mean plus 1 std:  (1/R) * 10 ^ ( alpha * R / 20 ) + ( R ^ beta ) / ( 1 + 10 ^ ( (gamma - R) / rho ) )
                a = alpha_mean + alpha_std;
                b = beta_mean + beta_std;
                g = gamma_mean + gamma_std;
                r = rho_mean + rho_std;

                double mean_plus_std_log10 = Math.log10((1 / R) * Math.pow(10, a * R / 20) + Math.pow(R, b) / (1 + Math.pow(10, (g - R) / r)));

                //  Difference to find the standard deviation.
                //  This is really ugly, but there is no closed form solution and 
                //  this yielded results that were close using monte-carlo simulations in Matlab.
                double std_log10 = Math.abs(mean_plus_std_log10 - mean_log10);

                NormalPDF atn = new NormalPDF(mean_log10, std_log10);
                attenuation.setValue(i, f, atn);

                recordIntrospection("Frequency (Hz): ", f);
                recordIntrospection("Attenuation (log10): ", atn);
                recordIntrospection("Alpha (1/km): ", alpha_mean);
                recordIntrospection("Beta (1/km): ", beta_mean);
                recordIntrospection("Gamma (km): ", gamma_mean);
                recordIntrospection("Rho (km): ", rho_mean);
                stopIntrospection();
            }
            
            recordIntrospection("Attenuations");
            stopIntrospection();
        }

        recordIntrospection("LePichon Path Attenuation (log10 Amplitude): ", attenuation);
        stopIntrospection();
        

        return attenuation;
    }
    
    @Override
    protected SpectraDouble computeLogSourceSpectra(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();
        SpectraDouble a = _sourceCache.get(frequency, epicenter, magnitude);
        
        //  Handle yield in KT
        if ( magnitude.getMagnitudeType() == MagnitudeType.KT )
        {
			ExplosionType explosionType = ((gov.sandia.gnem.netmod.infra.source.Sources) sources).getExplosionType();
			
			// Get the yield in KT
			double yield_kt = magnitude.getMagnitude();
			if ( yield_kt == 0 )
				a = SpectraDouble.NEGATIVE_999;
			
			if (a == null)
			{				
				SpectraDouble spectra = _sourceSpectraCache.get(magnitude);
				
				if (spectra == null)
				{
					double r = 1; // Range (km)
					double p_obs = 1013; // Ambient pressure in mbar
					double t_obs = 15; // Ambient temperature in celsius
					int Npts = 8192; // Number of points
					double dt = 0.01; // Sampling time period in seconds

					double[] y;

					if (explosionType == ExplosionType.NUCLEAR)
					{
						y = synthetic_y_nuclear(yield_kt, r, p_obs, t_obs, Npts,
						        dt);
					}
					else if (explosionType == ExplosionType.CHEMICAL)
					{
						// Convert yield from kt to kg
						double yield_kg = yield_kt * 1000 * 2000 / 2.20462;

						y = synthetic_y_chemical(yield_kg, r, p_obs, t_obs, Npts,
						        dt);
					}
					else
						y = new double[0];

					double[] spectra_freq = getspec_freq(y, 1.0 / dt);
					double[] spectra_Y = getspec_Y(y, 1.0 / dt);
					
					spectra = new SpectraDouble(spectra_freq, spectra_Y);
					_sourceSpectraCache.put(magnitude, spectra);
				}

				// Determine the frequencies to evaluate
				double[] f = frequency.getFrequencySamples();
				a = new SpectraDouble(f.length);
				for (int i = 0; i < f.length; i++)
					a.setValue(i, f[i],
					        Math.log10(Interpolation.interpolateQuadratic(
					                spectra.getFrequencies(), spectra.getValues(), f[i])));
			}

            recordIntrospection("Kinney & Graham Source Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Explosion: " + explosionType);
            recordIntrospection("Yield (kT): ", yield_kt);
        }
        else if ( magnitude.getMagnitudeType() == MagnitudeType.Pa )
        {
            if (a == null)
                a = new SpectraDouble(magnitude.getMoment());
            
            recordIntrospection("Pressure Source Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Magnitude (log10 Magnitude): ", magnitude);
        }
        else
        {
            if (a == null)
                a = new SpectraDouble(0);
            
            recordIntrospection("Source Amplitude (log10 Amplitude): ", a);
            recordIntrospection("Magnitude (log10 Magnitude): ", magnitude);
        }
        
        _sourceCache.put(frequency, epicenter, magnitude, a);
        
        stopIntrospection();
        
        return a;
    }
    
    
    
	private double get_f_d(double p_obs, double t_obs)
	{
		double term1 = Math.pow(p_obs / 1013.0, 1.0 / 3.0);
		double term2 = Math.pow(t_obs / 15.0, -1.0 / 3.0);
		double f_d = term1 * term2;

		return f_d;
	}
	
	/**
	 * Compute the chemical synthetic time series y values
	 * 
	 * @param W
	 * @param r
	 * @param p_obs
	 * @param t_obs
	 * @param N
	 * @param dt
	 * @return
	 */
	private double[] synthetic_y_chemical(double W, double r, double p_obs, double t_obs, int N, double dt)
	{
		startIntrospection();
		
		//  Calculate the overpressure
		double f_d = get_f_d(p_obs, t_obs);
		double R = scaledRange(W, r*1000, f_d);
		double P = overpressure_chemical(R, p_obs);
		
		//  Calculate the positive phase duration
		double T_pos = positiveDurationChemical(R);
		double t_pos = (Math.pow(W,  1.0/3.0) / f_d) * T_pos;
		t_pos = t_pos / 1000.0;
		
		//  Calculate b
		double b = 1;
		
		double[] t = new double[N];
		for (int k=0; k<N; k++)
			t[k] = -dt*N/2 + k * dt;
		
		double[] y = pierce(t, t_pos, b);
		for (int k=0; k<y.length; k++)
			y[k] *= P;

		recordIntrospection("Chemical Yield (kg): ", W);
		recordIntrospection("Scaled Range (m/kg^1/3): ", R);
		recordIntrospection("Peak Overpressure (Pa): ", P);
		recordIntrospection("Positive duration (sec): ", t_pos);
		stopIntrospection();
		
		return y;
	}
	
	/**
	 * Compute the nuclear time series y values
	 * 
	 * @param W
	 * @param r
	 * @param p_obs
	 * @param t_obs
	 * @param N
	 * @param dt
	 * @return
	 */
	private double[] synthetic_y_nuclear(double W, double r, double p_obs, double t_obs, int N, double dt)
	{		
		startIntrospection();
		
		//  Calculate the overpressure
		double f_d = get_f_d(p_obs, t_obs);
		double R = scaledRange(W, r*1000, f_d);
		double P = overpressure_nuclear(R, p_obs);
		
		//  Calculate the positive phase duration
		double T_pos = positiveDurationNuclear(R);
		double t_pos = (Math.pow(W,  1.0/3.0) / f_d) * T_pos;
		
		//  Calculate b
		double b = 1;
		
		double[] t = new double[N];
		for (int k=0; k<N; k++)
			t[k] = -dt*N/2 + k * dt;
		
		double[] y = pierce(t, t_pos, b);
		for (int k=0; k<y.length; k++)
			y[k] *= P;

		recordIntrospection("Nuclear Yield (kt): ", W);
		recordIntrospection("Scaled Range (m/kt^1/3): ", R);
		recordIntrospection("Peak Overpressure (Pa): ", P);
		recordIntrospection("Positive duration (sec): ", t_pos);
		stopIntrospection();
		
		return y;
	}
	
	private double[] pierce(double[] t, double tau, double b)
	{
		int N = t.length;
		
		double[] tn = Arrays.copyOf(t, N);
		NumericUtility.add(tn, Math.abs(NumericUtility.min(t)));
		
		double[] y = new double[N];
		Arrays.fill(y, 0.0);
		
		for (int i=0; i<N/2; i++)
			y[N/2+i] = ( 1.0 - tn[i] / tau ) * Math.exp( - b * tn[i] / tau );
		
		return y;
	}
	
	/**
	 * Compute the scaled range from the yield, range, and f_d
	 * 
	 * @param W
	 * @param r
	 * @param f_d
	 * @return
	 */
	private double scaledRange(double W, double r, double f_d)
	{
		double R = (f_d / Math.pow(W,  1.0/3.0)) * r;
		
		return R;
	}
	
	/**
	 * Compute the overpressure from the scaled range and ambient pressure
	 * 
	 * @param R Scale range
	 * @param p_obs Ambient pressure
	 * @return
	 */
	private double overpressure_chemical(double R, double p_obs)
	{
		double num = 808. * (1 + Math.pow(R / 4.5, 2.0));
		double den1 = Math.sqrt(1 + Math.pow(R / 0.048, 2.0));
		double den2 = Math.sqrt(1 + Math.pow(R / 0.32, 2.0));
		double den3 = Math.sqrt(1 + Math.pow(R / 1.35, 2.0));
		double den = den1 * den2 * den3;
		double P = (num / den) * (p_obs * 100);

		return P;
	}
	
	/**
	 * Compute the overpressure from the scaled range and ambient pressure
	 * 
	 * @param R Scale range
	 * @param p_obs Ambient pressure
	 * @return
	 */
	private double overpressure_nuclear(double R, double p_obs)
	{
		double num1 = 3.2e6 * Math.pow(R, -3.0);
		double num2 = Math.sqrt(1 + Math.pow(R / 87, 2.0));
		double num3 =  1 + R / 800;
		double P = 100 * p_obs * num1 * num2 * num3;

		return P;
	}
	
	/**
	 * Compute the positive duration in seconds from the scaled range
	 * 
	 * @param R Scaled range
	 * @return Positive time duration in seconds
	 */
	private double positiveDurationChemical(double R)
	{
		double num = 980.0 * (1 + Math.pow(R / 0.54, 10.0));
		double den1 = 1 + Math.pow(R / 0.02, 3.0);
		double den2 = 1 + Math.pow(R / 0.74, 6.0);
		double den3 = Math.sqrt(1 + Math.pow(R / 6.9, 2.0));
		double den = den1 * den2 * den3;
		double T = num / den;

		return T;
	}
	
	/**
	 * Compute the positive duration in seconds from the scaled range
	 * 
	 * @param R Scaled range
	 * @return Positive time duration in seconds
	 */
	private double positiveDurationNuclear(double R)
	{
		double num = 180 * Math.sqrt( 1 + Math.pow(R/100, 3));
		double den1 = Math.pow(1 + R/40,  0.5);
		double den2 = Math.pow(1 + Math.pow(R/285, 5),  1.0 / 6.0);
		double den3 = Math.pow(1 + R/50000, 1.0 / 6.0);
		double den = den1 * den2 * den3;
		double T = num / den;

		return T;
	}

	/**
	 * Get the Y values of the source spectrum
	 * 
	 * @param y
	 * @param Fs
	 * @return
	 */
	private double[] getspec_Y(double[] y, double Fs)
	{
		int n = y.length; // length of the signal
		FFT fft = new FFT(n);
		y = fft.fft(y).getMagnitude();
		
		//  Take out just the positive frequencies
		double[] Y = new double[n/2];
		for (int i=0; i<Y.length; i++)
			Y[i] = 2.0 * y[i] / n;
		
		return Y;
		
	}

	/**
	 * Get the frequency values of the source spectrum
	 * 
	 * @param y
	 * @param Fs
	 * @return
	 */
	private double[] getspec_freq(double[] y, double Fs)
	{
		int n = y.length; // length of the signal
		double T = n / Fs;
		
		double[] frq = new double[n];
		for (int i=0; i<n; i++)
			frq[i] = i / T; 
		
		return frq;
	}
    
}
