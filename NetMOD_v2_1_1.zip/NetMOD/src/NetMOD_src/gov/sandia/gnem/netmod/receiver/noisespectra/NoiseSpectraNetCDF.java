/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import ucar.ma2.Array;
import ucar.ma2.ArrayDouble;
import ucar.ma2.Index;
import ucar.nc2.Attribute;
import ucar.nc2.Group;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * @author bjmerch
 */
public class NoiseSpectraNetCDF extends AbstractNetModFile implements NoiseSpectra
{

	private static final NormalPDF NO_RESULT = new NormalPDF(999, 0);
	private static final SpectraPDF NO_RESULT_SPECTRA = new SpectraPDF(NO_RESULT);
	private static final String _type = "Noise Spectra CDF NetCDF File";

	// Register the plugin
	static
	{
		NoiseSpectraPlugin.getPlugin().registerComponent(_type, NoiseSpectraNetCDF.class);
	}

	private String _original_filename = "";
	private String _station;
	private String _dataType;
	private String _unit;
	private String[] _times;
	private Time[] _times_start;
	private double[] _time_start_year;
	private double[] _time_start_doy;
	private double[] _time_start_tod;
	private double[] _time_end_year;
	private double[] _time_end_doy;
	private double[] _time_end_tod;
	private double[] _frequencies;
	private double[] _percentiles;
	private boolean[] _isValid;
	private double[][][] _cdf;
	private double[][] _mean;
	private double[][] _std;

	// Cache frequently requested values
	private transient TupleCacheMap<Time, Frequency, SpectraPDF> _cache = new TupleCacheMap<Time, Frequency, SpectraPDF>(
			null, CacheMap.CACHE_TIME, CacheMap.CACHE_FREQUENCY);

	public NoiseSpectraNetCDF(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		_frequencies = null;
		_percentiles = null;
		_cdf = null;
		_mean = null;
		_std = null;
		_cache.clear();
	}

	/**
	 * Low-level method for computing noise at a particular frequency and time index
	 */
	private NonParametricCDF computeNoise(String dataType, String unit, double frequency, int time_index)
	{
		double conversion_factor_add = 0;
		double conversion_factor_scale = 1;

		double conversion_factor_mean_add = 0;
		double conversion_factor_mean_scale = 1;

		if (dataType.startsWith("hydro"))
		{
			if (unit.startsWith("db re (1uPa^2)/H"))
			{
				// Convert from dB((Pa^2)/Hz) to log10(("Pa^2)/Hz)
				conversion_factor_add = 0;
				conversion_factor_scale = 0.1;
				conversion_factor_mean_add = 0;
				conversion_factor_mean_scale = 1;
			}
			else
			{
				System.out.println("NoiseSpectraNetCDF:  Unknown unit type: " + unit);
			}
		}
		else if (dataType.startsWith("infra"))
		{
			if (unit.startsWith("(Pa^2)/Hz"))
			{
				// Pressure values stored as log10 values, requiring no scaling
				conversion_factor_add = 0;
				conversion_factor_scale = 1;
				conversion_factor_mean_add = 0;
				conversion_factor_mean_scale = 1;
			}
			else
			{
				System.out.println("NoiseSpectraNetCDF:  Unknown unit type: " + unit);
			}
		}
		else if (dataType.startsWith("seis"))
		{
			if (unit.startsWith("db re (m^2/s^4)/"))
			{
				// Compute the conversion factor betweeen acceleration dB( (m/s^2)^2/Hz ) and
				// log10(nano-m^2/Hz)
				conversion_factor_add = 2.0 * Math.log10(1.0e9 / (4 * Math.PI * Math.PI * frequency * frequency));
				conversion_factor_scale = 0.1;

				// Convert values from log10( (nano-m/s^2)^2/Hz ) and log10(nm^2/Hz)
				conversion_factor_mean_add = conversion_factor_add - 18;
				conversion_factor_mean_scale = 1;
			}
			else
			{
				System.out.println("NoiseSpectraNetCDF:  Unknown unit type: " + unit);
			}
		}
		else
		{
			System.out.println("NoiseSpectraNetCDF:  Unknown data type: " + dataType);
		}

		// Interpolate the percentile lines at the requested frequency
		int N = _percentiles.length;
		double[] x = new double[N];

		for (int i = 0; i < N; i++)
		{
			double value = Interpolation.interpolateQuadratic(_frequencies, _cdf[time_index][i], frequency);

			// Convert values
			x[i] = conversion_factor_add + conversion_factor_scale * value;
		}

		// Determine the mean and standard deviation
		double mean = Interpolation.interpolateQuadratic(_frequencies, _mean[time_index], frequency);
		double std = Interpolation.interpolateQuadratic(_frequencies, _std[time_index], frequency);

		// Convert values from log10( nano-meters acceleration ) to log10( displacement )
		mean = conversion_factor_mean_add + conversion_factor_mean_scale * mean;

		//  Check for bad values
		if ( mean < -999 )
			mean = NO_RESULT.getMean();

		// Construct a PDF of the noise
		return new NonParametricCDF(x, _percentiles, mean, std);
	}

	/**
	 * Get the CDF, double[times][percentiles][frequencies]
	 */
	public double[][][] getCDF()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_cdf == null)
			{
				read();
			}
		}

		return _cdf;
	}

	public String getDataType()
	{
		return _dataType;
	}

	/**
	 * Get the frequencies over which the noise spectra is defined
	 */
	@Override
	public double[] getFrequencies()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
			{
				read();
			}
		}

		return _frequencies;
	}

	@Override
	public SpectraPDF getNoise(Frequency frequency, Time time)
	{
		startIntrospection();
		recordIntrospection("Noise Spectra from file: ", getFilename(), "'");
		recordIntrospection("at frequency (Hz): ", frequency);
		recordIntrospection("at time (sec): ", time);

		// Check the first level of cache, synchronized
		SpectraPDF noise = _cache.get(time, frequency);
		if (noise != null)
		{
			recordIntrospection("Noise (log10): ", noise);
			stopIntrospection();
			return noise;
		}

		/*
		 * Check for no noise defined
		 */
		double[] frequencies = getFrequencies();
		int Nfrequencies = frequencies.length;
		if (Nfrequencies == 0)
		{
			noise = NO_RESULT_SPECTRA;
			recordIntrospection("No noise defined");
			recordIntrospection("Noise (log10): ", noise);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();
			return noise;
		}

		// Convert the time to a calendar object
		Calendar cal = time.getCalendar();

		int year = cal.get(Calendar.YEAR);
		int doy = cal.get(Calendar.DAY_OF_YEAR);
		double tod = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
				+ cal.get(Calendar.SECOND) / 3600.0;
		double hour_of_year = doy * 24 + tod;

		// Find the time index
		int time_index = 0;
		double min_d_hour_of_year = Double.MAX_VALUE;
		double min_d_year = Double.MAX_VALUE;
		for (int i = 0; i < _time_start_year.length; i++)
		{
			if (!_isValid[i])
			{
				continue;
			}

			double start_hour_of_year = _time_start_doy[i] * 24 + _time_start_tod[i];
			double end_hour_of_year = _time_end_doy[i] * 24 + _time_end_tod[i];

			double d_hour_of_year = Math.min(Math.abs(start_hour_of_year - hour_of_year),
					Math.abs(end_hour_of_year - hour_of_year));
			double d_year = Math.min(Math.abs(_time_start_year[i] - year), Math.abs(_time_end_year[i] - year));

			if (d_hour_of_year == min_d_hour_of_year)
			{
				if (d_year < min_d_year)
				{
					min_d_hour_of_year = d_hour_of_year;
					min_d_year = d_year;
					time_index = i;
				}
			}
			else if (d_hour_of_year < min_d_hour_of_year)
			{
				min_d_hour_of_year = d_hour_of_year;
				min_d_year = d_year;
				time_index = i;
			}
		}

		// Determine the frequencies to be evaluated
		double[] f_eval = getEvaluationFrequencies(frequency, frequencies);
		int N = f_eval.length;

		noise = new SpectraPDF(N);
		for (int i = 0; i < N; i++)
		{
			noise.setValue(i, f_eval[i], computeNoise(getDataType(), getUnit(), f_eval[i], time_index));
		}

		recordIntrospection("Noise (log10): ", noise);
		stopIntrospection();

		/*
		 * Cache the results for the next call, synchronized
		 */
		_cache.put(time, frequency, noise);

		return noise;
	}

	public double[] getPercentiles()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_percentiles == null)
			{
				read();
			}
		}

		return _percentiles;
	}

	/**
	 * @return
	 */
	public String getStation()
	{
		return _station;
	}

	public String[] getTimes()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_times == null)
			{
				read();
			}
		}

		return _times;
	}

	public Time getTimeStart(int time_index)
	{
		return _times_start[time_index];
	}

	/**
	 * @return
	 */
	public String getUnit()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_unit == null)
			{
				read();
			}
		}

		return _unit;
	}

	@Override
	public NoiseSpectraNetCDFViewer getViewer()
	{
		return new NoiseSpectraNetCDFViewer(this);
	}

	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
		{
			file = (File) o;
		}
		else if (o instanceof String)
		{
			file = IOUtility.openFile((String) o);
		}

		// Check if the file exists
		if (file == null || !file.exists())
		{
			return false;
		}

		// Noise CDF end with ".cdf" or ".nc"
		return IOUtility.endsWith(file, ".cdf") || IOUtility.endsWith(file, ".nc");
	}

	@Override
	public boolean read()
	{
		boolean value = false;

		// Synchronize on the type to prevent errors if simultaneously reading from the
		// same file
		synchronized (_type)
		{
			NetcdfFile ncfile = null;

			try
			{
				// Open the file and read in the title
				ncfile = NetcdfFile.open(IOUtility.cleanString(getFilename()));

				// Get the station name
				Attribute stationNameAtt = ncfile.findGlobalAttributeIgnoreCase("station_name");
				_station = stationNameAtt.getStringValue();

				// Get the data type
				Attribute dataTypeAtt = ncfile.findGlobalAttributeIgnoreCase("data_type");
				_dataType = dataTypeAtt.getStringValue().toLowerCase();

				// Get the unit
				Attribute unitAtt = ncfile.findGlobalAttributeIgnoreCase("units");
				_unit = unitAtt.getStringValue();

				// Read the percentiles
				{
					Variable v = ncfile.findVariable("percentiles");
					ArrayDouble.D1 data = (ArrayDouble.D1) v.read();

					_percentiles = new double[(int) data.getSize()];
					for (int i = 0; i < _percentiles.length; i++)
					{
						_percentiles[i] = data.get(i) / 100.0;
					}
				}

				// Read the frequencies
				{
					Variable v = ncfile.findVariable("frequencies");
					ArrayDouble.D1 data = (ArrayDouble.D1) v.read();

					_frequencies = new double[(int) data.getSize()];
					for (int i = 0; i < _frequencies.length; i++)
					{
						_frequencies[i] = data.get(i);

						// Check for monotonic values, needed because some hydro noise files have
						// "extra" frequencies
						if (i > 0 && _frequencies[i] < _frequencies[i - 1])
						{
							_frequencies = Arrays.copyOf(_frequencies, i);
							break;
						}
					}
				}

				// Find the group with a matching station name
				Group stationGroup = ncfile.getRootGroup().findGroup(_station);

				if (stationGroup != null)
				{
					List<Group> timeGroups = stationGroup.getGroups();
					int num_times = timeGroups.size();
					_times = new String[num_times];
					_times_start = new Time[num_times];
					_time_start_year = new double[num_times];
					_time_start_doy = new double[num_times];
					_time_start_tod = new double[num_times];
					_time_end_year = new double[num_times];
					_time_end_doy = new double[num_times];
					_time_end_tod = new double[num_times];
					_cdf = new double[num_times][_percentiles.length][_frequencies.length];
					_mean = new double[num_times][_frequencies.length];
					_std = new double[num_times][_frequencies.length];
					_isValid = new boolean[num_times];

					Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));

					// Iterate over the time groups within the station group
					for (int i = 0; i < num_times; i++)
					{
						_isValid[i] = true;
						Group timeGroup = timeGroups.get(i);

						Variable timeAttributes = timeGroup.findVariable("time_attributes");
						if (timeAttributes != null)
						{
							// Extract the begin and end time.
							String begin_time = timeAttributes.findAttribute("begin_time").getStringValue();
							String end_time = timeAttributes.findAttribute("end_time").getStringValue();

							_times[i] = begin_time + " - " + end_time;

							// Begin and End time has two parts: JDate and time of day
							_time_start_year[i] = Integer.parseInt(begin_time.substring(0, 4));
							_time_start_doy[i] = Integer.parseInt(begin_time.substring(4, 7));
							_time_start_tod[i] = Double.parseDouble(begin_time.substring(8, 10))
									+ Double.parseDouble(begin_time.substring(11, 13)) / 60
									+ Double.parseDouble(begin_time.substring(14, 16)) / 3600;

							_time_end_year[i] = Integer.parseInt(end_time.substring(0, 4));
							_time_end_doy[i] = Integer.parseInt(end_time.substring(4, 7));
							_time_end_tod[i] = Double.parseDouble(end_time.substring(8, 10))
									+ Double.parseDouble(end_time.substring(11, 13)) / 60
									+ Double.parseDouble(end_time.substring(14, 16)) / 3600;

							double hour = Double.parseDouble(begin_time.substring(8, 10));
							double min = Double.parseDouble(begin_time.substring(11, 13));
							double sec = Double.parseDouble(begin_time.substring(14, 16));

							// Create a calendar object
							cal.set(Calendar.YEAR, (int) _time_start_year[i]);
							cal.set(Calendar.DAY_OF_YEAR, (int) _time_start_doy[i]);
							cal.set(Calendar.HOUR_OF_DAY, (int) hour);
							cal.set(Calendar.MINUTE, (int) min);
							cal.set(Calendar.SECOND, (int) sec);

							_times_start[i] = new Time(cal.getTimeInMillis());
						}
						else
						{
							_times_start[i] = new Time(0);
							_isValid[i] = false;
							continue;
						}

						// There may be noises for multiple array elements/stations/channels. Use the
						// first
						for (Group elementGroup : timeGroup.getGroups())
						{
							// Give this element a chance to be valid
							_isValid[i] = true;

							// Get the distribution
							Variable cdf = elementGroup.findVariable("PDF");
							if (cdf != null)
							{
								Array data = cdf.read();
								Index index = data.getIndex();

								for (int j = 0; j < _percentiles.length; j++)
								{
									for (int k = 0; k < _frequencies.length; k++)
									{
										_cdf[i][j][k] = data.getDouble(index.set(j, k));
									}

									if (NumericUtility.isConstant(_cdf[i][j]))
									{
										_isValid[i] = false;
									}
								}
							}
							else
							{
								_isValid[i] = false;
								continue;
							}

							// Get the mean
							Variable mean = elementGroup.findVariable("log_PSD");
							if (mean != null)
							{
								Array data = mean.read();
								Index index = data.getIndex();

								for (int j = 0; j < _frequencies.length; j++)
								{
									_mean[i][j] = data.getDouble(index.set(j));
								}

								if (NumericUtility.isConstant(_mean[i]))
								{
									_isValid[i] = false;
								}
							}
							else
							{
								_isValid[i] = false;
								continue;
							}

							// Get the standard deviation
							Variable std = elementGroup.findVariable("log_PSD_std");
							if (std != null)
							{
								Array data = std.read();
								Index index = data.getIndex();

								for (int j = 0; j < _frequencies.length; j++)
								{
									_std[i][j] = data.getDouble(index.set(j));
								}

								if (NumericUtility.isConstant(_std[i]))
								{
									_isValid[i] = false;
								}
							}
							else
							{
								_isValid[i] = false;
								continue;
							}

							// Quit, once a spectra has been identified
							break;
						}
					}
				}

				value = true;
				_original_filename = getFilename();
				setDirty(false);
			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					System.out.println("Unable to read NetCDF noise file: '" + getFilename() + "'");
					e.printStackTrace();
				}

				_unit = "(none)";
				_frequencies = new double[0];
				_times = new String[0];
				_time_start_year = new double[0];
				_time_start_doy = new double[0];
				_time_start_tod = new double[0];
				_time_end_year = new double[0];
				_time_end_doy = new double[0];
				_time_end_tod = new double[0];
				_percentiles = new double[0];
				_cdf = new double[0][0][0];
				_isValid = new boolean[0];
			}
			finally
			{
				IOUtility.safeClose(ncfile);
			}
		}

		return value;
	}

	@Override
	public boolean write()
	{
		setDirty(false);

		// Copy the contents over
		if (!getFilename().equals(_original_filename) && !IOUtility.openFile(getFilename()).exists())
		{
			IOUtility.copy(_original_filename, getFilename());
			return true;
		}

		// Writing not yet supported
		return false;
	}
}
