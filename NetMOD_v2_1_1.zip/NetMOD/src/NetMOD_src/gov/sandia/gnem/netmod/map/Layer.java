/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map;

import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;

/**
 * Interface representing a layer on the Map.
 * 
 * @author bjmerch
 *
 */
public interface Layer<NMC extends NetModComponent>
{
    /**
     * Control the display of items within a layer
     * 
     * @author bjmerch
     *
     */
    public enum DISPLAY { ALL, SELECTED, NOT_SELECTED };
    
    /**
     * Get the data object that this layer represents.
     * 
     * @return
     */
    public NMC getNMC();
    
    /**
     * Set the data object that this layer represents.
     * 
     * @param data
     */
    public void setNMC(NMC data);
    
    /**
     * Get a JPanel that contains the symbology 
     * legend associated with this layer.
     * 
     * @return
     */
    public JPanel getLegendPanel();
    
    
    /**
     * Set the layer visibility
     * 
     * @param value
     */
    public void setVisible(boolean value);
    
    /**
     * Set the display option for this layer
     * 
     * @param display
     */
    public void setDisplay(DISPLAY display);
    
    /**
     * Get the display  option for this layer
     * 
     * @return
     */
    public DISPLAY getDisplay();
    
}
