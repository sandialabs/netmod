/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

/**
 * Container used for ALF information that is static between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class ALF_Data
{
	public int nmax0, mmax0;
    public double[][] anm, bnm, dnm;
    public double[] cm, en;

    private static ALF_Data _instance;
    
    public static ALF_Data getInstance()
    {
        if ( _instance == null )
            _instance = new ALF_Data();
        
        return _instance;
    }

    private ALF_Data()
    {
        GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();
        DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();
        HWM14_Data hwm08_data = HWM14_Data.getInstance();

        int nmax_geo = Math.max(hwm08_data.maxn, gd2qd_data.nmax);
        int maxo = Math.max(Math.max(hwm08_data.maxs, hwm08_data.maxm), hwm08_data.maxl);
        
        int mmax_geo = Math.max(maxo, gd2qd_data.mmax);

        int nmaxin = Math.max(nmax_geo, dwm07b_data.nmax);
        int mmaxin = Math.max(mmax_geo, dwm07b_data.mmax);
        
    	initalf(nmaxin, mmaxin);
    }
    
    private void initalf(int nmaxin, int mmaxin)
    {
        int nmax0 = nmaxin;
        int mmax0 = mmaxin;

        anm = new double[nmax0 + 1][mmax0 + 1];
        bnm = new double[nmax0 + 1][mmax0 + 1];
        cm = new double[mmax0 + 1];
        dnm = new double[nmax0 + 1][mmax0 + 1];
        en = new double[nmax0 + 1];

        for (int n = 1; n <= nmax0; n++)
        {
            en[n] = Math.sqrt(n * (n + 1.0));
            anm[n][0] = Math.sqrt((2.0 * n - 1.0) * (2.0 * n + 1.0)) / n;
            bnm[n][0] = Math.sqrt((2.0 * n + 1.0) * (n - 1.0) * (n - 1.0) / (2.0 * n - 3.0)) / n;
        }

        for (int m = 1; m <= mmax0; m++)
        {
            cm[m] = Math.sqrt((2.0 * m + 1) / (2.0 * m * m * (m + 1)));

            for (int n = m + 1; n <= nmax0; n++)
            {
                anm[n][m] = Math.sqrt((2.0 * n - 1.0) * (2.0 * n + 1.0) * (n - 1.0) / ((double) ((n - m) * (n + m) * (n + 1.0))));
                bnm[n][m] = Math.sqrt((2.0 * n + 1.0) * (n + m - 1.0) * (n - m - 1.0) * (n - 2.0) * (n - 1.0) /
                        ((double) ((n - m) * (n + m) * (2.0 * n - 3.0) * (n) * (n + 1.0))));
                dnm[n][m] = Math.sqrt((n - m) * (n + m) * (2.0 * n + 1.0) * (n - 1.0) / ((double) ((2.0 * n - 1.0) * (n + 1.0))));
            }
        }
        
        /*
         * Debugging statements
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("initalf");
        System.out.println("anm = ");
        for (int i=0; i<=nmax0; i++)
        	System.out.println(Arrays.toString(anm[i]));
        System.out.println("bnm = ");
        for (int i=0; i<=nmax0; i++)
        	System.out.println(Arrays.toString(bnm[i]));
        System.out.println("cm = ");
        System.out.println(Arrays.toString(cm));
        System.out.println("dnm = ");
        for (int i=0; i<=nmax0; i++)
        	System.out.println(Arrays.toString(dnm[i]));
        System.out.println("en = ");
        System.out.println(Arrays.toString(en));
        */
    }

}
