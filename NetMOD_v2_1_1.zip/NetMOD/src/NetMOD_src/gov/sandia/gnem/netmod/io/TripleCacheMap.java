/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import java.util.*;

/**
 * Map with a tuple key K1, K2, K3 to a single value V
 * 
 * @author bjmerch
 *
 */
public class TripleCacheMap<K1 extends Object, K2 extends Object, K3 extends Object, V extends Object>
{
    protected CacheMap<K1, CacheMap<K2, CacheMap<K3, V>>> _map;
    private Class<V> _c = null;
    private int _n1, _n2, _n3;

    /**
     * Construct a tuple map with the provided class identifier
     * if the "get" is desired to automatically create and insert
     * a default value (using the empty constructor).  Other wise,
     * a get will return null if the map does not contain the desired keys
     * 
     * @param c
     * @param n1
     * @param n2
     */
    public TripleCacheMap(Class<V> c, int n1, int n2, int n3)
    {
        _map = new CacheMap<K1, CacheMap<K2, CacheMap<K3, V>>>(n1);
        _c = c;
        _n1 = n1;
        _n2 = n2;
        _n3 = n3;
    }
    
    public void clear()
    {
        synchronized (_map)
        {
            for ( CacheMap<K2, CacheMap<K3, V>> entry1 : _map.values())
                if ( entry1 != null )
                {
                    for (CacheMap<K3, V> entry2 : entry1.values())
                    {
                        if ( entry2 != null )
                            entry2.clear();
                    }
                    entry1.clear();
                }
            
            _map.clear();
        }
    }
    
    /**
     * Get the set of K1 keys
     * 
     * @return
     */
    public Set<K1> getKeys1()
    {
        return _map.keySet();
    }
    
    /**
     * Get the set of K2 keys
     * 
     * @return
     */
    public Set<K2> getKeys2()
    {
        Set<K2> keys = new HashSet<K2>();

        synchronized (_map)
        {
            for (CacheMap<K2, CacheMap<K3, V>> entry : _map.values())
                keys.addAll(entry.keySet());
        }
        
        return keys;
    }
    
    /**
     * Get the set of K3 keys
     * 
     * @return
     */
    public Set<K3> getKeys3()
    {
        Set<K3> keys = new HashSet<K3>();

        synchronized (_map)
        {
            for (CacheMap<K2, CacheMap<K3, V>> entry1 : _map.values())
                for (CacheMap<K3, V> entry2 : entry1.values())
                    keys.addAll(entry2.keySet());
        }
        
        return keys;
    }
    
    /**
     * Get the collection of values in the tuple map
     * 
     * @return
     */
    public Collection<V> getValues()
    {
        List<V> values = new ArrayList<V>();
        
        synchronized(_map)
        {
            for (CacheMap<K2, CacheMap<K3, V>> entry1 : _map.values())
                for (CacheMap<K3, V> entry2 : entry1.values())
                    values.addAll(entry2.values());
        }
        
        return values;
    }
    
    /**
     * Get the value attached to the provided keys
     * 
     * @param k1
     * @param k2
     * @return
     */
    public V get(K1 k1, K2 k2, K3 k3)
    {
        CacheMap<K3, V> map3 = getMap3(k1, k2);

        synchronized (map3)
        {
            V value = map3.get(k3);
            if (value == null && _c != null)
            {
                try
                {
                    value = _c.getConstructor().newInstance();
                    map3.put(k3, value);
                }
                catch (Exception e)
                {
                }
            }
            return value;
        }
    }
    
    /**
     * Put the value assigned to the provided keys
     * 
     * @param k1
     * @param k2
     * @param k3
     * @param v
     */
    public void put(K1 k1, K2 k2, K3 k3, V v)
    {
    	getMap3(k1, k2).put(k3, v);
    }
    
    /**
     * Get the first level of the map
     * 
     * @return
     */
    private CacheMap<K1, CacheMap<K2, CacheMap<K3, V>>> getMap1()
    {
        return _map;
    }

    /**
     * Get the second level of the map
     * 
     * @param k1
     * @return
     */
    private CacheMap<K2, CacheMap<K3, V>> getMap2(K1 k1)
    {
    	CacheMap<K1, CacheMap<K2, CacheMap<K3, V>>> map1 = getMap1();
        synchronized (map1)
        {
        	CacheMap<K2, CacheMap<K3, V>> map2 = map1.get(k1);
            if (map2 == null)
            {
                map2 = new CacheMap<K2, CacheMap<K3, V>>(_n2);
                map1.put(k1, map2);
            }

            return map2;
        }
    }
    
    /**
     * Get the third level of the map
     * 
     * @param k1
     * @return
     */
    private CacheMap<K3, V> getMap3(K1 k1, K2 k2)
    {
        CacheMap<K2, CacheMap<K3, V>> map2 = getMap2(k1);
        synchronized (map2)
        {
        	CacheMap<K3, V> map3 = map2.get(k2);
            
            if (map3 == null)
            {
                map3 = new CacheMap<K3, V>(_n3);
                map2.put(k2, map3);
            }

            return map3;
        }
    }
}
