package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.detection.NetworkDetection;
import gov.sandia.gnem.netmod.detection.NetworkDetectionIndependent;
import gov.sandia.gnem.netmod.detection.NetworkDetectionMC;
import gov.sandia.gnem.netmod.detection.StationDetection;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.ParameterFolder;
import gov.sandia.gnem.netmod.io.NetSimParameters.RunType;
import gov.sandia.gnem.netmod.io.NetSimParameters.SimulTechnology;
import gov.sandia.gnem.netmod.io.NetSimParameters.WindMode;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.io.libpar.ParLoader;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.output.Outputs;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.media.PathMediaType;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.Plugin;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import gov.sandia.gnem.netmod.source.media.SourceMediaType;

import java.io.File;
import java.util.*;

abstract public class AbstractSimulation extends AbstractNetModComponent implements Simulation
{
    private String _projectFile = "";
    
    private Plugin<SimulationMethod> _simulationMethods;
    private Plugin<SimulationType> _simulationTypes;
    private Plugin<SignalAmplitude> _signalAmplitudes;
    private Plugin<NoiseAmplitude> _noiseAmplitudes;
    private Plugin<NetworkDetection> _networkDetections;

    private SimulationMethod _simulationMethod;
    private SimulationType _simulationType;
    private SignalAmplitude _signalAmplitude;
    private NoiseAmplitude _noiseAmplitude;
    private NetworkDetection _networkDetection;
    
    protected Sources _sources;
    protected Paths _paths;
    protected Receivers _receivers;
    private Outputs _output;
    
    private Time _simulationTime = new Time(0);
    
    transient private NetModComponentViewer<?> _viewer = null;
    
    /**
     * @param type Type identifier for the simulation
     * @param simulationTypes Plugin of available simulation types
     * @param signalAmplitudes Plugin of available signal amplitudes
     * @param noiseAmplitudes Plugin of available noise amplitudes
     * @param networkDetections Plugin of available network detections
     */
    protected AbstractSimulation(NetModComponent parent, String type, Plugin<SimulationMethod> simulationMethods, Plugin<SimulationType> simulationTypes, Plugin<SignalAmplitude> signalAmplitudes,
            Plugin<NoiseAmplitude> noiseAmplitudes, Plugin<NetworkDetection> networkDetections)
    {
        super(parent, type);
        
        //  Store the plugins
        _simulationMethods = simulationMethods;
        _simulationTypes = simulationTypes;
        _signalAmplitudes = signalAmplitudes;
        _noiseAmplitudes = noiseAmplitudes;
        _networkDetections = networkDetections;
        
        //  Load the plugin defaults
        _simulationMethod = getSimulationMethods().getDefaultComponent(this);
        _simulationType = getSimulationTypes().getDefaultComponent(this);
        _signalAmplitude = getSignalAmplitudes().getDefaultComponent(this);
        _noiseAmplitude = getNoiseAmplitudes().getDefaultComponent(this);
        _networkDetection = getNetworkDetections().getDefaultComponent(this);
        
        _output = new Outputs(this);

        _networkDetection.setPhases(getPhases());
    }
    
    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof SimulationType) || (component instanceof Sources) || (component instanceof Paths) || (component instanceof Receivers) ||
                (component instanceof SignalAmplitude) || (component instanceof NoiseAmplitude) || (component instanceof NetworkDetection) ||
                (component instanceof StationDetection) || (component instanceof Outputs);
    }
    
    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();

        if (_simulationMethod != null)
            children.add(_simulationMethod);
        if (_simulationType != null)
            children.add(_simulationType);
        if (_sources != null)
            children.add(_sources);
        if (_paths != null)
            children.add(_paths);
        if (_receivers != null)
            children.add(_receivers);
        if (_signalAmplitude != null)
            children.add(_signalAmplitude);
        if (_noiseAmplitude != null)
            children.add(_noiseAmplitude);
        if (_networkDetection != null)
            children.add(_networkDetection);
        if (_output != null)
            children.add(_output);

        return children;
    }

    /**
     * @return the networkDetection
     */
    @Override
    public NetworkDetection getNetworkDetection()
    {
        return _networkDetection;
    }

    /**
     * @return the networkDetections
     */
    public Plugin<NetworkDetection> getNetworkDetections()
    {
        return _networkDetections;
    }

    /**
     * @return the noiseAmplitude
     */
    @Override
    public NoiseAmplitude getNoiseAmplitude()
    {
        return _noiseAmplitude;
    }

    /**
     * @return the noiseAmplitudes
     */
    public Plugin<NoiseAmplitude> getNoiseAmplitudes()
    {
        return _noiseAmplitudes;
    }

    /**
     * @return the output
     */
    @Override
    public Outputs getOutputs()
    {
        return _output;
    }

    /**
     * @return the paths
     */
    @Override
    public Paths getPaths()
    {
        return _paths;
    }

    @Override
    public String getProjectFile()
    {
        return _projectFile;
    }

    /**
     * @return the receivers
     */
    @Override
    public Receivers getReceivers()
    {
        return _receivers;
    }

    /**
     * @return the signalAmplitude
     */
    @Override
    public SignalAmplitude getSignalAmplitude()
    {
        return _signalAmplitude;
    }

    /**
     * @return the signalAmplitudes
     */
    public Plugin<SignalAmplitude> getSignalAmplitudes()
    {
        return _signalAmplitudes;
    }

    /**
     * @return the simulationType
     */
    @Override
    public SimulationMethod getSimulationMethod()
    {
        return _simulationMethod;
    }

    /**
     * @return the simulationTypes
     */
    public Plugin<SimulationMethod> getSimulationMethods()
    {
        return _simulationMethods;
    }

    /**
     * @return the simulationTime
     */
    @Override
    public Time getSimulationTime()
    {
        return _simulationTime;
    }

    /**
     * @return the simulationType
     */
    @Override
    public SimulationType getSimulationType()
    {
        return _simulationType;
    }

    /**
     * @return the simulationTypes
     */
    public Plugin<SimulationType> getSimulationTypes()
    {
        return _simulationTypes;
    }
    
    /**
     * @return the sources
     */
    @Override
    public Sources getSources()
    {
        return _sources;
    }
    
    /**
     * Get the simulation technology
     * 
     * @return
     */
    abstract public String getTechnology();

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        if (_viewer == null)
            _viewer = new AbstractSimulationViewer(this);

        return _viewer;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        //  Verify that this is a detection simulation
        if (parameters.get(NetSimParameters.runType) != RunType.DETECTION)
            return;
        
        super.load(parameters);
        
        //  Set the name
        setName(parameters.get(NetSimParameters.title));

        //  Set the output directory
        String output = parameters.get(NetSimParameters.outputDir);
        if (output.isEmpty())
            output = IOUtility.openFile(parameters.getNS_CONFIG(), "output").getCanonicalPath();
        else
            output = IOUtility.openFile(IOUtility.fixPathSeparator(output)).getCanonicalPath();

        getOutputs().setOutputDir(output);
        
        //  Set the simulation type
        SimulationType st = getSimulationTypes().getComponent(this, parameters.get(NetSimParameters.subType).toString());
        st.load(parameters);
        setSimulationType(st);
        
        //  Set the time
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.set(GregorianCalendar.YEAR, 0);
        cal.set(GregorianCalendar.DAY_OF_YEAR, 1);
        if ( parameters.get(NetSimParameters.windDayOfYear) > 0 )
            cal.set(GregorianCalendar.DAY_OF_YEAR, parameters.get(NetSimParameters.windDayOfYear));
        cal.set(GregorianCalendar.HOUR_OF_DAY, 0);
        if ( parameters.get(NetSimParameters.windTimeOfDay) >= 0 )
            cal.set(GregorianCalendar.HOUR_OF_DAY, parameters.get(NetSimParameters.windTimeOfDay));
        cal.set(GregorianCalendar.MINUTE, 0);
        cal.set(GregorianCalendar.SECOND, 0);
        cal.set(GregorianCalendar.MILLISECOND, 0);
        setSimulationTime(new Time(cal));

        //  Load the sources
        getSources().load(parameters);

        //  Load the paths
        getPaths().load(parameters);

        //  Load the receivers
        getReceivers().load(parameters);

        //  Load the signal amplitude
        SignalAmplitude signal = getSignalAmplitudes().getComponent(this, parameters.get(SeismicDetectionParameters.signalAmplitude));
        signal.load(parameters);
        setSignalAmplitude(signal);

        //  Load the noise amplitude
        NoiseAmplitude noise = getNoiseAmplitudes().getComponent(this, parameters.get(SeismicDetectionParameters.noiseAmplitude));
        noise.load(parameters);
        setNoiseAmplitude(noise);

        //  Load the detection method
        int numMC = parameters.get(NetSimParameters.numMonteCarloIter);
        NetworkDetection detection = null;
        if (numMC > 1)
            detection = new NetworkDetectionMC(this);
        else
            detection = new NetworkDetectionIndependent(this);

        detection.load(parameters);
        setNetworkDetection(detection);
    }
    
    @Override
    public Output run()
    {
        //  Re-initialize the introspection
        recordIntrospection("Detection Simulation");

        //  Clear cache to force re-computation
        clearCache();

        //  Get the method of simulation
        final SimulationMethod simulationMethod = getSimulationMethod();

        //  Get the sources
        Sources sources = getSources();

        //  Get the paths
        Paths paths = getPaths();

        //  Get the receivers
        Receivers receivers = getReceivers();

        //  Get the Network Detection routine
        NetworkDetection networkDetection = getNetworkDetection();
        networkDetection.setPhases(getPhases());

        //  Get the set of epicenters
        final EpicenterGrid epicenters = sources.getEpicenterGrid();
        final int N = epicenters.size();

        //  Setup an output object
        Outputs outputs = getOutputs();
        final Output output = new Output(outputs, N);

        //  Add all the stations that were used
        double reliability = getReceivers().getDefaultReliability();
        for (Station station : receivers.getSelectedStations())
            output.setStation(station, reliability);

        //  Add the control parameters that were used
        NetSimParameters parameters = new NetSimParameters();
        parameters.setNS_CONFIG("");
        try
        {
            save(parameters, false, false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        output.setSimulKeyValues(parameters);
        
        //  Setup a progress Dialog
        final ProgressDialog pd = ProgressDialog.initProgressDialog(NetMOD.getFrame(), "Running " + toString());
        pd.setMainIndeterminate(false);
        pd.setSubIndeterminate(false);
        pd.setMainValues(0, N, 0);
        
        //  Start a thread to update the output
        String outputType = Property.OUTPUT_FORMAT.getValue();
        SimulationOutput simulationOutput = SimulationOutputPlugin.getPlugin().getComponent(this, outputType);
        if ( simulationOutput != null )
        	simulationOutput.start(pd, output, epicenters);

        //  Manage multi-threading
        ThreadExecuter executer = new ThreadExecuter();

        //  Maintain a set of the source media types and path media types
        //  for determining when to run single-threaded
        Set<SourceMediaType> sourceMediaTypes = new HashSet<SourceMediaType>();
        Set<PathMediaType> pathMediaTypes = new HashSet<PathMediaType>();

        //  Run the simulation for each of the source epicenters
        for (int i = 0; i < N; i++)
        {
            final int index = i;
            Point.Double location = epicenters.get(i);
            SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(location);
            PathMediaType pathMediaType = paths.getPathMedia().getMediaType(location);

            Thread thread = new Thread()
            {
                @Override
                public void run()
                {
                    if (pd.isCanceled())
                        return;
                    
                    //  Perform the desired simulation method, storing the results in the output
                    simulationMethod.run(AbstractSimulation.this, output, index);
                }
            };

            //  Single threaded when introspection enabled or a previously unused
            //  source or path media type
            if (isIntrospection() || !sourceMediaTypes.contains(sourceMediaType) || !pathMediaTypes.contains(pathMediaType))
            {
                thread.run();

                sourceMediaTypes.add(sourceMediaType);
                pathMediaTypes.add(pathMediaType);
            }
            else
                executer.execute(thread);

            if (pd.isCanceled())
                break;
        }

        //  Remove all threads awaiting completion
        if (pd.isCanceled())
            executer.stop();

        //  Wait for all threads to complete
        executer.join();
        
        //  Wait for the results to be recorded
        if ( simulationOutput != null )
        	simulationOutput.join();

        if (pd.isCanceled())
            return null;

        //  Generate the output file name
        String outputFileName = output.generateOutputName(parameters);
        
        File outputFile = IOUtility.openFile(outputs.getOutputDir(), outputFileName);
        output.setOutputFile(outputFile.getPath());

        //  Write the output to disk
        output.save();
        
        //  Add the output
        outputs.add(output);

        return output;
    }

	@Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(NetSimParameters.title, getName());
        parameters.set(NetSimParameters.simulTechnology, SimulTechnology.valueOf(getTechnology()));

        if (reset)
        {
            File outputFile = IOUtility.openFile(parameters.getNS_CONFIG(), "output");
            outputFile.mkdirs();
            getOutputs().setOutputDir(IOUtility.fixPathSeparator(outputFile.getPath()));
        }

        parameters.set(NetSimParameters.outputDir, IOUtility.fixPathSeparator(getOutputs().getOutputDir()));
        parameters.set(NetSimParameters.runType, RunType.DETECTION);

        //  Set a bunch of defaults for things that aren't used
        parameters.set(NetSimParameters.depthFixed, Boolean.FALSE);
        parameters.set(NetSimParameters.numMonteCarloIter, 1);
        parameters.set(NetSimParameters.noiseModel, "-");
        parameters.set(NetSimParameters.listOfStations, "-");
        parameters.set(NetSimParameters.net, "-");
        parameters.set(NetSimParameters.pctLo, 0.5);
        parameters.set(NetSimParameters.pctHi, 0.9);
        parameters.set(NetSimParameters.simulBaseline, getName());
        parameters.set(NetSimParameters.verboseLevel, 0);
        parameters.set(NetSimParameters.windMode, WindMode.NONE);
        parameters.set(NetSimParameters.windDayOfYear, -1);
        parameters.set(NetSimParameters.windTimeOfDay, -1);

        parameters.set(NetSimParameters.forceLinearPlot, Boolean.FALSE);
        parameters.set(NetSimParameters.forceLogPlot, Boolean.FALSE);
        parameters.set(NetSimParameters.fixedScaleMin, 0.0);
        parameters.set(NetSimParameters.fixedScaleMax, 1.0);
        parameters.set(NetSimParameters.fixedDiffScaleMin, 0.0);
        parameters.set(NetSimParameters.fixedDiffScaleMax, 0.0);
        parameters.set(NetSimParameters.reverseColorOrder, Boolean.FALSE);
        parameters.set(NetSimParameters.globalCenterLon, 0.0);

        //  Store the simulation type
        getSimulationType().save(parameters, files, reset);
        
        //  Store the simulation time
        Calendar cal = getSimulationTime().getCalendar();

        parameters.set(NetSimParameters.windDayOfYear, cal.get(GregorianCalendar.DAY_OF_YEAR));
        parameters.set(NetSimParameters.windTimeOfDay, cal.get(GregorianCalendar.HOUR_OF_DAY));

        //  Store the Sources
        getSources().save(parameters, files, reset);

        //  Store the Paths
        getPaths().save(parameters, files, reset);

        //  Store the Receivers
        getReceivers().save(parameters, files, reset);

        //  Store the signal amplitude
        getSignalAmplitude().save(parameters, files, reset);

        //  Store the noise amplitude
        getNoiseAmplitude().save(parameters, files, reset);

        //  Store the detection method
        getNetworkDetection().save(parameters, files, reset);
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof SimulationType)
                setSimulationType((SimulationType) child);
            else if (child instanceof SignalAmplitude)
                setSignalAmplitude((SignalAmplitude) child);
            else if (child instanceof NoiseAmplitude)
                setNoiseAmplitude((NoiseAmplitude) child);
            else if (child instanceof NetworkDetection)
                setNetworkDetection((NetworkDetection) child);
        }

        clearCache();
    }

    /**
     * @param networkDetection the networkDetection to set
     */
    public void setNetworkDetection(NetworkDetection networkDetection)
    {
        _networkDetection = networkDetection;
        _networkDetection.setPhases(getPhases());
    }

    /**
     * @param noiseAmplitude the noiseAmplitude to set
     */
    public void setNoiseAmplitude(NoiseAmplitude noiseAmplitude)
    {
        _noiseAmplitude = noiseAmplitude;
    }

    @Override
    public void setProjectFile(String file)
    {
        _projectFile = file;
    }

    /**
     * @param signalAmplitude the signalAmplitude to set
     */
    public void setSignalAmplitude(SignalAmplitude signalAmplitude)
    {
        _signalAmplitude = signalAmplitude;
    }

	public void setSimulationMethod(SimulationMethod simulationMethod)
    {
		_simulationMethod = simulationMethod;
    }

    /**
     * @param simulationTime the simulationTime to set
     */
    public void setSimulationTime(Time simulationTime)
    {
        _simulationTime = simulationTime;
    }

    /**
     * @param simulationType the simulationType to set
     */
    public void setSimulationType(SimulationType simulationType)
    {
        _simulationType = simulationType;
    }

    /**
     * Write the simulation parameters to the provided file
     * 
     * @param file
     * @param resetFiles
     */
    public void write(File file, boolean resetFiles)
    {
        setProjectFile(file.getPath());

        //  Save the netsim style parameters
        NetSimParameters nsp = new NetSimParameters();
        nsp.setNS_CONFIG(IOUtility.fixPathSeparator(file.getParent()));

        try
        {
            save(nsp, true, resetFiles);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        //  Store the general parameters into a LibPar container
        LibParParameters generalParameters = new LibParParameters();
        nsp.write(ParameterFolder.GENERAL, generalParameters);

        //  Store the parameters that are designated for sub-par files
        for (ParameterFolder folder : NetSimParameters.ParameterFolder.values())
        {
            if ( folder == ParameterFolder.GENERAL )
                continue;
            
            File folderPath = IOUtility.openFile(file.getParent(), folder.getFolder());
            folderPath.mkdirs();
            
            File folderFile = IOUtility.openFile(folderPath, folder.getParfile());
            
            LibParParameters folderParameters = new LibParParameters();
            nsp.write(folder, folderParameters);
            
            //  Scan for any parameters that need a "NS_CONFIG" prefix
            folderParameters.replace(nsp.getNS_CONFIG(), "$(NS_CONFIG)");
            
            //  Write out the parameters
            ParLoader.save(folderFile, folderParameters);
            
            //  Reference this sub-par file
            generalParameters.addParameterFile(IOUtility.fixPathSeparator(folderFile.getPath()));
        }

        //  Scan for any parameters that need a "NS_CONFIG" prefix
        generalParameters.replace(nsp.getNS_CONFIG(), "$(NS_CONFIG)");

        //  Write out the parameters
        ParLoader.save(file, generalParameters);
    }
    

    /**
     * Get the NetSimParameters for the provided object
     * 
     * @param o
     * @return
     */
    protected NetSimParameters getNSP(Object o)
    {
        //  Determine the object type
        NetSimParameters nsp = null;
        try
        {
            if (o instanceof String)
                o = IOUtility.openFile((String) o);

            if (o instanceof File)
            {
                File file = (File) o;
                LibParParameters parameters = new LibParParameters();
                parameters.set("NS_CONFIG", file.getParent());
                parameters = ParLoader.load(file, parameters);

                o = parameters;
            }

            if (o instanceof LibParParameters)
            {
                SeismicDetectionParameters sdp = new SeismicDetectionParameters();
                sdp.read((LibParParameters) o);

                o = sdp;
            }

            if (o instanceof NetSimParameters)
                nsp = (NetSimParameters) o;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return nsp;
    }


}
