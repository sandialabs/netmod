package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.path.wind.WindModelPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Simulation;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Map;
import java.util.WeakHashMap;

public class JG2S extends AbstractNetModFile implements WindModel
{

	private static final String _type = "Ground to Space (G2S)";

	// Register the plugin
	static
	{
		WindModelPlugin.getPlugin().registerComponent(_type, JG2S.class);
	}

	private Map<Thread, G2S> _threadMap = new WeakHashMap<Thread, G2S>();

	private G2SDB _g2sdb;
	private String _windModelFile = getFilename();

	public JG2S(NetModComponent parent)
	{
		super(parent, _type);
	}

	public Layer<?> getMapLayer()
	{
		if (NetMOD.getMap() == null)
		{
			return null;
		}
		return NetMOD.getMap().createWindModelLayer(this);
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		return new JG2SViewer(this);
	}

	public G2SDB readG2SFile()
	{
		synchronized (this)
		{
			if (_g2sdb == null)
				read();
		}
		return _g2sdb;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		// Check if the file exists
		if (file == null || !file.exists())
			return false;

		return IOUtility.endsWith(file, ".bin");
	}

	@Override
	public Complex getWindVelocity(Time time, double altitude, Point.Double location)
	{
		Calendar cal = time.getCalendar();

		double[] w = new double[2];

		// Construct the wind model inside the call so that it is thread safe
		G2S windModel;
		synchronized (this)
		{
			windModel = _threadMap.get(Thread.currentThread());
			if (windModel == null)
			{
				windModel = new G2S();
				_threadMap.put(Thread.currentThread(), windModel);
			}
			try
			{
				G2SDB db = readG2SFile();
				windModel.simulation(db, location.getLatitude(), location.getLongitude(), w);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		System.out.println(new Complex(w[0], w[1]));
		return new Complex(w[0], w[1]);
	}

	@Override
	public Complex getWindVelocity(double altitude, Point.Double location)
	{
		Time time = new Time(0);

		// Get the simulation time (Simulation -> Path -> JWHM)
		NetModComponent parent = getParent();
		if (parent instanceof Paths)
		{
			NetModComponent grandparent = parent.getParent();
			if (grandparent instanceof Simulation)
			{
				time = ((Simulation) grandparent).getSimulationTime();
			}
		}

		return getWindVelocity(time, altitude, location);
	}

	@Override
	public boolean isAvailable()
	{
		return !getFilename().isEmpty();
	}

	@Override
	public boolean read()
	{
		boolean value = false;

		synchronized (_type)
		{
			try
			{
				_g2sdb = LoadFile.loadfile(getWindModelFile());
				System.out.println("Calling Read....");
				value = true;
				setDirty(false);
			}
			catch (Exception e)
			{
				if (getWindModelFile().isEmpty())
				{
					System.out.println("No G2S wind model file found.");
					e.printStackTrace();
				}
				else if (!getWindModelFile().isEmpty())
				{
					System.out.println("Unable to read G2S wind model file: '" + getFilename() + "'");
					e.printStackTrace();
				}
			}
		}
		return true;
	}

	@Override
	public boolean write()
	{
		// Get the File to write to
		File file = IOUtility.openFile(getFilename());

		// Don't write if not needed
		if (!getDirty() && file.exists())
			return true;

		// Test whether there is no file to write to
		if (isEmpty(file.getPath()))
			return true;

		PrintWriter fout = null;
		boolean value = true;
		try
		{

			// Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));
			fout.println(getName());

			fout.println(_g2sdb.toString());

			setDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			value = false;
		}
		finally
		{
			if (fout != null)
				IOUtility.safeClose(fout);
		}

		return value;
	}

	public String getWindModelFile()
	{
		return _windModelFile;
	}

	public void setWindModelFile(String windModelFile)
	{

		if (_windModelFile.equals(windModelFile))
		{
			return;
		}

		// If file exists, load it
		if (IOUtility.openFile(windModelFile).exists())
		{
			_windModelFile = windModelFile;
		}
	}

	@Override
	public void load(NetSimParameters parameters) throws Exception
	{
		super.load(parameters);

		setWindModelFile(parameters.get(NetSimParameters.windModelFile));
	}

	@Override
	public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
	{
		super.save(parameters, files, reset);

		parameters.set(NetSimParameters.windModelFile, getWindModelFile());
	}

}
