package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

class EtmodDB {

  /* GLOBE7 */
  double xl = 1000.;
 double tll = 1000.;
 double dayl = -1;
 double p13 = -1000.;
 double p17 = -1000.;
 double p31 = -1000.;
 double p38 = -1000.;
 double[][] plg = new double[4][9];
 double ctloc, stloc;
 double c2tloc, s2tloc;
 double s3tloc, c3tloc;
 double apdf;
 double dfa;


  /* PARMB */
  double gsurf;
 double re;


  /* GTS */
  double dd;
 double tz = 0;
 double tz_gts = 0;
 double alast = 99999.;
 double mssl = -999;
 double tinf = 0;
 double g0 = 0;
 double zhm28;
 double b28;

  /* GTD7 */
  double ds[] = new double[9];
 double ts[] = new double[9];
 double[] tn1 = new double[5];
 double[] tn2 = new double[4];
 double[] tn3 = new double[5];
 double[] tgn1 = new double[2];
 double[] tgn2 = new double[2];
 double[] tgn3 = new double[2];

  /* MSISHWM */
  double[] d = new double[9];
 double[] t = new double[2];

  /* DMIX */
  double dm04, dm16, dm28, dm32, dm40, dm01, dm14, dm28m;


 double[] apt = new double[4];

  //  //******VTST7********
  int[] iydl = new int[]{-999, -999};
 double[] secl = new double[]{-999.0f, -999.0f};
 double[] glatl = new double[]{-999.0f, -999.0f};
 double[] gll = new double[]{-999.0f, -999.0f};
 double[] stll = new double[]{-999.0f, -999.0f};
 double[] fal = new double[]{-999.0f, -999.0f};
 double[] fl = new double[]{-999.0f, -999.0f};
 double[][] apl = new double[2][7];
 double[][] swl = new double[2][25];
 double[][] swcl = new double[2][25];

}

