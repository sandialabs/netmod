/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.epicenter;

import gov.sandia.gnem.netmod.gui.DoubleRangeFormatter;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import java.awt.*;

/**
 * @author bjmerch
 *
 */
public class EpicenterGridViewer extends NetModComponentViewer<EpicenterGrid>
{
    private JTextField _name = new JTextField();
    private JCheckBox _regular = new JCheckBox("Regular Grid");

    private JFormattedTextField _latMin = new JFormattedTextField(new DoubleRangeFormatter(-90, 90));
    private JFormattedTextField _latMax = new JFormattedTextField(new DoubleRangeFormatter(-90, 90));
    private JFormattedTextField _latDelta = new JFormattedTextField(new DoubleRangeFormatter(0, 180));

    private JFormattedTextField _lonMin = new JFormattedTextField(new DoubleRangeFormatter(-180, 180));
    private JFormattedTextField _lonMax = new JFormattedTextField(new DoubleRangeFormatter(-180, 180));
    private JFormattedTextField _lonDelta = new JFormattedTextField(new DoubleRangeFormatter(0, 360));

    private JFormattedTextField _elevation = new JFormattedTextField(new DoubleRangeFormatter(-1000, Double.MAX_VALUE));

    public EpicenterGridViewer(EpicenterGrid nmc)
    {
        super(nmc, true, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored
        registerControls(_regular, _latMin, _latMax, _latDelta, _lonMin, _lonMax, _lonDelta, _elevation);
    }

    @Override
    public void apply(EpicenterGrid nmc)
    {
        nmc.setName(_name.getText());
        nmc.setRegular(_regular.isSelected());
        nmc.setLatitude(((Number) _latMin.getValue()).doubleValue(), ((Number) _latMax.getValue()).doubleValue(), ((Number) _latDelta.getValue()).doubleValue());
        nmc.setLongitude(((Number) _lonMin.getValue()).doubleValue(), ((Number) _lonMax.getValue()).doubleValue(),
                ((Number) _lonDelta.getValue()).doubleValue());
        nmc.setElevation((Double) _elevation.getValue());
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Set the tooltips
            _regular.setToolTipText("Selected whether the grid points are regularly or evenly spaced");
            _latMin.setToolTipText("First latitude point in degrees");
            _latMax.setToolTipText("Last latitude point in degrees");
            _latDelta.setToolTipText("Latitude spacing in degrees");
            _lonMin.setToolTipText("First longitude point in degrees");
            _lonMax.setToolTipText("Last longitude point in degrees");
            _lonDelta.setToolTipText("Longitude spacing in degrees");
            _elevation.setToolTipText("Elevation of source in meters");

            //  Organize the lat/lon panels
            JPanel epicenterPanel = new JPanel(new GridBagLayout());
            GUIUtility.addRow(epicenterPanel, new JLabel(""), new JLabel("Min"), new JLabel("Max"), new JLabel("Delta"));
            GUIUtility.addRow(epicenterPanel, new JLabel("Latitude: "), _latMin, _latMax, _latDelta);
            GUIUtility.addRow(epicenterPanel, new JLabel("Longitude: "), _lonMin, _lonMax, _lonDelta);
            GUIUtility.addRow(epicenterPanel, new JLabel("Elevation: "), _elevation);

            GUIUtility.addRow(panel, new JLabel("Name:"), _name);
            GUIUtility.addRow(panel, _regular);
            GUIUtility.addRow(panel, epicenterPanel);
            
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(EpicenterGrid nmc)
    {
        _name.setText(nmc.getName());
        _regular.setSelected(nmc.getRegular());

        _latMin.setValue(nmc.getLatitudeStart());
        _latMax.setValue(nmc.getLatitudeEnd());
        _latDelta.setValue(nmc.getLatitudeDelta());

        _lonMin.setValue(nmc.getLongitudeStart());
        _lonMax.setValue(nmc.getLongitudeEnd());
        _lonDelta.setValue(nmc.getLongitudeDelta());

        _elevation.setValue(nmc.getElevation());
    }
}
