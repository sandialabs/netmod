/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.NumericUtility;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.util.Arrays;
import java.util.Scanner;

/**
 * NetModComponent that refers to a file on disk
 * 
 * @author bjmerch
 *
 */
abstract public class AbstractNetModFile extends AbstractNetModComponent implements NetModFile
{

    /**
     * Find the index of the first value greater than or equal to the provided value
     * 
     * @param values
     * @param value
     * @return
     */
    static public int findIndex(double[] values, double value)
    {
        if ( values == null || values.length == 0 )
            return 0;
        
        int N = values.length;
        
        for (int i=0; i<N; i++)
            if ( value <= values[i] )
                return i;
        
        return N;
    }
    
    /**
     * Return a copy of the provided array with the value at index inserted
     * 
     * @param values
     * @param index
     * @param new_value
     * @return
     */
    static public double[] insertIndex(double[] values, int index, double new_value)
    {
        if ( values == null || index < 0 )
            return values;
        
        //  Create a new array
        int N = values.length;
        double[] new_values = new double[Math.max(index+1, N+1)];
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Insert at index
        new_values[index] = new_value;
        
        //  Copy after index
        if ( index < N )
            System.arraycopy(values, index, new_values, index+1, N-index);
        
        return new_values;
    }
    
    /**
     * Return a copy of the provided array with the value at index inserted
     * 
     * @param values
     * @param index
     * @param new_value
     * @return
     */
    static public <O extends Object> O[] insertIndex(O[] values, int index, O new_value)
    {
        if ( values == null || index < 0 )
            return values;
        
        //  Create a new array
        int N = values.length;
        O[] new_values = Arrays.copyOf(values, Math.max(index+1, N+1));
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Insert at index
        new_values[index] = new_value;
        
        //  Copy after index
        if ( index < N )
            System.arraycopy(values, index, new_values, index+1, N-index);
        
        return new_values;
    }
    
    /**
     * Return a copy of the provided array with the value at index inserted
     * 
     * @param values
     * @param index
     * @param new_value
     * @return
     */
    static public double[][] insertIndex(double[][] values, int index, double[] new_value)
    {
        if ( values == null || index < 0 )
            return values;
        
        //  Create a new array
        int N = values.length;
        double[][] new_values = new double[N+1][];
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Insert at index
        new_values[index] = new_value;
        
        //  Copy after index
        if ( index < N )
            System.arraycopy(values, index, new_values, index+1, N-index);
        
        return new_values;
    }
    
    /**
     * Return a copy of the provided array with index removed
     * 
     * @param values
     * @param index
     * @return
     */
    static public double[] removeIndex(double[] values, int index)
    {
        if ( values == null || index < 0 || index >= values.length )
            return values;
        
        //  Create a new array
        int N = values.length;
        double[] new_values = new double[N-1];
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Copy after index
        if ( index < N-1 )
            System.arraycopy(values, index+1, new_values, index, N-1-index);
        
        return new_values;
    }
    
    /**
     * Return a copy of the provided array with index removed
     * 
     * @param values
     * @param index
     * @return
     */
    static public <O extends Object> O[] removeIndex(O[] values, int index)
    {
        if ( values == null || index < 0 || index >= values.length )
            return values;
        
        //  Create a new array
        int N = values.length;
        O[] new_values = Arrays.copyOf(values, N-1);
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Copy after index
        if ( index < N-1 )
            System.arraycopy(values, index+1, new_values, index, N-1-index);
        
        return new_values;
    }
    
    /**
     * @param values
     * @param index
     * @return
     */
    static public double[][] removeIndex(double[][] values, int index)
    {
        if ( values == null || index < 0 || index >= values.length )
            return values;
        
        //  Create a new array
        int N = values.length;
        double[][] new_values = new double[N-1][];
        
        //  Copy prior to index
        if ( index > 0 )
            System.arraycopy(values, 0, new_values, 0, index);
        
        //  Copy after index
        if ( index < N-1 )
            System.arraycopy(values, index+1, new_values, index, N-1-index);
        
        return new_values;
    }
    
    /**
     * Check if the file is an empty reference
     * 
     * @param file
     * @return
     */
    protected static boolean isEmpty(String file)
    {
        return file == null || file.isEmpty() || file.endsWith("-");
    }
    
    private String _filename = "";

    private boolean _dirty = false;

    protected AbstractNetModFile(NetModComponent parent, String type)
    {
        super(parent, type);
    }
    
    /**
     * Check whether the contents of the file are dirty
     * (modified from the original)
     * 
     * @return
     */
    public boolean getDirty()
    {
        return _dirty;
    }
    
    public String getFilename()
    {
        return _filename;
    }
    
    /**
     * Get the frequencies to be evaluated from the requested frequency and
     * the available frequencies.
     * 
     * @param frequency  requested frequency (or range)
     * @param frequencies available frequencies defined in the model
     * @return
     */
    public static double[] getEvaluationFrequencies(Frequency frequency, double[] frequencies)
    {
        double f_min = frequency.getMinimumFrequency();
        double f_max = frequency.getMaximumFrequency();
        
        //  Check if the requested frequency exceeds the available frequencies
        if ( f_min > frequencies[frequencies.length-1] || f_max < frequencies[0])
            return new double[0];
        
        //  Otherwise, return the sample frequencies
        return frequency.getFrequencySamples();
    }
    
    /**
     * Skip any comments
     * 
     * @param scanner
     */
    protected static void skipComments(Scanner scanner)
    {
        while (scanner.hasNext("#"))
        	scanner.nextLine();
    }
    
	/**
	 * Skip blank lines and return the next non-blank line
	 * 
	 * @param scanner
	 * @return
	 */
	protected static String skipBlanks(Scanner scanner)
	{
		String line = "";
		while (line.isEmpty() || line.equals(" "))
		{
			line = scanner.nextLine();
		}
		return line;
	}
    
	/**
	 * Skip blank lines and comments and return the next non-blank line
	 * 
	 * @param scanner
	 * @return
	 */
	protected static String skipBlanksComments(Scanner scanner)
	{
		String line = "";
		while (line.isEmpty() || line.trim().isEmpty() || line.startsWith("#"))
			line = scanner.nextLine();

		return line;
	}
    
    @Override
    public boolean isLeaf()
    {
        return true;
    }
    
    /**
     * Determine if the file is available (exists on disk and
     * proper format)
     * 
     * @return
     */
    abstract public boolean isAvailable();

    /**
     * Read the file contents .
     * Return true if read successfully, false otherwise.
     * @return
     */
    abstract public boolean read();
    
    /**
     * Set whether the contents of the file are dirty
     * (modified from the original)
     * 
     * @param dirty
     */
    public void setDirty(boolean dirty)
    {
        _dirty = dirty;
    }

    public void setFilename(String filename)
    {
        _filename = IOUtility.fixPathSeparator(filename);
    }
    
    /**
     * Write the file contents.
     * Return true if written successfully, false otherwise.
     * 
     * @return
     */
    abstract public boolean write();
}
