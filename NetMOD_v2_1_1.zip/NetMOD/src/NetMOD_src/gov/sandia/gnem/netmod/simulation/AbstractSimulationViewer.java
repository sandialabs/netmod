/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.simulation;

import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.swing.*;

import gov.sandia.gnem.netmod.detection.NetworkDetection;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComboBox;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.introspection.Introspection;
import gov.sandia.gnem.netmod.introspection.IntrospectionViewer;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.output.OutputViewer;
import gov.sandia.gnem.netmod.output.Outputs;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.project.Project;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;

/**
 * @author bjmerch
 */
public class AbstractSimulationViewer extends NetModComponentViewer<AbstractSimulation>
{
	private JTextField _name = new JTextField();
	private NetModComboBox<SimulationMethod> _simulationMethod;
	private NetModComboBox<SimulationType> _simulationType;
	private NetModComboBox<SignalAmplitude> _signalAmplitude;
	private NetModComboBox<NoiseAmplitude> _noiseAmplitude;
	private NetModComboBox<NetworkDetection> _networkDetection;

	private String[] months = new java.text.DateFormatSymbols().getMonths();

	private String[] hours = { "0:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "8:00", "9:00", "10:00",
			"11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00",
			"23:00" };
	private Integer[] days = new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
			22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };
	private Integer[] years = new Integer[] { 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981,
			1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999,
			2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017,
			2018, 2019, 2020 };

	private JComboBox _month = new JComboBox(months);
	private JComboBox _day = new JComboBox(days);
	private JComboBox _hour = new JComboBox(hours);
	private JComboBox _year = new JComboBox(years);

	/**
	 * @param nmc
	 */
	public AbstractSimulationViewer(AbstractSimulation nmc)
	{
		super(nmc, true, true);

		_simulationMethod = new NetModComboBox<SimulationMethod>(nmc.getSimulationMethods().getComponents(nmc));
		_simulationType = new NetModComboBox<SimulationType>(nmc.getSimulationTypes().getComponents(nmc));
		_signalAmplitude = new NetModComboBox<SignalAmplitude>(nmc.getSignalAmplitudes().getComponents(nmc));
		_noiseAmplitude = new NetModComboBox<NoiseAmplitude>(nmc.getNoiseAmplitudes().getComponents(nmc));
		_networkDetection = new NetModComboBox<NetworkDetection>(nmc.getNetworkDetections().getComponents(nmc));

		_month.setToolTipText("Month");
		_day.setToolTipText("Day of month");
		_hour.setToolTipText("Hour");
		_year.setToolTipText("Year");

		addNetModPostControl(new JLabel("-  " + nmc.getTechnology().toLowerCase()));
		addNetModPostControl(createSaveButton());
		addNetModPostControl(createRunSimulationButton());
		addNetModPostControl(createIntrospectionButton());
		addNetModPostControl(createRemoveSimulationButton());

		// Register the controls that are monitored after updating
		registerControls(_name, _simulationType, _networkDetection, _signalAmplitude, _noiseAmplitude, _month, _day,
				_hour, _year);
	}

	private JButton createRunSimulationButton()
	{
		JButton button = GUIUtility.createButton(Icons.RUN.getIcon());
		button.setToolTipText("Run simulation");

		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				runSimulation(false);
			}
		});

		return button;
	}

	private void runSimulation(final boolean enableIntrospection)
	{
		if (enableIntrospection)
		{
			// Turn on introspection
			Introspection introspection = new Introspection();

			// Ensure all objects share the introspection object
			_nmc.setIntrospection(introspection);

			// Display the introspection object
			IntrospectionViewer viewer = new IntrospectionViewer(introspection);
			viewer.setLocationRelativeTo(null);
			viewer.setVisible(true);
		}

		new SwingWorker<Output, Void>()
		{
			@Override
			protected Output doInBackground() throws Exception
			{
				return _nmc.run();
			}

			@Override
			protected void done()
			{
				// Display any exceptions thrown by background thread.
				Output output = null;
				try
				{
					output = get();
				}
				catch (Exception e)
				{
					GUIUtility.showExceptionDialog(null, "Error computing test results", e.getMessage(), e);
				}

				// Refresh the introspection
				if (enableIntrospection)
				{
					Introspection introspection = _nmc.getIntrospection();
					if (introspection != null)
						introspection.getRoot().fireUpdate();
				}

				// Disable introspection
				_nmc.setIntrospection(null);

				refresh();
				ProgressDialog.getProgressDialog().close();

				if (output == null)
					return;

				// Get the output
				Outputs outputs = _nmc.getOutputs();
				if (outputs.getOutputs().size() > 0)
				{
					// Expand the simulation Viewer
					setExpanded(true);

					// Expand the outputs viewer
					outputs.getViewer().setExpanded(true);

					// Display the output on the map
					OutputViewer outputViewer = (OutputViewer) output.getViewer();
					outputViewer.setExpanded(true);
					outputViewer.displayMap();
				}
			}
		}.execute();

	}

	private JButton createIntrospectionButton()
	{
		JButton button = GUIUtility.createButton(Icons.INTROSPECTION.getIcon());
		button.setToolTipText("Run simulation with Introspection enabled");

		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				runSimulation(true);
			}
		});

		return button;
	}

	private JButton createSaveButton()
	{
		JButton button = GUIUtility.createButton(Icons.SAVE.getIcon());
		button.setToolTipText("Save simulation");

		button.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				JCheckBox fileReset = new JCheckBox("Export files");
				fileReset.setToolTipText("Export referenced files to the new location");

				File file = GUIUtility.showSaveDialog(NetMOD.getFrame(), "", "Open simulation project file",
						JFileChooser.FILES_ONLY, null, fileReset);
				if (file == null)
					return;

				// Write the simulation
				_nmc.write(file, fileReset.isSelected());
			}
		});

		return button;
	}

	private JButton createRemoveSimulationButton()
	{
		JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
		button.setToolTipText("Remove simulation");

		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				// Get the simulation to remove
				int result = JOptionPane.showConfirmDialog(NetMOD.getFrame(), "Remove Simulation: " + _nmc,
						"Remove Simulation", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

				if (result != JOptionPane.YES_OPTION)
					return;

				Project project = (Project) _nmc.getParent();

				// Remove the simulation from the project
				project.remove(_nmc);

				// De-select anything on the map
				GUIUtility.deselectToggleButtons(_nmc.getViewer());

				// Update the display
				project.getViewer().refresh();
			}
		});

		return button;
	}

	@Override
	public void apply(AbstractSimulation nmc)
	{
		nmc.setName(_name.getText());
		nmc.setSimulationMethod(_simulationMethod.getSelectedItem());
		nmc.setSimulationType(_simulationType.getSelectedItem());
		nmc.setSignalAmplitude(_signalAmplitude.getSelectedItem());
		nmc.setNoiseAmplitude(_noiseAmplitude.getSelectedItem());

		// Set the time
		Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		cal.setTimeInMillis(0);
		cal.set(GregorianCalendar.MONTH, _month.getSelectedIndex());
		cal.set(GregorianCalendar.DAY_OF_MONTH, Integer.parseInt(_day.getSelectedItem().toString()));
		cal.set(GregorianCalendar.YEAR, Integer.parseInt(_year.getSelectedItem().toString()));
		cal.set(GregorianCalendar.HOUR_OF_DAY, _hour.getSelectedIndex());
		nmc.setSimulationTime(new Time(cal));

		// Transfer settings between the network detection types
		NetworkDetection old_nd = nmc.getNetworkDetection();
		NetworkDetection new_nd = (NetworkDetection) _networkDetection.getSelectedItem();
		if (old_nd != new_nd)
		{
			new_nd.getDetectionRules().clear();
			new_nd.getDetectionRules().putAll(old_nd.getDetectionRules());
			new_nd.setDetectionRule(old_nd.getDetectionRule());

			new_nd.getStationDetection().setFrequencies(old_nd.getStationDetection().getFrequencies());
			new_nd.getStationDetection().setFrequencyType(old_nd.getStationDetection().getFrequencyType());

			nmc.setNetworkDetection(new_nd);

			// Refresh the selected display
			_networkDetection.refresh();
		}
	}

	@Override
	public JPanel getExpandedPanel()
	{
		if (_expandedPanel == null)
		{
			JPanel panel = new JPanel(new GridBagLayout());

			// Create a generic NetModComponentViewer to allow general parameters to be
			// expanded/collapsed
			GUIUtility.addRow(panel, new NetModComponentViewer(new AbstractNetModComponent(_nmc, "General")
			{
			}, true, true)
			{
				{
					setExpanded(true);
				}

				@Override
				public JPanel getExpandedPanel()
				{
					if (_expandedPanel == null)
					{
						JPanel panel = new JPanel(new GridBagLayout());

						// Override month/day/hour preferred size to keep their widths from changing
						// dynamically
//                        Dimension d = new Dimension(15, _month.getPreferredSize().height);
//                        _month.setPreferredSize(d);
//                        _day.setPreferredSize(d);
//                        _hour.setPreferredSize(d);
//                        _year.setPreferredSize(d);k

						// Setup the panel
						GUIUtility.addRow(panel, new JLabel("Name: "), _name);
						GUIUtility.addRow(panel, new JLabel("Simulation Method: "), _simulationMethod);
						GUIUtility.addRow(panel, new JLabel("Simulation Type: "), _simulationType);
						GUIUtility.addRow(panel, new JLabel("Signal Amplitude: "), _signalAmplitude);
						GUIUtility.addRow(panel, new JLabel("Noise Amplitude: "), _noiseAmplitude);
						GUIUtility.addRow(panel, new JLabel("Network Detection: "), _networkDetection);
						GUIUtility.addRow(panel, new JLabel("Simulation Time: "), _year, _month, _day, _hour);

						_expandedPanel = panel;
					}

					return _expandedPanel;
				}
			});

			GUIUtility.addRow(panel, _nmc.getSources().getViewer());
			GUIUtility.addRow(panel, _nmc.getPaths().getViewer());
			GUIUtility.addRow(panel, _nmc.getReceivers().getViewer());
			GUIUtility.addRow(panel, _nmc.getOutputs().getViewer());

			_expandedPanel = panel;
		}

		return _expandedPanel;
	}

	@Override
	public void reset(AbstractSimulation nmc)
	{
		super.reset(nmc);

		_name.setText(nmc.getName());
		_simulationMethod.setSelectedType(nmc.getSimulationMethod());
		_simulationType.setSelectedType(nmc.getSimulationType());
		_signalAmplitude.setSelectedType(nmc.getSignalAmplitude());
		_noiseAmplitude.setSelectedType(nmc.getNoiseAmplitude());
		_networkDetection.setSelectedType(nmc.getNetworkDetection());

		// Set the time
		Calendar cal = nmc.getSimulationTime().getCalendar();

		_month.setSelectedItem(cal.get(GregorianCalendar.MONTH));
		_day.setSelectedItem(cal.get(GregorianCalendar.DAY_OF_MONTH));
		_hour.setSelectedItem(cal.get(GregorianCalendar.HOUR_OF_DAY));
		_year.setSelectedItem(cal.get(GregorianCalendar.YEAR));
	}

	public static List<String> range(String startYear, String endYear)
	{
		int cur = Integer.parseInt(startYear);
		int stop = Integer.parseInt(endYear);
		List<String> list = new ArrayList<String>();
		while (cur <= stop)
		{
			list.add(String.valueOf(cur++));
		}
		return list;
	}
}
