/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import gov.sandia.gnem.netmod.detection.StationDetection.FrequencyType;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.MonteCarloPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.receiver.StationPhaseParameter;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.ArrayList;
import java.util.List;

/**
 * Monte-Carlo station detection
 * 
 * @author bjmerch
 *
 */
public class StationDetectionMC extends StationDetection
{
    private static String _type = "Monte Carlo Detection";
    
    public StationDetectionMC(NetModComponent parent)
    {
        super(parent, _type);
    }

    /**
     * Compute the probability of a station detection
     * 
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param station
     * @param time
     * @param magnitude
     * @param phase
     * @param signal
     * @param noise
     * @return
     */
    public double[] computeDetectionProbability(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Time time, Magnitude magnitude, Phase phase,
            SignalAmplitude signal, NoiseAmplitude noise, int N, PRNG prng)
    {
        startIntrospection();
        
        //  Compute the SNR PDF's at each frequency
        Frequency[] frequencies = getFrequencies();
        int Nfreq = frequencies.length;
        List<PDF> logSNRs = new ArrayList<PDF>(Nfreq);
        
        for (int i = 0; i < Nfreq; i++)
        {
            Frequency frequency = frequencies[i];
            
            startIntrospection();
            
            //  Compute the PDF of the log signal
            Spectra logSignal = signal.generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            PDF avgSignal = logSignal.getMeanLogPDF();

            //  Compute the PDF of the log noise
            Spectra logNoise = noise.generateAmplitude(signal, sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);
            PDF avgNoise = logNoise.getMeanLogPDF();
            
            //  Compute the PDF of the log SNR
            PDF logSNR = avgSignal.minus(avgNoise);
            
            //  Ensure that the PDF is a MonteCarlo
            logSNR = logSNR.toMonteCarlo(prng, N);

            recordIntrospection("Frequency (Hz): ", frequency);
            recordIntrospection("SNR (log10): ", logSNR);
            recordIntrospection("Signal (Avg log10): ", avgSignal);
            recordIntrospection("Noise (Avg log10): ", avgNoise);

            //  Store the result
            logSNRs.add(logSNR);
            
            stopIntrospection();
        }
        
        //  Get the SNR threshold
        StationPhaseParameter phaseParameter = station.getPhaseParameters().getPhaseParameter(phase);
        double snrThreshold = phaseParameter.getSnrThreshold();
        if ( snrThreshold <= 0 )
            snrThreshold = receivers.getPhaseParameters().getPhaseParameter(phase).getSnrThreshold();

        double logSnrThreshold = Math.log10(snrThreshold);
        
        //  Get the combined snr across frequencies
        PDF logSNR = getFrequencyType().computeSNR(logSNRs, logSnrThreshold);
        
        //  Get the probability
        double[] probabilities = new double[N];
        if ( logSNR instanceof MonteCarloPDF )
        {
        	for (int i=0; i<N; i++)
        		probabilities[i] = ((MonteCarloPDF) logSNR).getValue(i);
        }
        else
        	System.out.print("Monte Carlo simulation and pdf is : " + logSNR);

        //  Factor in the station reliability
        double reliability = station.getReliability();
        if ( reliability <= 0 )
            reliability = receivers.getDefaultReliability();
        
        // Examine each of the SNR iterations for a detection
        for (int i=0; i<N; i++)
        {            
            //  Only detected if SNR >= threshold
            if ( probabilities[i] >= logSnrThreshold )
                probabilities[i] = ( prng.nextUniform() > reliability ? 0.0 : 1.0 );
            else
                probabilities[i] = 0.0;
        }
        
        recordIntrospection("Station Detection Probability: ", station, ", Phase ", phase);
        recordIntrospection("SNR Threshold (ratio): ", snrThreshold);
        recordIntrospection("SNR Threshold (log10): ", logSnrThreshold);
        recordIntrospection("SNR ", getFrequencyType(), " (log10): ", logSNR);

        if ( isIntrospection() )
        {
            // Identify which frequency was high
            if ( getFrequencyType() == FrequencyType.HIGH || getFrequencyType() == FrequencyType.HIGH_2 )
            {
                for (int i = 0; i < Nfreq; i++)
                {
                	if ( logSNR == logSNRs.get(i) )
                	{
                        recordIntrospection("High Frequency (Hz): ", frequencies[i]);
                		break;
                	}
                }
            }
        }
        recordIntrospection("Station Reliability: ", reliability);
        recordIntrospection("Probability: ", probabilities);
        
        stopIntrospection();
        
        return probabilities;
    }
}
