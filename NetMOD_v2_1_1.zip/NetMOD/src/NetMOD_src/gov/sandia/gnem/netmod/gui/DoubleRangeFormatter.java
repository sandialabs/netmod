/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.text.ParseException;

/**
 * Formatter for JFormattedTextField that limits input to numeric double
 * values within the provided range
 * 
 * @author bjmerch
 *
 */
public class DoubleRangeFormatter extends JFormattedTextField.AbstractFormatter
{
    private DocumentFilter _filter = new DoubleFilter();
    private double _min = -Double.MAX_VALUE;
    private double _max = Double.MAX_VALUE;
    

    public DoubleRangeFormatter()
    {
    }
    
    public DoubleRangeFormatter(double min, double max)
    {
        _min = min;
        _max = max;
    }
    
    @Override
    public DocumentFilter getDocumentFilter()
    {
        return _filter;
    }

    @Override
    public Object stringToValue(String str) throws ParseException
    {
        try
        {
            double value = Double.parseDouble(str);
            
            if ( value >= _min && value <= _max )
                return value;
        }
        catch (Exception e)
        {}
        
        invalidEdit();
        throw new ParseException(str, 0);
    }

    @Override
    public String valueToString(Object o) throws ParseException
    {
        if ( o instanceof Number )
            return o.toString();
        
        return "";
    }
    
    /**
     * Filter anything that isn't a double
     * 
     * @author bjmerch
     *
     */
    private class DoubleFilter extends DocumentFilter
    {
        @Override
        public void insertString(DocumentFilter.FilterBypass fb, int offset, String str, AttributeSet attr) throws BadLocationException
        {
            if ( containsBadCharacters(str) )
                return;

            //  Pass the string on to be accepted
            super.insertString(fb, offset, str, attr);
        }
        
        @Override
        public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String str, AttributeSet attr) throws BadLocationException
        {
            if ( containsBadCharacters(str) )
                return;

            //  Pass the string on to be accepted
            super.replace(fb,  offset, length, str,  attr);
        }
        
        private boolean containsBadCharacters(String str)
        {
            if ( str == null || str.isEmpty() )
                return false;
            
            
            //  Check for any non numeric or "." characters
            int N = str.length();
            for (int i=0; i<N; i++)
            {
                char c = str.charAt(i);
                
                //  check for a decimal point '.'
                if ( c == '.' )
                    continue;
                
                //  Check for a minus sign at the start
                if ( c == '-' && _min < 0 && i == 0)
                    continue;
                
                //  Check for an exponent character
                if ( c == 'e' )
                    continue;
                
                //  Check for a minus sign after an exponent
                if ( c == '-' && str.charAt(Math.max(0, i-1)) == 'e' )
                    continue;
                
                //  Only allow 0..9
                if ( c < 48 || c > 57 )
                    return true;
            }
            
            return false;
        }
    }
}
