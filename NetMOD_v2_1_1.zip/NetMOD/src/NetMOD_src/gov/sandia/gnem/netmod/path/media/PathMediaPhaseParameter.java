/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.media;

import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuation;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuationPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameter;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class PathMediaPhaseParameter extends PhaseParameter
{
    private double _stddevAttenuation = 0;
    private double _logSourceCorrection = 0;
    private String _amplitudeAttenuationFile = "";
    private double _logReceiverCorrection;

    private boolean _dirty = false;
    
    //  Cached objects
    transient private AmplitudeAttenuation _amplitudeAttenuation = null;

    /**
     * @param phase
     */
    public PathMediaPhaseParameter(NetModComponent parent, Phase phase)
    {
        super(parent, phase);
    }
    
    /**
     * Get the Amplitude Attenuation
     * 
     * @return
     */
    public AmplitudeAttenuation getAmplitudeAttenuation()
    {
        if (_amplitudeAttenuation == null)
        {
            _amplitudeAttenuation = AmplitudeAttenuationPlugin.getPlugin().getComponentFor(this, _amplitudeAttenuationFile);
            if ( _amplitudeAttenuation != null )
                _amplitudeAttenuation.setFilename(getAmplitudeAttenuationFile());
        }

        return _amplitudeAttenuation;
    }
    
    /**
     * @return the amplitudeAttenuationFile
     */
    public String getAmplitudeAttenuationFile()
    {
        return _amplitudeAttenuationFile;
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getAmplitudeAttenuation());

        return children;
    }
    
    /**
     * @return the dirty
     */
    public boolean getDirty()
    {
        return _dirty;
    }

    /**
     * @return the logReceiverCorrection
     */
    public double getLogReceiverCorrection()
    {
        return _logReceiverCorrection;
    }

    /**
     * @return the logSourceCorrection
     */
    public double getLogSourceCorrection()
    {
        return _logSourceCorrection;
    }

    /**
     * Get the Standard Deviation for the provided phase
     * 
     * @return
     */
    public double getStddevAttenuation()
    {
        return _stddevAttenuation;
    }

    @Override
    public PathMediaPhaseParameterViewer getViewer()
    {
        return new PathMediaPhaseParameterViewer(this);
    }

    /**
     * Set the amplitude attenuation for the provided phase
     * 
     * @param amplitudeAttenuation
     */
    public void setAmplitudeAttenuation(AmplitudeAttenuation amplitudeAttenuation)
    {
        if ( amplitudeAttenuation != null )
            _amplitudeAttenuationFile = amplitudeAttenuation.getFilename();

        _amplitudeAttenuation = amplitudeAttenuation;
        
        setDirty(true);
        
        //  Clear cached attenuation values
        clearCache();
    }

    /**
     * @param amplitudeAttenuationFile the amplitudeAttenuationFile to set
     */
    public void setAmplitudeAttenuationFile(String amplitudeAttenuationFile)
    {
        if (_amplitudeAttenuationFile.equals(amplitudeAttenuationFile))
            return;
        
        //  If file exists, load it
        if ( IOUtility.openFile(amplitudeAttenuationFile).exists() )
        {
            _amplitudeAttenuationFile = amplitudeAttenuationFile;
            setAmplitudeAttenuation(null);
        }
        //  Otherwise, save to it
        else
        {
            AmplitudeAttenuation amplitudeAttenuation = getAmplitudeAttenuation();
            amplitudeAttenuation.read();
            amplitudeAttenuation.setFilename(amplitudeAttenuationFile);
            amplitudeAttenuation.write();
            _amplitudeAttenuationFile = amplitudeAttenuation.getFilename();
        }
        
        setDirty(true);
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof AmplitudeAttenuation)
                setAmplitudeAttenuation((AmplitudeAttenuation) child);
        }

        clearCache();
    }

    /**
     * @param dirty the dirty to set
     */
    public void setDirty(boolean dirty)
    {
        _dirty = dirty;
    }

    /**
     * @param logReceiverCorrection the logReceiverCorrection to set
     */
    public void setLogReceiverCorrection(double logReceiverCorrection)
    {
        if ( _logReceiverCorrection == logReceiverCorrection )
            return;
        
        _logReceiverCorrection = logReceiverCorrection;
        setDirty(true);
    }

    /**
     * @param logSourceCorrection the logSourceCorrection to set
     */
    public void setLogSourceCorrection(double logSourceCorrection)
    {
        if ( _logSourceCorrection == logSourceCorrection )
            return;
        
        _logSourceCorrection = logSourceCorrection;
        setDirty(true);
    }

    /**
     * Set the standard deviation for the provided phase
     * 
     * @param value
     */
    public void setStddevAttenuation(double value)
    {
        if (_stddevAttenuation == value )
            return;
        
        _stddevAttenuation = value;
        setDirty(true);
        
        //  Clear cached attenuation values
        clearCache();
    }
}
