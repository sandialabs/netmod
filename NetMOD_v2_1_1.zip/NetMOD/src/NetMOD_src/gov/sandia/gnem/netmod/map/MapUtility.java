/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map;

import gov.sandia.gnem.netmod.geometry.Point;

import javax.swing.*;
import java.awt.*;
import java.awt.color.ColorSpace;
import java.awt.image.*;
import java.util.AbstractMap.SimpleEntry;
import java.util.List;
import java.util.Map;
import java.util.*;
import java.util.Map.Entry;

/**
 * @author bjmerch
 *
 */
public class MapUtility
{
    
    static public abstract class Interpolation
    {

        /**
         * Values returned by interpolation can be either extrapolated 
         * or interpolated.  This enumeration tells which occurred. 
         */
        public enum Flag
        {
            EXTRAPOLATED_LEFT, INTERPOLATED, EXTRAPOLATED_RIGHT
        }

        /**
         * InterpolatedResult objects group together the three results of
         * interpolation: whether result is interpolated or extrapolated,
         * value of function at input point, and value of the function's
         * derivative at the input point.
         */
        public static class InterpolatedResult
        {

            private Flag mFlag;

            private double mValue;

            private double mDerivative;

            public InterpolatedResult(Flag aFlag, double aValue, double aDerivative)
            {
                mFlag = aFlag;
                mValue = aValue;
                mDerivative = aDerivative;
            }

            public double derivative()
            {
                return mDerivative;
            }
            public Flag flag()
            {
                return mFlag;
            }
            public double value()
            {
                return mValue;
            }
        }

        /**
         * Using a bisection search, find those values of an array that bracket 
         * a given value.  Given the input array aValues(i), i=0,...,N-1, 
         * in non-decreasing order, and given the value aCompare, find
         * left in -1...N-1 such that 
         *      aValues[leftBracket]  <= aCompare <= aValues[leftBracket+1]
         *      aValues[leftBracket] < aValues[leftBracket+1]
         * where left = -1 is assumed to mean -infinity and
         *       left =  N is assumed to mean  infinity
         * @param aValues values used for bracketing, must be in non-decreasing order
         * @param aCompare value to compare against
         * @return left bracket index meeting the constraints detailed above.
         */
        public static int bracket(List<Double> aValues, double aCompare)
        {
            int lLeftBracket = -1;
            int lRightBracket = aValues.size();

            // Bisection search to find the bracket
            int lMid = 0;
            while (true)
            {
                lMid = (lRightBracket + lLeftBracket) / 2;

                // Mid became negative - went off the left end, return -1
                if ((lRightBracket + lLeftBracket) < 0)
                    return -1;

                // Found the bracket, return
                if (lMid == lLeftBracket)
                    return lLeftBracket;

                // Lower right bracket
                else if (aCompare < aValues.get(lMid))
                    lRightBracket = lMid;

                // Raise left bracket
                else if (aCompare > aValues.get(lMid))
                    lLeftBracket = lMid;

                // If the mid point equals the comparison value then find the
                // bracket such that values[leftBracket] < value[leftBracket+1]
                else
                    return moveBracket(aValues, aCompare, lMid);
            }
        }

        /**
         * Perform linear interpolation between two points to find the desired value.  Extrapolation will
         *  occur as required if aX is not in [aX0, aX1]
         * @param aX0 first x value to interpolate from
         * @param aX1 second x value to interpolate from
         * @param aY0 f(x0)
         * @param aY1 f(x1)
         * @param aX approximate function at this point
         * @return approximation of f(aX) and slope between the first and second input points.  The slope is forced
         *  to 0.0 if the x0 and x1 are the same (implying the inputs do not form a function in the first place).  
         */
        public static SimpleEntry<Double, Double> linear(double aX0, double aX1, double aY0, double aY1, double aX)
        {
            double lSlope = (aX1 == aX0) ? 0.0 : (aY1 - aY0) / (aX1 - aX0);
            double lY = aY0 + ((aX - aX0) * lSlope);

            return new SimpleEntry<Double, Double>(lY, lSlope);
        }

        /**
         * Perform linear interpolation between two points to find the desired value.  Extrapolation will
         *  occur as required if aX is not in [aX0, aX1]
         * @param aX0 first x value to interpolate from
         * @param aX1 second x value to interpolate from
         * @param aY0 f(x0)
         * @param aY1 f(x1)
         * @param aX approximate function at this point
         * @return approximation of f(aX)
         */
        public static double linearYOnly(double aX0, double aX1, double aY0, double aY1, double aX)
        {
            return linear(aX0, aX1, aY0, aY1, aX).getKey();
        }

        /**
         * Moves a bracket such that  values[leftBracket] < value[leftBracket+1]
         * It is assumed on input that aCompare == aValues[aMid] and so
         * the bracket needs to be shifted from aMid to meet this inequality
         * constraint.
         * @param aValues values used for bracketing, must be in non-decreasing order
         * @param aCompare value to compare against
         * @param aMid index into aValues, must satisfy aValues[aMid] == aCompare
         * @return leftBracket index meeting the constraints 
         *  aValues[leftBracket] < aValues[leftBracket+1]
         *  aValues[leftBracket]  <= aCompare <= aValues[leftBracket+1]
         */
        private static int moveBracket(List<Double> aValues, double aCompare, int aMid)
        {
            // Try moving up until a value > compare is found
            for (int i = aMid + 1; i < aValues.size(); ++i)
            {
                if (aValues.get(i) > aCompare)
                    return i - 1;
            }

            // Try moving down until a value < compare is found
            for (int i = aMid - 1; i >= 0; --i)
            {
                if (aValues.get(i) < aCompare)
                    return i;
            }

            // Left bracket is off the end of the array
            return -1;
        }

        protected List<Double> mX;

        protected List<Double> mF;

        private boolean mClamp = false;

        /**
         * Constructor to setup the function to use for interpolation.
         * @param x independent variable x
         * @param f value of function at input points x (i.e., holds values f(x))
         *  at which to find the interpolated value)
         * @param aDeepCopy if true then copy the array values for mX and mF to 
         *   internal copies.  Otherwise, just make a reference to the input lists.
         */
        public Interpolation(List<Double> x, List<Double> f, boolean aDeepCopy)
        {

            if (aDeepCopy)
            {
                mX = new ArrayList<Double>();
                mX.addAll(x);
                mF = new ArrayList<Double>();
                mF.addAll(f);
            }

            else
            {
                mX = x;
                mF = f;
            }

            // Cannot interpolate if the input vector does not have at least 2 points.
            // Also, cannot interpolate if the input vectors do not match in size.
            if (mX.size() != mF.size())
                throw new IllegalArgumentException("Input arrays must be same length");
            if (mX.size() < 2)
                throw new IllegalArgumentException("At least two function points needed for interpolation");
        }

        /**
         * @return if extrapolation is clamped to closest value or actually performed
         */
        public boolean clamp()
        {
            return mClamp;
        }

        /**
         * Set whether extrapolation is clamped to the nearest value or not.  If it is,
         * then extrapolated values are just set to the nearest known value.  Otherwise,
         * actually extrapolation is performed.
         * @param aClamp true if extrapolation is clamped and false otherwise
         */
        public void clamp(boolean aClamp)
        {
            mClamp = aClamp;
        }

        /**
         * Performs interpolation at each of the input points.  Returns only the interpolated
         * values (not extrapolation or derivative information).
         * @param aNewIndependents new values of the independent variable.  Find f(x) for each
         *  x in this list
         * @return a list containing an approximation of f(x) foubd via interpolation for each x
         *  in the aNewIndependents
         */
        public ArrayList<Double> interpolate(ArrayList<Double> aNewIndependents)
        {
            ArrayList<Double> lReturn = new ArrayList<Double>();
            for (double x : aNewIndependents)
                lReturn.add(interpolate(x).value());

            return lReturn;
        }

        /**
         * Perform interpolation of function f(x).  
         * @param x sample values of independent variable, ordered such that
         *  x[i] <= x[i+1]
         * 
         * @return InterpolatedResult object holding extrapolated value and derivative
         * @throws Exception 
         */
        public InterpolatedResult interpolate(double x)
        {

            // Last index in x and f
            int lLastIndex = mX.size() - 1;

            // Find the left index in x such that x0 is between lLeft and lLeft+1
            int lLeft = bracket(mX, x);

            // Left is off the left end of x - extrapolate left
            if (lLeft < 0)
            {
                return extrapolateLeft(x);
            }

            // Left is off the right end of x - extrapolate right
            if (lLeft >= lLastIndex)
                return extrapolateRight(x);

            return interpolate(x, lLeft);
        }

        /**
         * Perform interpolation of function f(x).  
         * @param x sample values of independent variable, ordered such that
         *  x[i] <= x[i+1]
         * 
         * @return extrapolated value
         */
        public double interpolateValueOnly(double x)
        {

            // Last index in x and f
            int lLastIndex = mX.size() - 1;

            // Find the left index in x such that x0 is between lLeft and lLeft+1
            int lLeft = bracket(mX, x);

            // Left is off the left end of x - extrapolate left
            if (lLeft < 0)
            {
                return extrapolateLeftValueOnly(x);
            }

            // Left is off the right end of x - extrapolate right
            if (lLeft >= lLastIndex)
                return extrapolateRightValueOnly(x);

            return interpolateValueOnly(x, lLeft);
        }

        /**
         * Find extrapolated value of function held by this interpolator at point x0
         * @param x point to the left of mX[0] at which to approximate f()
         * @return extrapolated approximation of f(x)
         */
        protected InterpolatedResult extrapolateLeft(double x)
        {

            // Clamp => return first value
            if (mClamp)
                return new InterpolatedResult(Flag.EXTRAPOLATED_LEFT, mF.get(0), 0.0);

            else
            {
                SimpleEntry<Double, Double> lInterp = linear(x, 0);
                return new InterpolatedResult(Flag.EXTRAPOLATED_LEFT, lInterp.getKey(), lInterp.getValue());
            }
        }

        /**
         * Find extrapolated value of function held by this interpolator at point x0
         * @param x point to the left of mX[0] at which to approximate f()
         * @return extrapolated approximation of f(x0)
         */
        protected double extrapolateLeftValueOnly(double x)
        {
            // Clamp => return first value
            if (mClamp)
                return mF.get(0);

            // else -> extrapolate to get the result
            return linear(x, 0).getKey();
        }

        /**
         * Find extrapolated value of function held by this interpolator at point x0 
         * @param x point to the right of mX[lastIndex] at which to approximate f()
         * @return extrapolated approximation of f(x0)
         */
        protected InterpolatedResult extrapolateRight(double x)
        {

            // Clamp => return last value
            if (mClamp)
                return new InterpolatedResult(Flag.EXTRAPOLATED_RIGHT, mF.get(mF.size() - 1), 0.0);

            // Otherwise, extrapolate
            else
            {
                SimpleEntry<Double, Double> lInterp = linear(x, mX.size() - 2);
                return new InterpolatedResult(Flag.EXTRAPOLATED_RIGHT, lInterp.getKey(), lInterp.getValue());
            }
        };

        /**
         * Find extrapolated value of function held by this interpolator at point x0 
         * @param x point to the right of mX[lastIndex] at which to approximate f()
         * @return extrapolated approximation of f(x0)
         */
        protected double extrapolateRightValueOnly(double x)
        {
            // Clamp => return last value
            if (mClamp)
                return mF.get(mF.size() - 1);

            // Otherwise, extrapolate
            return linear(x, mX.size() - 2).getKey();
        }

        /**
         * Find the interpolated value of the function held by this interpolator 
         * at point x0
         * @param x0 approximate the function at this point (use interpolation to find f(x0))
         * @param aLeft left hand bracket of x0 such that 
         *    mX[aLeft] <= x0 <= mX[aLeft+1] and 
         *    mX[aLeft] != mX[aLeft+1]
         *  See the bracket function for details.
         * @return interpolated approximation of f(x0)
         */
        protected abstract InterpolatedResult interpolate(double x0, int aLeft);
        /**
         * Find the interpolated value of the function held by this interpolator 
         * at point x0
         * @param x0 approximate the function at this point (use interpolation to find f(x0))
         * @param aLeft left hand bracket of x0 such that 
         *    mX[aLeft] <= x0 <= mX[aLeft+1] and 
         *    mX[aLeft] != mX[aLeft+1]
         *  See the bracket function for details.
         * @return interpolated approximation of f(x0)
         */
        protected double interpolateValueOnly(double x0, int aLeft)
        {
            return interpolate(x0, aLeft).value();
        }
        /**
         * Performs a linear interpolation of the function at point x.  This will be used
         * by many of the interpolators that assume linearity when performing extrapolation,
         * and of course by a linear interpolator.
         * @param x approximate the function at this point (use interpolation to find f(x0))
         * @param aLeft left hand bracket of x0 such that 
         *    mX[aLeft] <= x <= mX[aLeft+1] and 
         *    mX[aLeft] != mX[aLeft+1]
         *  See the bracket function for details.
         * @return linear interpolated approximation of f(x0)
         */
        protected SimpleEntry<Double, Double> linear(double x, int aLeft)
        {
            double lY0 = mF.get(aLeft);
            double lY1 = mF.get(aLeft + 1);
            double lX0 = mX.get(aLeft);
            double lX1 = mX.get(aLeft + 1);

            //          double lSlope = (lX1 == lX0) ? 0.0 : (lY1 - lY0) / (lX1 - lX0);     
            //          double lY = lY0 + ((x - lX0) * lSlope);     
            //          return new SimpleEntry<Double, Double>(lY, lSlope);

            return linear(lX0, lX1, lY0, lY1, x);
        }
    };
    
    static public class LinearInterpolation extends Interpolation
    {

        /**
         * Constructor to setup the function to use for interpolation.
         * @param x independent variable x
         * @param f value of function at input points x (i.e., holds values f(x))
         *  at which to find the interpolated value)
         * @param aDeepCopy if true then copy the array values for mX and mF to 
         *   internal copies.  Otherwise, just make a reference to the input lists.
         */
        public LinearInterpolation(List<Double> x, List<Double> f, boolean aDeepCopy)
        {
            super(x, f, aDeepCopy);
        }

        @Override
        protected InterpolatedResult interpolate(double x, int aLeft)
        {
            SimpleEntry<Double, Double> lInterp = linear(x, aLeft);
            return new InterpolatedResult(Flag.INTERPOLATED, lInterp.getKey(), lInterp.getValue());
        }

        @Override
        protected double interpolateValueOnly(double x, int aLeft)
        {
            return linear(x, aLeft).getKey();
        }
    }
    /**
     * ButtonGroup that allows buttons to be unselected
     * 
     * @author bjmerch
     *
     */
    private static class UnselectButtonGroup extends ButtonGroup
    {
            //  Allow for no buttons to be selected
            public void setSelected(ButtonModel model, boolean selected)
            {
                if (selected)
                    super.setSelected(model, selected);
                else
                    clearSelection();
            }
    }
    
    /*
     * Button Groups for only allowing a single display button to be selected at a time.
     */
    public static final ButtonGroup OutputButtonGroup = new UnselectButtonGroup();
    public static final ButtonGroup StationButtonGroup = new UnselectButtonGroup();
    public static final ButtonGroup SourceButtonGroup = new UnselectButtonGroup();
    public static final ButtonGroup MediaButtonGroup = new UnselectButtonGroup();
    public static final ButtonGroup SelectButtonGroup = new UnselectButtonGroup();
    public static final ButtonGroup WindVectorButtonGroup = new UnselectButtonGroup();

    public final static double EPSILON = 0.000001;
    
    /**
     * Perform a bilinear interpolation of the known values to the points specified
     * by aInterpolateTo.  This currently uses a clamped extrapolation for points outside
     * the range of known values.
     * @param aInterpolateTo interpolate aKnownValues to values at these points
     * @param aKnownValues known values to use for interpolation
     * @param aKnownByLatitude mapping of latitude->all longitudes for that latitude for the same locations
     *  as those found in aKnownValues
     * @return approximation of aKnownValues at the points specified by aInterpolateTo
     */
    public static Map<Point.Double, Double> bilinear(Collection<Point.Double> aInterpolateTo, Map<Point.Double, Double> aKnownValues,
            Map<Double, ArrayList<Double>> aKnownByLatitude)
    {

        HashMap<Point.Double, Double> lValues = new LinkedHashMap<Point.Double, Double>();
        Map<Double, LinearInterpolation> lRowInterps = createInterpolators(aKnownValues, aKnownByLatitude);

        // Get the known latitudes in sorted order
        ArrayList<Double> lLatitudes = new ArrayList<Double>();
        lLatitudes.addAll(aKnownByLatitude.keySet());
        java.util.Collections.sort(lLatitudes);

        // Do a bilinear interpolation to find the comparison values at each of the base value locations
        for (Point.Double basePos : aInterpolateTo)
        {
            int lSouth = bound(Interpolation.bracket(lLatitudes, basePos.getLatitude()), lLatitudes.size() - 1);
            int lNorth = bound(lSouth + 1, lLatitudes.size() - 1);

            if (isZero(basePos.getLatitude() - lLatitudes.get(lSouth)))
                lNorth = lSouth;
            else if (isZero(basePos.getLatitude() - lLatitudes.get(lNorth)))
                lSouth = lNorth;

            // Just linear interpolation when desired latitude matches known latitude
            // or if the desired latitude is not bounded by known latitudes
            double lValue = 0.0;
            if (lSouth == lNorth)
            {
                lValue = lRowInterps.get(lLatitudes.get(lSouth)).interpolate(basePos.getLongitude()).value();
            }

            // Do bilinear interpolation 
            else
            {
                double lSouthValue = lRowInterps.get(lLatitudes.get(lSouth)).interpolate(basePos.getLongitude()).value();
                double lNorthValue = lRowInterps.get(lLatitudes.get(lNorth)).interpolate(basePos.getLongitude()).value();

                double lSpan = Math.abs(lLatitudes.get(lSouth) - lLatitudes.get(lNorth));
                double lDesiredFromSouth = Math.abs(lLatitudes.get(lSouth) - basePos.getLatitude());
                double lFactor = (lSpan - lDesiredFromSouth) / lSpan;

                if (lFactor < 0.0)
                    lValue = lSouthValue;
                else if (lFactor > 1.0)
                    lValue = lNorthValue;
                else
                    lValue = (lFactor * lSouthValue) + ((1.0 - lFactor) * lNorthValue);
            }

            lValues.put(basePos, lValue);
        }

        return lValues;
    }

    /**
     * Perform a bilinear interpolation of the known values to the points specified
     * by aInterpolateTo.  This currently uses a clamped extrapolation for points outside
     * the range of known values.
     * @param aKnownValues known values to use for interpolation
     * @param aDesiredX interpolate to these x values
     * @param aDesiredY interpolate to these y values
     * @return approximation of aKnownValues at the points specified by aDesiredX and aDesiredY
     */
    public static Map<Point.Double, List<Double>> bilinear(Map<Point.Double, List<Double>> aKnownValues, ArrayList<Double> aDesiredX, ArrayList<Double> aDesiredY)
    {

        Set<Point.Double> lInterpolateTo = new TreeSet<Point.Double>();
        for (double lat : aDesiredY)
            for (double lon : aDesiredX)
                lInterpolateTo.add(new Point.Double(lat, lon));

        return bilinear(lInterpolateTo, aKnownValues);
    }

    /**
     * Perform a bilinear interpolation of the known values to the points specified
     * by aInterpolateTo.  This currently uses a clamped extrapolation for points outside
     * the range of known values.
     * @param aInterpolateTo interpolate aKnownValues to values at these points
     * @param aKnownValues known values to use for interpolation
     * @return approximation of aKnownValues at the points specified by aInterpolateTo
     */
    public static Map<Point.Double, List<Double>> bilinear(Set<Point.Double> aInterpolateTo, Map<Point.Double, List<Double>> aKnownValues)
    {
        Map<Double, ArrayList<Double>> latitudes = rows(aKnownValues.keySet());
        
        Map<Point.Double, Double> knownRow = new LinkedHashMap<Point.Double, Double>();
        Map<Point.Double, Double> interpRow = new LinkedHashMap<Point.Double, Double>();
        Map<Point.Double, List<Double>> interpValues = new LinkedHashMap<Point.Double, List<Double>>();
        
        //  Get the number of elements to interpolate
        int N = aKnownValues.values().iterator().next().size();
        
        //  Interpolate each of the variables
        for (int i=0; i<N; i++)
        {
            //  Load the i'th variable into knownRow
            for (Entry<Point.Double, List<Double>> entry : aKnownValues.entrySet())
                knownRow.put(entry.getKey(), entry.getValue().get(i));
            
            //  Interpolate the i'th variable
            interpRow = bilinear(aInterpolateTo, knownRow, latitudes);
            
            //  Store the interpolated row inot interpValues
            for (Entry<Point.Double, Double> entry : interpRow.entrySet())
            {
                List<Double> row = interpValues.get(entry.getKey());
                if ( row == null )
                {
                    row = new ArrayList<Double>();
                    interpValues.put(entry.getKey(), row);
                }
                
                row.add(entry.getValue());
            }
        }
        
        return interpValues;
    }

    /**
     * Determines if a given set of values contains infinity or not
     * @param aValues check if any of these values are infinity
     * @return true if aValues contains +/- infinity and false otherwise
     */
    public static boolean containsInfinity(Map<Point.Double, List<Double>> aValues)
    {
        for (Point.Double pos : aValues.keySet())
        {
            for (Double value : aValues.get(pos))
                if ( value.isInfinite() )
                    return true;
        }

        return false;
    }

    /**
     * Create linear interpolators for each row
     * @param aActualPoints known values.  Needed to associate values with rows
     * @param aRows mapping from latitudes to longitude values defined for those latitudes 
     * @return mapping of latitude value to interpolator for that latitude
     */
    public static Map<Double, LinearInterpolation> createInterpolators(Map<Point.Double, Double> aActualPoints, Map<Double, ArrayList<Double>> aRows)
    {

        HashMap<Double, LinearInterpolation> lRowInterps = new LinkedHashMap<Double, LinearInterpolation>();
        for (double y : aRows.keySet())
        {
            // Get the function values for this row
            ArrayList<Double> lFunctionValues = new ArrayList<Double>();
            for (double x : aRows.get(y))
                lFunctionValues.add(aActualPoints.get(new Point.Double(y, x)));

            // Make sure there are at least two points so that interpolation can take place
            if (aRows.get(y).size() == 1)
            {
                aRows.get(y).add(aRows.get(y).get(0) + 1.0);
                lFunctionValues.add(lFunctionValues.get(0));
            }

            // Make the interpolator
            lRowInterps.put(y, new LinearInterpolation(aRows.get(y), lFunctionValues, false));
            lRowInterps.get(y).clamp(true);
        }
        return lRowInterps;
    }

    /**
     * Determines if aData lies on a regular grid.  If it does, then just return it.  If it
     * does not, then do interpolation of aData so that it does lie on a regular grid.
     * @param aData data to (potentially) interpolate
     * @return aData interpolated to a regular grid (or aData if it is already on a regular grid)
     */
    public static Map<Point.Double, List<Double>> interpolateIfNecessary(Map<Point.Double, List<Double>> aData)
    {

        // Define the grid we are dealing with
        HashMap<Double, TreeSet<Double>> lLongitudesForLat = new LinkedHashMap<Double, TreeSet<Double>>();
        for (Point.Double pos : aData.keySet())
        {
            double lLatitude = pos.getLatitude();
            if (!lLongitudesForLat.containsKey(lLatitude))
                lLongitudesForLat.put(lLatitude, new TreeSet<Double>());

            lLongitudesForLat.get(lLatitude).add(pos.getLongitude());
        }

        // Return now if there is not sufficient data to continue
        if (lLongitudesForLat.size() == 0)
            return aData;

        // Determine if it is regular.  If not, determine what the longitudes to use should be.
        // These will be the longitudes for the latitude with the most longitudes.
        double lWidestLat = -1.0;
        boolean lAllSame = true;

        for (Double key : lLongitudesForLat.keySet())
        {
            if (lWidestLat == -1.0)
                lWidestLat = key;

            if (lLongitudesForLat.get(key).size() != lLongitudesForLat.get(lWidestLat).size())
                lAllSame = false;

            if (lLongitudesForLat.get(key).size() > lLongitudesForLat.get(lWidestLat).size())
                lWidestLat = key;
        }

        // If they are all the same width, make sure they are the same longitudes
        if (lAllSame)
        {
            for (Double key : lLongitudesForLat.keySet())
            {
                Iterator<Double> lBase = lLongitudesForLat.get(lWidestLat).iterator();
                Iterator<Double> lCompare = lLongitudesForLat.get(key).iterator();

                // Any non-negligible difference will require interpolation
                while (lBase.hasNext())
                {
                    if (!isZero(lBase.next().doubleValue() - lCompare.next().doubleValue()))
                    {
                        lAllSame = false;
                        break;
                    }
                }

                // Early exit if we know this is not already a grid
                if (!lAllSame)
                    break;
            }
        }

        // Still the same - no interpolation required
        if (lAllSame)
            return aData;

        // Otherwise, interpolate   
        ArrayList<Double> lLatitudes = fillDoubleList(lLongitudesForLat.keySet());
        ArrayList<Double> lLongitudes = fillDoubleList(lLongitudesForLat.get(lWidestLat));

        // If these is a value of infinity in this grid then do interpolation on the reciprocals
        // of the grid
        boolean lContainsInfinity = containsInfinity(aData);
        if (lContainsInfinity)
            oneOver(aData);

        Map<Point.Double, List<Double>> lInterpolatedGrid = bilinear(aData, lLongitudes, lLatitudes);

        // Take reciprocals again to get back to the original units
        if (lContainsInfinity)
        {
            oneOver(aData);
            oneOver(lInterpolatedGrid);
        }

        return lInterpolatedGrid;
    }

    public static boolean isZero(double aValue)
    {
        return (Math.abs(aValue) < EPSILON);
    }

    /**
     * Takes all of the values in the input and replaces them with 1.0 / original value.
     * @param aValues
     */
    public static void oneOver(Map<Point.Double, List<Double>> aValues)
    {
        for (Point.Double pos : aValues.keySet())
        {
            List<Double> row = aValues.get(pos);
            int N = row.size();
            for (int j=0; j<N; j++)
                row.set(j, 1.0 / row.get(j));
        }
    }

    /**
     * Reset the provieded button group to off.
     * 
     * @param group
     */
    public static final void resetMapButton(ButtonGroup group)
    {
        group.clearSelection();
    }

    /**
     * Reset all of the map buttons to off.
     */
    public static final void resetMapButtons()
    {
        resetMapButton(OutputButtonGroup);
        resetMapButton(StationButtonGroup);
        resetMapButton(SourceButtonGroup);
        resetMapButton(MediaButtonGroup);
        resetMapButton(SelectButtonGroup);
    }

    /**
     * Get all of the latitude points from the input values.  Store the corresponding longitude points
     *  in an array associated with the latitude value.
     * @param aValues listing of (latitude, longitude) points 
     * @return a mapping of latitude->array of longitudes using that latitude.  The list
     *  of longitudes is sorted from west to east.
     */
    public static Map<Double, ArrayList<Double>> rows(Collection<Point.Double> aValues)
    {

        HashMap<Double, ArrayList<Double>> lRows = new LinkedHashMap<Double, ArrayList<Double>>();

        for (Point.Double p : aValues)
        {
            double lLatitude = p.getLatitude();

            if (!lRows.containsKey(lLatitude))
                lRows.put(lLatitude, new ArrayList<Double>());

            lRows.get(lLatitude).add(p.getLongitude());
        }

        for (double y : lRows.keySet())
            java.util.Collections.sort(lRows.get(y));

        return lRows;
    }

    /**
     * Convert the provided image into a buffered image.
     * 
     * @param image
     * @return
     */
    public static BufferedImage toBufferedImage(Image image)
    {
        WritableRaster raster = Raster.createInterleavedRaster(DataBuffer.TYPE_BYTE, image.getWidth(null), image
                .getHeight(null), 3, null);

        ComponentColorModel colorModel = new ComponentColorModel(ColorSpace.getInstance(ColorSpace.CS_sRGB), new int[] {
                8, 8, 8}, false, false, ComponentColorModel.TRANSLUCENT, DataBuffer.TYPE_BYTE);

        BufferedImage bimage = new BufferedImage(colorModel, raster, false, null);

        // Copy image to buffered image
        Graphics g = bimage.createGraphics();

        // Paint the image onto the buffered image
        g.drawImage(image, 0, 0, null);
        g.dispose();

        return bimage;
    }


    /**
     * Determine whether x is located between x1 and x2.
     * Either x1 < x < x2 or x2 < x < x1
     * 
     * @param x1
     * @param x2
     * @param x
     * @return
     */
    private static final boolean between(double x1, double x2, double x)
    {
        return ((x >= x1 && x <= x2) || (x >= x2 && x <= x1));

    }

    /**
     * @param x1
     * @param x2
     * @param y1
     * @param y2
     * @param x
     * @return
     */
    private static final double interp(double x1, double x2, double y1, double y2, double x)
    {
        return gov.sandia.gnem.netmod.numeric.Interpolation.linear(x1, x2, y1, y2, x);
    }

    
    /**
     * Generate contours through the array of values
     * 
     * @param latitudes
     * @param longitudes
     * @param data
     * @param contourLevel
     * @return
     */
    public static Collection<List<Point.Double>> generateContours(double latitudes[], double longitudes[], double[][] data, double contourLevel)
    {
        int N = latitudes.length;
        int M = longitudes.length;
        List<List<Point.Double>> contourLines = new ArrayList<List<Point.Double>>();

        /*
         *  Step over each of the output-quads
         *           p2
         *    P12 _______ P22
         *     |           |
         *  p1 |           |  p3
         *     |           |
         *    P11 _______ P21
         *         
         *           p4
         *  
         */
        for (int i = 0; i < M - 1; i++)
        {
            for (int j = 0; j < N - 1; j++)
            {
                int edges = 0;
                Point.Double p1 = null;
                Point.Double p2 = null;
                Point.Double p3 = null;
                Point.Double p4 = null;

                //  Check for a line between P11 and P12
                if (between(data[i][j], data[i][j + 1], contourLevel))
                {
                    edges++;

                    //  Compute the latitude and longitudes of the crossing point
                    double lon = longitudes[i];
                    double lat = interp(data[i][j], data[i][j + 1], latitudes[j], latitudes[j + 1], contourLevel);

                    p1 = new Point.Double(lat, lon);
                }

                //  Check for a line between P12 and P22
                if (between(data[i][j + 1], data[i + 1][j + 1], contourLevel))
                {
                    edges++;

                    //  Compute the latitude and longitudes of the crossing point
                    double lon = interp(data[i][j + 1], data[i + 1][j + 1], longitudes[i], longitudes[i + 1], contourLevel);
                    double lat = latitudes[j + 1];

                    p2 = new Point.Double(lat, lon);
                }

                //  Check for a line between P21 and P22
                if (between(data[i + 1][j], data[i + 1][j + 1], contourLevel))
                {
                    edges++;

                    //  Compute the latitude and longitudes of the crossing point
                    double lon = longitudes[i + 1];
                    double lat = interp(data[i + 1][j], data[i + 1][j + 1], latitudes[j], latitudes[j + 1], contourLevel);

                    p3 = new Point.Double(lat, lon);
                }

                //  Check for a line between P11 and P21
                if (between(data[i + 1][j], data[i][j], contourLevel))
                {
                    edges++;

                    //  Compute the latitude and longitudes of the crossing point
                    double lon = interp(data[i][j], data[i + 1][j], longitudes[i], longitudes[i + 1], contourLevel);
                    double lat = latitudes[j];

                    p4 = new Point.Double(lat, lon);
                }

                //  Two edges, simple case
                //  If three edges, due to crossing at a vertex
                if (edges == 2 || edges == 3)
                {
                    //  Use a set to eliminate any duplicate vertex
                    Set<Point.Double> locations = new HashSet<Point.Double>();

                    if (p1 != null)
                        locations.add(p1);
                    if (p2 != null)
                        locations.add(p2);
                    if (p3 != null)
                        locations.add(p3);
                    if (p4 != null)
                        locations.add(p4);

                    if ( locations.size() > 1 )
                        contourLines.add(new ArrayList<Point.Double>(locations));
                }
                //  4 edges, more complex with two separate lines entering and exiting
                else if (edges == 4)
                {
                    //  Check if lines are p1-p2 and p3-p4
                    if (data[i][j] >= contourLevel && data[i + 1][j + 1] >= contourLevel)
                    {
                        //  Add p1-p2 
                        List<Point.Double> locations = new ArrayList<Point.Double>();

                        locations.add(p1);
                        locations.add(p2);

                        contourLines.add(locations);

                        //  Add p3-p4
                        locations = new ArrayList<Point.Double>();

                        locations.add(p3);
                        locations.add(p4);

                        contourLines.add(locations);
                    }
                    //  Check if lines are p1-p4 and p2-p3
                    else if (data[i + 1][j] >= contourLevel && data[i][j + 1] >= contourLevel)
                    {
                        //  Add p1-p4
                        List<Point.Double> locations = new ArrayList<Point.Double>();

                        locations.add(p1);
                        locations.add(p4);

                        contourLines.add(locations);

                        //  Add p2-p3
                        locations = new ArrayList<Point.Double>();

                        locations.add(p2);
                        locations.add(p3);

                        contourLines.add(locations);
                    }

                }
            }
        }

        //  Merge contour line segments with matching start and end points
        for (int i = 0; i < contourLines.size(); i++)
        {
            List<Point.Double> locations = contourLines.get(i);

            Point.Double p1_start = locations.get(0);
            Point.Double p1_end = locations.get(locations.size() - 1);

            //  Scan all of the subsequent segments for a matching piece
            boolean found = false;
            for (int j = i + 1; j < contourLines.size(); j++)
            {
                List<Point.Double> locations2 = contourLines.get(j);
                
                //  Assume that segments only contain 2 points
                Point.Double p2_start = locations2.get(0);
                Point.Double p2_end = locations2.get(locations2.size() - 1);
                
                if ( p1_end.equals(p2_start) )
                {
                    locations.add(p2_end);
                    
                    found = true;
                }
                else if ( p1_end.equals(p2_end) )
                {
                    locations.add(p2_start);
                    
                    found = true;                   
                }
                else if ( p1_start.equals(p2_end) )
                {
                    locations.add(0, p2_start);
                    
                    found = true;
                }
                else if ( p1_start.equals(p2_start) )
                {
                    locations.add(0, p2_end);
                    
                    found = true;
                }
                
                if ( found )
                {
                    contourLines.remove(j);
                    break;
                }
            }

            //  If added a segment, redo search
            if (found)
                i--;
        }
        
        //  Remove any polylines that are too short
        for (int i=contourLines.size(); --i>=0; )
        {
            if ( contourLines.get(i).size() < 6 )
                contourLines.remove(i);
        }
        
        return contourLines;
    }

    /**
     * Bounds a value to the range [0, aMaxValue]
     * @param aValue value to bound
     * @param aMaxValue upper end of the bounded range
     * @return 0 if aValue <= 0, aMaxValue if aValue >= aMaxValue, and
     *  aValue otherwise
     */
    private static int bound(int aValue, int aMaxValue)
    {
        if (aValue < 0)
            return 0;

        if (aValue > aMaxValue)
            return aMaxValue;

        return aValue;
    }

    /**
     * Fills in a double list with evenly spaced values based on the input collection.
     * The values will be evenly spaced starting at the smallest value in aValues.
     * Each value will be separated by the distance between the first two values in aValues.
     * There will be as many values in the output list as there are in aValues.
     * The output list will span essentially the same region as aValues, and will cover the
     * exact same region if aValues is already evenly spaced.
     * @param aValues create an evenly spaced list that spans essentially this region
     * @return evenly spaced set of values, sorted from lowest to highest
     */
    private static ArrayList<Double> fillDoubleList(Collection<Double> aValues)
    {

        ArrayList<Double> lSortedValues = new ArrayList<Double>();
        lSortedValues.addAll(aValues);
        java.util.Collections.sort(lSortedValues);

        double lFirstLat = lSortedValues.get(0);
        double lDeltaLat = (lSortedValues.size() == 1) ? 1.0 : Math.abs(lSortedValues.get(1) - lSortedValues.get(0));
        int lNumLat = lSortedValues.size();

        return fillDoubleList(lFirstLat, lDeltaLat, lNumLat);
    }
    /**
     * Fill in a double list with the specified sequence.
     * @param aBegin first number in the sequence
     * @param aDelta step between each successive number in the sequence
     * @param aNumber number of values in the sequence
     * @return list holding the described sequence
     */
    private static ArrayList<Double> fillDoubleList(double aBegin, double aDelta, int aNumber)
    {

        ArrayList<Double> lPoints = new ArrayList<Double>();

        double lValue = aBegin;
        for (int i = 0; i < aNumber; ++i)
        {
            lPoints.add(lValue);
            lValue += aDelta;
        }

        return lPoints;
    }
}
