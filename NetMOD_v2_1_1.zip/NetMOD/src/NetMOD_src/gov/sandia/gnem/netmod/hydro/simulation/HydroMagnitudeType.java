/**
 * 
 */
package gov.sandia.gnem.netmod.hydro.simulation;

import gov.sandia.gnem.netmod.simulation.MagnitudeType;

import java.util.Arrays;
import java.util.List;

/**
 * Magnitude types that are defined for hydro simulations
 * 
 * @author bjmerch
 *
 */
public class HydroMagnitudeType
{
    static private MagnitudeType[] _magnitudeTypes = new MagnitudeType[]{ MagnitudeType.KT, MagnitudeType.mb, MagnitudeType.Ms, MagnitudeType.mlg, MagnitudeType.ML, MagnitudeType.Mw }; 
    static private List<? extends MagnitudeType> _magnitudeTypesList = Arrays.asList(_magnitudeTypes);
    
    static public MagnitudeType[] values()
    {
        return _magnitudeTypes;
    }
    
    static public List<? extends MagnitudeType> getValuesList()
    {
        return _magnitudeTypesList;
    }

}
