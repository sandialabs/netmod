/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jhwm08;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import gov.sandia.gnem.netmod.io.IOUtility;

/**
 * @author aceaste
 */
public class HWM08_Data
{

	// Member Variables
	public int nbf = 0; // Count of basis terms per model level
	public int maxs = 0; // seasonal
	public int maxm = 0; // stationary
	public int maxl = 0; // migrating
	public int maxn = 0; // latitude

	public int splineOrder = 0; // p: B-splines order; 4 = cubic, 3 = quadratic, etc
	public int splineNodes = 0; // nlev: Number of B-spline nodes
	public int numEquations = 0; // nnode: Number of equations to solve B-spline; splineOrder + splineNodes

	public int[] nb; // total number of basis functions @ level
	public int[][] order; // spectral content @ level
	public double[] vnode; // Vertical Altitude Nodes
	public double[][] mparm; // Model Parameters

	private static HWM08_Data _instance = null;

	final public static HWM08_Data getInstance()
	{
		if (_instance == null)
		{
			_instance = new HWM08_Data();
		}

		return _instance;
	}

	private HWM08_Data()
	{
		int ncomp, numBytes;
		InputStream in = null;
		DataInputStream data = null;

		try
		{

			// in = new FileInputStream( defaultData );
			in = HWM08_Data.class.getResourceAsStream("/gov/sandia/gnem/netmod/infra/path/wind/hwm08/hwm071308e.dat");
			data = new DataInputStream(in);

			// Read number of bytes in this output stream
			numBytes = FortranDataReader.readInt(data);

			// Make sure that the file is in the correct format
			if (numBytes != 24)
			{
				throw new IOException();
			}
			nbf = FortranDataReader.readInt(data);
			maxs = FortranDataReader.readInt(data);
			maxm = FortranDataReader.readInt(data);
			maxl = FortranDataReader.readInt(data);
			maxn = FortranDataReader.readInt(data);
			ncomp = FortranDataReader.readInt(data);
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 24)
			{
				throw new IOException(); // Check against the expected trailer
			}

			// Read next stream
			numBytes = FortranDataReader.readInt(data);

			if (numBytes != 8)
			{
				throw new IOException();
			}
			splineNodes = FortranDataReader.readInt(data);
			splineOrder = FortranDataReader.readInt(data);
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 8)
			{
				throw new IOException();
			}

			// Initialize some variables
			numEquations = splineNodes + splineOrder;
			nb = new int[numEquations + 1];
			order = new int[numEquations + 1][ncomp];
			vnode = new double[numEquations + 1];
			mparm = new double[numEquations + 1][nbf];

			// Next stream
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 8 * vnode.length)
			{
				throw new IOException();
			}
			for (int i = 0; i < vnode.length; i++)
			{
				vnode[i] = FortranDataReader.readDouble(data);
			}
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 8 * vnode.length)
			{
				throw new IOException();
			}

			// Not sure why they did this, just copying what they did
			vnode[3] = 0.0;

			for (int i = 0; i < splineNodes - splineOrder; i++)
			{
				// Read one column of order
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 4 * ncomp)
				{
					throw new IOException();
				}
				for (int j = 0; j < ncomp; j++)
				{
					order[i][j] = FortranDataReader.readInt(data);
				}
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 4 * ncomp)
				{
					throw new IOException();
				}

				// Read nb
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 4)
				{
					throw new IOException();
				}
				nb[i] = FortranDataReader.readInt(data);
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 4)
				{
					throw new IOException();
				}

				// Read one column of mparm
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 8 * nbf)
				{
					throw new IOException();
				}
				for (int j = 0; j < nbf; j++)
				{
					mparm[i][j] = FortranDataReader.readDouble(data);
				}
				numBytes = FortranDataReader.readInt(data);
				if (numBytes != 8 * nbf)
				{
					throw new IOException();
				}
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( data != null )
				IOUtility.safeClose(data);
			if ( in != null )
				IOUtility.safeClose(in);
		}
	}

}
