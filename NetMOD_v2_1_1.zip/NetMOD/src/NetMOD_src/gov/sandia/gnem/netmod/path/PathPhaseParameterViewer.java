/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.path.codadecay.CodaDecay;
import gov.sandia.gnem.netmod.plugin.PhaseParameterViewer;
import gov.sandia.gnem.netmod.simulation.Phase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collection;

/**
 * @author bjmerch
 *
 */
class PathPhaseParameterViewer extends PhaseParameterViewer<PathPhaseParameter>
{
    private JLabel _phase1 = new JLabel("P:");
    private JLabel _phase2 = new JLabel("P:");
    private JFormattedTextField _timeWindowLength = new JFormattedTextField(new DoubleRangeFormatter());
    private JFormattedTextField _lowGroupVelocity = new JFormattedTextField(new DoubleRangeFormatter());
    private JFormattedTextField _highGroupVelocity = new JFormattedTextField(new DoubleRangeFormatter());

    private FileField _codaDecayFile = new FileField("Coda Decay File", createViewCodaDecayButton());
    private JComboBox _priorPhases;
    
    PathPhaseParameterViewer(PathPhaseParameter nmc, Collection<? extends Phase> phases)
    {
        super(nmc);
        
        _priorPhases = new JComboBox(phases.toArray());
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored after updating
        registerControls(_timeWindowLength, _lowGroupVelocity, _highGroupVelocity, _codaDecayFile, _priorPhases);
    }

    @Override
    public void apply(PathPhaseParameter nmc)
    {
        nmc.setTimeWindowLength(((Number) _timeWindowLength.getValue()).doubleValue());
        nmc.setLowGroupVelocity(((Number) _lowGroupVelocity.getValue()).doubleValue());
        nmc.setHighGroupVelocity(((Number) _highGroupVelocity.getValue()).doubleValue());
        nmc.setCodaDecayFile(_codaDecayFile.getText());
        nmc.setPriorPhase((Phase) _priorPhases.getSelectedItem());
    }

    @Override
    public JPanel getHeader1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "), 
                new JLabel("<html>Prior<br>Phase</html>"), 
                new JLabel("<html><br>Coda Decay Files</html>"));
        
        return panel;
    }

    @Override
    public JPanel getPanel1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        GUIUtility.addRow(panel, _phase2, _priorPhases, _codaDecayFile);
        
        return panel;
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Add a listener to disable velocity fields when a valid window length is set
            _timeWindowLength.addPropertyChangeListener("value", new PropertyChangeListener()
            {
                @Override
                public void propertyChange(PropertyChangeEvent arg0)
                {
                    double windowLength = ((Number) _timeWindowLength.getValue()).doubleValue();

                    boolean enabled = (windowLength < 0);
                    _lowGroupVelocity.setEnabled(enabled);
                    _highGroupVelocity.setEnabled(enabled);
                }
            });

            //  Setup the phase parameter panel
            GUIUtility.addRow(panel, _phase1, _timeWindowLength, _lowGroupVelocity, _highGroupVelocity);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public JPanel getHeader()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "),
                new JLabel("<html>Time Window (sec)</html>"),
                new JLabel("<html>Low Group Velocity (km/sec)</html"),
                new JLabel("<html>High Group Velocity (km/sec)</html>"));
        
        return panel;
    }

    @Override
    public void reset(PathPhaseParameter nmc)
    {
        _phase1.setText(nmc.getPhase() + ":");
        _phase2.setText(nmc.getPhase() + ":");
        _timeWindowLength.setValue(nmc.getTimeWindowLength());
        _lowGroupVelocity.setValue(nmc.getLowGroupVelocity());
        _highGroupVelocity.setValue(nmc.getHighGroupVelocity());
        _codaDecayFile.setText(nmc.getCodaDecayFile());
        _priorPhases.setSelectedItem(nmc.getPriorPhase());
    }

    private JButton createViewCodaDecayButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Attenuation");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                //  Get the attenuation object
                CodaDecay codaDecay = _nmc.getCodaDecay();
                if (codaDecay == null || !codaDecay.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) codaDecay.getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Coda Decay Rate - " + codaDecay.getName());
            }
        });

        return button;
    }
}
