/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.media;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuation;
import gov.sandia.gnem.netmod.plugin.PhaseParameterViewer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 *
 */
class PathMediaPhaseParameterViewer extends PhaseParameterViewer<PathMediaPhaseParameter>
{
    private JLabel _phase1 = new JLabel("P:");
    private JLabel _phase2 = new JLabel("P:");
    private JFormattedTextField _receiverCorrection = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _sourceCorrection = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _stddevAttenuation = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private FileField _attenuationFile = new FileField("Amplitude Attenuation File", createViewAttenuationButton());

    PathMediaPhaseParameterViewer(PathMediaPhaseParameter nmc)
    {
        super(nmc);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored
        registerControls(_sourceCorrection, _receiverCorrection, _stddevAttenuation, _attenuationFile);
    }

    @Override
    public void apply(PathMediaPhaseParameter nmc)
    {
        nmc.setStddevAttenuation(((Number) _stddevAttenuation.getValue()).doubleValue());
        nmc.setLogSourceCorrection(((Number) _sourceCorrection.getValue()).doubleValue());
        nmc.setLogReceiverCorrection(((Number) _receiverCorrection.getValue()).doubleValue());
        nmc.setAmplitudeAttenuationFile(_attenuationFile.getText());
    }

    @Override
    public JPanel getHeader1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel, new JLabel(" "), new JLabel("Amplitude Attenuation Files:"));
        
        return panel;
    }

    @Override
    public JPanel getPanel1()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        GUIUtility.addRow(panel, _phase2, _attenuationFile);
        
        return panel;
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            _sourceCorrection.setToolTipText("Teleseismic Source Correction (log10)");
            _receiverCorrection.setToolTipText("Teleseismic Receiver Correction (log10)");
            _stddevAttenuation.setToolTipText("Standard Deviation of Attenuation (log10)");

            //  Setup the panel
            GUIUtility.addRow(panel, _phase1, _sourceCorrection, _receiverCorrection, _stddevAttenuation);
            
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public JPanel getHeader()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        
        GUIUtility.addRow(panel,
                new JLabel(" "),
                new JLabel("<html>Teleseismic Source Correction</html>"),
                new JLabel("<html>Teleseismic Receiver Correction</html>"),
                new JLabel("<html>Attenuation Standard Deviation</html>"));
        
        return panel;
    }

    @Override
    public void reset(PathMediaPhaseParameter nmc)
    {
        _phase1.setText(nmc.getPhase() + ":");
        _phase2.setText(nmc.getPhase() + ":");
        _stddevAttenuation.setValue(nmc.getStddevAttenuation());
        _sourceCorrection.setValue(nmc.getLogSourceCorrection());
        _receiverCorrection.setValue(nmc.getLogReceiverCorrection());
        _attenuationFile.setText(nmc.getAmplitudeAttenuationFile());
    }

    private JButton createViewAttenuationButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Attenuation");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                //  Get the attenuation object
                AmplitudeAttenuation amplitudeAttenuation = _nmc.getAmplitudeAttenuation();
                if (amplitudeAttenuation == null || !amplitudeAttenuation.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) amplitudeAttenuation
                        .getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Amplitude Attenuation - " + amplitudeAttenuation.getName());
            }
        });

        return button;
    }
}
