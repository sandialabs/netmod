/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.codadecay;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @author bjmerch
 *
 */
public class CodaDecayTextFile extends AbstractNetModFile implements CodaDecay
{
	public static final Double NO_RESULT = 1.0;
	public static final SpectraDouble NO_RESULT_SPECTRA = new SpectraDouble(NO_RESULT);

	private static final String _type = "Coda Decay Text File";

    //  Register the plugin
    static
    {
        CodaDecayPlugin.getPlugin().registerComponent(_type, CodaDecayTextFile.class, true);
    }

    private double[] _distances = null;
    private double[] _codaDecay = null;

    /*
     * Cache requested codadecay
     */
    transient private CacheMap<Distance, SpectraDouble> _cache = new CacheMap<Distance, SpectraDouble>(CacheMap.CACHE_DISTANCE);

    public CodaDecayTextFile(NetModComponent parent)
    {
        super(parent, _type);
    }

    @Override
    public void clearCache()
    {
        super.clearCache();

        _distances = null;
        _codaDecay = null;
        _cache.clear();
    }

    public double[] getCodaDecay()
    {
        //  Synchronize around read check to avoid multi-threaded collisions
        synchronized (this)
        {
            if (_codaDecay == null)
                read();
        }

        return _codaDecay;
    }

    @Override
    public SpectraDouble getCodaDecay(Distance distance, Frequency frequency)
    {
        startIntrospection();
        recordIntrospection("Coda Decay from file: '", getFilename(), "'");
        recordIntrospection("at distance: ", distance);

        /*
         * Check for a cached value, synchronized
         */
        SpectraDouble decay = _cache.get(distance);
        if (decay != null)
        {
            recordIntrospection("Coda Decay: ", decay);
            stopIntrospection();
            return decay;
        }

        double[] distances = getDistances();
        if (distances == null || distances.length == 0)
        {
            decay = NO_RESULT_SPECTRA;
            
			recordIntrospection("No coda decay defined");
			recordIntrospection("Coda decay: ", decay);
            statusIntrospection(StatusType.WARNING);
            stopIntrospection();

            return decay;
        }

        //  Duplicate a change present in the partial C implementation of NetSim
        double value = NO_RESULT;
        if (Property.NETSIM_C_INTERP.getBooleanValue())
            value = Interpolation.interpolateLinear(distances, _codaDecay, distance.getDistance());
        //  Fortran method
        else
            value = Interpolation.interpolateQuadratic(distances, _codaDecay, distance.getDistance());

        decay = new SpectraDouble(value);

        recordIntrospection("Coda Decay: ", decay);
        stopIntrospection();

        //  Cache the result
        _cache.put(distance, decay);
        
        return decay;
    }

    /**
     * @return
     */
    public double[] getDistances()
    {
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_distances == null)
				read();
		}

        return _distances;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new CodaDecayTextFileViewer(this);
    }

    @Override
    public boolean isAvailable()
    {
        return getDistances().length > 0;
    }

    @Override
    public boolean isFor(Object o)
    {
        //  Extract a file from the object
        File file = null;
        if (o instanceof File)
            file = (File) o;
        else if (o instanceof String)
            file = IOUtility.openFile((String) o);

        //  Check if the file exists
        if (file == null || !file.exists())
            return false;

        //  Coda Decay Text Files end with ".nfc"
        return IOUtility.endsWith(file, ".nfc");
    }

    @Override
    public boolean read()
    {
        boolean value = false;

        //  Synchronize on the type to prevent errors if simultaneously reading from the same file
        synchronized (_type)
        {
            FileInputStream fis = null;
            Scanner fin = null;

            try
            {
                // Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);
				
                setName(fin.nextLine());
                
                //  Skip comments
                skipComments(fin);

                // Read in all of the distance/decay rate pairs
                int N = fin.nextInt();
                
                skipComments(fin);
                
                _distances = new double[N];
                _codaDecay = new double[N];
                for (int i = 0; i < N; ++i)
                {
                    _distances[i] = fin.nextDouble();
                    _codaDecay[i] = fin.nextDouble();
                }

                value = false;
                setDirty(false);
            }
            catch (Exception e)
            {
                if (!getFilename().isEmpty())
                {
                    System.out.println("Unable to read coda decay file: '" + getFilename() + "'");
                    e.printStackTrace();
                }
                _distances = new double[0];
                _codaDecay = new double[0];
            }
            finally
            {
    			if ( fin != null )
    				IOUtility.safeClose(fin);
    			if ( fis != null )
    				IOUtility.safeClose(fis);
            }
        }

        return value;
    }

    /**
     * Remove the coda decay value at the provided distance
     * 
     * @param distance
     */
    public void removeCodaDecay(double distance)
    {
        //  Find the index of the existing noise
        int index = Arrays.binarySearch(getDistances(), distance);
        if (index < 0)
            return;

        //  Create copies of the arrays, excluding the index
        _distances = removeIndex(_distances, index);
        _codaDecay = removeIndex(_codaDecay, index);

        _cache.clear();
        setDirty(true);
    }

    /**
     * Set the coda decay value at the provided distance
     * 
     * @param distance
     * @param decay
     */
    public void setCodaDecay(double distance, double decay)
    {
        double[] distances = getDistances();
        int index = findIndex(distances, distance);

        if (index < distances.length && distances[index] == distance)
        {
            _codaDecay[index] = decay;
        }
        else
        {
            _distances = insertIndex(_distances, index, distance);
            _codaDecay = insertIndex(_codaDecay, index, decay);
        }

        _cache.clear();
        setDirty(true);
    }

    @Override
    public boolean write()
    {
        // Get the File to write to
        File file = IOUtility.openFile(getFilename());

        //  Don't write if not needed
        if (!getDirty() && file.exists())
            return true;

        //  Test whether there is no file to write to
        if (isEmpty(file.getPath()))
            return true;

        PrintWriter fout = null;
        try
        {
            // Write the number of distances
            double[] distances = getDistances();
            double[] codaDecay = getCodaDecay();

            //  Ensure the path to the file exists
            file.getParentFile().mkdirs();

            // Open the file and write the title
            fout = new PrintWriter(new FileWriter(file));
            fout.println(getName());

            int N = distances.length;
            fout.println("# Number of distances");
            fout.println(String.format("\t%d", N));

            // Write the distance/decay rate pairs
            fout.println("# Distance \tCoda Decay");
            for (int i = 0; i < N; i++)
                fout.println(String.format("\t%7.3f\t%7.3f", distances[i], codaDecay[i]));

            setDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        finally
        {
        	if ( fout != null )
        		IOUtility.safeClose(fout);
        }

        return true;
    }

	public double[] getFrequencies()
	{
		return new double[0];
	}
}
