/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import java.util.Arrays;
import java.util.List;

/**
 * @author bjmerch
 *
 */
abstract public class AbstractPDF implements PDF
{
    public static PDF addTo(PDF pdf, PDF... pdfs)
    {
        //  Start with this PDF
        PDF sum = pdf;
        
        //  Sum all of the provided PDFs
        for (PDF pdf2 : pdfs)
            sum = new SumPDF(sum, pdf2);
        
        return sum;
    }
    
    /**
     * Function for subtracting two arbitrary PDFs.
     * 
     * @param pdf1
     * @param pdf2
     * @return
     */
    public static PDF minus(PDF pdf1, PDF pdf2)
    {
    	//  Convert PDF1 to non-parametric
    	NonParametricCDF npCDF1 = null;
    	if ( pdf1 instanceof NonParametricCDF )
    		npCDF1 = (NonParametricCDF) pdf1;
    	else
    	{
            int N = 1000;
            double delta = ( pdf1.getMax() - pdf1.getMin() ) / ( N - 1 );
            
            npCDF1 = new NonParametricCDF(pdf1, delta);
    	}

    	//  Convert PDF2 to non-parametric
    	NonParametricCDF npCDF2 = null;
    	if ( pdf2 instanceof NonParametricCDF )
    		npCDF2 = (NonParametricCDF) pdf2;
    	else
    	{
            int N = 1000;
            double delta = ( pdf2.getMax() - pdf2.getMin() ) / ( N - 1 );
            
            npCDF2 = new NonParametricCDF(pdf2, delta);
    	}
    	
    	
    	return npCDF1.add(npCDF2.scale(-1.0));
    }

    /**
     * Sum the provided PDFs
     * 
     * @param pdfs
     * @return
     */
    public static PDF sum(PDF... pdfs)
    {
        if ( pdfs.length == 0 )
            return NormalPDF.ZERO;
        else if ( pdfs.length == 1 )
            return pdfs[0];
        
        return pdfs[0].add(Arrays.copyOfRange(pdfs, 1,  pdfs.length));
    }

    /**
     * Sum the provided PDFs
     * 
     * @param pdfs
     * @return
     */
    public static PDF sum(List<PDF> pdfs)
    {
        return sum(pdfs.toArray(new PDF[pdfs.size()]));
    }
    
    /**
     * Implements the NetSim probability function (prob.f) which
     * is the SNAP/D probf function.   
     * @param x
     * @return
     */
    public static final double probability_normal(double x) 
    {
        double t = Math.abs(x);
        double p = 0;
        if ( t < 25 )
        {
            double q = ((((t * 0.00063419 - 0.00010754) * t + 0.01057706) * t + 0.04833145) * t + 0.10882473) * t + 1.09050773;
            q = 1.0 / (q * q);
            q = q * q;
            p = q * q;
            
            //  (1.0/(((((t*0.00063419 - 0.00010754)*t+0.01057706)*t+0.04833145)*t+0.10882473)*t + 1.09050773))^8
        }
        
        if ( x > 0 )
            p = 1 - p;
        
        return p;
    }

    /*
     * Coefficients for estimating the error function
     */
	private static final double	erf_a0	= -1.26551223;
	private static final double	erf_a1	= 1.00002368;
	private static final double	erf_a2	= 0.37409196;
	private static final double	erf_a3	= 0.09678418;
	private static final double	erf_a4	= -0.18628806;
	private static final double	erf_a5	= 0.27886807;
	private static final double	erf_a6	= -1.13520398;
	private static final double	erf_a7	= 1.48851587;
	private static final double	erf_a8	= -0.82215223;
	private static final double	erf_a9	= 0.17087277;
    
    /**
     * Estimate the error function for x.
     * 
     * Parameters obtained from 
     * "Numerical Recipes in Fortran 77: The Art of Scientific Computing (ISBN 0-521-43064-X), 1992, page 214, Cambridge University Press" 
     * 
     * @param x
     * @return
     */
    protected static final double erf(double x)
    {
    	if ( x < 0 )
    		return - erf(-x);

    	double t = 1.0 / ( 1.0 + 0.5 * x);
        
        return 1.0 - t * Math.exp(-x*x + erf_a0 + t * ( erf_a1 + t * ( erf_a2 + t * ( erf_a3 + t * ( erf_a4 + t * ( erf_a5 + t * ( erf_a6 + t * ( erf_a7 + t * ( erf_a8 + t * erf_a9 )))))))));
    }
    
    private static final double erf_inv_a = 0.147;
    private static final double erf_inv_tmp1 = 2 / ( Math.PI * erf_inv_a );
    
    /**
     * Estimate the inverse error function for x.
     * 
     * 
     * @param x
     * @return
     */
    protected static final double erf_inverse(double x)
    {
        double tmp1 = Math.log(1 - x * x);
        double tmp2 = erf_inv_tmp1 + tmp1 / 2;
        
        return Math.signum(x) * Math.sqrt( Math.sqrt(tmp2 * tmp2 - tmp1 / erf_inv_a) - tmp2);
    }


    @Override
    public PDF add(double value)
    {
        return scale(1.0, value);
    }
    
    @Override
    public PDF add(double x, PDF... pdfs)
    {
        return addTo(this, pdfs).add(x);
    }

    @Override
    public PDF add(PDF... pdfs)
    {
    	return add(0.0, pdfs);
    }

    @Override
    public double computeProbabilityGTE(double x)
    {
        return 1.0 - computeCumulativeDistribution(x);
    }

    @Override
    public double getVariance()
    {
        double sd = getStandardDeviation();
        
        return sd * sd;
    }

    @Override
    public PDF log10()
    {
        return new FunctionPDF(this,
                new Function()
        {
            @Override
            public double derivative(double x)
            {
                return Math.log10(Math.E) / x;
            }
            
            @Override
            public double function(double x)
            {
                return Math.log10(x);
            }

            @Override
            public double inverse(double y)
            {
                return Math.pow(10, y);
            }
            
            @Override
            public String toString()
            {
                return "log10()";
            }
        });
    }

    @Override
    public PDF minus(PDF pdf)
    {
        return minus(this, pdf);
    }
    
    @Override
    public PDF pow10()
    {
        return new FunctionPDF(this,
                new Function()
        {
            @Override
            public double derivative(double x)
            {
                return _log10Conversion * function(x);
            }
            
            @Override
            public double function(double x)
            {
                return Math.pow(10, x);
            }

            @Override
            public double inverse(double y)
            {
                return Math.log10(y);
            }
            
            @Override
            public String toString()
            {
                return "10^";
            }
        });
    }

    @Override
    public PDF scale(double x)
    {
        return scale(x, 0.0);
    }
    @Override
    public PDF scale(final double a, final double b)
    {
        return new FunctionPDF(this,
                new Function()
        {
            @Override
            public double derivative(double x)
            {
                return a;
            }
            
            @Override
            public double function(double x)
            {
                return a * x + b;
            }

            @Override
            public double inverse(double y)
            {
                return (y - b) / a;
            }
            
            @Override
            public String toString()
            {
                return a + " * value + " + b;
            }
        });
    }

    @Override
    public String toString()
    {
        return getDescription();
    }
}
