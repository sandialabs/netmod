package gov.sandia.gnem.netmod.path.attenuation;


import gov.sandia.gnem.netmod.gui.*;

import javax.swing.*;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.LogAxis;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.GrayPaintScale;
import org.jfree.chart.renderer.LookupPaintScale;
import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.chart.title.PaintScaleLegend;
import org.jfree.data.xy.AbstractXYZDataset;
import org.jfree.ui.RectangleEdge;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.IndexColorModel;

public class AmplitudeAttenuation2DQViewer extends NetModComponentViewer<AmplitudeAttenuation2DQ> {

    private class AttenuationDataset extends AbstractXYZDataset 
    {
        int _frequency_index = 0;
        private AmplitudeAttenuation2DQ _attenuation = null;

        @Override
        public int getItemCount(int series) 
        {
        	if ( _attenuation == null )
        		return 0;

        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	
        	return NLat * NLon;
        }

		@Override
		public int getSeriesCount()
		{
			return 1;
		}

        @Override
        public Comparable getSeriesKey(int series) 
        {
            return "Frequency = " + _attenuation.getFrequencies()[_frequency_index] + " Hz";
        }

        @Override
        public Number getX(int series, int item) 
        {
        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	int NFreq = _attenuation.getNFreq();

            int lat_index = item % NLat;
            int lon_index = item / NLat;
            
            return _attenuation.getLon()[lon_index];
        }

        @Override
        public Number getY(int series, int item) 
        {
        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	int NFreq = _attenuation.getNFreq();

            int lat_index = item % NLat;
            int lon_index = item / NLat;
            
            return _attenuation.getLat()[lat_index];
        }

        @Override
        public Number getZ(int series, int item) 
        {
        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	int NFreq = _attenuation.getNFreq();

            int lat_index = item % NLat;
            int lon_index = item / NLat;

            double value = _attenuation.getQ()[lon_index][lat_index][_frequency_index];
            
            if (Double.isFinite(value))
            	return value;
            
            return 0;
		}

		public void setAttenuation(AmplitudeAttenuation2DQ attenuation, int frequency_index)
		{
			_attenuation = attenuation;
			_frequency_index = frequency_index;
			fireDatasetChanged();
		}
	}

    private class QTableModel extends NetMODTable.NetMODTableModel 
    {
        private AmplitudeAttenuation2DQ _attenuation = null;

        @Override
        public int getColumnCount() {
            if (_attenuation == null)
                return 1;
            return _attenuation.getFrequencies().length + 2;
        }

        public String getColumnName(int column) {
            if (column == 0)
                return "<html>Longitude<br>(degrees)</html>";
            else if (column == 1)
                return "<html>Latitude<br>(degrees)</html>";
            else
                return Double.toString(_attenuation.getFrequencies()[column - 2]) + " Hz";
        }

        @Override
        public int getRowCount() 
        {
            return (_attenuation == null ? 0 : _attenuation.getNLat() * _attenuation.getNLon()) + 10;
        }

        @Override
        public Object getValueAt(int row, int column) 
        {
        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	int NFreq = _attenuation.getNFreq();
        	
            if (_attenuation == null || row >= NLat * NLon || column > NFreq+2)
                return "";

            int lat_index = row % NLat;
            int lon_index = row / NLat;

            if (column == 0)
            	return _attenuation.getLon()[lon_index];
            else if ( column == 1 )
                return _attenuation.getLat()[lat_index];
            else 
            {
                int f_index = column - 2;
                		
                double q = _attenuation.getQ()[lon_index][lat_index][f_index];
                
                return q;
            }
        }

        @Override
        public boolean isCellEditable(int r, int c) 
        {
        	return c > 1;
        }

        public void setAttenuation(AmplitudeAttenuation2DQ attenuation) 
        {
            _attenuation = attenuation;
            fireTableStructureChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
        	int NLat = _attenuation.getNLat();
        	int NLon = _attenuation.getNLon();
        	int NFreq = _attenuation.getNFreq();
        	
            if (aValue == null || row >= NLat * NLon || column < 2 || column > NFreq+2)
                return;

            int lat_index = row % NLat;
            int lon_index = row / NLat;

            {
                int f_index = column - 2;
                		
                double q = Double.parseDouble(aValue.toString());
                _attenuation.getQ()[lon_index][lat_index][f_index] = q;
            }     

            fireTableDataChanged();
        }

		@Override
		public void remove(int[] rows)
		{
			// TODO Auto-generated method stub
			
		}

    }

    private ChartViewer _chartViewer = new ChartViewer();
    private QTableModel _tableModel = new QTableModel();
    private NetMODTable _table = new NetMODTable(_tableModel);

	public AmplitudeAttenuation2DQViewer(AmplitudeAttenuation2DQ nmc)
	{
		super(nmc, false, false, false);
		setExpanded(true);
		reset(nmc);
	}

	@Override
	public void apply(AmplitudeAttenuation2DQ nmc)
	{

	}

	@Override
	public JPanel getExpandedPanel()
	{
		if (_expandedPanel == null)
		{
			JPanel panel = new JPanel(new GridBagLayout());

			// Configure the chart viewer
			XYPlot plot = _chartViewer.getPlot();
			plot.getDomainAxis().setLabel("Longitude (deg)");
			plot.getRangeAxis().setLabel("Latitude (deg)");
			
			//  Force domain and range to be equal
            _chartViewer.getChartPanel().addComponentListener(new ComponentAdapter()
            {
                public void componentResized(ComponentEvent e)
                {
                    rescaleMap();
                }
            });
            
            plot.getDomainAxis().addChangeListener(new AxisChangeListener()
            {

                @Override
                public void axisChanged(AxisChangeEvent arg0)
                {
                    rescaleMap();
                }
                
            });
            
            plot.getRangeAxis().addChangeListener(new AxisChangeListener()
            {

                @Override
                public void axisChanged(AxisChangeEvent arg0)
                {
                    rescaleMap();
                }
                
            });
			
			

			// Setup the table
			JScrollPane sp = new JScrollPane(_table);
			//sp.setCorner(ScrollPaneConstants.UPPER_RIGHT_CORNER, createAddFrequencyButton());
			sp.getVerticalScrollBar()
					.setPreferredSize(new Dimension(Math.max(20, Icons.ADD.getIcon().getIconWidth()), 0));

			JPanel spPanel = new JPanel(new BorderLayout());
			spPanel.add(BorderLayout.CENTER, sp);
			spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
			spPanel.setPreferredSize(new Dimension(400, 0));

			// Arrange the chart viewer and table
			JSplitPane splitPane = new JSplitPane();
			splitPane.setBorder(null);
			splitPane.setContinuousLayout(true);
			splitPane.setDividerLocation(0.6);
			splitPane.setOneTouchExpandable(false);
			splitPane.setResizeWeight(0.5);
			splitPane.setLeftComponent(_chartViewer);
			splitPane.setRightComponent(spPanel);

			// Setup the panel
			GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);

			_expandedPanel = panel;
		}

		return _expandedPanel;
	}
	
    /**
     * Rescale the map to keep the axes square
     * 
     */
    private void rescaleMap()
    {
        Dimension dim = _chartViewer.getChartPanel().getSize();

        XYPlot plot = _chartViewer.getPlot();
        ValueAxis domain = plot.getDomainAxis();
        ValueAxis range = plot.getRangeAxis();

        double xResolution = domain.getRange().getLength() / dim.width;
        double yResolution = range.getRange().getLength() / dim.height;

        double resolution = Math.max(xResolution, yResolution);

        //  Set the map dimensions
        int height = (int) (range.getRange().getLength() / resolution);
        int width = (int) (domain.getRange().getLength() / resolution);

        _chartViewer.setSize(width, height);
        
        _chartViewer.getChart().fireChartChanged();
        SwingUtilities.updateComponentTreeUI(_chartViewer.getChartPanel());
    }

	@Override
    public void reset(AmplitudeAttenuation2DQ nmc) 
	{
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the datasets
        XYPlot plot = (XYPlot) _chartViewer.getChart().getPlot();
        for (int i = 0; i < 100; i++)
            plot.setDataset(i, null);
        double[] f = nmc.getFrequencies();

        double[][][] q = nmc.getQ();
        int NLat = nmc.getNLat();
        int NLon = nmc.getNLon();

        //  Determine the min/max range of values
        double min = Double.MAX_VALUE;
        double max = 0;
        for (int i = 0; i < f.length; i++) 
        	for (int j=0; j<NLon; j++)
        		for (int k=0; k<NLat; k++)
        		{
        			double value = q[j][k][i];
                	if (Double.isFinite(value) && value > 0)
                	{
                		min = Math.min(min, value);
                		max = Math.max(max, value);	
                	}    			
        		}
        
        double log_min = Math.log10(min);
        double log_max = Math.log10(max);

        //  Build a color scale
        LookupPaintScale scale = new LookupPaintScale(min, max, Color.BLACK);
        IndexColorModel jet = ColorModel.JET.getColorModel();
        int N = jet.getMapSize();
        double log_delta = (log_max-log_min)/(N-1.0);
        for (int i=0; i<N; i++)
        {
        	double value = Math.pow(10, log_min + i * log_delta);
        	scale.add(value, new Color(jet.getRed(i), jet.getGreen(i), jet.getBlue(i), jet.getAlpha(i)));
        }
        
        //  Build a legend for the color scale
        PaintScaleLegend psl = new PaintScaleLegend(scale, new FrequencyLogAxis("Q"));
        
        psl.setPosition(RectangleEdge.RIGHT);
        psl.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        psl.setMargin(50.0, 20.0, 80.0, 0.0);
        
        JFreeChart chart = _chartViewer.getChart();
        for (int i=0; i<chart.getSubtitleCount(); i++)
        	chart.removeSubtitle(chart.getSubtitle(i));
        chart.addSubtitle(psl);
        
        //  Create datasets and renderers for each frequency
        for (int i = f.length-1; i < f.length; i++) 
        {
            AmplitudeAttenuation2DQViewer.AttenuationDataset dataset = new AmplitudeAttenuation2DQViewer.AttenuationDataset();
            dataset.setAttenuation(nmc, i);
            
            XYBlockRenderer renderer = new XYBlockRenderer();
            renderer.setPaintScale(scale);
            renderer.setSeriesToolTipGenerator(0, _chartViewer.getToolTipGenerator());
            
            plot.setDataset(i, dataset);
            plot.setRenderer(i, renderer);
            
            break;
        }

        //  Update the table
        _tableModel.setAttenuation(nmc);
    }
//
//    private JButton createAddFrequencyButton() {
//        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
//        button.setToolTipText("Add Frequency");
//        button.setMargin(new Insets(0, 0, 0, 0));
//        button.setBorder(null);
//        button.setContentAreaFilled(false);
//
//        button.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent arg0) {
//                String value = JOptionPane.showInputDialog(AmplitudeAttenuation2DQViewer.this, "Frequency (Hz) :");
//                if (value == null)
//                    return;
//
//                double frequency = Double.parseDouble(value);
//                _nmc.setAttenuation(_nmc.getDistances()[0], frequency, 0);
//                refresh();
//            }
//        });
//
//        return button;
//    }

}
