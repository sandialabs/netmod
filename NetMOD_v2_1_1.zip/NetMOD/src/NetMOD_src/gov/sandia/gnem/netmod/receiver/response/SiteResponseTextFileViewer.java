/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.response;

import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.ChartViewer.AxisScale;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetMODTable;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.AbstractXYDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * @author bjmerch
 *
 */
public class SiteResponseTextFileViewer extends NetModComponentViewer<SiteResponseTextFile>
{
    private class ResponseDataset extends AbstractXYDataset
    {
        int N = 100;
        private SiteResponseTextFile _response = null;

        @Override
        public int getItemCount(int series)
        {
            if ( series == 0 )
                return (_response == null ? 0 : _response.getFrequencies().length);
            else
                return (_response == null ? 0 : N * (_response.getFrequencies().length - 1 ) + 1);
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable<String> getSeriesKey(int series)
        {
            return "Response";
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _response.getFrequencies()[item];
            else
            {
                int index = item / N;
                double[] f = _response.getFrequencies();

                if (index == f.length - 1)
                    return f[index];

                return Interpolation.linear(index * N, (index + 1) * N, f[index], f[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            return getResponse(series, item);
        }

        public void setResponse(SiteResponseTextFile response)
        {
            _response = response;
            fireDatasetChanged();
        }

        private double getResponse(int series, int item)
        {
            return _response.getResponse(new DiscreteFrequency(getX(series, item).doubleValue())).getValue(0);
        }
    }
    
    private class ResponseTableModel extends NetMODTableModel
    {
        private SiteResponseTextFile _response = null;

        @Override
        public int getColumnCount()
        {
            return 2;
        }

        public String getColumnName(int column)
        {
            if (column == 0)
                return "Frequency (Hz)";
            else
                return "Mean (log10)";
        }

        @Override
        public int getRowCount()
        {
            return (_response == null ? 0 : _response.getFrequencies().length) + 10;
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_response == null || row >= _response.getFrequencies().length)
                return "";

            double f = _response.getFrequencies()[row];

            if (column == 0)
                return f;
            else if (column == 1)
                return _response.getResponse(new DiscreteFrequency(f));

            return 0;
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return true;
        }

        public void setResponse(SiteResponseTextFile response)
        {
            _response = response;
            fireTableDataChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
            if (aValue == null || _response == null)
                return;

            try
            {
                double f = 0;
                if (row < _response.getFrequencies().length)
                    f = _response.getFrequencies()[row];
                double response = _response.getResponse(new DiscreteFrequency(f)).getValue(0);

                if (column == 0)
                {
                    _response.removeResponse(f);
                    f = Double.parseDouble(aValue.toString());
                }
                else if (column == 1)
                    response = Double.parseDouble(aValue.toString());

                _response.setResponse(f, response);

                fireTableDataChanged();
                if (_dataset != null)
                    _dataset.setResponse(_response);

                //  Keep row selected
                int index = _response.findIndex(_response.getFrequencies(), f);
                _table.getSelectionModel().setSelectionInterval(index, index);
                _table.scrollRectToVisible(_table.getCellRect(index, 0, true));
            }
            catch (Exception e)
            {
            }
        }

        @Override
        public void remove(int[] rows)
        {
            for (int row : rows)
            {
                double f = _response.getFrequencies()[row];
                _response.removeResponse(f);
            }
        }
    }

    private ChartViewer _chartViewer = new ChartViewer();
    private ResponseDataset _dataset = new ResponseDataset();

    private ResponseTableModel _tableModel = new ResponseTableModel();

    private NetMODTable _table = new NetMODTable(_tableModel);
	private JComboBox _frequencyComboBox;
	private JComboBox _percentileComboBox;

    public SiteResponseTextFileViewer(SiteResponseTextFile nmc)
    {
        super(nmc, false, false, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);
    }

    @Override
    public void apply(SiteResponseTextFile nmc)
    {
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Configure the chart viewer
            _chartViewer.setXScale(AxisScale.LOG);
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Frequency (Hz)");
            plot.getRangeAxis().setLabel("Amplitude Response (log10)");

            // Response Dataset
            plot.setDataset(0, _dataset);

//            //  Configure the renderer
//            DeviationRenderer devRenderer = new DeviationRenderer(true, false);
//            devRenderer.setAlpha(0.5f);
//            devRenderer.setBaseToolTipGenerator(_chartViewer.getToolTipGenerator());
//            
//            devRenderer.setSeriesPaint(0, _chartViewer.getLinePaint(0));
//            devRenderer.setSeriesFillPaint(0, _chartViewer.getLinePaint(0));
//            devRenderer.setSeriesShape(0,  new Ellipse2D.Double(-3, -3, 7, 7));
//            devRenderer.setSeriesShapesVisible(0, true);
//            devRenderer.setSeriesLinesVisible(0, false);
//            devRenderer.setSeriesVisibleInLegend(0, false);
//            
//            devRenderer.setSeriesPaint(1, ((Color) _chartViewer.getLinePaint(0)));
//            devRenderer.setSeriesFillPaint(1, _chartViewer.getLinePaint(0));
//            devRenderer.setSeriesStroke(1, new BasicStroke(_chartViewer.getLineWidth()));
//            plot.setRenderer(0, devRenderer);

            //  Setup the table
            _table.addKeyListener(new KeyAdapter()
            {
                public void keyReleased(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                    {
                        // Only grab the rows with BOTH cells selected
                        int[] rows = _table.getSelectedRows();

                        double[] frequencies = _nmc.getFrequencies();
                        for (int i = 0; i < rows.length; i++)
                            _nmc.removeResponse(frequencies[rows[i]]);

                        reset(_nmc);
                    }
                }
            });

            //  Setup the combo-box of frequencies and percentiles
            JPanel comboboxPanel = new JPanel(new GridBagLayout());

            _frequencyComboBox = new JComboBox(GUIUtility.toArrayDoubles(_nmc.getFrequencies()));
            if ( _frequencyComboBox.getItemCount() > 0 )
            	_frequencyComboBox.setSelectedIndex(0);
            _frequencyComboBox.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    reset(_nmc);
                }
            });
            
            _percentileComboBox = new JComboBox(GUIUtility.toArrayDoubles(_nmc.getFrequencies()));
            if ( _percentileComboBox.getItemCount() > 0 )
            	_percentileComboBox.setSelectedIndex(0);
            _percentileComboBox.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    reset(_nmc);
                }
            });
            
            GUIUtility.addRow(comboboxPanel, new JLabel("Frequency: "), _frequencyComboBox);
            GUIUtility.addRow(comboboxPanel, new JLabel("Percentile: "), _percentileComboBox);

            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.NORTH, comboboxPanel);
            spPanel.add(BorderLayout.CENTER, new JScrollPane(_table));
            spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            spPanel.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(spPanel);

            //  Setup the panel
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    };

    @Override
    public void reset(SiteResponseTextFile nmc)
    {
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the plot
        _dataset.setResponse(nmc);

        //  Update the table
        _tableModel.setResponse(nmc);
    }
}
