/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 * 
 * Notice: This computer software was prepared by Sandia Corporation, 
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are 
 * reserved by DOE on behalf of the United States Government and the 
 * Contractor as provided in the Contract. You are authorized to use this 
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE 
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY 
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author aceaste
 *
 */
public class FortranDataReader
{

    public static double readDouble(DataInputStream data) throws IOException
    {
        double temp = 1;
        int exponent = 0, sign = 1;
        short[] raw = new short[8]; //To avoid issues with signed bytes

        for (int i = 7; i >= 0; i--)
        {
            raw[i] = (short) data.readUnsignedByte();
        }

        exponent = ((raw[0] & 0x007F) << 4) + ((raw[1] & 0x00F0) >> 4);

        sign -= 2 * (raw[0] >> 7);

        if (exponent == 0)
        {
            temp = 0;
        }

        temp += (raw[1] & 0x000F) * Math.pow(2, -4);

        for (int i = 2; i < 8; i++)
        {
            temp += (raw[i] & 0x00FF) * Math.pow(2, -4 - (8 * (i - 1)));
        }

        return (sign * temp * Math.pow(2, exponent - 1023));
    }

    public static double readDouble(RandomAccessFile raf) throws IOException
    {
        double temp = 1;
        int exponent = 0, sign = 1;
        short[] raw = new short[8]; //To avoid issues with signed bytes

        for (int i = 7; i >= 0; i--)
        {
            raw[i] = (short) raf.readUnsignedByte();
        }

        exponent = ((raw[0] & 0x007F) << 4) + ((raw[1] & 0x00F0) >> 4);

        sign -= 2 * (raw[0] >> 7);

        if (exponent == 0)
        {
            temp = 0;
        }

        temp += (raw[1] & 0x000F) * Math.pow(2, -4);

        for (int i = 2; i < 8; i++)
        {
            temp += (raw[i] & 0x00FF) * Math.pow(2, -4 - (8 * (i - 1)));
        }

        return (sign * temp * Math.pow(2, exponent - 1023));
    }

    public static float readFloat(DataInputStream data) throws IOException
    {
        float temp = 1;
        int exponent = 0, sign = 1;
        short[] raw = new short[4]; //To avoid issues with signed bytes

        for (int i = 3; i >= 0; i--)
        {
            raw[i] = (short) data.readUnsignedByte();
        }

        exponent = ((raw[0] & 0x007F) << 1) + ((raw[1] & 0x0080) >> 7);

        sign -= 2 * (raw[0] >> 7);

        if (exponent == 0)
        {
            temp = 0;
        }

        temp += (raw[1] & 0x007F) * Math.pow(2, -7);

        for (int i = 2; i < 4; i++)
        {
            temp += (raw[i] & 0x00FF) * Math.pow(2, -7 - (8 * (i - 1)));
        }

        return (float) (sign * temp * Math.pow(2, exponent - 127));
    }

    /**
     * @param raf
     * @return
     * @throws IOException 
     */
    public static double readFloat(RandomAccessFile raf) throws IOException
    {
        float temp = 1;
        int exponent = 0, sign = 1;
        short[] raw = new short[4]; //To avoid issues with signed bytes

        for (int i = 3; i >= 0; i--)
        {
            raw[i] = (short) raf.readUnsignedByte();
        }
        exponent = ((raw[0] & 0x007F) << 1) + ((raw[1] & 0x0080) >> 7);

        sign -= 2 * (raw[0] >> 7);

        if (exponent == 0)
        {
            temp = 0;
        }

        temp += (raw[1] & 0x007F) * Math.pow(2, -7);

        for (int i = 2; i < 4; i++)
        {
            temp += (raw[i] & 0x00FF) * Math.pow(2, -7 - (8 * (i - 1)));
        }

        return (float) (sign * temp * Math.pow(2, exponent - 127));
    }

    public static int readInt(DataInputStream data) throws IOException
    {
        int temp = 0;

        for (int i = 0; i < 4; i++)
        {
            temp += data.readUnsignedByte() * Math.pow(256, i);
        }

        return temp;
    }

    public static int readInt(RandomAccessFile raf) throws IOException
    {
        int temp = 0;

        for (int i = 0; i < 4; i++)
        {
            temp += raf.readUnsignedByte() * Math.pow(256, i);
        }

        return temp;
    }

	/**
	 * Read an array of 4-byte integers from the provided data stream including
	 * the Fortran start and stop integers.
	 * 
	 * @param data
	 * @param array
	 * @return
	 * @throws IOException
	 */
	public static void readIntArray(DataInputStream data, int[] array, int start, int end) throws IOException
    {
		int N = end - start;
        
        //  Read the array elements
        for (int i=0; i<N; i++)
        	array[start+i] = readInt(data);
    }

	/**
	 * Read an array of 8-byte doubles from the provided data stream including
	 * the Fortran start and stop integers.
	 * 
	 * @param data
	 * @param array
	 * @param start
	 * @param end
	 * @return
	 * @throws IOException
	 */
	public static void readDoubleArray(DataInputStream data, double[] array, int start, int end) throws IOException
    {
		int N = end - start;
        
        //  Read the array elements
        for (int i=0; i<N; i++)
        	array[start+i] = readDouble(data);
    }

	/**
	 * Read an array of 4-byte floats from the provided data stream including
	 * the Fortran start and stop integers.
	 * 
	 * @param data
	 * @param array
	 * @param start
	 * @param end
	 * @return
	 * @throws IOException
	 */
	public static void readFloatArray(DataInputStream data, float[] array, int start, int end) throws IOException
    {
		int N = end - start;
		
        //  Read the array elements
        for (int i=0; i<N; i++)
        	array[start+i] = readFloat(data);
    }

	public static void readFloatArray(DataInputStream data, double[] array, int start, int end) throws IOException
    {
		int N = end - start;
		
        //  Read the array elements
        for (int i=0; i<N; i++)
        	array[start+i] = readFloat(data);
    }

}
