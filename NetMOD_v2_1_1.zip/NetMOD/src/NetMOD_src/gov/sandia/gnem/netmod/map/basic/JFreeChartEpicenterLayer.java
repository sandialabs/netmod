/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.gui.AbstractVisibleXYDataset;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;

import javax.swing.*;
import java.awt.geom.Ellipse2D;

/**
 * @author bjmerch
 *
 */
public class JFreeChartEpicenterLayer extends AbstractVisibleXYDataset implements Layer<EpicenterGrid>, JFreeChartLayer<EpicenterGrid>
{
    private XYLineAndShapeRenderer _renderer = new XYLineAndShapeRenderer();
    private EpicenterGrid _epicenterGrid;
    
    public JFreeChartEpicenterLayer(EpicenterGrid epicenterGrid)
    {
        _epicenterGrid = epicenterGrid;
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public int getItemCount(int arg0)
    {
        if ( !isVisible() )
            return 0;
        
        return _epicenterGrid.size();
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public EpicenterGrid getNMC()
    {
        return _epicenterGrid;
    }

    /**
     * @return
     */
    public XYItemRenderer getRenderer(int index)
    {
        int size = (int) Property.MAP_SOURCE_POINTSIZE.getFloatValue();
        _renderer.setSeriesPaint(0, Property.MAP_SOURCE_COLOR.getColorValue());
        _renderer.setSeriesShape(0, new Ellipse2D.Double(-size/2, -size/2, size, size));
        _renderer.setBaseLinesVisible(false);
        _renderer.setBaseShapesVisible(true);
        _renderer.setBaseToolTipGenerator(new XYToolTipGenerator()
        {
            @Override
            public String generateToolTip(XYDataset dataset, int series, int item)
            {
                if ( dataset instanceof JFreeChartEpicenterLayer )
                {
                    return ((JFreeChartEpicenterLayer) dataset)._epicenterGrid.get(item).toString();
                }
                
                return null;
            }});
        
        return _renderer;
    }

    @Override
    public int getSeriesCount()
    {
        return (_epicenterGrid == null ? 0 : 1 );
    }

    @Override
    public Comparable getSeriesKey(int arg0)
    {
        return _epicenterGrid.getName();
    }

    @Override
    public Number getX(int series, int item)
    {
        return _epicenterGrid.get(item).getLongitude();
    }

    @Override
    public Number getY(int series, int item)
    {
        return _epicenterGrid.get(item).getLatitude();
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
    }

    @Override
    public void setNMC(EpicenterGrid data)
    {
        _epicenterGrid = data;
        fireDatasetChanged();
    }
}