package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

/**
 * Implementation of no command line output for a simulation.
 * 
 * @author bjmerch
 *
 */
public class SimulationOutputNone extends AbstractNetModComponent implements SimulationOutput
{
    public static final String _type = "None";
    static
    {
        SimulationOutputPlugin.getPlugin().registerComponent(_type, SimulationOutputNone.class);
    }
    
    public SimulationOutputNone(NetModComponent parent)
	{
		super(parent);
	}

	@Override
	public void start(final ProgressDialog pd, final Output output, final EpicenterGrid epicenters)
	{
	}

	@Override
	public void join()
	{
		
	}
}
