/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import java.io.DataInputStream;
import java.io.InputStream;

import gov.sandia.gnem.netmod.io.IOUtility;

/**
 * Container used for GD2QD information that is static between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class GD2QD_Data
{
    public int nterm; // Spherical harmonic expansion parameter
    public int nmax; // Spherical harmonic expansion parameter
    public int mmax; // Spherical harmonic expansion parameter
    public double[] xcoeff; // Coefficients for x-coordinate
    public double[] ycoeff; // Coefficients for y-coordinate
    public double[] zcoeff; // Coefficients for z-coordinate
    public double[] normadj; // Adjustment to VSH normalization factor
    public float epoch, alt;

    public final static double sineps = 0.39781868;
    
    private String datafile = "/gov/sandia/gnem/netmod/infra/path/wind/hwm14/gd2qd.dat";

    private static GD2QD_Data _instance = null;
    
    final public static GD2QD_Data getInstance()
    {
        if ( _instance == null )
            _instance = new GD2QD_Data();
        
        return _instance;
    }

    private GD2QD_Data()
    {
    	initgd2qd();
    }
    
    private void initgd2qd()
    {
        InputStream in = null;
        DataInputStream data = null;
        int numBytes = 0;

        try
        {
            in = GD2QD_Data.class.getResourceAsStream(datafile);
            data = new DataInputStream(in);

            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 20)
                throw new Exception("Unexpected number of bytes: " + numBytes);
            
            nmax = FortranDataReader.readInt(data);
            mmax = FortranDataReader.readInt(data);
            nterm = FortranDataReader.readInt(data);
            epoch = FortranDataReader.readFloat(data);
            alt = FortranDataReader.readFloat(data);
            
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 20)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            xcoeff = new double[nterm];
            ycoeff = new double[nterm];
            zcoeff = new double[nterm];
            normadj = new double[nmax + 1];

            numBytes = FortranDataReader.readInt(data);
            if (numBytes != nterm * 3 * 8)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            FortranDataReader.readDoubleArray(data, xcoeff, 0, nterm);
            FortranDataReader.readDoubleArray(data, ycoeff, 0, nterm);
            FortranDataReader.readDoubleArray(data, zcoeff, 0, nterm);
            
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != nterm * 3 * 8)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            for (int n = 0; n <= nmax; n++)
                normadj[n] = Math.sqrt(n * (n + 1.0));

            /*
             * Debugging statements
            System.out.println("");
            System.out.println("initgd2qd");
            System.out.println("nmax = " + nmax);
            System.out.println("mmax = " + mmax);
            System.out.println("nterm = " + nterm);
            System.out.println("epoch = " + epoch);
            System.out.println("alt = " + alt);
            System.out.println("xcoeff = ");
            System.out.println(Arrays.toString(xcoeff));
            System.out.println("ycoeff = ");
            System.out.println(Arrays.toString(ycoeff));
            System.out.println("zcoeff = ");
            System.out.println(Arrays.toString(zcoeff));
            System.out.println("normadj = ");
            System.out.println(Arrays.toString(normadj));
            */
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
        	if ( data != null )
        		IOUtility.safeClose(data);
        	if ( in != null )
        		IOUtility.safeClose(in);
        }
    }

}
