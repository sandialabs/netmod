/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.gui.SplashWindow;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.io.libpar.ParLoader;
import gov.sandia.gnem.netmod.map.wordwind2.WorldWindMap_v2_2;
import gov.sandia.gnem.netmod.project.Project;
import gov.sandia.gnem.netmod.simulation.Simulation;
import gov.sandia.gnem.netmod.simulation.SimulationPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Main class for launching the NetMOD application
 * 
 * @author bjmerch
 *
 */
public class Main
{
	private static final String version = "2.1.1";
	
    private static final String[] USAGE = new String[] { 
            "Usage: java -jar NetMOD.jar [CONFIG] [PAR] [GUI] [NETSIM_PAR] [NETMOD_CFG]", 
            "",
            "  NetMOD Version " + version,
            "",
            "  CONFIG - Specify the NetMOD configuration file.  By default,",
            "        NetMOD will use a file named 'NetMOD.cfg' located within", 
            "        the startup directory.",
            "     CONFIG=<file>   Where <file> is the location of the configuration file.", 
            "",
            "  PAR - Specify a NetSim libpar format parameter file that will be loaded.",
            "     PAR=<file>      Where <file> is the location of the parameter file.", 
            "",
            "  GUI - Specify whether or not to display the graphic user interface.", 
            "        If the user interface is not displayed, then the simulation",
            "        defined by the provided parameter file will be run and the", 
            "        application will then exit.", 
            "     GUI=[ true | false ]", 
            "",
            "  NETSIM_PAR - Any of the parameters defined within the NetSim libpar format",
            "        may be entered here.  See the specification document 'NetSim Control",
            "        Parameters and Output Data', May 2009, for the full list. Any provided",
            "        parameters will override values set within the parameter file.", 
            "     <parameter-name>=<value>",
            "",
            "  NETMOD_CFG - Any of the NetMOD runtime configuration parameters",
            "        may be entered here.  See the NetMOD manual for the full list. Any provided",
            "        parameters will override values set within the configuration file.", 
            "     <parameter-name>=<value>" };

    /**
     * Start NetMOD
     * 
     * @param args
     */
    public static void main(String[] args)
    {
        //  Print out the usage
        if (args.length == 0)
            for (int i = 0; i < USAGE.length; i++)
                System.out.println(USAGE[i]);
        
        startApplication("NetMOD", version, args);
    }
    
    /**
     * Launch the NetMOD based application with the provided title and arguments
     * 
     * @param title
     * @param args
     */
    protected static void startApplication(String title, String version, String[] args)
    {
    	NetMOD.name = title;
    	NetMOD.version = version;
    	
        //  Parse command line arguments
        LibParParameters parameters = null;
        try
        {
            parameters = ParLoader.load(args, true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        //  Extract the GUI and parfile parameters
        String configFile = null;
        String parFile = null;
        boolean gui = true;
        if (parameters != null)
        {
            configFile = parameters.getAsWithDefault("CONFIG", String.class, "");
            parFile = parameters.getAsWithDefault("PAR", String.class, "");
            gui = parameters.getAsWithDefault("GUI", Boolean.class, Boolean.TRUE);
        }

        //  Display the splash screen
        if (gui)
        {
            SplashWindow.splash(title, SplashWindow.class.getResource("/gov/sandia/gnem/netmod/gui/NetMOD.png"));
        }

        //  Specify the config file
        if (configFile != null && !configFile.isEmpty())
            Property.setPropertiesFile(IOUtility.openFile(configFile));
        
        //  Load the default properties
        Property.loadProperties();
        
        //  Load properties from the command line parameters
        Property.loadProperties(parameters);

        try
        {
            GUIUtility.setDefaultLAF();

            // Displayed all uncaught exceptions in a modal dialog.
            Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler()
            {
                @Override
                public void uncaughtException(Thread t, Throwable e)
                {
                    String stackTrace = GUIUtility.showExceptionDialog(null, "Program error on thread " + t, e.getMessage(), e);
                    
                    //  Check for an error with an opengl map.  Reset to a "Basic" map.
                    if ( stackTrace.contains("gl") && NetMOD.isGUI() )
                    {
                        Property.MAP.setValue("Basic");
                        NetMOD.getFrame().resetMap();
                    }
                }
            });
        }
        catch (Exception e)
        {
            GUIUtility.showExceptionDialog(null, "Program error", e.getMessage(), e);
        }

        try
        {
            initializeClassPath();
        }
        catch (Exception e)
        {
            GUIUtility.showExceptionDialog(null, "Program error", e.getMessage(), e);
        }

        //  Launch the the NetMod GUI
        if (gui)
        {
        	Class<WorldWindMap_v2_2> c = gov.sandia.gnem.netmod.map.wordwind2.WorldWindMap_v2_2.class;
            NetMOD netMod = new NetMOD();
            netMod.setVisible(true);

            SplashWindow.disposeSplash();
        }

        //  Try to load a par file
        if (parFile != null && !parFile.isEmpty())
        {
        	Simulation simulation = SimulationPlugin.load(parFile,  parameters);
        	if ( simulation != null )
        	{
                //  Check if the GUI is visible
                if (gui)
                {
                    //  Insert the simulation into the project
                    Project project = NetMOD.getFrame().getProject();
                    project.add(simulation);
                    project.getViewer().refresh();
                }
                else
                {
                    //  Run the simulation
                    simulation.run();
                }
        	}
        }
    }
    
    /**
     * Force the class loader to initialize all classes
     * within the defined classpath.
     * <p>
     * This is needed to for the plugins to register themselves.
     * 
     * @throws Exception
     */
    public static void initializeClassPath()
    {
        try
        {
	        initializeClassPath(IOUtility.openFile(Main.class.getProtectionDomain().getCodeSource().getLocation().getPath()));
        }
        catch (Exception e)
        {
	        e.printStackTrace();
        }
    }

    /**
     * Force the class loader to initialize all classes
     * within the defined classpath.
     * <p>
     * This is needed to for the plugins to register themselves.
     * 
     * @param file
     * @throws Exception
     */
    protected static void initializeClassPath(File file) throws Exception
    {
        String path = file.getPath();
        
        if ( path.endsWith(".jar") || path.endsWith(".zip") )
            initializeJar(file);
        else
            initializeDir(path + File.separatorChar, file);
    }

    /**
     * Initialize the contents of a jar file
     * 
     * @param file
     */
    private static void initializeJar(File file) throws Exception
    {
        ZipFile zipFile = null;
        
		try
		{
			zipFile = new ZipFile(file);
			for (Enumeration<? extends ZipEntry> entry = zipFile.entries(); entry.hasMoreElements();)
			{
				String name = entry.nextElement().getName();

				if (name.endsWith(".class"))
				{
					// Remove the ".class" extention
					name = name.substring(0, name.length() - 6);

					// Convert JAR location to package
					name = name.replace('/', '.');
					try
					{
						// Load the class
						Class.forName(name);
					}
					catch (Throwable e)
					{
						e.printStackTrace();
					}
				}
			}
		}
        finally
        {
        	if ( zipFile != null )
        		IOUtility.safeClose(zipFile);
        }
    }

    /**
     * Initialize the contents of a directory
     * 
     * @param prefix Starting prefix of a directory hierarchy, used for building java package name from directory structure
     * @param file
     * @throws ClassNotFoundException
     */
    private static void initializeDir(String prefix, File file) throws ClassNotFoundException
    {
        //  Process all the subdirectories
        if (file.isDirectory())
        {
            for (File nextFile : file.listFiles())
                initializeDir(prefix, nextFile);
        }
        //  Process the individual file
        else
        {
            String name = file.getPath();

            if (name.endsWith(".class"))
            {
                //  Remove the path
                name = name.replace(prefix, "");

                //  Remove the ".class" extention
                name = name.substring(0, name.length() - 6);

                //  Change all '/' to '.'
                name = name.replace(File.separatorChar, '.');

                try
                {
                    //  Load the class
                    Class.forName(name);
                }
                catch (Throwable e)
                {
                	e.printStackTrace();
                }
            }
        }
    }
}
