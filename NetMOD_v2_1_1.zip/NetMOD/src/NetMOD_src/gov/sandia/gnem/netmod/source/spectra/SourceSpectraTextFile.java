/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.spectra;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Magnitude;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @author bjmerch
 *
 */
public class SourceSpectraTextFile extends AbstractNetModFile implements SourceSpectra
{
    public static final double NO_RESULT = -99999.0;
    public static final SpectraDouble NO_RESULT_SPECTRA = new SpectraDouble(NO_RESULT);
    private static final String _type = "Source Spectra Text File";
    static
    {
        SourceSpectraPlugin.getPlugin().registerComponent(_type, SourceSpectraTextFile.class, true);
    }

    private double[] _frequencies;
    private double[] _moments;
    private double[][] _amplitudes;

    //  Cache frequently requested frequencies
    private transient TupleCacheMap<Frequency, Magnitude, SpectraDouble> _cache = new TupleCacheMap<Frequency, Magnitude, SpectraDouble>(null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_MAGNITUDE);

    public SourceSpectraTextFile(NetModComponent parent)
    {
        super(parent, _type);
    }

    @Override
    public void clearCache()
    {
        super.clearCache();

        _frequencies = null;
        _moments = null;
        _amplitudes = null;
        _cache.clear();
    }

    @Override
    public SpectraDouble getAmplitude(Magnitude moment, Frequency frequency)
    {
        startIntrospection();
        recordIntrospection("Source Spectra from file: '", getFilename(), "'");
        recordIntrospection("at moment: ", moment);
        recordIntrospection("at frequency: ", frequency);

        //  Check the cache
        SpectraDouble a = _cache.get(frequency, moment);
        if ( a != null )
        {
            recordIntrospection("Spectral Amplitude (log10): ", a);
            stopIntrospection();
            return a;
        }

        double[] frequencies = getFrequencies();
        double[] moments = getMoments();
        if (frequencies == null || frequencies.length == 0 || moments == null || moments.length == 0)
        {
            a = NO_RESULT_SPECTRA;
            
            recordIntrospection("Spectral Amplitude (log10): ", a);
            recordIntrospection("No source spectra defined");
            statusIntrospection(StatusType.WARNING);
            stopIntrospection();
            
            return a;
        }

        //  Identify the evaluation frequencies
        double[] f_eval = getEvaluationFrequencies(frequency, frequencies);
        int N = f_eval.length;
        
        if (N == 0)
        {
            a = NO_RESULT_SPECTRA;

            recordIntrospection("Spectral Amplitude (log10): ", a);
            recordIntrospection("Frequency exceeds defined bounds");
            statusIntrospection(StatusType.WARNING);
            stopIntrospection();
            
            return a;
        }
        
        a = new SpectraDouble(N);
        for (int i=0; i<N; i++)
            a.setValue(i, f_eval[i], computeSourceSpectra(moment.getMoment(), f_eval[i]));

        recordIntrospection("Spectral Amplitude (log10): ", a);
        stopIntrospection();

        //  Cache the result
        _cache.put(frequency, moment, a);

        return a;
    }
    
    private double computeSourceSpectra(double moment, double frequency)
    {
        return Interpolation.interpolateBiquadratic(_moments, _frequencies, _amplitudes, moment, frequency);
    }

    /**
     * @return
     */
    @Override
    public double[] getFrequencies()
    {
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
				read();
		}

        return _frequencies;
    }

    /**
     * @return
     */
    @Override
    public double[] getMoments()
    {
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_moments == null)
				read();
		}

        return _moments;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new SourceSpectraTextFileViewer(this);
    }

    @Override
    public boolean isFor(Object o)
    {
        //  Extract a file from the object
        File file = null;
        if (o instanceof File)
            file = (File) o;
        else if (o instanceof String)
            file = IOUtility.openFile((String) o);

        //  Check if the file exists
        if (file == null || !file.exists())
            return false;

        //  Source Spectra Text Files end with ".cdf"
        return IOUtility.endsWith(file, ".sor");
    }

    @Override
    public boolean isAvailable()
    {
        return getFrequencies().length > 0;
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public boolean read()
    {
        boolean value = false;

        //  Synchronize on the type to prevent errors if simultaneously reading from the same file
        synchronized (_type)
        {
            FileInputStream fis = null;
            Scanner fin = null;
            try
            {
                // Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);

                setName(fin.nextLine());

                //  Skip comments
                skipComments(fin);

                // Read in the frequencies
                int Nfreq = fin.nextInt();
                double[] frequencies = new double[Nfreq];
                for (int i = 0; i < Nfreq; i++)
                    frequencies[i] = fin.nextDouble();
                setFrequencies(frequencies);
                
                //  Skip comments
                skipComments(fin);

                // Read in the scalar log seismic moments
                int Nmoments = fin.nextInt();
                double[] moments = new double[Nmoments];
                for (int i = 0; i < Nmoments; i++)
                    moments[i] = fin.nextDouble();
                setMoments(moments);
                
                //  Skip comments
                skipComments(fin);

                // For each frequency, read in the source spectra amplitudes
                _amplitudes = new double[Nmoments][Nfreq];
                for (int i = 0; i < Nfreq; ++i)
                {
                    //  Skip whitespace              
                    fin.skip("\\s");

                    //  Skip the empty lines and the line "Source amplitudes for frequency = ???"
                    while (fin.nextLine().trim().equals(""))
                        ;

                    for (int j = 0; j < Nmoments; j++)
                        _amplitudes[j][i] = fin.nextDouble();
                }

                value = true;
                setDirty(false);
            }
            catch (Exception e)
            {
                if (!getFilename().isEmpty())
                {
                    System.out.println("Unable to read source spectra text file: '" + getFilename() + "'");
                    e.printStackTrace();
                }

                _frequencies = new double[0];
                _moments = new double[0];
                _amplitudes = new double[0][0];
            }
            finally
            {
    			if ( fin != null )
    				IOUtility.safeClose(fin);
    			if ( fis != null )
    				IOUtility.safeClose(fis);
            }
        }

        return value;
    }

    /**
     * Remove all amplitudes for the provided frequency
     * 
     * @param frequency
     */
    public void removeAmplitudeFrequency(double frequency)
    {
        //  Find the index of the existing frequency
        int index = Arrays.binarySearch(getFrequencies(), frequency);
        if (index < 0)
            return;

        //  Create copies of the arrays, excluding the index
        _frequencies = removeIndex(_frequencies, index);
        for (int i = 0; i < _amplitudes.length; i++)
            _amplitudes[i] = removeIndex(_amplitudes[i], index);

        _cache.clear();
        setDirty(true);
    }

    /**
     * Remove all amplitudes for the provided moment
     * 
     * @param moment
     */
    public void removeAmplitudeMoment(double moment)
    {
        //  Find the index of the existing moment
        int index = Arrays.binarySearch(getMoments(), moment);
        if (index < 0)
            return;

        //  Create copies of the arrays, excluding the index
        _moments = removeIndex(_moments, index);
        _amplitudes = removeIndex(_amplitudes, index);

        _cache.clear();
        setDirty(true);
    }

    /**
     * Set the amplitude at the provided moment and frequency
     * 
     * @param moment
     * @param frequency
     */
    public void setAmplitude(double moment, double frequency, double amplitude)
    {
        int m_index = findIndex(getMoments(), moment);
        int f_index = findIndex(getFrequencies(), frequency);

        //  Update the frequency
        if (f_index >= _frequencies.length || _frequencies[f_index] != frequency)
        {
            _frequencies = insertIndex(_frequencies, f_index, frequency);

            //  Create a new frequency array of 0's at all moments
            for (int i = 0; i < _moments.length; i++)
                _amplitudes[i] = insertIndex(_amplitudes[i], f_index, 0);
        }

        if (m_index >= _moments.length || _moments[m_index] != moment)
        {
            _moments = insertIndex(_moments, m_index, moment);

            //  Insert new moment entry for all frequencies
            _amplitudes = insertIndex(_amplitudes, m_index, new double[_frequencies.length]);
        }

        //  Insert attenuation at location
        _amplitudes[m_index][f_index] = amplitude;
        setDirty(true);
    }

    @Override
    public boolean write()
    {
        // Get the File to write to
        File file = IOUtility.openFile(getFilename());

        //  Don't write if not needed
        if (!getDirty() && file.exists())
            return true;

        //  Test whether there is no file to write to
        if (isEmpty(file.getPath()))
            return true;

        PrintWriter fout = null;
        try
        {
            double[] frequencies = getFrequencies();
            double[] moments = getMoments();

            //  Ensure the path to the file exists
            file.getParentFile().mkdirs();

            // Open the file and write the title
            fout = new PrintWriter(new FileWriter(file));
            fout.println(getName());

            // Write the frequencies
            fout.println("  " + frequencies.length);
            GUIUtility.printArray(frequencies, fout, "%10.3f\t");

            // Write the scalar log seismic moments
            fout.println();
            fout.println("  " + moments.length);
            GUIUtility.printArray(moments, fout, "%10.3f\t");
            fout.println();

            // For each frequency, write out the corresponding source amplitudes
            for (int i = 0; i < frequencies.length; ++i)
            {
                fout.println(String.format("Source amplitudes for frequency:\t%.3f", frequencies[i]));

                for (int j = 0; j < moments.length; j++)
                {
                    double amplitude = _amplitudes[j][i];

                    if (j % 8 == 0 && j != 0)
                        fout.println();

                    fout.print(String.format("%10.3f\t", amplitude));
                }
                fout.println();
            }

            setDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        finally
        {
        	if ( fout != null )
        		IOUtility.safeClose(fout);
        }

        return true;
    }

    /**
     * @param lFrequencies
     */
    private void setFrequencies(double[] frequencies)
    {
        _frequencies = frequencies;
    }

    /**
     * @param lScalarLogSeismicMoments
     */
    private void setMoments(double[] moments)
    {
        _moments = moments;
    }
}
