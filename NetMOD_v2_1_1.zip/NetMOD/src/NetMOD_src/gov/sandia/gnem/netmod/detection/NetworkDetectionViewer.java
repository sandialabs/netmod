/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import gov.sandia.gnem.netmod.detection.StationDetection.FrequencyType;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.numeric.Frequency;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Map;

/**
 * @author bjmerch
 *
 */
abstract public class NetworkDetectionViewer<ND extends NetworkDetection> extends NetModComponentViewer<ND>
{
	/**
	 * Display the frequency type using a human readable name
	 * 
	 * @author bjmerch
	 *
	 */
	private class FrequencyTypeRenderer extends DefaultListCellRenderer
	{
		@Override
		public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
				boolean cellHasFocus)
		{
			Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

			if ((c instanceof JLabel) && (value instanceof FrequencyType))
			{
				FrequencyType frequencyType = (FrequencyType) value;
				JLabel label = (JLabel) c;

				label.setText(frequencyType.getName());
			}

			return c;
		}
	}
	
    private JComboBox _detectionRules = new JComboBox();
    private JTextField _detectionRule = new JTextField();
    private JComboBox _frequencyType = new JComboBox(StationDetection.FrequencyType.values());
    private JTextField _frequencies = new JTextField();
    /**
     * @param nmc
     */
    public NetworkDetectionViewer(ND nmc)
    {
        super(nmc, true, false);
        
        _frequencyType.setRenderer(new FrequencyTypeRenderer());

        //  Register the controls that are monitored after updating
        registerControls(_detectionRule, _detectionRules, _frequencyType, _frequencies);
    }

    @Override
    public void apply(NetworkDetection nmc)
    {
        String detectionKey = _detectionRules.getSelectedItem().toString();
        String detectionValue = _detectionRule.getText();
        nmc.getDetectionRules().put(detectionKey, detectionValue);
        nmc.setDetectionRule(detectionKey);
        nmc.getStationDetection().setFrequencyType((StationDetection.FrequencyType) _frequencyType.getSelectedItem());
        nmc.getStationDetection().setFrequencies(Frequency.parseFrequencies(_frequencies.getText()));
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            _detectionRules.setEditable(true);
            _detectionRules.setToolTipText("<html>Phase detection rule.<br>Select from the list or<br>enter a custom value.</html>");
            _frequencies.setToolTipText("Comma separated list of frequencies.");
            _frequencyType
                    .setToolTipText("<html>Method for combining SNR values across frequencies.<br>High uses the SNR values from the frequency that results in the highest probability.<br>High 2 uses the SNR that results in the second highest propbability.<br>Average finds the probability of the average SNR across frequency.</html>");
            
            // Add a listener to the detection rule combo box to update the text field
            _detectionRules.addItemListener(new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent ie)
                {
                    if (ie.getStateChange() != ItemEvent.SELECTED)
                        return;
                    
                    _detectionRule.setText(_nmc.getDetectionRules().get(ie.getItem()));
                }                
            });

            //  Setup the panel
            GUIUtility.addRow(panel, new JLabel("Phase Detection Rule: "), createRemoveDetectionRuleButton(), _detectionRules, _detectionRule);
            GUIUtility.addRow(panel, new JLabel("Frequencies (Hz): "), _frequencies);
            GUIUtility.addRow(panel, new JLabel("Frequency Type: "), _frequencyType);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(NetworkDetection nmc)
    {
        _detectionRules.removeAllItems();
        for (String rule : nmc.getDetectionRules().keySet())
            _detectionRules.addItem(rule);
        _detectionRules.setSelectedItem(nmc.getDetectionRule());
        _frequencyType.setSelectedItem(nmc.getStationDetection().getFrequencyType());
        _frequencies.setText(Frequency.formatFrequencies(nmc.getStationDetection().getFrequencies()));
    }

    private JComponent createRemoveDetectionRuleButton()
    {
        JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
        button.setToolTipText("Remove current detection rule");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                String rule = _nmc.getDetectionRule();
                Map<String, String> rules = _nmc.getDetectionRules();

                if (rules.size() > 1)
                {
                    rules.remove(rule);

                    _nmc.setDetectionRule(rules.keySet().iterator().next());
                }

                refresh();
            }
        });

        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.add(button);

        return toolBar;
    }
}
