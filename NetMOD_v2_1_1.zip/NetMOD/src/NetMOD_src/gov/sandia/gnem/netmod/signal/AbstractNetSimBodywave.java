/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.ReceiverPhaseParameter;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.receiver.StationPhaseParameter;
import gov.sandia.gnem.netmod.receiver.attenuation.StationAttenuation;
import gov.sandia.gnem.netmod.receiver.attenuation.StationTransmissionLossModelTextFile;
import gov.sandia.gnem.netmod.receiver.response.SiteResponse;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.media.SourceMediaType;

/**
 * Abstract class that implements the general NetSim signal amplitude equations
 *
 * @author bjmerch
 */
abstract public class AbstractNetSimBodywave extends AbstractNetModComponent implements SignalAmplitude
{

	/**
	 * @param parent
	 */
	protected AbstractNetSimBodywave(NetModComponent parent, String type, String name)
	{
		super(parent, type, name);
	}

	@Override
	public Spectra generateAmplitude(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		// Compute the media constant
		double log_c_ijk = computeLogMediaConstant(sources, paths, receivers, epicenter, station, distance, magnitude,
				phase, frequency, time, N, prng);

		// Compute the log source spectra and excitation factor
		Spectra logS_jk = computeLogSourceSpectra(sources, paths, receivers, epicenter, station, distance, magnitude,
				phase, frequency, time, N, prng);
		double log_k_jk = computeLogSourceExcitationFactor(sources, paths, receivers, epicenter, station, distance,
				magnitude, phase, frequency, time, N, prng);

		// get coupling factor
		double cf = computeCouplingFactor(sources, paths, receivers, epicenter, station, distance, magnitude, phase,
				frequency, time, N, prng);

		// Compute station specific transmission loss
		Spectra B_ijk = computeStationAttenuation(sources, paths, receivers, epicenter, station, distance, magnitude,
				phase, frequency, time, N, prng);

		// Compute the site response
		Spectra SR_ik = computeSiteResponse(sources, paths, receivers, epicenter, station, distance, magnitude, phase,
				frequency, time, N, prng);

		// station correction for this phase
		PDF stacorr_ik = computeStationCorrection(sources, paths, receivers, epicenter, station, distance, magnitude,
				phase, frequency, time, N, prng);

		// Sum all of the probability distributions
		Spectra sum = Spectra.sum(log_c_ijk + log_k_jk + cf, stacorr_ik, logS_jk, B_ijk, SR_ik);

		// Make it monte carlo if needed
		sum = sum.toMonteCarlo(prng, N);

		recordIntrospection(getName(), "Signal Amplitude (log10 Amplitude): ", sum);
		stopIntrospection();

		return sum;
	}

	@Override
	public boolean isLeaf()
	{
		return true;
	}

	@Override
	public void load(NetSimParameters parameters) throws Exception
	{
		super.load(parameters);
	}

	@Override
	public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
	{
		super.save(parameters, files, reset);

		parameters.set(SeismicDetectionParameters.signalAmplitude, getType());
	}
	
	/**
	 * Compute the station specific attenuation, if there is a defined transmission loss model.
	 * Otherwise, the traditional methods of computing attenuation and spreading will be used.
	 * 
	 * @return
	 */
	private Spectra computeStationAttenuation(Sources sources, Paths paths, Receivers receivers,
			Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase,
			Frequency frequency, Time time, int N, PRNG prng)
	{
		
		Spectra spectra = null;
		
		// Obtain the station transmission loss model
		StationAttenuation tlm = station.getPhaseParameters().getPhaseParameter(phase).getStationAttenuation();
		if (tlm != null || tlm.isAvailable() )
		{
			startIntrospection();
			spectra = tlm.getAttenuation(station.getLocation(), epicenter, distance, frequency);
			if ( spectra == StationTransmissionLossModelTextFile.NO_RESULT_SPECTRA )
			{
				recordIntrospection("Undefined Station Specific Attenuation Model");
				spectra = null;
			}
			else
				recordIntrospection("Station Specific Attenuation Model: ", spectra);
			
			stopIntrospection();
		}

		// Compute the attenuation & geometric spreading factor
		if ( spectra == null )
		{
			spectra = computeAttenuationSpreading(sources, paths, receivers, epicenter, station, distance, magnitude,
				phase, frequency, time, N, prng);
		}
		
		return spectra;
	}

	/**
	 * Compute the attenuation and spreading
	 * 
	 * @return
	 */
	abstract protected Spectra computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers,
			Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase,
			Frequency frequency, Time time, int N, PRNG prng);

	/**
	 * Compute the media constant from the properties of the source and station
	 * media
	 *
	 * @return
	 */
	protected double computeLogMediaConstant(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		// Obtain the source media type
		SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(epicenter);
		if (sourceMediaType == null)
		{
			recordIntrospection("Unable to determine a source media type for this epicenter");
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();
			return 0;
		}

		// Compute the station media density
		double p_i = station.getMediaDensity();
		if (p_i <= 0)
			p_i = receivers.getDefaultDensity();

		// Compute the source media density
		double p_j = sourceMediaType.getDensity();

		// Compute the station phase velocity
		double v_ik = station.getPhaseParameters().getPhaseParameter(phase).getReceiverMediaVelocity();
		if (v_ik == 0)
			v_ik = receivers.getPhaseParameters().getPhaseParameter(phase).getReceiverMediaVelocity();

		// Compute the source phase velocity
		double v_jk = sourceMediaType.getPhaseParameters().getPhaseParameter(phase).getMediaVelocity();

		double mediaConstant = 9.0 - Math.log10(4 * Math.PI * Math.sqrt(p_j * p_i * Math.pow(v_jk, 5) * v_ik));

		recordIntrospection("Media Constant (log10 Amplitude): ", mediaConstant);
		recordIntrospection("Source Media Type: ", sourceMediaType);
		recordIntrospection("Source Media Density: ", p_j);
		recordIntrospection("Source Phase Velocity: ", v_jk);
		recordIntrospection("Station Media Density: ", p_i);
		recordIntrospection("Station Phase Velocity: ", v_ik);

		// Set the introspection status
		if (Double.isNaN(mediaConstant) || Double.isInfinite(mediaConstant))
			statusIntrospection(StatusType.ERROR);

		stopIntrospection();

		return mediaConstant;
	}

	protected double computeCouplingFactor(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		// Obtain the source media type
		SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(epicenter);
		if (sourceMediaType == null)
		{
			recordIntrospection("Unable to determine a source media type for this epicenter");
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();
			return 0;
		}

		Magnitude log_moment = sourceMediaType.getEventSizeConversion().convertToMoment(magnitude.getMagnitude(),
				magnitude.getMagnitudeType());
		double yield_kt = sourceMediaType.getEventSizeConversion().convertFromMoment(log_moment.getMoment(),
				MagnitudeType.KT);
		double elev = epicenter.getElevation();

		double beta3 = sourceMediaType.getBeta3();
		double beta4 = sourceMediaType.getBeta4();
		double beta5 = sourceMediaType.getBeta5();

		double cf = computeCouplingFactor(beta3, beta4, beta5, yield_kt, elev);

		stopIntrospection();
		return cf;
	}

	/**
	 * Method for computing the couple factor that can be easily checked for
	 * accuracy with a unit test
	 * 
	 * @param beta3
	 * @param beta4
	 * @param beta5
	 * @param yield_kt
	 * @param elev
	 * @return
	 */
	public double computeCouplingFactor(double beta3, double beta4, double beta5, double yield_kt, double elev)
	{
		double yield_kg = yield_kt * 1000000;
		double hs = elev / Math.cbrt(yield_kg);

		double cf = beta3 * (Math.tanh(beta4 * hs + beta5) + 1);

		recordIntrospection("Coupling Factor (log10 Amplitude): ", cf);
		recordIntrospection("Beta3: ", beta3);
		recordIntrospection("Beta4: ", beta4);
		recordIntrospection("Beta5: ", beta5);
		recordIntrospection("Yield (kt): ", yield_kt);
		recordIntrospection("Yield (kg): ", yield_kg);
		recordIntrospection("Depth: ", elev);
		recordIntrospection("Scaled Depth: ", hs);

		return cf;
	}

	protected Spectra computeLogSourceSpectra(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		// Obtain the source media type
		SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(epicenter);
		if (sourceMediaType == null)
		{
			recordIntrospection("Source Spectra:  Unable to determine a source media type for this epicenter");
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();
			return new SpectraDouble(0.0);
		}

		// Get the amplitude
		Spectra amplitude = sourceMediaType.getSourceSpectra().getAmplitude(magnitude, frequency);

		recordIntrospection("Source Spectra (log10 Amplitude): ", amplitude);
		recordIntrospection("Source Media Type: ", sourceMediaType);
		stopIntrospection();

		return amplitude;
	}

	protected double computeLogSourceExcitationFactor(Sources sources, Paths paths, Receivers receivers,
			Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase,
			Frequency frequency, Time time, int N, PRNG prng)
	{
		startIntrospection();

		// Obtain the source media type
		SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(epicenter);
		if (sourceMediaType == null)
		{
			recordIntrospection("Source Spectra:  Unable to determine a source media type for this epicenter");
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();
			return 0;
		}

		// Compute the source excitation factor
		double k_jk = sourceMediaType.getPhaseParameters().getPhaseParameter(phase).getExcitationFactor();
		double k_jk_log10 = Math.log10(k_jk);

		recordIntrospection("Source Excitation Factor (log10): ", k_jk_log10);
		recordIntrospection("Source Media Type: ", sourceMediaType);
		stopIntrospection();

		return k_jk_log10;

	}

	protected Spectra computeSiteResponse(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		SiteResponse responseModel = station.getPhaseParameters().getPhaseParameter(phase).getSiteResponse();
		if (!responseModel.isAvailable())
			responseModel = receivers.getDefaultSiteResponse();

		Spectra response = responseModel.getResponse(frequency);

		recordIntrospection("Site Response (log10): ", response);
		stopIntrospection();

		return response;
	}

	protected PDF computeStationCorrection(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter,
			Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N,
			PRNG prng)
	{
		startIntrospection();

		StationPhaseParameter staPP = station.getPhaseParameters().getPhaseParameter(phase);

		// Get the amplitude correction
		PDF correction = staPP.getLogAmplitudeCorrection();
		if (correction.getMean() == 0 && correction.getStandardDeviation() == 0)
		{
			ReceiverPhaseParameter receiverPP = receivers.getPhaseParameters().getPhaseParameter(phase);
			correction = receiverPP.getLogAmplitudeCorrection();
		}
		else if (correction.getMean() == 0)
		{
			ReceiverPhaseParameter receiverPP = receivers.getPhaseParameters().getPhaseParameter(phase);
			correction = new NormalPDF(receiverPP.getLogAmplitudeCorrection().getMean(),
					correction.getStandardDeviation());
		}
		else if (correction.getStandardDeviation() == 0)
		{
			ReceiverPhaseParameter receiverPP = receivers.getPhaseParameters().getPhaseParameter(phase);
			correction = new NormalPDF(correction.getMean(),
					receiverPP.getLogAmplitudeCorrection().getStandardDeviation());
		}

		recordIntrospection("Station Correction (log10 Amplitude): ", correction);
		stopIntrospection();

		return correction;
	}
}
