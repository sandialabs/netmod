package gov.sandia.gnem.netmod.infra.path.wind.jecmwf;

import gov.sandia.gnem.netmod.geometry.Point.Double;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import ucar.ma2.ArrayFloat;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;

import java.io.IOException;

public class Ecmwf
{
	private String _file;
	private int x, y, z;  //  dimensions of the sampled grid.  x=longitude, y=latitude, z=height
	private double[][][] U, V, T;   //  3-d arrays of dimension x,y,z
	private double[] lon, lat; //  Vector of longitudes and latitudes in degrees
	private double[] height;  //  Vector of heights in meters above ground level of length z.

	public Ecmwf(String file)
	{
		_file = file;

	}
	
	protected void read()
	{
		try
		{
			//  Don't re-read if it's already read.
			if ( U != null )
				return;

			NetcdfFile ncfile = NetcdfFile.open(_file);

	        x = readDimension("x", ncfile);
	        y = readDimension("y", ncfile);
	        z = readDimension("z", ncfile);

	        U = readVariable3d("U", ncfile);
	        V = readVariable3d("V", ncfile);
	        T = readVariable3d("T", ncfile);
	        height = readVariable1d("height", ncfile);
	        
	        double dx = readVariable("dx", ncfile);
	        double dy = readVariable("dy", ncfile);
	        double xlon0 = readVariable("xlon0", ncfile);
	        double ylat0 = readVariable("ylat0", ncfile);

	        lon = new double[x];
	        for (int i=0; i<x; i++)
	        	lon[i] = xlon0 + dx * i;
	        
	        lat = new double[y];
	        for (int i=0; i<y; i++)
	        	lat[i] = ylat0 + dy * i;
	        
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Compute the wind vector at the provided location and altitude
	 * 
	 * @param location Location in degrees of latitude and longitude.
	 * @param altitude Altitude in meters above ground level.
	 * @return  Complex wind vector with East as the real component and North as the imaginary component
	 */
	public Complex getWindVelocity(Double location, double altitude)
	{
		if ( U == null )
			read();
		
		//  u is the east component
		double u = Interpolation.interpolateTriquadratic(lon, lat, height, U, location.getLongitude(), location.getLatitude(), altitude);
		//  v is the north component
		double v = Interpolation.interpolateTriquadratic(lon, lat, height, V, location.getLongitude(), location.getLatitude(), altitude);
		
		return new Complex(u,v);
	}

	private static double[][][] readVariable3d(String varName, NetcdfFile ncfile)
	{
		ArrayFloat.D3 data = null;
		Variable v = ncfile.findVariable(varName);
		if (v == null)
		{
			System.out.println("Variable " + varName + " not found");
			return null;
		}
		try
		{
			data = (ArrayFloat.D3) v.read();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}

		int[] shape = data.getShape();

		double[][][] varArray = new double[shape[0]][shape[1]][shape[2]];
		for (int i = 0; i < shape[0]; i++)
		{
			for (int j = 0; j < shape[1]; j++)
			{
				for (int k = 0; k < shape[2]; k++)
				{
					varArray[i][j][k] = data.get(i, j, k);
				}
			}
		}
		return varArray;
	}
	
	private static double readVariable(String varName, NetcdfFile ncfile)
	{
		Variable v = ncfile.findVariable(varName);
		if (v == null)
		{
			System.out.println("Variable " + varName + " not found");
			return 0;
		}
		
		try
		{
			return v.readScalarDouble();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	private static int readDimension(String dimName, NetcdfFile ncfile)
	{
		Dimension d = ncfile.findDimension(dimName);
		if (d == null)
		{
			System.out.println("Dimension " + dimName + " not found");
			return 0;
		}
		
		return d.getLength();
	}

	private static double[] readVariable1d(String varName, NetcdfFile ncfile)
	{
		ArrayFloat.D1 data = null;
		Variable v = ncfile.findVariable(varName);
		if (v == null)
		{
			System.out.println("Variable " + varName + " not found");
			return null;
		}
		try
		{
			data = (ArrayFloat.D1) v.read();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}

		int[] shape = data.getShape();

		double[] varArray = new double[shape[0]];
		for (int i = 0; i < shape[0]; i++)
		{
			varArray[i] = data.get(i);
		}
		return varArray;
	}
}
