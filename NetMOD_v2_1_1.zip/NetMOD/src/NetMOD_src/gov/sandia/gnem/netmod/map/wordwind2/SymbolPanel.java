package gov.sandia.gnem.netmod.map.wordwind2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import gov.nasa.worldwind.avlist.AVList;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable.Record;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.AbstractShape;
import gov.nasa.worldwind.render.AnnotationAttributes;
import gov.nasa.worldwind.render.BasicBalloonAttributes;
import gov.nasa.worldwind.render.GlobeAnnotation;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Offset;
import gov.nasa.worldwind.render.Path;
import gov.nasa.worldwind.render.PatternFactory;
import gov.nasa.worldwind.render.PointPlacemark;
import gov.nasa.worldwind.render.PointPlacemarkAttributes;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.lineofsight.PointGrid;
import gov.sandia.gnem.netmod.gui.DoubleRangeFormatter;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.JColorButton;

/**
 * Panel for displaying and changing the symbols used for WorldWind Renderables
 * 
 * @author bjmerch
 *
 */
public class SymbolPanel extends JPanel
{
	/**
	 * Panel for changing general layer parameters
	 * 
	 * @author bjmerch
	 *
	 */
	private class GeneralPanel extends JPanel
	{
		private JTextField _layerName = new JTextField();
		
		public GeneralPanel()
		{
			setBorder(BorderFactory.createTitledBorder("General"));
			setLayout(new GridBagLayout());

			GUIUtility.addRow(this, new JLabel("Name: "), _layerName);
		}
		
		/**
		 * Update the content of this panel with the values from the renderable layer
		 * 
		 * @param layer
		 */
		public void update(RenderableLayer layer)
		{
			_layerName.setText(layer.getName());
		}

		public void getSymbols(RenderableLayer layer)
		{
			layer.setName(_layerName.getText());
		}
	}	
	
	/**
	 * Panel for changing how text labels are drawn
	 * 
	 * @author bjmerch
	 *
	 */
	private class TextLabelPanel extends JPanel
	{
		private JComboBox<String> _labelField = new JComboBox<String>();
	    private JFormattedTextField _fontSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));	
	    private JColorButton _textColor = new JColorButton(35,20);
		
		public TextLabelPanel()
		{
			setBorder(BorderFactory.createTitledBorder("Labels"));
			setLayout(new GridBagLayout());

			GUIUtility.addRow(this, new JLabel("Label Field: "), _labelField);
			GUIUtility.addRow(this, new JLabel("Font Size: "), _fontSize);
			GUIUtility.addRow(this, new JLabel("Text Color: "), _textColor);
		}
		
		
		/**
		 * Update the content of this panel with the values from the renderable layer
		 * 
		 * @param layer
		 */
		public void update(RenderableLayer layer)
		{
			int fontsize = 12;
			Color textColor = Color.BLACK;

			GUIUtility.setEnabled(TextLabelPanel.this, true);
			
			for (Renderable r : layer.getRenderables())
			{
				if ( r instanceof GlobeAnnotation )
				{
					GlobeAnnotation ga = (GlobeAnnotation) r;
					
					updateTextLabel(ga.getText(), ga);
					fontsize = ga.getAttributes().getFont().getSize();
					textColor = ga.getAttributes().getTextColor();
					
					break;
				}
				else if ( r instanceof PointGrid )
				{
					PointGrid pg = (PointGrid) r;
					
					//  No labels on a point grid
				}
				else if ( r instanceof PointPlacemark )
				{
					PointPlacemark pp = (PointPlacemark) r;
					PointPlacemarkAttributes ppa = pp.getAttributes();

					updateTextLabel(pp.getLabelText(), pp);
					fontsize = ppa.getLabelFont().getSize();
					textColor = ppa.getLabelColor();
					
					break;
				}
				else
					GUIUtility.setEnabled(TextLabelPanel.this, false);
			}
			
			_fontSize.setValue(fontsize);
			_textColor.setColor(textColor);
		}
		
		private void updateTextLabel(String label, AVList avlist)
		
		{
			_labelField.removeAllItems();
			_labelField.addItem("");
			for (Entry<String,Object> entry : avlist.getEntries())
			{
				if ( entry.getKey().contains("avlist") )
					continue;
				
				_labelField.addItem(entry.getKey());
				if ( entry.getValue().equals(label) )
					_labelField.setSelectedItem(entry.getKey());
			}
		}


		public void getSymbols(RenderableLayer layer)
		{
			String labelField = "";
			if ( _labelField.getSelectedItem() != null )
				labelField = _labelField.getSelectedItem().toString().trim();
			
			Font font = new Font("Dialog", Font.PLAIN, ((Number) _fontSize.getValue()).intValue());
			Color color = _textColor.getColor();
			
			for (Renderable r : layer.getRenderables())
			{
				if ( r instanceof GlobeAnnotation )
				{
					GlobeAnnotation ga = (GlobeAnnotation) r;
					
					Object value = ga.getValue(labelField);
					if ( value != null )
						ga.setText(value.toString());
					else
						ga.setText("");
					
					ga.getAttributes().setFont(font);
					ga.getAttributes().setTextColor(color);
					ga.getAttributes().setBorderColor(color);
				}
				else if ( r instanceof PointGrid )
				{
					PointGrid pg = (PointGrid) r;
					
					//  No labels on a point grid
				}
				else if ( r instanceof PointPlacemark )
				{
					PointPlacemark pp = (PointPlacemark) r;
					PointPlacemarkAttributes ppa = pp.getAttributes();

					ppa.setDrawLabel(!labelField.isEmpty());
					Object value = pp.getValue(labelField);
					if ( value != null )
						pp.setLabelText(value.toString());
					else
						pp.setLabelText("");
					
					ppa.setLabelFont(font);
					ppa.setLabelMaterial(new Material(color));
					ppa.setLabelOffset(new Offset(10.0,10.0,null, null));
					ppa.setLineMaterial(new Material(color));
				}
			}
		}
	}
	
	/**
	 * Panel for changing how points are drawn
	 * 
	 * @author bjmerch
	 *
	 */
	private class PointPanel extends JPanel
	{
		private JComboBox<String> _pointType = new JComboBox<String>(new String[] { PatternFactory.PATTERN_CIRCLE, PatternFactory.PATTERN_TRIANGLE_UP,
				PatternFactory.PATTERN_SQUARE, PatternFactory.PATTERN_DIAGONAL_DOWN, PatternFactory.PATTERN_DIAGONAL_UP, PatternFactory.PATTERN_HLINE, 
				PatternFactory.PATTERN_HVLINE, PatternFactory.PATTERN_VLINE});
	    private JFormattedTextField _pointSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));	
	    private JColorButton _pointColor = new JColorButton(35,20);
		
		public PointPanel()
		{
			setBorder(BorderFactory.createTitledBorder("Points"));
			setLayout(new GridBagLayout());

			GUIUtility.addRow(this, new JLabel("Point Type: "), _pointType);
			GUIUtility.addRow(this, new JLabel("Point Size: "), _pointSize);
			GUIUtility.addRow(this, new JLabel("Point Color: "), _pointColor);
		}
		
		
		/**
		 * Update the content of this panel with the values from the renderable layer
		 * 
		 * @param layer
		 */
		public void update(RenderableLayer layer)
		{
			//  Get the attributes of the point
			double size = 10;
			Color color = Color.BLACK;
			String type = PatternFactory.PATTERN_CIRCLE;

			GUIUtility.setEnabled(PointPanel.this, true);
			
			for (Renderable r : layer.getRenderables())
			{
				Image image = null;

				System.out.println("updating with : " + r + ", " + r.getClass());
				if ( r instanceof GlobeAnnotation )
				{
					GlobeAnnotation ga = (GlobeAnnotation) r;
					AnnotationAttributes gaa = ga.getAttributes();
					type = gaa.getLeader();
					image = (Image) gaa.getImageSource();
				}
				else if ( r instanceof PointGrid )
				{
					PointGrid pg = (PointGrid) r;
					size = ExtendedPointGrid.getSize(pg);
					color = ExtendedPointGrid.getColor(pg);
					type = ( ExtendedPointGrid.getPointSmoothing(pg) ? PatternFactory.PATTERN_CIRCLE : PatternFactory.PATTERN_SQUARE );
				}
				else if ( r instanceof PointPlacemark )
				{
					PointPlacemark pp = (PointPlacemark) r;
					PointPlacemarkAttributes ppa = pp.getAttributes();

					image = ppa.getImage();
					color = ppa.getImageColor();
					type = ppa.getImageAddress();
				}
				else
					GUIUtility.setEnabled(PointPanel.this, false);
				
				BufferedImage bimage = getBufferedImage(image);
				if ( bimage != null )
				{
					size = Math.min(bimage.getHeight(), bimage.getWidth());
					color = new Color(bimage.getRGB((int) (size/2), (int) (size/2)));
				}
				
//				if ( type == PatternFactory.PATTERN_CIRCLE )
//					size += 4;
			}
			
			_pointType.setSelectedItem(type);
			_pointSize.setValue(size);
			_pointColor.setColor(color);
		}
		
		private BufferedImage getBufferedImage(Image image)
		{
			if ( image == null )
				return null;
			
			if ( image instanceof BufferedImage )
				return (BufferedImage) image;
			
		    BufferedImage bimage = new BufferedImage(
		    		image.getWidth(null), 
		    		image.getHeight(null), BufferedImage.TYPE_INT_ARGB);

		    // Draw the image on to the buffered image
		    Graphics2D g2d = bimage.createGraphics();
		    g2d.drawImage(image, 0, 0, null);
		    g2d.dispose();

		    // Return the buffered image
		    return bimage;
		}
		
		public void getSymbols(RenderableLayer layer)
		{
			//  Get the attributes of the point
			int size = ((Number) _pointSize.getValue()).intValue();
			Color color = _pointColor.getColor();
			String type = _pointType.getSelectedItem().toString();
			
//			if ( type == PatternFactory.PATTERN_CIRCLE )
//				size = Math.max(size-4, 1);
			
			BufferedImage image = PatternFactory.createPattern(type, new Dimension(size, size), 1.0f, color, null);
			
			for (Renderable r : layer.getRenderables())
			{
				System.out.println("getting symbols with : " + r + ", " + r.getClass());
				if ( r instanceof GlobeAnnotation )
				{
					GlobeAnnotation ga = (GlobeAnnotation) r;
					AnnotationAttributes gaa = ga.getAttributes();
					
					gaa.setLeader(type);
					gaa.setImageSource(image);
				}
				else if ( r instanceof PointGrid )
				{
					PointGrid pg = (PointGrid) r;
					
					ExtendedPointGrid.setSize(pg, size);
					ExtendedPointGrid.setColor(pg, color);
					ExtendedPointGrid.setPointSmoothing(pg, type.equals(PatternFactory.PATTERN_CIRCLE));
				}
				else if ( r instanceof PointPlacemark )
				{
					PointPlacemark pp = (PointPlacemark) r;
					PointPlacemarkAttributes ppa = pp.getAttributes();

					ppa.setImageAddress(type);
					ppa.setImageColor(color);
					ppa.setImage(image);
					ppa.setImageAddress(type);
				}
			}
		}
	}
	
	/**
	 * Extend PointGrid so that we can access some of the protected attributes within PointGrid.
	 * Work-around for something wrong with WorldWind.
	 * 
	 * @author bjmerch
	 *
	 */
	private static class ExtendedPointGrid extends PointGrid
	{
		public static void setSize(PointGrid pg, double size)
		{
			pg.getAttributes().setPointSize(size);
		}
		
		public static void setPointSmoothing(PointGrid pg, boolean value)
		{
			pg.getAttributes().setEnablePointSmoothing(value);
		}
		
		public static void setColor(PointGrid pg, Color color)
		{
			pg.getAttributes().setPointColor(color);
		}
		
		public static double getSize(PointGrid pg)
		{
			return pg.getAttributes().getPointSize();
		}
		
		public static Color getColor(PointGrid pg)
		{
			return pg.getAttributes().getPointColor();
		}
		
		public static boolean getPointSmoothing(PointGrid pg)
		{
			return pg.getAttributes().isEnablePointSmoothing();
		}
	}
	
	enum StipplePattern
	{
		SOLID("Solid", 0xFFFF, 1),
		DASH("Dash", 0xF8F8, 1),
		DOT("Dot", 0xC0C0, 1),
		DASHDOT("Dash Dot", 0xF861, 1);
		
		private String name;
		private int stipple;
		private int factor;
		
		StipplePattern(String name, int stipple, int factor)
		{
			this.name = name;
			this.stipple = stipple;
			this.factor = factor;
		}
		
		public static StipplePattern valueOf(int stipple, int factor)
		{
			for (StipplePattern pattern : values())
			{
				if (pattern.stipple == stipple && pattern.factor == factor)
					return pattern;
			}
			
			return SOLID;
		}
	
	}
	
	/**
	 * Panel for changing how lines are drawn
	 * 
	 * @author bjmerch
	 *
	 */
	private class LinePanel extends JPanel
	{
		private JCheckBox _lineDrawn = new JCheckBox("Draw Lines");
		private JComboBox<StipplePattern> _lineType = new JComboBox<StipplePattern>(StipplePattern.values());
	    private JFormattedTextField _lineWidth = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));	
	    private JFormattedTextField _lineOpacity = new JFormattedTextField(new DoubleRangeFormatter(0, 1));	
	    private JColorButton _lineColor = new JColorButton(35,20);
		private JCheckBox _lineAntialias = new JCheckBox("Anti-Aliasing");
		
		public LinePanel()
		{
			setBorder(BorderFactory.createTitledBorder("Lines"));
			setLayout(new GridBagLayout());

			GUIUtility.addRow(this,  _lineDrawn);
			GUIUtility.addRow(this, new JLabel("Line Type: "), _lineType);
			GUIUtility.addRow(this, new JLabel("Line Width: "), _lineWidth);
			GUIUtility.addRow(this, new JLabel("Line Color: "), _lineColor);
			GUIUtility.addRow(this,  new JLabel("Line Opacity: "), _lineOpacity);
			GUIUtility.addRow(this,  _lineAntialias);
		}
		
		
		/**
		 * Update the content of this panel with the values from the renderable layer
		 * 
		 * @param layer
		 */
		public void update(RenderableLayer layer)
		{
			//  Get the attributes of the line
			boolean lineDrawn = true;
			StipplePattern lineType = StipplePattern.SOLID;
			double lineWidth = 1.0;
			Color lineColor = Color.BLACK;
			double lineOpacity = 1.0;
			boolean lineAntialias = true;

			GUIUtility.setEnabled(LinePanel.this, true);
			
			for (Renderable r : layer.getRenderables())
			{
				System.out.println("ShapePanel.update: " + r);
				if ( r instanceof AbstractShape )
				{
					AbstractShape shape = (AbstractShape) r;
					ShapeAttributes attributes = shape.getAttributes();
					
					lineDrawn = attributes.isDrawOutline();
					lineWidth = attributes.getOutlineWidth();
					lineColor = attributes.getOutlineMaterial().getSpecular();
					lineOpacity = attributes.getOutlineOpacity();
					lineType = StipplePattern.valueOf(attributes.getOutlineStipplePattern(), attributes.getOutlineStippleFactor());
					lineAntialias = attributes.isEnableAntialiasing();
				}
				else if ( r instanceof ShapefileRenderable )
				{
					 
					ShapefileRenderable sfr = (ShapefileRenderable) r;
					System.out.println("LinePanel.update ShapefileRenderable " + sfr.getRecordCount() + ": " + r);
					
					for (int i=0; i<sfr.getRecordCount(); i++)
					{
						Record record = sfr.getRecord(i);
						ShapeAttributes attributes = record.getAttributes();

						lineDrawn = attributes.isDrawOutline();
						lineWidth = attributes.getOutlineWidth();
						lineColor = attributes.getOutlineMaterial().getSpecular();
						lineOpacity = attributes.getOutlineOpacity();
						lineType = StipplePattern.valueOf(attributes.getOutlineStipplePattern(), attributes.getOutlineStippleFactor());
						lineAntialias = attributes.isEnableAntialiasing();
					}
				}
				else
					GUIUtility.setEnabled(LinePanel.this, false);
			}
			
			_lineType.setSelectedItem(lineType);
			_lineDrawn.setSelected(lineDrawn);
			_lineWidth.setValue(lineWidth);
			_lineColor.setColor(lineColor);
			_lineOpacity.setValue(lineOpacity);
			_lineAntialias.setEnabled(lineAntialias);
		}
		
		public void getSymbols(RenderableLayer layer)
		{
			//  Get the attributes of the line
			boolean lineDrawn = _lineDrawn.isSelected();
			StipplePattern lineType = (StipplePattern) _lineType.getSelectedItem();
			double lineWidth = ((Number) _lineWidth.getValue()).intValue();
			Color lineColor = _lineColor.getColor();
			double lineOpacity = ((Number) _lineOpacity.getValue()).doubleValue();
			boolean lineAntialias = _lineAntialias.isSelected();
			
			for (Renderable r : layer.getRenderables())
			{
				if ( r instanceof AbstractShape )
				{
					AbstractShape shape = (AbstractShape) r;
					ShapeAttributes attributes = shape.getAttributes();
					
					attributes.setDrawOutline(lineDrawn);
					attributes.setOutlineWidth(lineWidth);
					attributes.setOutlineMaterial(new Material(lineColor));
					attributes.setOutlineOpacity(lineOpacity);
					attributes.setOutlineStipplePattern((short) lineType.stipple);
					attributes.setOutlineStippleFactor(lineType.factor);
					attributes.setEnableAntialiasing(lineAntialias);
					
					shape.setAttributes(attributes);
				}
				else if ( r instanceof ShapefileRenderable )
				{
					ShapefileRenderable sfr = (ShapefileRenderable) r;
					for (int i=0; i<sfr.getRecordCount(); i++)
					{
						Record record = sfr.getRecord(i);
						ShapeAttributes attributes = record.getAttributes();

						attributes.setDrawOutline(lineDrawn);
						attributes.setOutlineWidth(lineWidth);
						attributes.setOutlineMaterial(new Material(lineColor));
						attributes.setOutlineOpacity(lineOpacity);
						attributes.setOutlineStipplePattern((short) lineType.stipple);
						attributes.setOutlineStippleFactor(lineType.factor);
						attributes.setEnableAntialiasing(lineAntialias);
					}
				}
			}
		}
	}
	
	/**
	 * Panel for changing how polygons are drawn
	 * 
	 * @author bjmerch
	 *
	 */
	private class PolygonPanel extends JPanel
	{
		private JCheckBox _fillDrawn = new JCheckBox("Draw Interior");
	    private JColorButton _fillColor = new JColorButton(35,20);
	    private JFormattedTextField _fillOpacity = new JFormattedTextField(new DoubleRangeFormatter(0, 1));	
		private JCheckBox _enableLighting = new JCheckBox("Enable Lighting");
		
		public PolygonPanel()
		{
			setBorder(BorderFactory.createTitledBorder("Fill"));
			setLayout(new GridBagLayout());

			GUIUtility.addRow(this,  _fillDrawn);
			GUIUtility.addRow(this, new JLabel("Fill Color: "), _fillColor);
			GUIUtility.addRow(this,  new JLabel("Fill Opacity: "), _fillOpacity);
			GUIUtility.addRow(this,  _enableLighting);
		}
		
		
		/**
		 * Update the content of this panel with the values from the renderable layer
		 * 
		 * @param layer
		 */
		public void update(RenderableLayer layer)
		{
			//  Get the attributes of the line
			boolean fillDrawn = true;
			Color fillColor = Color.BLACK;
			double fillOpacity = 1.0;
			boolean enableLighting = true;

			GUIUtility.setEnabled(PolygonPanel.this, true);
			
			for (Renderable r : layer.getRenderables())
			{
				if ( r instanceof AbstractShape )
				{
					AbstractShape shape = (AbstractShape) r;
					ShapeAttributes attributes = shape.getAttributes();
					
					fillDrawn = attributes.isDrawInterior();
					fillColor = attributes.getInteriorMaterial().getSpecular();
					fillOpacity = attributes.getInteriorOpacity();
					enableLighting = attributes.isEnableLighting();
				}
				else if ( r instanceof ShapefileRenderable )
				{
					ShapefileRenderable sfr = (ShapefileRenderable) r;
					for (int i=0; i<sfr.getRecordCount(); i++)
					{
						Record record = sfr.getRecord(i);
						ShapeAttributes attributes = record.getAttributes();
						
						fillDrawn = attributes.isDrawInterior();
						fillColor = attributes.getInteriorMaterial().getSpecular();
						fillOpacity = attributes.getInteriorOpacity();
						enableLighting = attributes.isEnableLighting();
					}
				}
				else
					GUIUtility.setEnabled(PolygonPanel.this, false);
			}
			
			_fillDrawn.setSelected(fillDrawn);
			_fillColor.setColor(fillColor);
			_fillOpacity.setValue(fillOpacity);
			_enableLighting.setSelected(enableLighting);
		}
		
		public void getSymbols(RenderableLayer layer)
		{
			//  Get the attributes of the line
			boolean fillDrawn = _fillDrawn.isSelected();
			Color fillColor = _fillColor.getColor();
			double fillOpacity = ((Number) _fillOpacity.getValue()).doubleValue();
			boolean enableLighting = _enableLighting.isSelected();
			
			for (Renderable r : layer.getRenderables())
			{
				if ( r instanceof AbstractShape )
				{
					AbstractShape shape = (AbstractShape) r;
					ShapeAttributes attributes = shape.getAttributes();
					
					attributes.setDrawInterior(fillDrawn);
					attributes.setInteriorMaterial(new Material(fillColor));
					attributes.setInteriorOpacity(fillOpacity);
					attributes.setEnableLighting(enableLighting);
					
					shape.setAttributes(attributes);
				}
				else if ( r instanceof ShapefileRenderable )
				{
					ShapefileRenderable sfr = (ShapefileRenderable) r;
					
					for (int i=0; i<sfr.getRecordCount(); i++)
					{
						Record record = sfr.getRecord(i);
						ShapeAttributes attributes = record.getAttributes();
						
						attributes.setDrawInterior(fillDrawn);
						attributes.setInteriorMaterial(new Material(fillColor));
						attributes.setInteriorOpacity(fillOpacity);
						attributes.setEnableLighting(enableLighting);
						
						record.setAttributes(attributes);
					}
				}
			}
		}
	}
	
	private GeneralPanel generalPanel = new GeneralPanel();
	private TextLabelPanel labelPanel = new TextLabelPanel();
	private PointPanel pointPanel = new PointPanel();
	private LinePanel linePanel = new LinePanel();
	private PolygonPanel polygonPanel = new PolygonPanel();
	
	public SymbolPanel()
	{
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(generalPanel);
        add(labelPanel);
        add(pointPanel);
        add(linePanel);
        add(polygonPanel);
	}

	public void setLayer(RenderableLayer layer)
	{
		update(layer);
	}

	private void update(RenderableLayer layer)
	{
		generalPanel.update(layer);
		labelPanel.update(layer);
		pointPanel.update(layer);
		linePanel.update(layer);
		polygonPanel.update(layer);
	}

	public void getSymbols(RenderableLayer layer)
	{
		generalPanel.getSymbols(layer);
		labelPanel.getSymbols(layer);
		pointPanel.getSymbols(layer);
		linePanel.getSymbols(layer);
		polygonPanel.getSymbols(layer);
	}
}
