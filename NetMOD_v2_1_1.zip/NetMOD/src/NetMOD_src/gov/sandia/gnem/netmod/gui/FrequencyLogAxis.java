/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberTick;
import org.jfree.chart.axis.ValueTick;
import org.jfree.data.Range;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

/**
 * A log-scale axis used for displaying the frequency domain. It
 * overrides {@link LogarithmicAxis} to display axis labels for only a
 * subset of grid lines, and let the user to specify the minimum value to be
 * labeled.
 * 
 * @author bjmerch
 * 
 */
public class FrequencyLogAxis extends LogarithmicAxis
{
    private int _maxTickCount = 10;
    private double _minTickValue = Math.ulp(1.0);
    private double _maxTickValue = Double.MAX_VALUE;
    public FrequencyLogAxis(String label)
    {
        super(label);
        setAutoRangeNextLogFlag(false);
        setAllowNegativesFlag(false);
    }

    /**
     * @return the maxTickCount
     */
    public int getMaxTickCount()
    {
        return _maxTickCount;
    }

    /**
     * @return the maxTickValue
     */
    public double getMaxTickValue()
    {
        return _maxTickValue;
    }
    /**
     * @return the minTickValue
     */
    public double getMinTickValue()
    {
        return _minTickValue;
    }

    /**
     * Return a list of axis ticks, one for each power of 10 and its integer
     * multiples. Create labels only for ticks that are powers of 10, but if
     * fewer than 3 powers of 10 are visible, create a label for every tick.
     */
    @Override
    @SuppressWarnings("unchecked")
    public List refreshTicks(java.awt.Graphics2D g2, AxisState state, java.awt.geom.Rectangle2D dataArea, org.jfree.ui.RectangleEdge edge)
    {
        Range range = getRange();
        
        double lower = Math.max(range.getLowerBound(), _minTickValue);
        if (lower <= 0) {
        	lower = _minTickValue;
        }

        double upper = Math.min(range.getUpperBound(), _maxTickValue);
        if (lower > upper)
        {
            double temp = lower;
            lower = upper;
            upper = temp;
        }
        
        setRange(new Range(lower, upper), false, false);

        List<ValueTick> ticks = (List<ValueTick>) super.refreshTicks(g2, state, dataArea, edge);
        
        // Make a label to be displayed for each tick.
        Map<ValueTick, Boolean> tickDecade = new LinkedHashMap<ValueTick, Boolean>();
        Map<ValueTick, Double> tickWeights = new LinkedHashMap<ValueTick, Double>();

        NumberFormat format1 = new DecimalFormat();
        NumberFormat format2 = new DecimalFormat("0.0##E0");
        
        int prevDecadeExponent = Integer.MIN_VALUE;
        double prevLogVal = 0;
        int decades = 0;

        for (ValueTick tick : ticks)
        {
            double val = tick.getValue();
            double logVal = Math.log10(val);
            int intLogVal = (int) Math.rint(logVal);
            boolean isDecadeMarker = Math.abs(logVal - intLogVal) < 0.001;
            if ( isDecadeMarker )
                decades++;

            // Tick is a decade marker.
            if (isDecadeMarker)
            {
                // Check for duplicate decade marker returned from
                // LogarithmicAxis.
                if (intLogVal == prevDecadeExponent)
                    continue;

                prevDecadeExponent = intLogVal;
            }
            
            double weight = Math.abs(logVal - prevLogVal);
            prevLogVal = logVal;

            tickDecade.put(tick, isDecadeMarker);
            tickWeights.put(tick, weight);
        }
        
        //  Determine the weight threshold to allow at most 5 ticks.
        List<Double> weights = new ArrayList<Double>(tickWeights.values());
        Collections.sort(weights);
        
        double weightThreshold = Double.MAX_VALUE;
        if ( decades <= 3 && weights.size() > 0 )
            weightThreshold = weights.get(Math.max(0, weights.size()- getMaxTickCount()));

        // Make axis ticks. Make a label for all ticks if fewer than 2
        // powers of 10 are visible. Otherwise, show labels only for powers
        // of 10.
        List<NumberTick> myTicks = new ArrayList<NumberTick>();
        int i = 0;

        for (ValueTick tick : tickDecade.keySet())
        {
            double val = tick.getValue();
            
            boolean isDecade = tickDecade.get(tick);
            boolean isFirst = i == 0;
            boolean isLast = i == tickDecade.size()-1;
            
            String label = "";
            if ( isDecade || isFirst || isLast || tickWeights.get(tick) >= weightThreshold )
            {
                if ( val >= 0.001 && val <= 10000 )
                    label = format1.format(val);
                else
                    label = format2.format(val);
            }
            
            myTicks.add(new NumberTick(tick.getTickType(), val, label, tick.getTextAnchor(), tick.getRotationAnchor(), tick.getAngle()));
            
            i++;
        }

        return myTicks; 
    }

    /**
     * @param maxTickCount the maxTickCount to set
     */
    public void setMaxTickCount(int maxTickCount)
    {
        _maxTickCount = maxTickCount;
    } 

    /**
     * Set the maximum tick for this axis to the specified value.
     */
    public void setMaxTickValue(double value)
    {
        _maxTickValue = value;
    }

    /**
     * Set the minimum tick for this axis to the specified value.
     */
    public void setMinTickValue(double value)
    {
        _minTickValue = value;
    }

    /**
     * Overridden method used to force the axis to always display ticks and
     * labels for values less than 1.
     */
    @Override
    protected void setupSmallLogFlag()
    {
        this.smallLogFlag = true;
    }
    
//    @Override
//    public void autoAdjustRange()
//    {
//        Range range = getRange();
//        double lower = Math.max(range.getLowerBound(), _minTickValue);
//        double upper = Math.min(range.getUpperBound(), _maxTickValue);
//        setRange(new Range(lower, upper), false, false);
//        
//        //  Handle ranges that include <= 0
//        try
//        {
//            super.autoAdjustRange();
//        }
//        catch (Exception e)
//        {}
//        
//    }
    
//    @Override
//    public void setRange(Range range, boolean turnOffAutoRange, boolean notify)
//    {
//        //  Get the existing range
//        double length = range.getLength();
//        double lower = range.getLowerBound();
//        double upper = range.getUpperBound();
//        
//        //  Expand slightly so that the upper and lower limits are integer values
//        if ( upper < 0.03 )
//        {
//            upper = Math.ceil(upper * 1000) / 1000;
//        }
//        else if ( upper < 0.3 )
//        {
//            upper = Math.ceil(upper * 100) / 100;
//        }
//        else if ( upper < 3.0 )
//        {
//            upper = Math.ceil(upper * 10) / 10;
//        }
//        else if ( upper < 30.0 )
//        {
//            upper = Math.ceil(upper);
//        }
//        else
//        {
//            upper = Math.ceil(upper / 10) * 10;
//        }
//        
//        if (  lower < 0.03 )
//        {
//            lower = Math.floor(lower * 1000) / 1000;
//        }
//        else if ( lower < 0.3 )
//        {
//            lower = Math.floor(lower * 100) / 100;
//        }
//        else if ( lower < 3.0 )
//        {
//            lower = Math.floor(lower * 10) / 10;
//        }
//        else if ( lower < 30.0 )
//        {
//            lower = Math.floor(lower);
//        }
//        else
//        {
//            lower = Math.floor(lower / 10) * 10;
//        }
//        
//        lower = Math.max(lower, _minTickValue);
//        upper = Math.min(upper, _maxTickValue);
//        
//        //  Set the new adjusted range
//        super.setRange(new Range(lower, upper), turnOffAutoRange, notify);
//    }
}
