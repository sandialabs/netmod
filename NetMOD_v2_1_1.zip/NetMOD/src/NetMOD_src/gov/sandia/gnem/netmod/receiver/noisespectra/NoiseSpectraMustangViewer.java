/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.gui.ChartViewer.AxisScale;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.PDF;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.AbstractIntervalXYDataset;
import org.jfree.data.xy.AbstractXYDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.IndexColorModel;
import java.util.List;

/**
 * Viewer for a NoiseSpectraTextCDF
 * 
 * @author bjmerch
 *
 */
class NoiseSpectraMustangViewer extends NetModComponentViewer<NoiseSpectraMustang> implements NoiseSpectraViewerInterface
{
    private class CDFNoiseDataset extends AbstractIntervalXYDataset implements VisibleXYDataset
    {

        private boolean _visible = true;
        private NoiseSpectraMustang _noise = null;

        @Override
        public Number getEndX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getEndY(int series, int item)
        {
            if (series >= getSeriesCount() - 1)
                return getY(getSeriesCount() - 1, item);

            return getY(series + 1, item);
        }

        @Override
        public int getItemCount(int series)
        {
            if (!isVisible())
                return 0;

            return (_noise == null || series == 0 ? 0 : _noise.getFrequencies().length);
        }

        @Override
        public int getSeriesCount()
        {
            return (_noise == null ? 1 : _noise.getPercentiles().length+1);
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            if ( series == 0 )
                return "CDF";
            
            //  Reverse the series index so that legend is ascending
            series = getSeriesCount() - series - 1;

            return String.format("%6.2f%%", _noise.getPercentiles()[series] * 100);
        }

        @Override
        public Number getStartX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getStartY(int series, int item)
        {
            return getY(series, item);
        }

        @Override
        public Number getX(int series, int item)
        {
            return _noise.getFrequencies()[item];
        }

        @Override
        public Number getY(int series, int item)
        {
            //  Reverse the series index so that legend is ascending
            series = getSeriesCount() - series - 1;
            
            NonParametricCDF pdf = getPDF(series, item);
            
            return pdf.getX(series);
        }

        /**
         * Get the visibility
         * 
         * @return
         */
        @Override
        public boolean isVisible()
        {
            return _visible;
        }

        public void setNoise(NoiseSpectraMustang noise)
        {
            _noise = noise;
            fireDatasetChanged();
        }

        /**
         * Set the visibility
         * 
         * @param visible
         * @return
         */
        @Override
        public void setVisible(boolean visible)
        {
            _visible = visible;

            fireDatasetChanged();
        }

        private NonParametricCDF getPDF(int series, int item)
        {
            return (NonParametricCDF) _noise.getNoise(new DiscreteFrequency(getX(series, item).doubleValue()), new Time(0)).getValue(0);
        }
    }

    /**
     * Dataset to represent the noise spectra on a plot
     * 
     * @author bjmerch
     *
     */
    private class NoiseIntervalDataset extends AbstractIntervalXYDataset implements VisibleXYDataset
    {

        private boolean _visible = true;

        int N = 100;

        private NoiseSpectraMustang _noise = null;

        private String _name = "Noise Spectra";

        public NoiseIntervalDataset()
        {
        }

        public NoiseIntervalDataset(NoiseSpectraMustang noise)
        {
            _name = noise.getName();

            setNoise(noise);
        };

        @Override
        public Number getEndX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getEndY(int series, int item)
        {
            PDF pdf = getPDF(series, item);

            //  Only plot std-dev bars for the interpolated series
            if (series == 0)
                return pdf.getMean();
            else
                return pdf.getMean() + pdf.getStandardDeviation();
        }

        @Override
        public int getItemCount(int series)
        {
            if (!isVisible())
                return 0;

            if (series == 0)
                return (_noise == null ? 0 : _noise.getFrequencies().length);
            else
                return (_noise == null ? 0 : N * (_noise.getFrequencies().length - 1) + 1);
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return _name;
        }

        @Override
        public Number getStartX(int series, int item)
        {
            return getX(series, item);
        }

        @Override
        public Number getStartY(int series, int item)
        {
            PDF pdf = getPDF(series, item);

            //  Only plot std-dev bars for the interpolated series
            if (series == 0)
                return pdf.getMean();
            else
                return pdf.getMean() - pdf.getStandardDeviation();
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _noise.getFrequencies()[item];
            else
            {
                int index = item / N;
                double[] f = _noise.getFrequencies();

                if (index == f.length - 1)
                    return f[index];

                return Interpolation.linear(index * N, (index + 1) * N, f[index], f[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            return getPDF(series, item).getMean();
        }

        /**
         * Get the visibility
         * 
         * @return
         */
        @Override
        public boolean isVisible()
        {
            return _visible;
        }

        public void setNoise(NoiseSpectraMustang noise)
        {
            _noise = noise;
            fireDatasetChanged();
        }

        /**
         * Set the visibility
         * 
         * @param visible
         * @return
         */
        @Override
        public void setVisible(boolean visible)
        {
            _visible = visible;

            fireDatasetChanged();
        }

        private PDF getPDF(int series, int item)
        {
            return _noise.getNoise(new DiscreteFrequency(getX(series, item).doubleValue()), new Time(0)).getValue(0);
        }
    }

    private class NoiseTableModel extends NetMODTableModel
    {
        private NoiseSpectraMustang _noise = null;

        @Override
        public int getColumnCount()
        {
            return (_noise == null ? 0 : _noise.getPercentiles().length + 3);
        }

        public String getColumnName(int column)
        {
            if (column == 0)
                return "Frequency (Hz)";
            else if (column == 1)
                return "Mean";
            else if (column == 2)
                return "Std";
            else
                return (float) (_noise.getPercentiles()[column - 3] * 100) + " %";
        }

        @Override
        public int getRowCount()
        {
            return (_noise == null ? 0 : _noise.getFrequencies().length);
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_noise == null || row >= _noise.getFrequencies().length)
                return "";

            if (column == 0)
                return _noise.getFrequencies()[row];
            if (column == 1)
                return _noise.getNoise(new DiscreteFrequency(_noise.getFrequencies()[row]), new Time(0)).getValue(0).getMean();
            else if (column == 2)
                return _noise.getNoise(new DiscreteFrequency(_noise.getFrequencies()[row]), new Time(0)).getValue(0).getStandardDeviation();
            else
            {
                return _noise.getCDF()[column - 3][row];
            }
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return false;
        }

        @Override
        public void remove(int[] rows)
        {
            //  Deleting not supported
        }

        public void setNoise(NoiseSpectraMustang noise)
        {
            _noise = noise;
            fireTableStructureChanged();
        }
    }

    private ChartViewer _chartViewer = new ChartViewer();
    private CDFNoiseDataset _cdf_dataset = new CDFNoiseDataset();
    private NoiseIntervalDataset _interval_dataset = new NoiseIntervalDataset();

    private NoiseTableModel _tableModel = new NoiseTableModel();

    private NetMODTable _table = new NetMODTable(_tableModel);

    NoiseSpectraMustangViewer(NoiseSpectraMustang nmc)
    {
        super(nmc, false, false, false);

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Update the viewer
        reset(nmc);
    }

    @Override
    public void addNoiseModels(List<NoiseSpectra> noiseModels)
    {
        if (noiseModels == null)
            return;

        Color[] colors = new Color[] { Color.RED, Color.GREEN, Color.BLUE };

        XYPlot plot = _chartViewer.getPlot();

        for (int i = 0; i < noiseModels.size(); i++)
        {
            int count = plot.getDatasetCount();

            StandardXYItemRenderer renderer = new StandardXYItemRenderer();
            renderer.setBaseShapesVisible(false);
            renderer.setSeriesStroke(0, new BasicStroke(_chartViewer.getLineWidth() + 2));
            renderer.setSeriesPaint(0, colors[i % colors.length]);

            plot.setDataset(count, NoiseSpectraPlugin.createDataset(noiseModels.get(i)));
            plot.setRenderer(count, renderer);
        }
    }

    @Override
    public void apply(NoiseSpectraMustang nmc)
    {
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Configure the chart viewer
            _chartViewer.setXScale(AxisScale.LOG);
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Frequency (Hz)");
            plot.getRangeAxis().setLabel("Power Spectra Density (log10/Hz)");

            // Noise interval Dataset
            plot.setDataset(0, _interval_dataset);

            DeviationRenderer devRenderer = new DeviationRenderer(true, false);
            devRenderer.setAlpha(0.5f);
            devRenderer.setBaseToolTipGenerator(_chartViewer.getToolTipGenerator());

            devRenderer.setSeriesPaint(0, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesFillPaint(0, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesShape(0, new Ellipse2D.Double(-3, -3, 7, 7));
            devRenderer.setSeriesShapesVisible(0, true);
            devRenderer.setSeriesLinesVisible(0, false);
            devRenderer.setSeriesVisibleInLegend(0, false);

            devRenderer.setSeriesPaint(1, ((Color) _chartViewer.getLinePaint(0)));
            devRenderer.setSeriesFillPaint(1, _chartViewer.getLinePaint(0));
            devRenderer.setSeriesStroke(1, new BasicStroke(_chartViewer.getLineWidth()));
            plot.setRenderer(0, devRenderer);

            // Noise Dataset
            plot.setDataset(1, _cdf_dataset);

            //  Setup the table
            _table.addKeyListener(new KeyAdapter()
            {
                public void keyReleased(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                    {
                        // Get selected rows
                        int[] rows = _table.getSelectedRows();

                        reset(_nmc);
                    }
                }
            });

            JPanel sp = new JPanel(new BorderLayout());
            sp.add(BorderLayout.CENTER, new JScrollPane(_table));
            sp.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JPanel tablePanel = new JPanel(new BorderLayout());
            tablePanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            tablePanel.add(BorderLayout.CENTER, sp);

            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(tablePanel);

            //  Setup the panel
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    };

    @Override
    public void reset(NoiseSpectraMustang nmc)
    {
    	_nmc = nmc;
    	
        //  Update the plot
        _interval_dataset.setNoise(nmc);
        _cdf_dataset.setNoise(nmc);
        
        //  Update the renderer
        DeviationRenderer devRenderer = new DeviationRenderer(true, false);
        devRenderer.setAlpha(0.5f);
        devRenderer.setSeriesPaint(0, new Color(0,0,0,0));
        
        //  Get the Jet color model
        IndexColorModel colorModel = ColorModel.REVERSE_JET.getColorModel();
        int Ncolors = colorModel.getMapSize();
        double[] percentiles = nmc.getPercentiles();
        int Npercentiles = percentiles.length;
        
        for (int i = 0; i < Npercentiles; i++)
        {
        	//  Get percentile, reverse order
        	double percentile = percentiles[Npercentiles-i-1];
        	
        	//  Limit the percentile to 0..1
        	percentile = Math.max(0.0, Math.min(1.0, percentile));
        	
        	// scale so that 50% -> Red and 0/100% -> Blue
        	int i_color = (int) ( Math.abs( percentile - 0.5 ) * 2 * (Ncolors - 1));
        	
        	Paint paint = new Color(colorModel.getRGB(i_color));
        	
            devRenderer.setSeriesPaint(i+1, paint);
            devRenderer.setSeriesFillPaint(i+1, paint);
            devRenderer.setSeriesStroke(i+1, new BasicStroke(_chartViewer.getLineWidth()));
        }
        _chartViewer.getPlot().setRenderer(1, devRenderer);

        //  Update the table
        _tableModel.setNoise(nmc);
    }
}
