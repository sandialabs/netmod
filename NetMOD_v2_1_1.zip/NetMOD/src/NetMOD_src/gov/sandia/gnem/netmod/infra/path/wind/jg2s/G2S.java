package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import gov.sandia.gnem.netmod.path.wind.WindModel;

public class G2S {

  EtmodDB etmodDB = new EtmodDB();
  int nz = 1;
  double delz = WindModel.ALTITUDE_KM;
  int order = 121;
  double[] ai = new double[nz];
  double[] ui = new double[nz];
  double[] vi = new double[nz];
  double[] ti = new double[nz];
  double[] di = new double[nz];
  double[] pr = new double[nz];


  public void simulation(G2SDB g2sdb, double glat, double glon, double[] w) {

    Profile.initprofile(g2sdb, glon, glat, delz, nz, order);

    Profile.getProfile2(g2sdb, etmodDB, ai, ti, ui, vi, di, pr);

    w[0] = vi[0];
    w[1] = ui[0];
  }

}
