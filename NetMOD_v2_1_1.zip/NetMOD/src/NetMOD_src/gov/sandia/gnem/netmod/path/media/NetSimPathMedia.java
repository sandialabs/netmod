/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.media;

import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.simulation.DetectionPhase;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import cern.colt.Arrays;

/**
 * @author bjmerch
 *
 */
public class NetSimPathMedia extends PathMedia
{
    private static String _type = "NetSIM Path Media";

    //  Register the plugin
    static
    {
        PathMediaPlugin.getPlugin().registerComponent(_type, NetSimPathMedia.class, true);
    }

    private String _pathGridFile = "";
    private String _pathMediaFile = "";
    private Collection<? extends Phase> _phases;

    public NetSimPathMedia(NetModComponent parent)
    {
        super(parent, _type);
        
        setName("Path Media");
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof PathMediaType);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.addAll(getMediaTypes());

        return children;
    }

    @Override
    public Layer<?> getMapLayer()
    {
        if ( NetMOD.getMap() == null )
            return null;

        return NetMOD.getMap().createMediaGridLayer(this);
    }

    @Override
    public boolean getMediaDirty()
    {
        boolean dirty = false;
        
        for (PathMediaType media : getMediaTypes())
            dirty |= media.getDirty();
        
        return dirty;
    }

    @Override
    public String getPathGridFile()
    {
        return _pathGridFile;
    }

    @Override
    public String getPathMediaFile()
    {
        return _pathMediaFile;
    }

    @Override
    public Collection<? extends Phase> getPhases()
    {
        return _phases;
    }
    
    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new PathMediaViewer(this);
    }

    @Override
    public boolean isFor(Object o)
    {
        //  Extract a file from the object
        File file = null;
        if (o instanceof File)
            file = (File) o;
        else if (o instanceof String)
            file = IOUtility.openFile((String) o);

        //  Check if the file exists
        if (file == null || !file.exists())
            return false;
        
        //  Path Media Text Files end with ".pmd"
        return IOUtility.endsWith(file, ".pmd");
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof PathMediaType)
                addMediaType((PathMediaType) child);
        }

        clearCache();
    }

    @Override
    public void setMediaDirty(boolean mediaDirty)
    {
        for (PathMediaType media : getMediaTypes())
            media.setDirty(mediaDirty);
    }

    @Override
    public void setPathGridFile(String pathGridFile)
    {
        if ( _pathGridFile.equals(pathGridFile) )
            return;
        
        _pathGridFile = pathGridFile;
        if ( IOUtility.openFile(pathGridFile).exists() )
            readPathGrid();
        else
            writePathGrid();
    }

    @Override
    public void setPathMediaFile(String pathMediaFile)
    {
        if ( _pathMediaFile.equals(pathMediaFile) )
            return;
        
        _pathMediaFile = pathMediaFile;
        if ( IOUtility.openFile(pathMediaFile).exists() )
            readPathMedia();
        else
            writePathMedia();
    }

    @Override
    public void setPhases(Collection<? extends Phase> phases)
    {
        _phases = phases;
        
        //  Clear the existing path media, retaining reference
        {
            getMediaTypes().clear();
            
            //  Define the reference media type
            PathMediaType mediaType = new PathMediaType(this, getPhases());
            mediaType.setName(MediaGrid.REFERENCE);
            addMediaType(mediaType);
        }
    }

    @Override
    public boolean write()
    {
        writePathMedia();
        writePathGrid();
        
        return true;
    }

    private void readPathGrid()
    {
        readGrid(getPathGridFile());
    }

    private void readPathMedia()
    {
        //  Clear the existing path media, retaining reference
        {
            getMediaTypes().clear();
            
            //  Define the reference media type
            PathMediaType mediaType = new PathMediaType(this, getPhases());
            mediaType.setName(MediaGrid.REFERENCE);
            addMediaType(mediaType);
        }

        //  Read the media types from the file
        FileInputStream fis = null;
        Scanner fin = null;
        try
        {
            // Open file
            File pathMediaFile = IOUtility.openFile(getPathMediaFile());
            
            fis = new FileInputStream(pathMediaFile);
            fin = new Scanner(fis);

            //  Read the title
            fin.nextLine();
            
            //  Read the source spectra directory
            File attenuationDirectory = IOUtility.openFile(skipBlanksComments(fin).trim());

            //  If it doesn't exist check if the attenuation directory shares some common path with the path media directory
            if ( ! attenuationDirectory.exists() )
            {
                //  Split the paths based upon file separator
                String[] parentPath = pathMediaFile.getParent().split(Pattern.quote(File.separator));
                int N1 = parentPath.length;
                String[] attenuationPath = attenuationDirectory.getPath().split(Pattern.quote(File.separator));
                int N2 = attenuationPath.length;
                
                //  Start at the end of the attenuation directory and find where it starts to match the parent path
                for (int k=N2; --k>=0; )
                {
                    //  Flag to record whether the sub-path matches
                    boolean found = true;
                    
                    //  Verify that the sub-path matches
                    int N = Math.min(N1, N2-k);
                    for (int l=0; l<N; l++)
                    {
                        //  This piece of the path matches, so keep checking
                        if ( attenuationPath[k-l].equals(parentPath[N1-l-1]) )
                            continue;
                        
                        //  This piece didn't match, go on to the next found
                        found = false;
                        break;
                    }
                    
                    //  Found a matching sub path, build a new reference to the attenuation directory
                    if ( found )
                    {
                        StringBuilder sb = new StringBuilder();
                        for (int l=0; l<N1-k-1; l++)
                            sb.append(parentPath[l]).append(File.separator);
                        
                        sb.append(attenuationDirectory);
                        
                        attenuationDirectory = IOUtility.openFile(sb.toString());
                        
                        break;
                    }
                }
            }
            
            skipComments(fin);
            
            // Read in and store all of the source media types
            int numTypes = fin.nextInt();
            
            //  Read the first path media name
            String name = skipBlanksComments(fin).trim();
            
            for (int i = 0; i < numTypes; i++)
            {
                //  Create a new path media type, if necessary
                PathMediaType pmt = getMediaType(name);
                if (pmt == null)
                {
                    pmt = new PathMediaType(this, getPhases());
                    pmt.setName(name);
                    addMediaType(pmt);
                }
                
                PhaseParameters<PathMediaPhaseParameter> pp = pmt.getPhaseParameters();
                
                //  Read each of the phase parameters
                for (int j=0; ; j++)
                {
                	if ( !fin.hasNext() )
                		break;
                	
                	//  Get the line containing the attenuation and travel time files
                	String[] files = skipBlanksComments(fin).trim().split("\\s*(\\s|,)\\s*");
                	
                	//  If the next token is not a double, then the end of the phase parameters for this media type has been reached.
                	//  Go straight to the next source media types
                	if ( !fin.hasNextDouble() )
                	{
                		name = "";
                		
                		//  Make the file line to be the next path media name
                		if ( files.length > 0 )
                			name = files[0].toLowerCase();
                		break;
                	}
                	
                    //  Read the attenuation file
                    String amplitudeAttenuationFilename = ( files.length > 1 ? files[0] : "" );
                    File amplitudeAttenuationFile = IOUtility.openFile(attenuationDirectory, amplitudeAttenuationFilename);
                    
                    //  If it doesn't exist check if the file is located in the same path as the path media file
                    if ( !amplitudeAttenuationFile.exists() )
                        amplitudeAttenuationFile = IOUtility.openFile(pathMediaFile.getParent(), amplitudeAttenuationFilename);
                    
                    //  Read the travel time file
                    String traveltimeFilename = ( files.length > 2 ? files[1] : "" );
                    File traveltimeFile = IOUtility.openFile(traveltimeFilename);
                    
                    //  Read the log attenuation standard deviation
                    double stddevAttenuation = fin.nextDouble();
                    
                    //  Read the teleseismic log source correction
                    double logSourceCorrection = fin.nextDouble();
                    
                    //  Read the teleseismic log receiver correction
                    double logReceiverCorrection = fin.nextDouble();
                    
                    //  Read the travel time standard deviation
                    double ttStddev = fin.nextDouble();
                    
                    //  Read the azimuth standard deviation
                    double azStddev = fin.nextDouble();
                    
                    //  Identify the phase for this index
                    PathMediaPhaseParameter p = pp.getPhaseParameter(DetectionPhase.indexToPhase(j));
                    if (p != null)
                    {
                        if (amplitudeAttenuationFile.exists())
                            p.setAmplitudeAttenuationFile(amplitudeAttenuationFile.getCanonicalPath());
                        p.setStddevAttenuation(stddevAttenuation);
                        p.setLogSourceCorrection(logSourceCorrection);
                        p.setLogReceiverCorrection(logReceiverCorrection);
                    }
                }
            }
            
            setMediaDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
			if ( fin != null )
				IOUtility.safeClose(fin);
			if ( fis != null )
				IOUtility.safeClose(fis);
        }

    }

    /**
     * Write the path grid file
     */
    private void writePathGrid()
    {
        writeGrid(_pathGridFile);
    }

    /**
     * Write the path media file
     */
    private void writePathMedia()
    {        
        PrintWriter fout = null;
        try
        {
            String pathMediaFile = getPathMediaFile();
            if (pathMediaFile.isEmpty())
                return;
            
            File file = IOUtility.openFile(pathMediaFile);
            
            if ( !getMediaDirty() && file.exists() )
                return;
            
            int numPhases = DetectionPhase.size();

            //  Ensure the path to the file exists
            file.getParentFile().mkdirs();
            
            // Open the file
            fout = new PrintWriter(new FileWriter(file));

            //  Write the title
            fout.println(getName());

            //  Directory for attenuation and travel time files, relative to this file
            fout.println("." + File.separator);
            String parent = IOUtility.fixPathSeparator(file.getParent() + File.separator);
            
            //  Number of path media types
            fout.println(String.format("%d", getMediaTypes().size()));
            
            //  Write each media type
            for (PathMediaType mediaType : getMediaTypes())
            {
                fout.println("# Path Media Type: " + mediaType.getName());
                
                //  Media type name
                fout.println(mediaType.getName());
                
                //  Write out each of the phases
                for (int i=0; i<numPhases; i++)
                {
                	DetectionPhase phase = DetectionPhase.indexToPhase(i);
                    PathMediaPhaseParameter p = mediaType.getPhaseParameters().getPhaseParameter(phase);
                    fout.println("# Phase: " + phase);
                    if ( p == null )
                    {
                        fout.println("-\t-");
                        fout.println(String.format("%8.3f %8.3f %8.3f %8.3f %8.3f", 0.0, 0.0, 0.0, 0.0, 0.0));
                    }
                    else
                    {
                        p.getAmplitudeAttenuation().write();
                        
                        String atnFile = IOUtility.fixPathSeparator(p.getAmplitudeAttenuationFile()).replace(parent, "").trim();
                        if ( atnFile.isEmpty() )
                            atnFile = "-";
                        
                        fout.print(atnFile);
                        fout.println("\t-");
                        fout.println(String.format("%8.3f %8.3f %8.3f %8.3f %8.3f", 
                                p.getStddevAttenuation(), p.getLogSourceCorrection(), p.getLogReceiverCorrection(), 0.0, 0.0));
                    }
                    
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (fout != null)
            	IOUtility.safeClose(fout);
        }
    }

	@Override
	public boolean isAvailable()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean read()
	{
		readPathGrid();
		readPathMedia();
		
		return true;
	}
}
