/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.infra.path;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.NetSimParameters.WindMode;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.path.wind.WindModelPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

/**
 * @author bjmerch
 *
 */
public class PathsViewer extends NetModComponentViewer<Paths>
{
	/**
	 * Display the wind mode using a human readable name
	 * 
	 * @author bjmerch
	 *
	 */
	private class WindModeRenderer extends DefaultListCellRenderer
	{
		@Override
		public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
				boolean cellHasFocus)
		{
			Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

			if ((c instanceof JLabel) && (value instanceof WindMode))
			{
				WindMode windMode = (WindMode) value;
				JLabel label = (JLabel) c;

				label.setText(windMode.getName());
			}

			return c;
		}
	}

	private AbstractButton _windModelDisplayButton = createDisplayWindOnMapButton(MapUtility.WindVectorButtonGroup);
	private NetModComboBox<WindModel> _windModel;
	private FileField _windModelFile = new FileField("Wind Model File");
	private JComboBox _windMode = new JComboBox(WindMode.values());
	private FileField _pathMediaFile = new FileField("Path Media File");
	private FileField _pathGridFile = new FileField("Path Grid File");

	public PathsViewer(Paths nmc)
	{
		super(nmc, true, true);

		_windModel = new NetModComboBox(WindModelPlugin.getPlugin().getComponents(nmc), _windModelDisplayButton);
		_windMode.setRenderer(new WindModeRenderer());

		// Register the controls that are monitored
		registerControls(_windModel, _windModelFile, _windMode, _pathMediaFile, _pathGridFile);
	}

	@Override
	public void apply(Paths nmc)
	{
		nmc.setWindModel(_windModel.getSelectedItem());
		nmc.setWindMode((WindMode) _windMode.getSelectedItem());
		nmc.setPathMediaFile(_pathMediaFile.getText());
		nmc.setPathGridFile(_pathGridFile.getText());
	}

	@Override
	public void reset(Paths nmc)
	{
		_windModel.setSelectedType(nmc.getWindModel());
		_windMode.setSelectedItem(nmc.getWindMode());
		_pathMediaFile.setText(nmc.getPathMediaFile());
		_pathGridFile.setText(nmc.getPathGridFile());

		// Update the path media viewer
		JPanel panel = getExpandedPanel();
		if (panel.getComponentCount() > 0)
		{
			// Remove the old path media viewer
			panel.remove(panel.getComponentCount() - 1);

			// Add the new source media viewer
			GUIUtility.addRow(panel, _nmc.getPathMedia().getViewer());
		}
	}

	@Override
	public JPanel getExpandedPanel()
	{
		if (_expandedPanel == null)
		{
			_windModel.addItemListener(new ItemListener()
			{
				@Override
				public void itemStateChanged(ItemEvent event)
				{
					if (event.getStateChange() != ItemEvent.SELECTED)
					{
						return;
					}

					if (!_windModelDisplayButton.isSelected())
					{
						return;
					}

					// Refresh the map data layer
					((NetModComponent) event.getItem()).getMapLayer();

					if (NetMOD.getMap() != null)
					{
						NetMOD.getMap().refresh();
					}
				}
			});

			JPanel panel = new JPanel(new GridBagLayout());

			GUIUtility.addRow(panel, _nmc.getPhaseParameters().getViewer());
			GUIUtility.addRow(panel, new JLabel("Wind Model: "), _windModel);
			GUIUtility.addRow(panel, new JLabel("Wind Mode: "), _windMode);
			GUIUtility.addRow(panel, new JLabel("Path Media File: "), _pathMediaFile);
			GUIUtility.addRow(panel, new JLabel("Path Grid File: "), _pathGridFile);
			GUIUtility.addRow(panel, _nmc.getPathMedia().getViewer());

			_expandedPanel = panel;
		}

		return _expandedPanel;
	}

	private AbstractButton createDisplayWindOnMapButton(ButtonGroup group)
	{
		AbstractButton button = GUIUtility.createToggleButton(Icons.MAP.getIcon());
		button.setToolTipText("Display on map");

		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				// Get the button selection
				AbstractButton button = (AbstractButton) event.getSource();

				// Get the map layer
				Map map = NetMOD.getMap();
				if (map == null)
				{
					return;
				}

				Layer<?> layer = _nmc.getWindModel().getMapLayer();

				// Unselect button if no layer to draw
				if (layer == null)
				{
					button.setSelected(false);
					return;
				}

				// Remove and re-add the layer
				map.remove(layer);
				if (button.isSelected())
				{
					layer.setVisible(true);
					map.addLayer(layer);
				}

				map.refresh();
				refresh();
			}
		});

		// Add the button to the provided group
		if (group != null)
		{
			group.add(button);
		}

		return button;
	}
}
