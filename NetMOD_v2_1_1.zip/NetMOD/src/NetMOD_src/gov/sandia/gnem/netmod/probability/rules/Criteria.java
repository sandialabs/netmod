/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author bjmerch
 *
 */
abstract public class Criteria extends AbstractNetModComponent
{
    public static final String PAREN_OPEN = "(";
    public static final String PAREN_CLOSE = ")";
    
    /**
     * Parse Criteria from the provided criteria strings.
     * 
     * Criteria are defined as:
     *      SubCriteria/N [ op Criteria ]
     *      "(" Criteria ")"
     * 
     * Where N is the minimum number of detections, op is an operator (i.e. "*" or "+"),
     * elements within square brackets (i.e. [ ... ]) are optional, and Criteria may
     * be contained within parenthesis.
     * 
     * @param phases list of available phases
     * @param criteria_str list of the criteria strings
     * @return Criteria object
     * @throws CriteriaParseException exception if there is an error when parsing the criteria
     */
    public static Criteria parse(List<? extends Phase> phases, List<String> criteria_str) throws CriteriaParseException
    {
        if ( criteria_str.isEmpty() || phases.isEmpty() )
            return new NullCriteria();

        Criteria criteria = null;

        //  Try to build a SubCriteria, see if it generates an exception due to unbalanced parenthesis
        {
            //  Backup the criteria_str
            ArrayList<String> criteria_str_backup = new ArrayList<String>(criteria_str);

            SubCriteria subcriteria = null;
            try
            {
                subcriteria = SubCriteria.parse(phases, criteria_str);
            }
            catch (CriteriaParseException e)
            {
                //  Restore the criteria_str
                criteria_str.clear();
                criteria_str.addAll(criteria_str_backup);
            }

            if (subcriteria != null)
            {
                //  Confirm the number of observations character
                if (criteria_str.size() == 0 || !criteria_str.get(0).equals(NCriteria.N_OBS))
                    throw new CriteriaParseException("Missing " + NCriteria.N_OBS + " character in criteria string");

                //  Remove the number of observations character
                criteria_str.remove(0);

                //  Look for the number value
                String num_obs = "";
                try
                {
                    num_obs = criteria_str.get(0);
                    int N = Integer.parseInt(num_obs);

                    criteria = new NCriteria(subcriteria, N);
                    
                    //  Remove the number of observations
                    criteria_str.remove(0);
                }
                catch (Exception e)
                {
                    throw new CriteriaParseException("Invalid or missing number of observations: " + num_obs);
                }
            }
        }
        
        //  Didn't find a sub_criteria to bundled into a criteria
        if ( criteria == null )
        {
            if ( criteria_str.isEmpty() )
                return new NullCriteria();
            
            String first = criteria_str.get(0);
            
            //  Look for starting with parenthesis
            if ( first.equals(PAREN_OPEN) )
            {
                //  Remove the open parenthesis from the list
                criteria_str.remove(0);
                
                //  Parse the contents of the parenthesis
                criteria = parse(phases, criteria_str);
                
                //  Confirm a close parenthesis
                if ( criteria_str.size() == 0 || !criteria_str.get(0).equals(PAREN_CLOSE))
                    throw new CriteriaParseException("Unbalanced parenthesis");
                
                //  Remove the close parenthesis from the list
                criteria_str.remove(0);
            }
        }
        
        if ( criteria == null )
            throw new CriteriaParseException("Unrecognized Criteria");

        //  Check for an optional OR or AND operator
        String next = "";
        if ( criteria_str.size() > 0 )
            next = criteria_str.get(0);
        
        if ( next.equals(OrCriteria.OR) )
        {
            //  Remove the identified criteria from the list
            criteria_str.remove(0);
            
            criteria = new OrCriteria(criteria, parse(phases, criteria_str));
        }
        else if ( next.equals(AndCriteria.AND) )
        {
            //  Remove the identified criteria from the list
            criteria_str.remove(0);
            
            criteria = new AndCriteria(criteria, parse(phases, criteria_str));
        }
        
        //  Couldn't find anything
        if ( criteria == null )
            throw new CriteriaParseException("Unrecognized Criteria");
        
        return criteria;
    }
    
    protected Criteria()
    {
        super(null);
    }
    
    /**
     * Get the phases used by this Criteria
     * 
     * @return phases set
     */
    abstract public Set<Phase> getPhases();

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities Nested map of probabilities for each phase and station name
     */
    abstract public double getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities);
}
