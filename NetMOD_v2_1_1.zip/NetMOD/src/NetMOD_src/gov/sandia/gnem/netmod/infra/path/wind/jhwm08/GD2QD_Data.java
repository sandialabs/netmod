/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jhwm08;

import java.io.DataInputStream;
import java.io.InputStream;

import gov.sandia.gnem.netmod.io.IOUtility;

/**
 * @author aceaste
 */
public class GD2QD_Data
{

	public int nterm; // Spherical harmonic expansion parameter
	public int nmax; // Spherical harmonic expansion parameter
	public int mmax; // Spherical harmonic expansion parameter
	public double[] xcoeff; // Coefficients for x-coordinate
	public double[] ycoeff; // Coefficients for y-coordinate
	public double[] zcoeff; // Coefficients for z-coordinate

	public double[] normadj; // Adjustment to VSH normalization factor

	private static GD2QD_Data _instance = null;

	final public static GD2QD_Data getInstance()
	{
		if (_instance == null)
		{
			_instance = new GD2QD_Data();
		}

		return _instance;
	}

	private GD2QD_Data()
	{
		InputStream in = null;
		DataInputStream data = null;
		int numBytes = 0;

		try
		{
			// in = new FileInputStream( defaultData );
			in = GD2QD_Data.class.getResourceAsStream("/gov/sandia/gnem/netmod/infra/path/wind/hwm08/gd2qd.dat");
			data = new DataInputStream(in);

			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 20)
			{
				throw new Exception();
			}
			nmax = FortranDataReader.readInt(data);
			mmax = FortranDataReader.readInt(data);
			nterm = FortranDataReader.readInt(data);
			/* epoch = */
			data.readFloat();
			/* alt = */
			data.readFloat();
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != 20)
			{
				throw new Exception();
			}

			xcoeff = new double[nterm];
			ycoeff = new double[nterm];
			zcoeff = new double[nterm];
			normadj = new double[nmax + 1];

			numBytes = FortranDataReader.readInt(data);
			if (numBytes != nterm * 3 * 8)
			{
				throw new Exception();
			}
			for (int n = 0; n < nterm; n++)
			{
				xcoeff[n] = FortranDataReader.readDouble(data);
			}
			for (int n = 0; n < nterm; n++)
			{
				ycoeff[n] = FortranDataReader.readDouble(data);
			}
			for (int n = 0; n < nterm; n++)
			{
				zcoeff[n] = FortranDataReader.readDouble(data);
			}
			numBytes = FortranDataReader.readInt(data);
			if (numBytes != nterm * 3 * 8)
			{
				throw new Exception();
			}

			for (int n = 0; n <= nmax; n++)
			{
				normadj[n] = Math.sqrt(n * (n + 1));
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( data != null )
				IOUtility.safeClose(data);
			if ( in != null )
				IOUtility.safeClose(in);
		}
	}

}
