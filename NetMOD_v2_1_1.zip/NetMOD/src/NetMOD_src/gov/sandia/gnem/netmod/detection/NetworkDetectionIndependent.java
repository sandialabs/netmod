/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.rules.Criteria;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.*;

/**
 * @author bjmerch
 *
 */
public class NetworkDetectionIndependent extends NetworkDetection
{
    private static String _type = "Probability";
    static
    {
        NetworkDetectionPlugin.getPlugin().registerComponent(_type, NetworkDetectionIndependent.class, true);
    }
    
    private double _lowProbabilityCutoff = 0.2;
    private StationDetectionProbability _stationDetection;

    public NetworkDetectionIndependent(NetModComponent parent)
    {
        super(parent, _type);
        _stationDetection = new StationDetectionProbability(parent);
    }

    @Override
    public double computeDetectionProbability(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Time time, Magnitude magnitude,
            SignalAmplitude signal, NoiseAmplitude noise)
    {
        startIntrospection();
        recordIntrospection("Network Detection Probability of Moment (log): ", magnitude);

        //  Construct the detection criteria
        Criteria criteria = getDetectionCriteria();

        //  Determine the phases to detect
        Set<Phase> phases = criteria.getPhases();
        
        //  Get the set of stations
        Set<Station> stations = receivers.getSelectedStations();

        //  Initialize the map to hold all of the probabilities
        Map<Phase, ObjectDoubleMap<String>> networkProbability = new TreeMap<Phase, ObjectDoubleMap<String>>();
        for (Phase phase : phases)
            networkProbability.put(phase,  new ObjectDoubleOpenHashMap<String>(stations.size(), 1.0f));

        //  Iterate over each station and phase
        startIntrospection();
        recordIntrospection("Stations");
        for (Station station : stations)
        {
            startIntrospection();
            recordIntrospection(station);
            
            Distance distance = Distance.computeDistance(epicenter, station.getLocation());
            String group = station.getGroup();
            
            for (Phase phase : phases)
            {
                startIntrospection();
                recordIntrospection("Phase ", phase);

                //  Compute the station detection probability
                double probability = _stationDetection.computeDetectionProbability(sources, paths, receivers, epicenter, station, distance, time, magnitude, phase, signal, noise);

                //  Check for a probability below the cutoff
                recordIntrospection("Low Probability Cutoff: ", _lowProbabilityCutoff);
                if ( probability < _lowProbabilityCutoff )
                    probability = 0;

                recordIntrospection("Probability: ", probability);
                
                //  Store the result for this station, only if its greater than the existing value
                ObjectDoubleMap<String> map = networkProbability.get(phase);
                if ( map.containsKey(group) )
                {
                    double old_value = map.get(group);
                    if ( probability < old_value )
                    {
                        recordIntrospection("Retaining prior probability for group: ", group);
                    }
                    else
                        map.put(group, probability);
                }
                else
                    map.put(group, probability);
                
                stopIntrospection();
                
                //  Check introspection because this performs an auto-box
                if ( isIntrospection() )
                    recordIntrospection(phase, ": ", probability);
            }

            stopIntrospection();
        }
        stopIntrospection();

        //  Use the detection criteria to compute the overall probability
        double probability = criteria.getProbability(networkProbability);

        stopIntrospection();
        
        return probability;
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        if (children.size() == 0)
        {
            children.add(getDetectionCriteria());
            children.add(getStationDetection());
        }

        return children;
    }


    /**
     * @return the lowProbabilityCutoff
     */
    public double getLowProbabilityCutoff()
    {
        return _lowProbabilityCutoff;
    }

    /**
     * @return the stationDetection
     */
    @Override
    public StationDetectionProbability getStationDetection()
    {
        return _stationDetection;
    }

    @Override
    public NetworkDetectionIndependentViewer getViewer()
    {
        return new NetworkDetectionIndependentViewer(this);
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setLowProbabilityCutoff(parameters.get(NetSimParameters.lowProbCutoff));
        
        getStationDetection().load(parameters);
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(NetSimParameters.lowProbCutoff, getLowProbabilityCutoff());
        parameters.set(NetSimParameters.numMonteCarloIter, 1);
        
        getStationDetection().save(parameters, files, reset);
    }

    /**
     * @param lowProbabilityCutoff the lowProbabilityCutoff to set
     */
    public void setLowProbabilityCutoff(double lowProbabilityCutoff)
    {
        _lowProbabilityCutoff = lowProbabilityCutoff;
    }

    /**
     * @param stationDetection the stationDetection to set
     */
    public void setStationDetection(StationDetection stationDetection)
    {
        if ( stationDetection instanceof StationDetectionProbability )
            _stationDetection = (StationDetectionProbability) stationDetection;
    }
}
