package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import java.util.Arrays;

public class Profile {

  public static void initprofile(G2SDB g2sdb, double glatin, double glonin, double dzin,
                                 int naltsin, int truncin) {
    /*
     * real(8),intent(in) :: glatin real(8),intent(in) :: glonin
     * real(8),intent(in) :: dzin integer,intent(in) :: naltsin
     * integer,intent(in) :: truncin real(8) :: theta real(8) :: zfs real(8)
     * :: glonrad real :: z2(nzs) integer :: k,m,n integer :: ltrunc
     *
     * real,external :: geopot2alt : this is a function
     */
    // ! ----------------------------------------------------------
    // ! Place the input variables variables in the global space
    // ! ----------------------------------------------------------

    g2sdb.glat = glatin;
    g2sdb.glon = glonin;
    int nalts = naltsin;
//    System.out.println("initprofile");
//    System.out.println("*****************************************************************");
//    System.out.println("glatin: " + glatin);
//    System.out.println("glonin: " + glonin);
    g2sdb.dz = dzin;
    g2sdb.nalts = nalts;
    g2sdb.utrunc = truncin;

    // ! --------------------------------------------------------------
    // ! Reconstruct the altitude coordinates of the VSH coefficients
    // ! --------------------------------------------------------------

    float deg2rad = (float) (Math.PI / 180);

//    System.out.println("Altitude Coordinates:");
    if (g2sdb.glon != g2sdb.lastlon) {
      double glonrad = g2sdb.glon * deg2rad;
      for (int m = 1; m < g2sdb.ntrunc - 1; m++) {
        double val = m * glonrad;
        g2sdb.cosl[m] = Math.cos(val);
        g2sdb.sinl[m] = Math.sin(val);
      }
    }

    // ! --------------------------------------------------------------
    // ! Construct the basis functions in colatitude coordinates
    // ! --------------------------------------------------------------

//    System.out.println("basis functions in colatitude coordinates:");

    if (g2sdb.glat != g2sdb.lastlat) {
      double theta = (90.d + 00 - g2sdb.glat) * deg2rad;
      VshLib.scalar_basis(g2sdb.ntrunc, g2sdb.ntrunc, theta, g2sdb.pbar);
      VshLib.vector_basis(g2sdb.ntrunc, g2sdb.ntrunc, g2sdb.pbar, g2sdb.vbar, g2sdb.wbar);
    }

    // ! -------------------------------------------------------------------
    // ! Calculate the rest of the geopotential height levels
    // ! -------------------------------------------------------------------
    for (int k = 0; k < g2sdb.nzs; k++) {
      int ltrunc = Math.min(g2sdb.utrunc, g2sdb.trunc[k]) - 1;

      double zfs = 0.0;
      for (int n = 0; n <= ltrunc; n++) {
        zfs = zfs + .50 * g2sdb.zas[0][n][k] * g2sdb.pbar[0][n];
      }
//      System.out.println("ltrunc: " + ltrunc + ", zfs: " + zfs);

      for (int n = 0; n <= ltrunc; n++) {
        //System.out.println(n);
        for (int m = 0; m <= n; m++) {
          //System.out.println(g2sdb.pbar[m][n]);
          zfs = zfs + g2sdb.pbar[m][n] * (g2sdb.zas[m][n][k] * g2sdb.cosl[m]
                  - g2sdb.zbs[m][n][k] * g2sdb.sinl[m]);
//          System.out.println(zfs);
//          System.out.println("zas[" + m + "][" + n + "][" + k +
//              "] = " + g2sdb.zas[m][n][k]);
//          System.out.println("zbs[" + m + "][" + n + "][" + k +
//              "] = " + g2sdb.zbs[m][n][k]);
        }
      }

      g2sdb.zs[k] = (float) zfs;
    }

    //System.out.println("zs: " + Arrays.toString(g2sdb.zs));

    // ! -------------------------------------------------------------------
    // ! Calculate the pressure surfaces for models with sigma levels
    // ! -------------------------------------------------------------------
    //System.out.println("");
    //System.out.println("pressure surfaces with sigma levels:");
    if (g2sdb.SIGMA) {
      for (int k = 0; k < g2sdb.nzsp; k++) {
        int ltrunc = Math.min(g2sdb.utrunc, g2sdb.trunc[k]) - 1;

        double zfs = 0.0;
        for (int n = 0; n <= ltrunc; n++) {
          zfs = zfs + .50 * g2sdb.pas[0][n][k] * g2sdb.pbar[0][n];
        }

        for (int n = 1; n <= ltrunc; n++) {
          for (int m = 1; m <= n; m++) {
            zfs = zfs + g2sdb.pbar[m][n] * (g2sdb.pas[m][n][k] * g2sdb.cosl[m]
                    - g2sdb.pbs[m][n][k] * g2sdb.sinl[m]);
          }
        }

        g2sdb.zgrid[k] = (float) -Math.log(zfs / g2sdb.pref);
      }
    }
    //System.out.println("zgrid: " + Arrays.toString(g2sdb.zgrid));

    // ! --------------------------------------------------------------
    // ! Manage the altitude coordinate system - Convert from
    // ! geopotential to altitude, generate the grid, and locate
    // ! the maximum height.
    // ! --------------------------------------------------------------
    //System.out.println("");
    //System.out.println("manage altitude coordinate system:");
    for (int k = 0; k < g2sdb.nzs; k++) {
      g2sdb.zs[k] = (float) (VshLib.geopot2alt(g2sdb.zs[k], g2sdb.glat) / 1000.0);
    }
//    System.out.println("zs: " + Arrays.toString(g2sdb.zs));

    for (int k = 0; k < nalts; k++) {
      g2sdb.alt[k] = (float) (k * g2sdb.dz);
    }
    //System.out.println("alt: " + Arrays.toString(g2sdb.alt));

    double zmax = g2sdb.zs[g2sdb.nzs - 2];
    int kk = 0;
    for (kk = 0; kk < nalts; kk++) {
      if (g2sdb.alt[kk] > zmax) {
        break;
      }
    }
    g2sdb.kmax = kk - 1;
//    System.out.println("alt: " + Arrays.toString(g2sdb.alt));

//    System.out.println("zmax: " + zmax);
//    System.out.println("alt[k]: " + g2sdb.alt[kk]);
//    System.out.println("kmax: " + kmax);

    // !
    // -------------------------------------------------------------------------
    // ! Calculate pressure as a function of altitude
    // !
    // -------------------------------------------------------------------------

//    System.out.println("pressure as a function of altitude:");
    float[] z2 = new float[g2sdb.nzs];

    UtilityA.spline_nr(g2sdb.zs, g2sdb.zgrid, g2sdb.nzs, z2);
    for (int k = 0; k <= g2sdb.kmax; k++) {
      if (g2sdb.alt[k] < g2sdb.zs[0] && g2sdb.SIGMA) {
        g2sdb.alt[k] = g2sdb.zs[0];
      }

      g2sdb.prs[k] = UtilityA.splint_nr(g2sdb.zs, g2sdb.zgrid, z2, g2sdb.nzs, g2sdb.alt[k]);
      g2sdb.prs[k] = (float) (g2sdb.pref * Math.exp(-g2sdb.prs[k]));
    }
//    System.out.println("prs: " + Arrays.toString(g2sdb.prs));

    // ! -------------------------------------------------------
    // ! Done
    // ! -------------------------------------------------------

    g2sdb.lastlon = g2sdb.glon;
    g2sdb.lastlat = g2sdb.glat;
    g2sdb.lastnalt = nalts;
  }

  public static void getProfile2(G2SDB g2sdb, EtmodDB etmodDB, double[] zi, double[] ti,
                                 double[] ui, double[] vi,
                                 double[] di, double[] pr) {
//    System.out.println("getProfile2");

//    Get the MSIS values at all (the upper) altitude ranges
    if (zi[0] == 93.0) {
      msishwm
              .getmsishwm(g2sdb, etmodDB, g2sdb.glat, g2sdb.glon, g2sdb.dz, g2sdb.nalts, zi, ti, ui, vi,
                      di, pr);
    } else {
      msishwm.getmsishwm2(g2sdb, etmodDB, g2sdb.glat, g2sdb.glon, g2sdb.dz, g2sdb.nalts, zi, ti, ui,
              vi, di,
              pr);
    }

//     Initialize altitude grid

    for (int k = 0; k < g2sdb.kmax; k++) {
      double wght = k * g2sdb.dz;
      if (wght < g2sdb.zg) {
        zi[k] = g2sdb.zg;
      } else {
        zi[k] = wght;
      }
    }

//    System.out.println("dz: " + g2sdb.dz);
//    System.out.println("zi: " + Arrays.toString(zi));
//    System.out.println("pr: " + Arrays.toString(pr));
    for (int k = 0; k < g2sdb.kmax; k++) {
      double wght = 1.0 - 1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta)));
      pr[k] = wght * g2sdb.prs[k] + (1.0 - wght) * pr[k];
    }
//    System.out.println("alpha: " + g2sdb.alpha);
//    System.out.println("beta: " + g2sdb.beta);
//    System.out.println("alt: " + Arrays.toString(g2sdb.alt));
//    System.out.println("prs: " + Arrays.toString(g2sdb.prs));
//    System.out.println("pr: " + Arrays.toString(pr));

//  !!! Calculate the temperature field

    genscalar(g2sdb, g2sdb.tas, g2sdb.tbs);

    for (int k = 0; k <= g2sdb.kmax; k++) {
      double wght = 1.0 - (1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta))));

      ti[k] = wght * g2sdb.tmp[k] + (1.0 - wght) * ti[k];
    }
//    System.out.println("ti: " + Arrays.toString(ti));

//    !!! Extract or calculate the density field

    if (g2sdb.DENSITY) {
      genscalar(g2sdb, g2sdb.das, g2sdb.dbs);
      for (int k = 0; k < g2sdb.kmax; k++) {
        double wght = 1.0 - 1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta)));
        di[k] = wght * g2sdb.dref * g2sdb.tmp[k] + (1.0 - wght) * di[k];
      }
//      System.out.println(Arrays.toString(di));
    } else {
      for (int k = 0; k < g2sdb.kmax; k++) {
        double wght = 1.0 - 1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta)));
        di[k] = wght * 100.0 * pr[k] / (g2sdb.Rd * ti[k] * 1000.0) + (1.0 - wght) * di[k];
      }
//      System.out.println(Arrays.toString(di));
    }

    if (g2sdb.SIGMA) {
      for (int k = 0; k < g2sdb.kmax; k++) {
        double wght = 1.0 - 1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta)));
        di[k] = wght * 100.0 * pr[k] / (g2sdb.Rd * ti[k] * 1000.0) + (1.0 - wght) * di[k];
      }
    }
//    System.out.println("di: " + Arrays.toString(di));

//    !!! Calculate the wind field
    genvector(g2sdb);

    for (int k = 0; k <= g2sdb.kmax; k++) {
      double wght = 1.0 - 1.0 / (1.0 + Math.exp(-g2sdb.alpha * (g2sdb.alt[k] - g2sdb.beta)));
      ui[k] = wght * g2sdb.zon[k] + (1.0 - wght) * ui[k];
      vi[k] = wght * g2sdb.mer[k] + (1.0 - wght) * vi[k];
    }
//    System.out.println("ui: " + Arrays.toString(ui));
//    System.out.println("vi: " + Arrays.toString(vi));
  }

  public static void genscalar(G2SDB g2sdb, double[][][] was, double[][][] wbs) {
    float[] ws = new float[g2sdb.nzs];

    // !
    // ======================================================================
    // ! Synthesize vertical profiles from the spherical harmonic
    // coefficients
    // !
    // ======================================================================
    for (int k = 0; k < g2sdb.nzs; k++) {
      int ltrunc = Math.min(g2sdb.utrunc, g2sdb.trunc[k]) - 1;
      double wfs = 0;

      for (int n = 0; n <= ltrunc; n++) {
        wfs = wfs + 0.5 * was[0][n][k] * g2sdb.pbar[0][n];
      }

      for (int n = 1; n <= ltrunc; n++) {
        for (int m = 1; m <= n; m++) {
          wfs = wfs + g2sdb.pbar[m][n] * (was[m][n][k] * g2sdb.cosl[m]
                  - wbs[m][n][k] * g2sdb.sinl[m]);
        }
      }
      ws[k] = (float) wfs;
    }

    // !
    // ======================================================================
    // ! Now use splines to map from the pressure nodes to the altitude grid
    // !
    // ======================================================================
    float[] z2 = new float[g2sdb.nzs];
    Arrays.fill(g2sdb.tmp, 0.0f);
    UtilityA.spline_nr(g2sdb.zs, ws, g2sdb.nzs, z2);
    for (int k = 0; k <= g2sdb.kmax; k++) {
      g2sdb.tmp[k] = UtilityA.splint_nr(g2sdb.zs, ws, z2, g2sdb.nzs, g2sdb.alt[k]);
    }

  }

  public static void genvector(G2SDB g2sdb) {
    // !
    // ======================================================================
    // ! Get the profile in pressure coordinates from the spectral
    // coefficients
    // !
    // ======================================================================
    float[] us = new float[g2sdb.nzs];
    float[] vs = new float[g2sdb.nzs];

    for (int k = 0; k < g2sdb.nzs; k++) {
      int ltrunc = Math.min(g2sdb.utrunc, g2sdb.trunc[k]) - 1;
      double vfs = 0;
      double ufs = 0;

      for (int n = 0; n <= ltrunc; n++) {
        vfs = vfs + 0.5 * g2sdb.brs[0][n][k] * g2sdb.vbar[0][n];
        ufs = ufs - 0.5 * g2sdb.crs[0][n][k] * g2sdb.vbar[0][n];
      }

      for (int n = 0; n <= ltrunc; n++) {
        for (int m = 0; m <= n; m++) {
          double v = g2sdb.vbar[m][n];
          double w = g2sdb.wbar[m][n];
          double br = g2sdb.brs[m][n][k];
          double bi = g2sdb.bis[m][n][k];
          double cr = g2sdb.crs[m][n][k];
          double ci = g2sdb.cis[m][n][k];

          vfs = vfs + (br * v - ci * w) * g2sdb.cosl[m] - (bi * v + cr * w) * g2sdb.sinl[m];
          ufs = ufs - (cr * v + bi * w) * g2sdb.cosl[m] + (ci * v - br * w) * g2sdb.sinl[m];
        }
      }

      us[k] = (float) ufs;
      vs[k] = (float) -vfs;
    }

    // ! =================================================================
    // ! Now use splines to map from the pressure coordinates to altitude
    // ! =================================================================

    // ! -----------------------------------------
    // ! Zonal wind
    // ! -----------------------------------------
    float[] z2 = new float[g2sdb.nzs];
    UtilityA.spline_nr(g2sdb.zs, us, g2sdb.nzs, z2);
    for (int k = 0; k <= g2sdb.kmax; k++) {
      g2sdb.zon[k] = UtilityA.splint_nr(g2sdb.zs, us, z2, g2sdb.nzs, g2sdb.alt[k]);
    }

    // ! -----------------------------------------
    // ! Meridional wind
    // ! -----------------------------------------

    UtilityA.spline_nr(g2sdb.zs, vs, g2sdb.nzs, z2);
    for (int k = 0; k <= g2sdb.kmax; k++) {
      g2sdb.mer[k] = UtilityA.splint_nr(g2sdb.zs, vs, z2, g2sdb.nzs, g2sdb.alt[k]);
    }

    // ! ================================================================
    // ! Done
    // ! ================================================================
  }

}
