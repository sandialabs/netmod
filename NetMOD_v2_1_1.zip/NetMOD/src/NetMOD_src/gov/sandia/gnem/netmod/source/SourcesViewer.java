/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collection;

/**
 * @author bjmerch
 *
 */
public class SourcesViewer extends NetModComponentViewer<Sources>
{
    private AbstractButton _epicenterDisplayButton = createEpicenterDisplayOnMapButton();
    private NetModComboBox _epicenterGrids = new NetModComboBox(null, createAddEpicenterGridButton(), createRemoveEpicenterGridButton(),
            _epicenterDisplayButton, createSelectSourcesButton());
    private FileField _sourceMediaFile = new FileField("Source Media File");
    private FileField _sourceGridFile = new FileField("Source Grid File");

    public SourcesViewer(Sources nmc)
    {
        super(nmc, true, true);

        //  Register the controls that are monitored after updating
        registerControls(_epicenterGrids, _sourceMediaFile, _sourceGridFile);
    }

    @Override
    public void apply(Sources nmc)
    {
        nmc.getEpicenterGrids().clear();
        nmc.getEpicenterGrids().addAll((Collection<EpicenterGrid>) _epicenterGrids.getItems());
        nmc.setEpicenterGrid((EpicenterGrid) _epicenterGrids.getSelectedItem());
        nmc.setSourceMediaFile(_sourceMediaFile.getText());
        nmc.setSourceGridFile(_sourceGridFile.getText());
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Setup the Epicenter Grids
            _epicenterGrids.addItemListener(new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent event)
                {
                    if (event.getStateChange() != ItemEvent.SELECTED)
                        return;

                    if (!_epicenterDisplayButton.isSelected())
                        return;

                    //  Refresh the map data layer
                    ((EpicenterGrid) event.getItem()).getMapLayer();

                    if (NetMOD.getMap() != null)
                        NetMOD.getMap().refresh();
                }
            });

            //  Setup the panel
            GUIUtility.addRow(panel, new JLabel("Epicenter Grid: "), _epicenterGrids);
            GUIUtility.addRow(panel, new JLabel("Source Media File: "), _sourceMediaFile);
            GUIUtility.addRow(panel, new JLabel("Source Grid File: "), _sourceGridFile);
            GUIUtility.addRow(panel, _nmc.getSourceMedia().getViewer());

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(Sources nmc)
    {
        _epicenterGrids.setItems(nmc.getEpicenterGrids());
        _epicenterGrids.setSelectedItem(nmc.getEpicenterGrid());
        _sourceMediaFile.setText(nmc.getSourceMediaFile());
        _sourceGridFile.setText(nmc.getSourceGridFile());
        
        //  Update the source media viewer
        JPanel panel = getExpandedPanel();
        if ( panel.getComponentCount() > 0 )
        {
        	//  Remove the old source media viewer
        	panel.remove(panel.getComponentCount()-1);
        	
        	//  Add the new source media viewer
            GUIUtility.addRow(panel, _nmc.getSourceMedia().getViewer());
        }
    }

    private JButton createAddEpicenterGridButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Create new epicenter grid");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Get the name of the new epicenter grid
                String name = JOptionPane.showInputDialog(SourcesViewer.this, "Name: ", "Create new Epicenter Grid", JOptionPane.INFORMATION_MESSAGE);
                if (name == null)
                    return;

                //  Don't allow empty names
                name = name.trim();
                if (name.isEmpty())
                    return;

                //  Create the epicenter grid
                EpicenterGrid eg = new EpicenterGrid(_nmc);
                eg.setName(name);

                //  Add the epicenter grid as the selected one
                _nmc.setEpicenterGrid(eg);
                _epicenterGrids.addNetModComponent(eg);
                _epicenterGrids.setSelectedItem(eg);
            }
        });

        return button;
    }

    private JButton createRemoveEpicenterGridButton()
    {
        JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
        button.setToolTipText("Remove current epicenter grid");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Get the current epicenter Grid
                EpicenterGrid eg = _nmc.getEpicenterGrid();
                if (eg == null || _nmc.getEpicenterGrids().size() <= 1)
                    return;

                //  Remove the epicenter Grid
                _nmc.getEpicenterGrids().remove(eg);
                _epicenterGrids.removeNetModComponent(eg);

                //  Set the next grid as the selected
                _nmc.setEpicenterGrid(_nmc.getEpicenterGrid());
            }
        });

        return button;
    }

    /**
     * Create a button that will display the map layer on the map
     * 
     * @return
     */
    protected AbstractButton createEpicenterDisplayOnMapButton()
    {
        AbstractButton button = GUIUtility.createToggleButton(Icons.MAP.getIcon());
        button.setToolTipText("Display on map");
        MapUtility.SourceButtonGroup.add(button);

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                // Get the button selection
                AbstractButton button = (AbstractButton) event.getSource();

                //  Get the map layer
                Map map = NetMOD.getMap();
                if (map == null)
                    return;

                Layer<?> layer = _nmc.getEpicenterGrid().getMapLayer();

                //  Unselect button if no layer to draw
                if (layer == null)
                {
                    button.setSelected(false);
                    return;
                }

                //  Remove and re-add the layer
                map.remove(layer);
                if (button.isSelected())
                {
                    layer.setVisible(true);
                    map.addLayer(layer);
                }

                map.refresh();
            }
        });

        return button;
    }

    private JToggleButton createSelectSourcesButton()
    {
        JToggleButton button = GUIUtility.createToggleButton(Icons.SELECT.getIcon());
        MapUtility.SelectButtonGroup.add(button);
        button.setAction(new AbstractAction()
        {
            private Map _map = null;
            private Action _selectAction = null;
            private boolean _updating = false;

            {
                putValue(SHORT_DESCRIPTION, "Select sources");
                putValue(SELECTED_KEY, Boolean.FALSE);
                putValue(SMALL_ICON, Icons.SELECT.getIcon());
            }

            @Override
            public void actionPerformed(ActionEvent e)
            {
                Action action = getSelectAction();
                if (action != null)
                    action.actionPerformed(e);
            }
            
            @Override
            public void putValue(String str, Object o)
            {
                if (!_updating)
                {
                    _updating = true;
                    super.putValue(str, o);

                    Action action = getSelectAction();
                    if (action != null)
                        action.putValue(str, o);
                    _updating = false;
                }
            }

            private Action getSelectAction()
            {
                //  Reset the selection action if the map changes
                if (_map != NetMOD.getMap())
                {
                    _map = NetMOD.getMap();
                    if (_map == null)
                        _selectAction = null;
                    else
                    {
                        _selectAction = _map.createSourceSelectionTool(_nmc);
                        _selectAction.addPropertyChangeListener(new PropertyChangeListener()
                        {
                            @Override
                            public void propertyChange(PropertyChangeEvent pce)
                            {
                                putValue(pce.getPropertyName(), pce.getNewValue());
                            }
                        });
                    }
                }

                return _selectAction;
            }
        });

        return button;
    }
}
