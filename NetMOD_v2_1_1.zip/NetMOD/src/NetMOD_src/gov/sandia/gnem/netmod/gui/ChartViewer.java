/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.TextAnchor;

import javax.swing.*;
import javax.swing.border.SoftBevelBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

/**
 * A ChartViewer displays a plot containing a chart and datasets.
 * 
 * @author bjmerch
 *
 */
public class ChartViewer extends JPanel
{
    static public enum AxisScale
    {
        LINEAR, LOG
    }

    protected JComponent _toolBar = null;
    protected ChartPanel _chartPanel = null;
    protected JPanel _viewerPanel = null;

    private boolean _copySaveControls = false;
    private boolean _panZoomControls = false;
    private boolean _configureAxesControls = false;
    protected boolean _allowYLogAxis = false; // NOT for PSD, Model or Response viewer charts	

    protected boolean _visibilityControl = false;
    protected JButton _visibleButton = null;

    private boolean _enableAutoScaleOption = false; // for all chart viewers in tests
    private JCheckBox _autoScalingCheckbox = new JCheckBox("Turn on axes auto-scaling");

    protected float _lineWidth = 1.0f;
    protected Font _labelFont = new Font(Font.SANS_SERIF, Font.PLAIN, 10);

    private MouseListener old_ml = null;

    private MouseMotionListener old_mml = null;

    public ChartViewer()
    {
        this(true, true, true, true, true, true);
    }

    public ChartViewer(boolean copy_save, boolean pan_zoom, boolean configure_axes, boolean allowYLogAxis, boolean visible, boolean enableAutoScale)
    {
        _copySaveControls = copy_save;
        _panZoomControls = pan_zoom;
        _configureAxesControls = configure_axes;
        _allowYLogAxis = allowYLogAxis;
        _visibilityControl = visible;
        _enableAutoScaleOption = enableAutoScale;
        _autoScalingCheckbox.setSelected(enableAutoScale);

        _chartPanel = createChart();
        _viewerPanel = _chartPanel;
        init();
    }

    /**
     * Create a renderer for the i'th 
     * 
     * @param i
     * @return
     */
    public XYLineAndShapeRenderer createRenderer(int i)
    {
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setBaseShapesVisible(false);
        renderer.setBaseToolTipGenerator(getToolTipGenerator());

        Paint p = getLinePaint(i);

        //  The 0'th series is the shapes
        renderer.setSeriesPaint(0, p);
        renderer.setSeriesShape(0,  new Ellipse2D.Double(-3, -3, 7, 7));
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesLinesVisible(0, false);
        renderer.setSeriesVisibleInLegend(0, false);

        //  The 1'st series is the interpolated fit
        renderer.setSeriesPaint(1, p);
        renderer.setSeriesStroke(1, new BasicStroke(getLineWidth()));
        renderer.setSeriesShapesVisible(1, false);
        renderer.setSeriesLinesVisible(1, true);
        renderer.setSeriesVisibleInLegend(1, true);

        return renderer;
    }

    public JFreeChart getChart()
    {
        return _chartPanel.getChart();
    }

    public ChartPanel getChartPanel()
    {
        return _chartPanel;
    }

    /**
     * Get the line color for the specified index.
     */
    public Paint getLinePaint(int index)
    {
        List<Color> colors = getPaints();
        return colors.get(index % colors.size());
    }

    /**
     * Get the line width as specified by the Property value.
     */
    public float getLineWidth()
    {
        return Property.CHART_VIEWER_LINE_WIDTH.getFloatValue();
    }

    public XYPlot getPlot()
    {
        return _chartPanel.getChart().getXYPlot();
    }

    /**
     * @return
     */
    public Component getToolBar()
    {
        return _toolBar;
    }

    public XYToolTipGenerator getToolTipGenerator()
    {
        return new XYToolTipGenerator()
        {
            private DecimalFormat format = new DecimalFormat("#,##0.####");

            public String generateToolTip(XYDataset dataset, int row, int column)
            {
                double x = dataset.getXValue(row, column);
                double y = dataset.getYValue(row, column);
                
            	if ( dataset instanceof XYZDataset )
            	{
            		double z = ((XYZDataset) dataset).getZValue(row, column);
            		
            		return "<html>" + dataset.getSeriesKey(row).toString().replaceAll("\n", "<br>") + "<br>" + format.format(z) + " at " + format.format(x) + ", " + format.format(y) +
                        "</html>";
            	}
            	else
            		return "<html>" + dataset.getSeriesKey(row).toString().replaceAll("\n", "<br>") + "<br>" + format.format(y) + " at " + format.format(x) +
                        "</html>";
            }
        };
    }

    /**
     * Get the scale of the X Axis for this plot
     * 
     * @return
     */
    public AxisScale getXScale()
    {
        // Get the domain axis
        XYPlot plot = (XYPlot) _chartPanel.getChart().getPlot();
        ValueAxis domain = plot.getDomainAxis();

        // Determine the type of the domain axis
        if (domain instanceof LogarithmicAxis)
            return AxisScale.LOG;
        else
            return AxisScale.LINEAR;
    }

    /** Get the scale of the Y Axis for this plot
    * 
    * @return
    */
    public AxisScale getYScale()
    {
        // Get the domain axis
        XYPlot plot = (XYPlot) _chartPanel.getChart().getPlot();
        ValueAxis range = plot.getRangeAxis();

        // Determine the type of the domain axis
        if (range instanceof LogarithmicAxis)
            return AxisScale.LOG;
        else
            return AxisScale.LINEAR;
    }

    /**
     * Get the status of the auto scaling checkbox
     * @return boolean
     */
    public boolean isAutoScaleEnabled()
    {
        return _autoScalingCheckbox.isSelected();
    }

    public void setAutoScaleEnabled(boolean value)
    {
        _autoScalingCheckbox.setSelected(value);
    }

    /**
     * Configure the plot to use the specified MouseListener and 
     * MouseMotionListener (all other mouse listeners are removed). Also, 
     * change the appearance of the mouse cursor to the given Cursor object when
     * hovering over the plot.
     */
    public void setListeners(Object source, MouseListener ml, MouseMotionListener mml, Cursor cursor)
    {
        // Set the selected appearance for the all buttons
        for (Component c : _toolBar.getComponents())
            if (c instanceof JButton)
                ((JButton) c).setSelected(c == source);

        // Remove the old listeners
        _chartPanel.removeMouseListener(old_ml);
        _chartPanel.removeMouseMotionListener(old_mml);

        // Add the new listeners
        _chartPanel.addMouseListener(ml);
        _chartPanel.addMouseMotionListener(mml);
        _chartPanel.setCursor(cursor);

        old_ml = ml;
        old_mml = mml;
    }

    /**
     * Set the scale of the X Axis for this plot
     */
    public void setXScale(AxisScale scale)
    {
        // Get the domain axis
        XYPlot plot = (XYPlot) _chartPanel.getChart().getPlot();
        NumberAxis domain = (NumberAxis) plot.getDomainAxis();
        Range range = domain.getRange();
        boolean autoRange = domain.isAutoRange();

        // Only create a new Axis if we need to
        NumberAxis domainNew = null;
        if (scale == AxisScale.LINEAR)
        {
            domainNew = new RoundedAxis();
        }
        else if (scale == AxisScale.LOG)
        {
            domainNew = new FrequencyLogAxis("");
        }
        if (domainNew != null)
        {
            domainNew.setLabel(domain.getLabel());
            domain = domainNew;
        }

        domain.setAutoRangeIncludesZero(false);

        // Set label and tick label font size
        domain.setTickLabelFont(_labelFont);
        domain.setLabelFont(_labelFont);

        if (autoRange)
            domain.setAutoRange(true);
        else
        {
            if (scale == AxisScale.LOG && range.getLowerBound() <= 0)
                range = new Range(Math.ulp(1.0), range.getUpperBound());
            
            domain.setRange(range);
        }

        plot.setDomainAxis(domain);
    }

    /**
     * Set the scale of the Y Axis for this plot
     */
    public void setYScale(AxisScale scale)
    {
        if (!_allowYLogAxis && scale.equals(AxisScale.LOG))
            return;

        // Get the range axis
        XYPlot plot = (XYPlot) _chartPanel.getChart().getPlot();
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        if (rangeAxis == null)
            return;
        Range range = rangeAxis.getRange();
        boolean autoRange = rangeAxis.isAutoRange();

        NumberAxis rangeAxisNew = null;
        if (scale == AxisScale.LINEAR)
        {
            rangeAxisNew = new RoundedAxis();
        }
        else if (scale == AxisScale.LOG)
        {
            rangeAxisNew = new FrequencyLogAxis("");
        }

        if (rangeAxisNew != null)
        {
            rangeAxisNew.setLabel(rangeAxis.getLabel());
            rangeAxis = rangeAxisNew;
        }

        rangeAxis.setAutoRangeIncludesZero(false);

        // Set label and tick label font size
        rangeAxis.setTickLabelFont(_labelFont);
        rangeAxis.setLabelFont(_labelFont);

        if (autoRange)
        {
            rangeAxis.setAutoRange(true);
        }
        else
        {
            if (scale == AxisScale.LOG && range.getLowerBound() <= 0)
                range = new Range(Math.ulp(1.0), range.getUpperBound());
            
            rangeAxis.setRange(range);
        }

        plot.setRangeAxis(rangeAxis);
    }

    /**
     * Add the specified button to the given tool bar.
     */
    protected void addButton(JComponent toolBar, AbstractButton button)
    {
        button.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
        button.setBorderPainted(false);
        button.setFocusable(false);
        button.setOpaque(false);
        toolBar.add(button);
    }

    /**
     * Create and return a toolbar for the viewer with controls to load/write 
     * data, pan and zoom the graph, etc.
     */
    protected JComponent createButtonBar()
    {
        JButton copyButton = GUIUtility.createButton(Icons.EDIT.getIcon());
        copyButton.setToolTipText("Copy Image");
        copyButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                GUIUtility.copyToClipboard(makeViewerImage());
            }
        });

        JButton saveButton = GUIUtility.createButton(Icons.CAMERA.getIcon());
        saveButton.setToolTipText("Save Image");
        saveButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                try
                {
                    GUIUtility.saveImageAsPNG(makeViewerImage());
                }
                catch (IOException e)
                {
                    GUIUtility.showExceptionDialog(null, "Save Image Error", e.getMessage(), e);
                }
            }
        });

        JButton panButton = GUIUtility.createButton(Icons.PAN.getIcon());
        panButton.setToolTipText("Pan");
        panButton.addActionListener(new ActionListener()
        {
            private ChartPanelPanListener pl = new ChartPanelPanListener();

            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (((JButton) e.getSource()).isSelected())
                { // de-select button
                    setListeners(e.getSource(), null, null, null);
                    ((JButton) e.getSource()).setSelected(false);
                }
                else
                { // select button
                    setListeners(e.getSource(), pl, pl, Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
                }
            }
        });

        JButton zoomButton = GUIUtility.createButton(Icons.ZOOM.getIcon());
        zoomButton.setToolTipText("Zoom");
        zoomButton.addActionListener(new ActionListener()
        {
            private ChartPanelZoomListener zl = new ChartPanelZoomListener();

            public void actionPerformed(ActionEvent e)
            {
                if (((JButton) e.getSource()).isSelected())
                { // de-select button
                    setListeners(e.getSource(), null, null, null);
                    ((JButton) e.getSource()).setSelected(false);
                }
                else
                { // select button
                    setListeners(e.getSource(), zl, zl, Icons.ZOOM.getCursor());
                }
            }
        });

        JButton configPlotButton = GUIUtility.createButton(Icons.PREFERENCES.getIcon());
        configPlotButton.setToolTipText("Configure chart");
        configPlotButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                showChartConfigDialog();
            }
        });

        JButton visibleButton = GUIUtility.createButton(Icons.VISIBLE.getIcon());
        visibleButton.setToolTipText("Set Visibility");
        visibleButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                // Initialize the visible popup
                JPopupMenu visiblePopup = new JPopupMenu();

                // Display all button
                JMenuItem displayAll = new JMenuItem(new AbstractAction("Display All")
                {
                    @Override
                    public void actionPerformed(ActionEvent arg0)
                    {
                        XYPlot plot = getPlot();
                        int N = plot.getDatasetCount();
                        for (int i = 0; i < N; i++)
                        {
                            XYDataset dataset = plot.getDataset(i);

                            if (dataset instanceof AbstractVisibleXYDataset)
                            {
                                AbstractVisibleXYDataset visibleDataset = (AbstractVisibleXYDataset) dataset;
                                visibleDataset.setVisible(true);
                            }
                        }
                    }
                });

                // Hide all button
                JMenuItem hideAll = new JMenuItem(new AbstractAction("Hide All")
                {
                    @Override
                    public void actionPerformed(ActionEvent arg0)
                    {
                        XYPlot plot = getPlot();
                        int N = plot.getDatasetCount();
                        for (int i = 0; i < N; i++)
                        {
                            XYDataset dataset = plot.getDataset(i);

                            if (dataset instanceof AbstractVisibleXYDataset)
                            {
                                AbstractVisibleXYDataset visibleDataset = (AbstractVisibleXYDataset) dataset;
                                visibleDataset.setVisible(false);
                            }
                        }
                    }
                });
                visiblePopup.add(displayAll);
                visiblePopup.add(hideAll);
                visiblePopup.addSeparator();

                //  Add check boxes for each dataset and series
                XYPlot plot = getPlot();
                int N = plot.getDatasetCount();
                for (int i = 0; i < N; i++)
                {
                    XYDataset dataset = plot.getDataset(i);

                    if (dataset instanceof VisibleXYDataset && dataset.getSeriesCount() > 0)
                    {
                        final VisibleXYDataset visibleDataset = (VisibleXYDataset) dataset;

                        // Make the checkbox for the waveform selected by default.
                        JCheckBoxMenuItem cb = new JCheckBoxMenuItem();
                        final boolean visible = visibleDataset.isVisible();

                        cb.setSelected(visible);
                        cb.setText(visibleDataset.getSeriesKey(0).toString());
                        cb.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e)
                            {
                                visibleDataset.setVisible(!visibleDataset.isVisible());
                            }
                        });
                        visiblePopup.add(cb);
                    }

                }
                visiblePopup.show((JComponent) e.getSource(), 0, ((JComponent) e.getSource()).getHeight());
            }
        });

        // Add the buttons to the toolbar
        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.setBorder(BorderFactory.createEtchedBorder());

        if (_copySaveControls)
        {
            addButton(toolBar, copyButton);
            addButton(toolBar, saveButton);
            // addButton(toolBar, exportDataButton);
        }
        if (_panZoomControls)
        {
            toolBar.add(new JLabel(" "));
            addButton(toolBar, panButton);
            addButton(toolBar, zoomButton);
        }
        if (_configureAxesControls)
        {
            toolBar.add(new JLabel(" "));
            addButton(toolBar, configPlotButton);
        }
        if (_visibilityControl)
        {
            addButton(toolBar, visibleButton);
        }

        return toolBar;
    }

    protected ChartPanel createChart()
    {
        XYPlot plot = new XYPlot();

        plot.setRangeGridlinesVisible(true);
        plot.setDomainGridlinesVisible(true);

        // Set background color
        plot.setBackgroundPaint(Property.CHART_VIEWER_BACKGROUND_COLOR.getColorValue());

        // Set gridline color
        Color color = Property.CHART_VIEWER_GRIDLINE_COLOR.getColorValue();
        plot.setRangeGridlinePaint(color);
        plot.setDomainGridlinePaint(color);

        // Set gridline width
        float gridlineWidth = Property.CHART_VIEWER_GRIDLINE_WIDTH.getFloatValue();
        BasicStroke s = (BasicStroke) plot.getDomainGridlineStroke();
        BasicStroke newStroke = new BasicStroke(gridlineWidth, s.getEndCap(), s.getLineJoin(), s.getMiterLimit(), s.getDashArray(), s.getDashPhase());
        plot.setDomainGridlineStroke(newStroke);
        plot.setRangeGridlineStroke(newStroke);

        //  Set a default renderers
        for (int i = 0; i < 100; i++)
            plot.setRenderer(i, createRenderer(i));

        // Set label and tick label font size
        int size = Property.CHART_VIEWER_LABEL_FONT_SIZE.getIntegerValue();
        _labelFont = new Font(Font.SANS_SERIF, Font.PLAIN, size);

        // Create the Range axis
        NumberAxis range = new NumberAxis("");
        range.setAutoRange(true);
        range.setAutoRangeIncludesZero(false);
        range.setTickLabelFont(_labelFont);
        range.setLabelFont(_labelFont);
        plot.setRangeAxis(range);

        // Create the Domain axis
        NumberAxis domain = new NumberAxis("");
        domain.setAutoRangeIncludesZero(false);
        domain.setAutoRange(true);
        domain.setTickLabelFont(_labelFont);
        domain.setLabelFont(_labelFont);
        plot.setDomainAxis(domain);

        // Construct the JFreeChart objects
        JFreeChart chart = new JFreeChart("", _labelFont, plot, true);

        // Turn off anti-aliasing
        chart.setAntiAlias(false);

        // Turn on anti-aliasing for text
        RenderingHints renderhints = chart.getRenderingHints();
        renderhints.add(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON));

        ChartPanel chartPanel = new ChartPanel(chart, false);
        chartPanel.setPopupMenu(null);
        chartPanel.setMouseZoomable(false);
        chart.getLegend().setPosition(RectangleEdge.RIGHT);
        chart.getLegend().setItemFont(_labelFont);

        // Make tooltips appear instantly and forever
        chartPanel.setInitialDelay(0);
        chartPanel.setReshowDelay(0);
        chartPanel.setDismissDelay(Integer.MAX_VALUE);

        // Prevent chart panel from being scaled (and text from stretching)
        chartPanel.setMaximumDrawHeight(3000);
        chartPanel.setMaximumDrawWidth(3000);

        // Set height of viewer
        int height = Property.CHART_VIEWER_HEIGHT.getIntegerValue();
        int width = Property.CHART_VIEWER_WIDTH.getIntegerValue();
        Dimension d = new Dimension(width, height);
        chartPanel.setPreferredSize(d);
        chartPanel.addComponentListener(new ComponentAdapter()
        {
            public void componentResized(ComponentEvent e)
            {
                Dimension dim = e.getComponent().getSize();

                _chartPanel.setMaximumDrawHeight(dim.height);
                _chartPanel.setMinimumDrawHeight(dim.height);
                _chartPanel.setMaximumDrawWidth(dim.width);
                _chartPanel.setMinimumDrawWidth(dim.width);

                _chartPanel.getChart().fireChartChanged();
            }
        });

        return chartPanel;
    }

    /**
     * Get the line colors as specified by the Property value.
     */
    protected List<Color> getPaints()
    {
        return Property.CHART_VIEWER_LINE_COLOR_PALETTE.getColorPaletteValue();
    }

    // Assumes that _chartPanel and _viewerPanel have been setup correctly
    protected void init()
    {
        setLayout(new BorderLayout());

        // Add the toolbar
        _toolBar = createButtonBar();
        add(_toolBar, BorderLayout.NORTH);

        // Add the viewer panel
        add(_viewerPanel, BorderLayout.CENTER);

        //  Set the domain and range axis units
        Plot plot = _chartPanel.getChart().getPlot();

        //  Click on data point to add an annotation
        if (plot instanceof XYPlot)
        {
            final XYPlot xyPlot = (XYPlot) plot;
            _chartPanel.addChartMouseListener(new ChartMouseListener()
            {
                @Override
                public void chartMouseClicked(ChartMouseEvent cme)
                {
                    MouseEvent me = cme.getTrigger();
                    if (me == null)
                        return;

                    //  Check for a single click
                    if (me.getClickCount() != 1)
                        return;

                    //  Check that none of the mouse tools are active
                    for (Component c : _toolBar.getComponents())
                        if (c instanceof JButton)
                            if (((JButton) c).isSelected())
                                return;

                    //  Get the chart entity being clicked on
                    ChartEntity entity = cme.getEntity();
                    if (entity == null)
                        return;

                    //  Get the tooltip text
                    String text = entity.getToolTipText();
                    if (text == null || text.isEmpty())
                        return;

                    //  Strip the dataset name and html formatting
                    if ( !text.contains("<html>") )
                        return;
                    
                    text = text.substring(text.indexOf("<br>") + 4, text.indexOf("</html>"));

                    //  Get the click point in data-space
                    double x = xyPlot.getDomainAxis().java2DToValue(me.getPoint().getX(), _chartPanel.getScreenDataArea(), xyPlot.getDomainAxisEdge());
                    double y = xyPlot.getRangeAxis().java2DToValue(me.getPoint().getY(), _chartPanel.getScreenDataArea(), xyPlot.getRangeAxisEdge());

                    //  Add the annotation
                    XYTextAnnotation annotation = new XYTextAnnotation(text, x, y);
                    annotation.setFont(_labelFont);
                    annotation.setTextAnchor(TextAnchor.BOTTOM_LEFT);

                    xyPlot.addAnnotation(annotation);
                }

                @Override
                public void chartMouseMoved(ChartMouseEvent cme)
                {
                }
            });
        }

        // Set background color
        plot.setBackgroundPaint(Property.CHART_VIEWER_BACKGROUND_COLOR.getColorValue());

        // Set gridline color
        Color color = Property.CHART_VIEWER_GRIDLINE_COLOR.getColorValue();
        if (plot instanceof XYPlot)
        {
            ((XYPlot) plot).setRangeGridlinePaint(color);
            ((XYPlot) plot).setDomainGridlinePaint(color);
        }

        // Set gridline width
        float gridlineWidth = Property.CHART_VIEWER_GRIDLINE_WIDTH.getFloatValue();
        if (plot instanceof XYPlot)
        {
            BasicStroke s = (BasicStroke) ((XYPlot) plot).getDomainGridlineStroke();
            BasicStroke newStroke = new BasicStroke(gridlineWidth, s.getEndCap(), s.getLineJoin(), s.getMiterLimit(), s.getDashArray(), s.getDashPhase());
            ((XYPlot) plot).setDomainGridlineStroke(newStroke);
            ((XYPlot) plot).setRangeGridlineStroke(newStroke);
        }

        // Set label and tick label font size
        int size = Property.CHART_VIEWER_LABEL_FONT_SIZE.getIntegerValue();
        _labelFont = new Font(Font.SANS_SERIF, Font.PLAIN, size);

        // Set anti-aliasing
        boolean on = Property.CHART_VIEWER_ANTI_ALIASING.getBooleanValue();
        _chartPanel.getChart().setAntiAlias(on);

        // Set height of viewer
        int height = Property.CHART_VIEWER_HEIGHT.getIntegerValue();
        int width = Property.CHART_VIEWER_WIDTH.getIntegerValue();
        Dimension d = new Dimension(width, height);
        _chartPanel.setPreferredSize(d);
        _chartPanel.setMaximumSize(d);

        // Set line width variable
        _lineWidth = Property.CHART_VIEWER_LINE_WIDTH.getFloatValue();

        // Prevent chart panel from being scaled (and text from stretching)
        _chartPanel.setMaximumDrawHeight(3000);
        _chartPanel.setMaximumDrawWidth(3000);

        // Increase padding in order to lower chances that labels are cut-off from the ChartPanel
        _chartPanel.getChart().setPadding(new RectangleInsets(3, 0, 0, 10));

        // Make tooltips appear instantly and forever
        _chartPanel.setInitialDelay(0);
        _chartPanel.setReshowDelay(0);
        _chartPanel.setDismissDelay(Integer.MAX_VALUE);
    }

    /**
     * Create and return a BufferedImage of the PSD chart and parameter fields
     * in this viewer. The returned image is just the entire PSDViewer minus its 
     * toolbar. 
     */
    protected BufferedImage makeViewerImage()
    {
        // Change background color of chart panel to white, prior to making image.
        _chartPanel.setOpaque(false);
        _chartPanel.getChart().setBackgroundPaint(new Color(255, 255, 255, 255));

        BufferedImage result = GUIUtility.makeImage(_viewerPanel, false);

        // Change background colors back to transparent, ater making image.
        _chartPanel.setOpaque(false);
        _chartPanel.getChart().setBackgroundPaint(new Color(255, 255, 255, 0));

        return result;
    }

    /**
     * Display a dialog for setting axes limits for the graph
     */
    protected void showChartConfigDialog()
    {
        // Get the max/min of the x and y values of the data currently displayed by the chart.
        XYPlot plot = (XYPlot) _chartPanel.getChart().getPlot();
        String xMinStr, xMaxStr, yMinStr, yMaxStr;
        xMinStr = xMaxStr = yMinStr = yMaxStr = "N/A";

        Range domain = plot.getDataRange(plot.getDomainAxis());
        Range range = plot.getDataRange(plot.getRangeAxis());

        // Make GUI components for the dialog box.
        Font smallFont = new Font(Font.DIALOG, Font.PLAIN, 10);
        JLabel label;

        // Make controls for the y axis.
        JPanel y_panel = new JPanel(new GridLayout(1, 2));
        y_panel.setBorder(BorderFactory.createTitledBorder("Y Axis"));

        JFormattedTextField yLowerTextField = new JFormattedTextField(new DoubleRangeFormatter());
        yLowerTextField.setValue(range.getLowerBound());
        label = new JLabel("<html><p style=\"color:#0000FF\">min = " + yMinStr + " </p></html>");
        label.setFont(smallFont);

        JCheckBox y_freqLogScaleCheckbox = new JCheckBox("Log scale", getYScale() == AxisScale.LOG);

        JPanel y_panel1 = new JPanel(new GridBagLayout());
        y_panel1.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));
        GUIUtility.addRow(y_panel1, new JLabel("Lower limit:"), yLowerTextField);
        GUIUtility.addRow(y_panel1, new JLabel(" "), label);

        if (_allowYLogAxis)
            GUIUtility.addRow(y_panel1, y_freqLogScaleCheckbox);

        JFormattedTextField yUpperTextField = new JFormattedTextField(new DoubleRangeFormatter());
        yUpperTextField.setValue(range.getUpperBound());
        label = new JLabel("<html><p style=\"color:#0000FF\">max = " + yMaxStr + " </p></html>");
        label.setFont(smallFont);

        JPanel y_panel2 = new JPanel(new GridBagLayout());
        GUIUtility.addRow(y_panel2, new JLabel("Upper limit:"), yUpperTextField);
        GUIUtility.addRow(y_panel2, new JLabel(" "), label);

        if (_allowYLogAxis)
            GUIUtility.addRow(y_panel2, new JLabel(" "), null);

        y_panel.add(y_panel1);
        y_panel.add(y_panel2);

        // Make controls for the x axis.
        JPanel x_panel = new JPanel(new GridLayout(1, 2));
        x_panel.setBorder(BorderFactory.createTitledBorder("X Axis"));

        JFormattedTextField xLowerTextField = new JFormattedTextField(new DoubleRangeFormatter());
        xLowerTextField.setValue(domain.getLowerBound());
        label = new JLabel("<html><p style=\"color:#0000FF\">min = " + xMinStr + " </p></html>");
        label.setFont(smallFont);

        JCheckBox x_freqLogScaleCheckbox = new JCheckBox("Log scale", getXScale() == AxisScale.LOG);

        JPanel x_panel1 = new JPanel(new GridBagLayout());
        x_panel1.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));
        GUIUtility.addRow(x_panel1, new JLabel("Lower limit:"), xLowerTextField);
        GUIUtility.addRow(x_panel1, new JLabel(" "), label);
        GUIUtility.addRow(x_panel1, x_freqLogScaleCheckbox);

        JFormattedTextField xUpperTextField = new JFormattedTextField(new DoubleRangeFormatter());
        xUpperTextField.setValue(domain.getUpperBound());
        label = new JLabel("<html><p style=\"color:#0000FF\">max = " + xMaxStr + " </p></html>");
        label.setFont(smallFont);

        JPanel x_panel2 = new JPanel(new GridBagLayout());
        GUIUtility.addRow(x_panel2, new JLabel("Upper limit:"), xUpperTextField);
        GUIUtility.addRow(x_panel2, new JLabel(" "), label);
        GUIUtility.addRow(x_panel2, new JLabel(" "), null);

        x_panel.add(x_panel1);
        x_panel.add(x_panel2);

        // Add a checkbox to allow the user to  auto-scale axes (for tests).
        JPanel auto_scaling_panel = new JPanel(new GridLayout(1, 2));
        JPanel auto_scaling_panel1 = new JPanel(new GridBagLayout());
        JPanel auto_scaling_panel2 = new JPanel(new GridBagLayout());
        GUIUtility.addRow(auto_scaling_panel1, _autoScalingCheckbox);
        GUIUtility.addRow(auto_scaling_panel2, new JLabel(" "), null);
        auto_scaling_panel.add(auto_scaling_panel1);
        auto_scaling_panel.add(auto_scaling_panel2);

        //  Layout the panels
        Object[] mesg = new Object[4];
        mesg[0] = new JLabel("<html><p style=\"color:#0000FF\">(Set upper " + "limit &le; lower limit for auto-scaling)</p><p></html>");
        mesg[1] = y_panel;
        mesg[2] = x_panel;

        if (_enableAutoScaleOption)
        {
            mesg[3] = auto_scaling_panel;
        }

        // Display the dialog.
        String[] options = { "OK", "Cancel" };
        int result = JOptionPane.showOptionDialog(this, mesg, "Configure plot axes", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options,
                options[0]);

        if (result == 0)
        {
            // User clicked OK.
            double lowY = ((Number) yLowerTextField.getValue()).doubleValue();
            double highY = ((Number) yUpperTextField.getValue()).doubleValue();
            double lowX = ((Number) xLowerTextField.getValue()).doubleValue();
            double highX = ((Number) xUpperTextField.getValue()).doubleValue();

            setXScale(x_freqLogScaleCheckbox.isSelected() ? AxisScale.LOG : AxisScale.LINEAR);
            setYScale(y_freqLogScaleCheckbox.isSelected() ? AxisScale.LOG : AxisScale.LINEAR);
            plot.getDomainAxis().setRange(lowX, highX);
            plot.getRangeAxis().setRange(lowY, highY);
        }
    }
}
