/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.media.PathMedia;
import gov.sandia.gnem.netmod.path.media.PathMediaPhaseParameter;
import gov.sandia.gnem.netmod.path.media.PathMediaType;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * TeleseismicBodywave implements the SignalAmplitude interface.
 * However, it does not register itself with as a Plugin as it
 * is used within higher level signal amplitude routines.
 * 
 * @author bjmerch
 *
 */
public class TeleseismicBodywave extends AbstractNetSimBodywave
{
    public TeleseismicBodywave(NetModComponent parent, String type, String name)
    {
        super(parent, type, name);
    }

    @Override
    protected Spectra computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        // Get the reference Path Media Type
        PathMedia pathMedia = paths.getPathMedia();
        PathMediaType pathMediaType = pathMedia.getMediaType(PathMedia.REFERENCE);
        if (pathMediaType == null)
        {
            SpectraPDF attenuation = SpectraPDF.ZERO;
            recordIntrospection("Path Attenuation (log10 Amplitude): ", attenuation);
            recordIntrospection("Unable to determine a path media type for this epicenter");
            statusIntrospection(StatusType.ERROR);
            stopIntrospection();
            return attenuation;
        }
        
        PathMediaPhaseParameter phaseParameters = pathMediaType.getPhaseParameters().getPhaseParameter(phase);
        
        //  Get the attenuation from the phase specific reference path media
        Spectra Bk = phaseParameters.getAmplitudeAttenuation().getAttenuation(station.getLocation(), epicenter, distance, frequency);
        
        //  Get the attenuation standard deviation from the reference path media
        double sd = phaseParameters.getStddevAttenuation();

        //  Duplicate a NetSim bug to get standard deviation from the path media at the station location
        if (Property.NETSIM_PATH_SD.getBooleanValue())
        {
            //  Get the path media at the station location
            PathMediaType sourcePathMediaType = pathMedia.getMediaType(station.getLocation());

            sd = sourcePathMediaType.getPhaseParameters().getPhaseParameter(phase).getStddevAttenuation();
        }
        
        //  teleseismic source and receiver corrections
        double teleseismic_correction = 
        		computeTeleseismicSourceCorrection(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time) +
                computeTeleseismicReceiverCorrection(sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time);

        //  Combine the attenuation with the standard deviation and add corrections
        Spectra attenuation = Spectra.sum(teleseismic_correction, sd, Bk);
        
        if ( N > 1 )
        	attenuation = attenuation.toMonteCarlo(prng, N);

        recordIntrospection("Path Attenuation (log10 Amplitude): ", attenuation);
        recordIntrospection("Path Media Type: ", pathMediaType);
        recordIntrospection("Path Media Std Dev (log10 Amplitude): ", sd);

        stopIntrospection();

        return attenuation;
    }

    /**
     * Compute the path attenuation correction due to the source location.
     * 
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param station
     * @param magnitude
     * @param phase
     * @param frequency
     * @param time
     * @return
     */
    private double computeTeleseismicSourceCorrection(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time)
    {
        startIntrospection();

        PathMediaType pathMediaType = paths.getPathMedia().getMediaType(epicenter);
        if (pathMediaType == null)
        {
            recordIntrospection("Teleseismic Source Correction:  Unknown path media type");
            statusIntrospection(StatusType.ERROR);
            stopIntrospection();
            return 0;
        }

        double correction = pathMediaType.getPhaseParameters().getPhaseParameter(phase).getLogSourceCorrection();

        recordIntrospection("Teleseismic Source Correction (log10 Amplitude): ", correction);
        recordIntrospection("Path Media Type: ", pathMediaType);
        stopIntrospection();
        return correction;
    }

    /**
     * Compute the path attenuation correction due to the receiver location.
     * 
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param station
     * @param magnitude
     * @param phase
     * @param frequency
     * @param time
     * @return
     */
    private double computeTeleseismicReceiverCorrection(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time)
    {
        startIntrospection();

        PathMediaType pathMediaType = paths.getPathMedia().getMediaType(station.getLocation());
        if (pathMediaType == null)
        {
            recordIntrospection("Teleseismic Receiver Correction: Unknown path media type");
            statusIntrospection(StatusType.ERROR);
            stopIntrospection();
            return 0;
        }

        double correction = pathMediaType.getPhaseParameters().getPhaseParameter(phase).getLogReceiverCorrection();

        recordIntrospection("Teleseismic Receiver Correction (log10 Amplitude): ", correction);
        recordIntrospection("Path Media Type: ", pathMediaType);
        stopIntrospection();

        return correction;
    }
}
