package gov.sandia.gnem.netmod.map.wordwind2;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.util.Map.Entry;
import java.util.Set;

import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.avlist.AVList;
import gov.nasa.worldwind.avlist.AVListImpl;
import gov.nasa.worldwind.formats.shapefile.Shapefile;
import gov.nasa.worldwind.formats.shapefile.ShapefileLayerFactory;
import gov.nasa.worldwind.formats.shapefile.ShapefileLayerFactory.CompletionCallback;
import gov.nasa.worldwind.formats.shapefile.ShapefileRecord;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable;
import gov.nasa.worldwind.formats.shapefile.ShapefileUtils;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.PatternFactory;
import gov.nasa.worldwind.render.PointPlacemark;
import gov.nasa.worldwind.render.PointPlacemarkAttributes;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.io.IOUtility;

public class ShapefileLoader
{
	/**
	 * Load a shapefile from the provided file
	 * 
	 * @param file
	 * @return
	 */
	public static Layer load(File file)
	{
		Layer layer = load(getShapefile(file));
		layer.setName(file.getName());
		return layer;
	}
	
	public static Layer load(Shapefile shp)
	{		
		return load(shp, null);
	}
	
	/**
	 * 
	 * 
	 * @param file
	 * @return
	 */
	public static Layer load(File file, ShapefileRenderable.AttributeDelegate delegate)
	{
		Layer layer = load(getShapefile(file), delegate);
		layer.setName(file.getName());
		return layer;
	}
	
	private static Shapefile getShapefile(File file)
	{
		Shapefile shp = null;
		
		if ( IOUtility.endsWith(file, ".zip") )
			shp = ShapefileUtils.openZippedShapefile(file);
		else
            //  Override shapefile checking of coordinate system, because it always shows an error message due to missing coordinate system
			shp = new Shapefile(file)
			{
				@Override
				protected String validateCoordinateSystem(AVList params)
				{
					return null;
				}
			};
		
		return shp;
	}
	
	/**
	 * 
	 * 
	 * @param file
	 * @return
	 */
	public static Layer load(Shapefile shp, ShapefileRenderable.AttributeDelegate delegate)
	{
		//  Transfer over attributes from shapefile
		Set<String> attributes = shp.getAttributeNames();
		AVList dbasemapping = new AVListImpl();
		for (String key : attributes)
			dbasemapping.setValue(key, key);
		
        ShapefileLayerFactory factory = new ShapefileLayerFactory();
        factory.setDBaseMappings(dbasemapping);
        
        //  Set default visualization attributes
        factory.setNormalPointAttributes(getNormalPointAttributes());
        factory.setNormalShapeAttributes(getNormalShapeAttributes());
        if ( delegate != null )
        	factory.setAttributeDelegate(delegate);
        
         Layer layer = (gov.nasa.worldwind.layers.Layer) factory.createFromShapefileSource(shp, 
        		 new CompletionCallback()
        		 {

					@Override
					public void completion(Object o)
					{
						Layer layer = (Layer)  o;
				         //  Customize the display
				         if ( layer instanceof RenderableLayer )
				         {
				        	 RenderableLayer l = (RenderableLayer) layer;

				        	 for ( Renderable r : l.getRenderables())
				        	 {
				        		 //  Check for a property to use as a label
				        		 if ( r instanceof PointPlacemark )
				        		 {
				        			 PointPlacemark pp = (PointPlacemark) r;
				        			 Set<Entry<String, Object>> entries = pp.getEntries();
				        			 for (Entry<String,Object> entry : entries)
				        			 {
				        				 String key = entry.getKey().toLowerCase();
				        				 if ( key.contains("name") || key.contains("label") )
				        					 pp.setLabelText(entry.getValue().toString());
				        			 }
				        		 }
				        	 }
				         }
					}

					@Override
					public void exception(Exception e)
					{
						e.printStackTrace();
					}
        		 });
         
        
        return layer;
	}

	private static ShapeAttributes getNormalShapeAttributes()
	{
		BasicShapeAttributes attrs = new BasicShapeAttributes();
		attrs.setDrawInterior(false);
		attrs.setDrawOutline(true);
		attrs.setEnableAntialiasing(false);
		attrs.setEnableLighting(false);
		attrs.setInteriorMaterial(new Material(Color.BLACK));
		attrs.setInteriorOpacity(0.0);
		attrs.setOutlineMaterial(new Material(Color.BLACK));
		attrs.setOutlineOpacity(1.0);
		attrs.setOutlineStippleFactor(1);
		attrs.setOutlineStipplePattern((short) 0xFFFF);
		attrs.setOutlineWidth(2.0);
		
		return attrs;
	}

	private static PointPlacemarkAttributes getNormalPointAttributes()
	{
        PointPlacemarkAttributes attrs = new PointPlacemarkAttributes();

        attrs.setUsePointAsDefaultImage(true);
        attrs.setLineMaterial(new Material(Color.BLACK));
        attrs.setImageAddress(PatternFactory.PATTERN_CIRCLE);
        attrs.setScale(7d);
        attrs.setDrawLabel(true);
        attrs.setLabelMaterial(new Material(Color.WHITE));
        attrs.setLabelFont(new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue()));
        
        return attrs;
	}
}
