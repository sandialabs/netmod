package gov.sandia.gnem.netmod.infra.path.attenuation;

public class LANLEmpiricalAttenuation2021
{

}
