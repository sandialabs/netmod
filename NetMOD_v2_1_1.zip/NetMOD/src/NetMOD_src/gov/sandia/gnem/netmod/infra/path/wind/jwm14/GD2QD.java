/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 * 
 * Notice: This computer software was prepared by Sandia Corporation, 
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are 
 * reserved by DOE on behalf of the United States Government and the 
 * Contractor as provided in the Contract. You are authorized to use this 
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE 
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY 
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

/**
 * Container used for GD2QD information that is variable between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class GD2QD
{

    public double[] sh; // Array to hold spherical harmonic functions
    private double[] shgradtheta; // Array to hold spherical harmonic gradients
    private double[] shgradphi; // Array to hold spherical harmonic gradients

    //private double     epoch;
    //private double     alt;

    public GD2QD()
    {
        GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();
        
        sh = new double[gd2qd_data.nterm];
        shgradtheta = new double[gd2qd_data.nterm];
        shgradphi = new double[gd2qd_data.nterm];
    }

    /**
     * Converts geodetic coordinates to Quasi-Dipole coordinates (Richmond, J. Geomag. 
     * Geoelec., 1995, p. 191), using a spherical harmonic representation.
     */
    public void gd2qd(double glatin, double glon, double[] qCoord, double[][] f, ALF alf) throws Exception
    {
        GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();
        
        double glat, theta, phi, mphi, cosmphi, sinmphi, x, y, z;
        double cosqlat, cosqlon, sinqlon, xgradtheta, ygradtheta, zgradtheta;
        double xgradphi, ygradphi, zgradphi, qlonrad;
        int i;

        glat = glatin;
        if (glat != alf.glatalf)
        {
            theta = Math.toRadians(90.0 - glat);
            alf.ALFBasisGBar(theta);
            alf.glatalf = glat;
        }
        phi = Math.toRadians(glon);

        double[] gpbar_0 = alf.gpbar[0];
        double[] gvbar_0 = alf.gvbar[0];
        i = 0;
        for (int n = 0; n <= gd2qd_data.nmax; n++)
        {
            sh[i] = gpbar_0[n];
            shgradtheta[i] = gvbar_0[n] * gd2qd_data.normadj[n];
            shgradphi[i] = 0.0;
            i++;
        }

        for (int m = 1; m <= gd2qd_data.mmax; m++)
        {
            double[] gpbar_m = alf.gpbar[m];
            double[] gvbar_m = alf.gvbar[m];
            double[] gwbar_m = alf.gwbar[m];
            
            mphi = m * phi;
            cosmphi = Math.cos(mphi);
            sinmphi = Math.sin(mphi);

            for (int n = m; n <= gd2qd_data.nmax; n++)
            {
            	double gpbar = gpbar_m[n];
            	double gvbar = gvbar_m[n];
            	double gwbar = gwbar_m[n];
            	
            	double normadj = gd2qd_data.normadj[n];
            	
                sh[i]              =  gpbar * cosmphi;
                sh[i + 1]          =  gpbar * sinmphi;
                shgradtheta[i]     =  gvbar * normadj * cosmphi;
                shgradtheta[i + 1] =  gvbar * normadj * sinmphi;
                shgradphi[i]       = -gwbar * normadj * sinmphi;
                shgradphi[i + 1]   =  gwbar * normadj * cosmphi;
                i += 2;
            }
        }

        x = mathutil.dotProduct(sh, gd2qd_data.xcoeff);
        y = mathutil.dotProduct(sh, gd2qd_data.ycoeff);
        z = mathutil.dotProduct(sh, gd2qd_data.zcoeff);

        qlonrad = Math.atan2(y, x);
        cosqlon = Math.cos(qlonrad);
        sinqlon = Math.sin(qlonrad);
        cosqlat = x * cosqlon + y * sinqlon;

        qCoord[0] = Math.toDegrees(Math.atan2(z, cosqlat));
        qCoord[1] = Math.toDegrees(qlonrad);

        xgradtheta = mathutil.dotProduct(shgradtheta, gd2qd_data.xcoeff);
        ygradtheta = mathutil.dotProduct(shgradtheta, gd2qd_data.ycoeff);
        zgradtheta = mathutil.dotProduct(shgradtheta, gd2qd_data.zcoeff);

        xgradphi = mathutil.dotProduct(shgradphi, gd2qd_data.xcoeff);
        ygradphi = mathutil.dotProduct(shgradphi, gd2qd_data.ycoeff);
        zgradphi = mathutil.dotProduct(shgradphi, gd2qd_data.zcoeff);

        f[0][0] = (-zgradtheta * cosqlat + (xgradtheta * cosqlon + ygradtheta * sinqlon) * z);
        f[0][1] = (-zgradphi * cosqlat + (xgradphi * cosqlon + ygradphi * sinqlon) * z);
        f[1][0] = (ygradtheta * cosqlon - xgradtheta * sinqlon);
        f[1][1] = (ygradphi * cosqlon - xgradphi * sinqlon);

        /*
         * Debugging statements
        System.out.println("");
        System.out.println("gd2qd");
        System.out.println("glat = " + glat);
        System.out.println("glon = " + glon);
        System.out.println("qlat = " + qCoord[0]);
        System.out.println("qlon = " + qCoord[1]);
        System.out.println("xgradtheta = " + xgradtheta);
        System.out.println("ygradtheta = " + ygradtheta);
        System.out.println("zgradtheta = " + zgradtheta);
        System.out.println("xgradphi = " + xgradphi);
        System.out.println("ygradphi = " + ygradphi);
        System.out.println("zgradphi = " + zgradphi);
        System.out.println("x = " + x);
        System.out.println("y = " + y);
        System.out.println("z = " + z);
        System.out.println("qlonrad = " + qlonrad);
        System.out.println("cosqlon = " + cosqlon);
        System.out.println("sinqlon = " + sinqlon);
        System.out.println("cosqlat = " + cosqlat);
        System.out.println("f1e = " + f[0][0]);
        System.out.println("f1n = " + f[0][1]);
        System.out.println("f2e = " + f[1][0]);
        System.out.println("f2n = " + f[1][1]);
        */
    }
}
