/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.map.MapPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.project.Project;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

/**
 * NetMOD main GUI.
 * 
 * @author bjmerch
 *
 */
public class NetMOD extends JFrame
{
    /**
     * NetMOD Version number
     */
	public static String name = "NetMOD";
    public static String version = "";
    
    //  Static reference to the main GUI
    private static NetMOD _netMOD = null;
    
    //  NetMod UI components
    private NetMODMenuBar _menuBar;
    private Project _project = new Project(null);
    private Map _map = null;
    
    //  Swing organizational objects
    private JSplitPane _tocSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    private JScrollPane _tocScrollPane;
    
    /**
     * Create a NetMOD GUI with the provided title
     * 
     * @param title
     */
    public NetMOD()
    {
        _netMOD = this;
        
        setTitle(name);
        
        //  Setup the Menu Bar
        _menuBar = new NetMODMenuBar(this);
        setJMenuBar(_menuBar);
        
        //  Setup the Table of Contents
        _tocScrollPane = new JScrollPane(new ProjectContainer(_project.getViewer()));
        _tocScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        _tocScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _tocScrollPane.getViewport().setScrollMode(JViewport.BLIT_SCROLL_MODE);
        
        //  Set the application icon
        try
        {
            setIconImage(ImageIO.read(getClass().getResource("/gov/sandia/gnem/netmod/gui/NetMOD.png")));
        }
        catch (IOException e)
        {}

        // Get the screen dimensions
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        
        //  Scale the width to be a ratio of the height
        width = (int) (height * Math.min(16.0 / 10, ((double) width) / height));
        
        //  Reduce the width and height by 10%
        width = (int) (width * 0.9);
        height = (int) (height * 0.9);
        
        //  Determine the divider location
        int dividerLocation = (int) ( width * 0.3 );
        try
        {
            dividerLocation = (int) ( width * Double.parseDouble(Property.DIVIDER_LOCATION.getValue()));
        }
        catch (Exception e)
        {}
        _tocSplitPane.setRightComponent(new JPanel());
        _tocSplitPane.setLeftComponent(_tocScrollPane);
        _tocSplitPane.setDividerLocation(dividerLocation);
        
        setContentPane(_tocSplitPane);
        resetMap();
        
        // Add a listener to close the application if the window is closed
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                _menuBar.fileExit.actionPerformed(null);
            }
        });
        //  Set the size and position
        setSize(width, height);
        setLocationRelativeTo(null);
    }
    
    /**
     * Get the NetMod frame
     * 
     * @return
     */
    public static NetMOD getFrame()
    {
        return _netMOD;
    }
    
    /**
     * Get the project within NetMod
     * 
     * @return
     */
    public Project getProject()
    {
        return _project;
    }
    
    /**
     * Get the Map that is used for visualization
     * 
     * @return
     */
    public static Map getMap()
    {
        if ( _netMOD == null )
            return null;
        
        return _netMOD._map;
    }
    
    /**
     * Reset the map.
     */
    public void resetMap()
    {
        //  Search for a valid map
        _map = MapPlugin.getPlugin().getComponent(null, Property.MAP.getValue(), true);
        
        if ( _map != null )
            _tocSplitPane.setRightComponent(_map.getViewer());
        
        // Get the screen dimensions
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        
        //  Determine the divider location
        int dividerLocation = (int) ( width * Property.DIVIDER_LOCATION.getFloatValue() );
        _tocSplitPane.setDividerLocation(dividerLocation);
    }
    
    /**
     * Refresh the display of the provided NetModComponent
     * 
     * @param nmc
     */
    public static void refresh(NetModComponent nmc)
    {
        if ( _netMOD == null )
            return;
        
        //  Refresh the map
        if ( _netMOD._map != null )
            _netMOD._map.refresh();
    }
    
    /**
     * Check whether NetMod is running in a GUI (true) or command line (false) mode.
     * 
     * @return
     */
    public static boolean isGUI()
    {
        return _netMOD != null;
    }
    
    /**
     * Container to make ProjectViewer fit well into a JScrollPane
     * 
     * @author bjmerch
     *
     */
    private class ProjectContainer extends JPanel implements Scrollable
    {
        public ProjectContainer(NetModComponentViewer<?> viewer)
        {
            super(new GridLayout(0,1));
            
            add(viewer);
        }
        
        @Override
        public Dimension getPreferredScrollableViewportSize()
        {
            return getPreferredSize();
        }
        
        @Override
        public Dimension getPreferredSize()
        {
            Dimension d = super.getPreferredSize();
            
            return new Dimension(d.width, Math.max(d.height, _tocScrollPane.getViewport().getSize().height));
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle arg0, int arg1, int arg2)
        {
            return 100;
        }

        @Override
        public boolean getScrollableTracksViewportHeight()
        {
            return false;
        }

        @Override
        public boolean getScrollableTracksViewportWidth()
        {
            return true;
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle arg0, int arg1, int arg2)
        {
            return 20;
        }
    }
}
