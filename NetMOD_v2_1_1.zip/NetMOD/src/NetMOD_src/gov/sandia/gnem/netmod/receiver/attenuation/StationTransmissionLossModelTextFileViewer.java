package gov.sandia.gnem.netmod.receiver.attenuation;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.numeric.NumericUtility;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuation2DQ;
import gov.sandia.gnem.netmod.path.attenuation.AmplitudeAttenuation2DQViewer;

import javax.swing.*;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.LookupPaintScale;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.chart.title.PaintScaleLegend;
import org.jfree.data.xy.AbstractIntervalXYDataset;
import org.jfree.data.xy.AbstractXYZDataset;
import org.jfree.ui.RectangleEdge;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.IndexColorModel;

public class StationTransmissionLossModelTextFileViewer
		extends NetModComponentViewer<StationTransmissionLossModelTextFile>
{
	private class AttenuationDataset extends AbstractIntervalXYDataset implements VisibleXYDataset
    {
        int _frequency_index = 0;
        int _azimuth_index = 0;
        private StationTransmissionLossModelTextFile _attenuation = null;

        @Override
        public int getItemCount(int series) 
        {
        	if ( _attenuation == null )
        		return 0;

        	int Nr = _attenuation.getNRanges();
        	
        	return Nr;
        }

		@Override
		public int getSeriesCount()
		{
        	if ( _attenuation == null )
        		return 0;
        	
        	int Np = _attenuation.getNPercentiles();
        	
        	return Np;
		}

        @Override
        public Comparable getSeriesKey(int series) 
        {
            return "Percentile = " + _attenuation.getPercentiles()[series];
        }

        @Override
        public Number getX(int series, int item) 
        {
            return _attenuation.getRanges()[item];
        }

        @Override
        public Number getY(int series, int item) 
        {
            double value = _attenuation.getTLM()[_azimuth_index][item][_frequency_index][series];
            
            //  Sometimes attenuation models contain really large values at upper end for no good reason.
            if ( value > 1 && series > 0 )
            	return 1;
            
            if (Double.isFinite(value))
            	return value;
            
            return 0;
        }

		public void setAttenuation(StationTransmissionLossModelTextFile attenuation, int frequency_index, int azimuth_index)
		{
			_attenuation = attenuation;
			_frequency_index = frequency_index;
			_azimuth_index = azimuth_index;
			fireDatasetChanged();
		}

		@Override
		public Number getEndX(int series, int item) 
		{
			return getX(series, item);
		}

		@Override
		public Number getEndY(int series, int item) 
		{
            if (series >= getSeriesCount() - 1)
                return getY(getSeriesCount() - 1, item);

            return getY(series + 1, item);
		}

		@Override
		public Number getStartX(int series, int item) 
		{
			return getX(series, item);
		}

		@Override
		public Number getStartY(int series, int item) 
		{
			return getY(series, item);
		}

		@Override
		public boolean isVisible()
		{
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void setVisible(boolean visible)
		{
			// TODO Auto-generated method stub
			
		}
	}


	private class SiteAttenuationTableModel extends NetMODTable.NetMODTableModel
	{
		private StationTransmissionLossModelTextFile _attenuation = null;

		@Override
		public int getColumnCount()
		{
			if (_attenuation == null)
				return 1;
			return _attenuation.getNPercentiles()+1;
		}

		public String getColumnName(int column)
		{
			if (column == 0)
				return "<html>Distance<br>(degrees)</html>";
			else
				return Double.toString(_attenuation.getPercentiles()[column-1]);
		}

		@Override
		public int getRowCount()
		{
			return (_attenuation == null ? 0 : _attenuation.getNRanges() + 10 );
		}

		@Override
		public Object getValueAt(int row, int column)
		{
			int i_range = row;
			int i_cdf = column-1;
			int i_freq = getFrequencyIndex();
			int i_az = getAzimuthIndex();
			
			int Nrange = _attenuation.getNRanges();
			int Naz = _attenuation.getNAzimuths();
			int Nfreq = _attenuation.getNFrequencies();
			int Ncdf = _attenuation.getNPercentiles();
			
			if (i_range >= Nrange || i_az >= Naz || i_freq >= Nfreq || i_cdf >= Ncdf )
				return "";
			
			if ( column == 0 )
				return _attenuation.getRanges()[row];

			return _attenuation.getTLM()[i_az][i_range][i_freq][i_cdf];
		}

		@Override
		public boolean isCellEditable(int r, int c)
		{
			return c > 1;
		}

		public void setAttenuation(StationTransmissionLossModelTextFile attenuation)
		{
			_attenuation = attenuation;
			fireTableStructureChanged();
		}

		@Override
		public void setValueAt(Object aValue, int row, int column)
		{
			int i_range = row;
			int i_cdf = column-1;
			int i_freq = getFrequencyIndex();
			int i_az = getAzimuthIndex();
			
			int Nrange = _attenuation.getNRanges();
			int Naz = _attenuation.getNAzimuths();
			int Nfreq = _attenuation.getNFrequencies();
			int Ncdf = _attenuation.getNPercentiles();

			if (aValue == null || i_range >= Nrange || i_az >= Naz || i_freq >= Nfreq || i_cdf >= Ncdf )
				return;

			{
				double value = Double.parseDouble(aValue.toString());
				_attenuation.getTLM()[i_az][i_range][i_freq][i_cdf] = value;
			}

			fireTableDataChanged();
		}

		@Override
		public void remove(int[] rows)
		{

		}

	}

	private ChartViewer _chartViewer = new ChartViewer();
	private SiteAttenuationTableModel _tableModel = new SiteAttenuationTableModel();
	private NetMODTable _table = new NetMODTable(_tableModel);
	private JComboBox _frequencyComboBox = null;
	private JComboBox _azimuthComboBox = null;

	
	private int getAzimuthIndex()
	{
		if (_azimuthComboBox == null)
			return 0;
		
		int index = _azimuthComboBox.getSelectedIndex();
		
		if ( index < 0 )
			index = 0;
		
		return index;
	}
	
	private int getFrequencyIndex()
	{
		if (_frequencyComboBox == null)
			return 0;
		
		int index = _frequencyComboBox.getSelectedIndex();
		
		if ( index < 0 )
			index = 0;
		
		return index;
	}
	
	public StationTransmissionLossModelTextFileViewer(StationTransmissionLossModelTextFile nmc)
	{
		super(nmc, false, false, false);
		setExpanded(true);
		reset(nmc);
	}

	@Override
	public void apply(StationTransmissionLossModelTextFile nmc)
	{

	}

	@Override
	public JPanel getExpandedPanel()
	{
		if (_expandedPanel == null)
		{
			JPanel panel = new JPanel(new GridBagLayout());

			// Configure the chart viewer
			XYPlot plot = _chartViewer.getPlot();
			plot.getDomainAxis().setLabel("Range (deg)");
			plot.getRangeAxis().setLabel("Transmission Loss (log10)");

			// Force domain and range to be equal
			_chartViewer.getChartPanel().addComponentListener(new ComponentAdapter()
			{
				public void componentResized(ComponentEvent e)
				{
					rescaleMap();
				}
			});

			plot.getDomainAxis().addChangeListener(new AxisChangeListener()
			{

				@Override
				public void axisChanged(AxisChangeEvent arg0)
				{
					rescaleMap();
				}

			});

			plot.getRangeAxis().addChangeListener(new AxisChangeListener()
			{

				@Override
				public void axisChanged(AxisChangeEvent arg0)
				{
					rescaleMap();
				}

			});
            //  Setup the combo-box of frequencies and percentiles
            JPanel comboboxPanel = new JPanel(new GridBagLayout());

            _frequencyComboBox = new JComboBox(GUIUtility.toArrayDoubles(_nmc.getFrequencies()));
            if ( _frequencyComboBox.getItemCount() > 0 )
            	_frequencyComboBox.setSelectedIndex(0);
            _frequencyComboBox.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    reset(_nmc);
                }
            });
            
            _azimuthComboBox = new JComboBox(GUIUtility.toArrayDoubles(_nmc.getAzimuths()));
            if ( _azimuthComboBox.getItemCount() > 0 )
            	_azimuthComboBox.setSelectedIndex(0);
            _azimuthComboBox.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    reset(_nmc);
                }
            });
            
            GUIUtility.addRow(comboboxPanel, new JLabel("Frequency: "), _frequencyComboBox);
            GUIUtility.addRow(comboboxPanel, new JLabel("Azimuth: "), _azimuthComboBox);

            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.NORTH, comboboxPanel);

			// Setup the table
			JScrollPane sp = new JScrollPane(_table);
			sp.getVerticalScrollBar()
					.setPreferredSize(new Dimension(Math.max(20, Icons.ADD.getIcon().getIconWidth()), 0));
			spPanel.add(BorderLayout.CENTER, sp);
			spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
			spPanel.setPreferredSize(new Dimension(400, 0));

			// Arrange the chart viewer and table
			JSplitPane splitPane = new JSplitPane();
			splitPane.setBorder(null);
			splitPane.setContinuousLayout(true);
			splitPane.setDividerLocation(0.6);
			splitPane.setOneTouchExpandable(false);
			splitPane.setResizeWeight(0.5);
			splitPane.setLeftComponent(_chartViewer);
			splitPane.setRightComponent(spPanel);

			// Setup the panel
			GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);

			_expandedPanel = panel;
		}

		return _expandedPanel;
	}

	/**
	 * Rescale the map to keep the axes square
	 * 
	 */
	private void rescaleMap()
	{
		Dimension dim = _chartViewer.getChartPanel().getSize();

		XYPlot plot = _chartViewer.getPlot();
		ValueAxis domain = plot.getDomainAxis();
		ValueAxis range = plot.getRangeAxis();

		double xResolution = domain.getRange().getLength() / dim.width;
		double yResolution = range.getRange().getLength() / dim.height;

		double resolution = Math.max(xResolution, yResolution);

		// Set the map dimensions
		int height = (int) (range.getRange().getLength() / resolution);
		int width = (int) (domain.getRange().getLength() / resolution);

		_chartViewer.setSize(width, height);

		_chartViewer.getChart().fireChartChanged();
		SwingUtilities.updateComponentTreeUI(_chartViewer.getChartPanel());
	}

	@Override
	public void reset(StationTransmissionLossModelTextFile nmc)
	{
		double f = nmc.getFrequencies()[getFrequencyIndex()];
		double az = nmc.getAzimuths()[getAzimuthIndex()];
		
		_chartViewer.getChart().setTitle(nmc.getName() + ", " + f + " Hz, " + az + " degrees azimuth" );

		// Update the table
		_tableModel.setAttenuation(nmc);
		
        //  Update the datasets
        XYPlot plot = (XYPlot) _chartViewer.getChart().getPlot();
        for (int i = 0; i < 100; i++)
            plot.setDataset(i, null);

        //  Create the color scale
        double min = 0.0;
        double max = 1.0;
        LookupPaintScale scale = new LookupPaintScale(min, max, Color.BLACK);
        IndexColorModel colorModel = ColorModel.JET.getColorModel();
        int Ncolors = colorModel.getMapSize();
        
        //  Populate the lower half of the color scale
        min = 0.0;
        max = 0.5;
        double delta = (max-min)/(Ncolors-1.0);
        for (int i=0; i<Ncolors; i++)
        {
        	double value = min + i * delta;
        	scale.add(value, new Color(colorModel.getRed(i), colorModel.getGreen(i), colorModel.getBlue(i), colorModel.getAlpha(i)));
        }
        
        //  Populate the upper half of the color scale
        min = 1.0;
        max = 0.5;
        delta = (max-min)/(Ncolors-1.0);
        for (int i=0; i<Ncolors; i++)
        {
        	double value = min + i * delta;
        	scale.add(value, new Color(colorModel.getRed(i), colorModel.getGreen(i), colorModel.getBlue(i), colorModel.getAlpha(i)));
        }
        
        //  Build a legend for the color scale
        PaintScaleLegend psl = new PaintScaleLegend(scale, new NumberAxis("Percentile"));
        psl.setBackgroundPaint(null);
        psl.setPosition(RectangleEdge.RIGHT);
        psl.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        psl.setMargin(50.0, 20.0, 80.0, 0.0);
        
        JFreeChart chart = _chartViewer.getChart();
        for (int i=0; i<chart.getSubtitleCount(); i++)
        	chart.removeSubtitle(chart.getSubtitle(i));
        chart.addSubtitle(psl);

        //  Create dataset
        AttenuationDataset dataset = new AttenuationDataset();
        dataset.setAttenuation(nmc, getFrequencyIndex(), getAzimuthIndex());
        
        //  Update the renderer
        DeviationRenderer renderer = new DeviationRenderer(true, false);
        renderer.setAlpha(1.0f);
        renderer.setSeriesPaint(0, new Color(0,0,0,0));
        
        double[] percentiles = nmc.getPercentiles();
        int Npercentiles = percentiles.length;
        
        for (int i = 0; i < Npercentiles; i++)
        {
        	//  Get percentile, reverse order
        	double percentile = percentiles[i];
        	
        	//  Limit the percentile to 0..1
        	percentile = Math.max(0.0, Math.min(1.0, percentile));
        	
        	// scale so that 50% -> Red and 0/100% -> Blue
        	int i_color = (int) ( (0.5 - Math.abs( percentile - 0.5 )) * 2 * (Ncolors - 1));
        	
        	Paint paint = new Color(colorModel.getRGB(i_color));
        	
        	renderer.setSeriesPaint(i, paint);
        	renderer.setSeriesFillPaint(i, paint);
            renderer.setSeriesStroke(i, new BasicStroke(_chartViewer.getLineWidth()));
        }
            
        plot.setDataset(0, dataset);
        plot.setRenderer(0, renderer);
	}

}
