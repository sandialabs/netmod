/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Earth;
import gov.nasa.worldwind.globes.EarthFlat;
import gov.nasa.worldwind.globes.FlatGlobe;
import gov.nasa.worldwind.globes.GeographicProjection;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.globes.projections.ProjectionEquirectangular;
import gov.nasa.worldwind.globes.projections.ProjectionMercator;
import gov.nasa.worldwind.globes.projections.ProjectionModifiedSinusoidal;
import gov.nasa.worldwind.globes.projections.ProjectionPolarEquidistant;
import gov.nasa.worldwind.globes.projections.ProjectionSinusoidal;
import gov.nasa.worldwind.globes.projections.ProjectionUPS;
import gov.nasa.worldwind.terrain.ZeroElevationModel;
import gov.nasa.worldwind.view.orbit.BasicOrbitView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.Enumeration;

/**
 * Tool for changing the map projection
 * 
 * @author bjmerch
 *
 */
public class ProjectionTool extends AbstractAction
{
    /**
     * Action to reset the projection
     * 
     * @author bjmerch
     *
     */
    private class ProjectionAction extends AbstractAction
    {
        private GeographicProjection _projection;

        private ProjectionAction(String name, GeographicProjection projection)
        {
            putValue(NAME, name);
            _projection = projection;
        }

        @Override
        public void actionPerformed(ActionEvent arg0)
        {
            setProjection(_wwd, _projection);
        }
    }

    public static final GeographicProjection spherical = null;
	public static final GeographicProjection rectangular = new ProjectionEquirectangular()
	{
		@Override
		public boolean isContinuous()
		{
			return false;
		}
	};
	public static final GeographicProjection mercator = new ProjectionMercator()
	{
		@Override
		public boolean isContinuous()
		{
			return false;
		}
	};
    public static final GeographicProjection sinusoidal = new ProjectionSinusoidal();
    public static final GeographicProjection modified_sinusoidal = new ProjectionModifiedSinusoidal();
    public static final GeographicProjection north_pole_equidistant = new ProjectionPolarEquidistant(AVKey.NORTH);
    public static final GeographicProjection south_pole_equidistant = new ProjectionPolarEquidistant(AVKey.SOUTH);
    public static final GeographicProjection north_pole_stereographic = new ProjectionUPS(AVKey.NORTH);
    public static final GeographicProjection south_pole_stereographic = new ProjectionUPS(AVKey.SOUTH);
    

    private static Globe roundGlobe = null;
    private static FlatGlobe flatGlobe = null;
    private JPopupMenu popup;
    private WorldWindow _wwd;

    public ProjectionTool(WorldWindow wwd)
    {
        _wwd = wwd;
    }

    @Override
    public void actionPerformed(ActionEvent event)
    {
        //  Create the popup
        if (popup == null)
        {
            popup = new JPopupMenu();

            JRadioButtonMenuItem defaultProjection = new JRadioButtonMenuItem(new ProjectionAction("Equidistant Cylindrical", rectangular));
            defaultProjection.setSelected(true);

            //  Create the control to switch between projections
            ButtonGroup group = new ButtonGroup();
            group.add(new JRadioButtonMenuItem(new ProjectionAction("Spherical", spherical)));
            group.add(defaultProjection);
            group.add(new JRadioButtonMenuItem(new ProjectionAction("Mercator", mercator)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("Sinusoidal", sinusoidal)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("Modified Sinusoidal", modified_sinusoidal)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("North Polar Equidistant", north_pole_equidistant)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("South Polar Equidistant", south_pole_equidistant)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("North Polar Stereographic", north_pole_stereographic)));
            group.add(new JRadioButtonMenuItem(new ProjectionAction("South Polar Stereographic", south_pole_stereographic)));

            //  Add the controls to the popup
            for (Enumeration<AbstractButton> e = group.getElements(); e.hasMoreElements();)
                popup.add(e.nextElement());
        }

        //  Display the popup
        JButton button = (JButton) event.getSource();
        popup.show(button, 0, button.getSize().height);
    }

    /**
     * Set the project to the provided WorldWind projection key.
     * If the key is null, default to a round globe.
     * 
     * @param key
     */
    public static void setProjection(WorldWindow wwd, GeographicProjection projection)
    {
        BasicOrbitView orbitView = new BasicOrbitView();
        
        if (projection == null)
        {
            if ( roundGlobe == null )
                roundGlobe = new Earth();

            orbitView.setGlobe(roundGlobe);
            wwd.getModel().setGlobe(roundGlobe);
        }
        else
        {
            if ( flatGlobe == null )
                flatGlobe = new EarthFlat();

            flatGlobe.setProjection(projection);
            flatGlobe.setElevationModel(new ZeroElevationModel());

            orbitView.setGlobe(flatGlobe);
            orbitView.setOrientation(new Position(LatLon.fromDegrees(0, 0), 50000000),new Position(LatLon.fromDegrees(0, 0), 0));
            wwd.getModel().setGlobe(flatGlobe);
        }
        
        wwd.setView(orbitView);
        
        wwd.redraw();
    }

}
