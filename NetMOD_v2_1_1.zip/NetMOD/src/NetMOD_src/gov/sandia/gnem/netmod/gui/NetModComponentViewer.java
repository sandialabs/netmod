/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collection;

/**
 * Abstract component viewer that is extended by other viewers
 * of NetModComponents
 * 
 * @author bjmerch
 *
 */
abstract public class NetModComponentViewer<NMC extends NetModComponent> extends JPanel
{
    /**
     * Listener that updates whenever a change is made to a component.  Updates 
     * 
     * @author bjmerch
     *
     */
    private class ComponentChangeListener implements ActionListener, FocusListener, ItemListener, ChangeListener, PropertyChangeListener
    {
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            update(true, false);
        }

        @Override
        public void focusGained(FocusEvent fe)
        {
            //  Don't do anything when a component gains focus, only when losing focus.
        }

        @Override
        public void focusLost(FocusEvent fe)
        {
            update(true, true);
        }

        @Override
        public void itemStateChanged(ItemEvent ie)
        {
            if ( ie.getStateChange() == ItemEvent.SELECTED )
                update(true, true);  //  JComboBox calls should update later in the event dispatch thread)
        }

        @Override
        public void propertyChange(PropertyChangeEvent arg0)
        {
            update(true, false);
        }

        @Override
        public void stateChanged(ChangeEvent ce)
        {
            //  Don't do an update if the JSlider is adjusting
            if ( ce.getSource() instanceof JSlider )
            {
                if ( !((JSlider) ce.getSource()).getValueIsAdjusting() )
                    update(true, true);
            }
            else
                update(true, false);
                    
        }

        private void update(final boolean refresh, boolean invokeLater)
        {
            //  Check updating flag to prevent recursive flow.
            if ( _updating )
                return;
            
			Runnable runnable = new Runnable()
			{
				@Override
				public void run()
				{
					// Check updating flag to prevent recursive flow.
					if (_updating)
						return;

					_updating = true;

					apply(_nmc);

					if (refresh)
					{
						refresh();
						NetMOD.refresh(_nmc);
					}

					_updating = false;
				}
			};
            
            if ( invokeLater )
            	EventQueue.invokeLater(runnable);
            else
            	runnable.run();
        }
    }
    
    private static final Border _titleBorder = BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(""), BorderFactory.createEmptyBorder(0,  10,  0,  0));
    private static final Border _emptyBorder = BorderFactory.createEmptyBorder(0,  10,  0,  0);
    
    //  Flag to define whether the viewer is expanded
    private boolean _expanded = false;
    private Border _expandedBorder;
    private JComponent _preControlToolBar = GUIUtility.createToolBar();
    private JComponent _postControlToolBar = GUIUtility.createToolBar();
    private JButton _toggleDisplayButton = createToggleDisplayButton();
    protected JPanel _expandedPanel = null;
    private JLabel _viewerName;
    
    //  Flag to prevent recursive updates
    protected boolean _updating = false;
    
    private ComponentChangeListener _ccl = new ComponentChangeListener();
    protected NMC _nmc = null;

    /**
     * @param nmc
     */
    public NetModComponentViewer(NMC nmc)
    {
        this(nmc, false, false);
    }
    /**
     * @param nmc
     * @param border
     * @param expandable
     */
    public NetModComponentViewer(NMC nmc, boolean border, boolean expandable)
    {
        this(nmc, border, expandable, expandable);
    }

    /**
     * @param nmc
     * @param border
     * @param expandable
     * @param header
     */
    public NetModComponentViewer(NMC nmc, boolean border, boolean expandable, boolean header)
    {
        super(new GridBagLayout());
        _nmc = nmc;
        
        //  Create the shrink/expand button
        _viewerName = new JLabel(nmc.toString());
        _viewerName.setVerticalAlignment(SwingConstants.BOTTOM);
        _viewerName.setOpaque(false);
        
        if ( border )
            _expandedBorder = _titleBorder;
        else
            _expandedBorder = _emptyBorder;
        
        if ( header )
        {
            if ( expandable )
                addNetModPreControl(_toggleDisplayButton);
            
            addNetModPostControl(_viewerName);
            addNetModPostControl(new JLabel("  "));
            
            GUIUtility.addRow(this, _preControlToolBar, _postControlToolBar);
        }
        
        setExpanded(false);
        
        //  make it resizeable
        makeResizeable();
    }
    
    /**
     * Add a control item to the NetModViewer header
     * 
     * @param component
     */
    public void addNetModPostControl(Component component)
    {
        _postControlToolBar.add(component);
    }
    
    /**
     * Add a control item to the NetModViewer header
     * 
     * @param control
     */
    public void addNetModPreControl(JComponent control)
    {
        _preControlToolBar.add(control);
    }
    
    /**
     * Apply any changes in the viewer to the provided component
     * 
     */
    public void apply(NMC nmc)
    {
        
    }

    /**
     * Get the panel that is displayed when the viewer is expanded.
     * 
     * @return
     */
    abstract public JPanel getExpandedPanel();

    /**
     * Get the NetModComponent
     * 
     * @return
     */
    public NMC getNetModComponent()
    {
        apply(_nmc);

        return _nmc;
    }
    
    /**
     * Return whether this viewer is expanded
     * 
     * @return
     */
    public boolean isExpanded()
    {
        return _expanded;
    }
    
    /**
     * Refresh the display
     */
    public void refresh()
    {
        _updating = true;
        
        _viewerName.setText(_nmc.toString());
        
        reset(_nmc);
        
        _updating = false;
        
        SwingUtilities.updateComponentTreeUI(this);
    }
    
    /**
     * Refresh the parent display
     */
    public void refreshParent()
    {
        Container parent = getParent();
        while ( parent != null )
        {
            if ( parent instanceof NetModComponentViewer )
            {
                ((NetModComponentViewer) parent).refresh();
                break;
            }
            
            parent = parent.getParent();
        }
    }
    
    /**
     * Register the provided controls to automatically store their updates
     * as they are changed.
     * 
     * @param components
     */
    public void registerControls(Component... components)
    {
        for (Component c : components)
        {
            if ( c instanceof JTextField )
            {
                ((JTextField) c).addActionListener(_ccl);
                c.addFocusListener(_ccl);
            }
            else if (c instanceof JCheckBox || c instanceof JRadioButton )
                ((JToggleButton) c).addActionListener(_ccl);
            else if (c instanceof JComboBox )
                ((JComboBox) c).addItemListener(_ccl);
            else if (c instanceof JSlider )
                ((JSlider) c).addChangeListener(_ccl);
            else if (c instanceof JSpinner )
                ((JSpinner) c).addChangeListener(_ccl);
            else if (c instanceof NetModComboBox )
                ((NetModComboBox) c).addItemListener(_ccl);
            else if (c instanceof JComponent)
                registerControls(((JComponent) c).getComponents());
        }
    }
    
    /**
     * Update the viewer to reflect the provided component
     * 
     * @param nmc
     */
    public void reset(NMC nmc)
    {
        
    }
    
    /**
     * Set the expanded state of this viewer
     * 
     * @param expanded
     */
    public void setExpanded(boolean expanded)
    {
        //  Check if expanding is enabled
        _expanded = expanded;

        if (expanded)
        {
            _toggleDisplayButton.setToolTipText("Hide Viewer");
            _toggleDisplayButton.setIcon(Icons.DOWN.getIcon());

            //  Only construct the expanded panel when requested
            if (_expandedPanel == null)
            {
                _expandedPanel = getExpandedPanel();
                _expandedPanel.setBorder(_expandedBorder);
            }

            GUIUtility.addRow(this, GridBagConstraints.REMAINDER, _expandedPanel);
            validate();
            refresh();
        }
        else
        {
            _toggleDisplayButton.setToolTipText("Show Viewer");
            _toggleDisplayButton.setIcon(Icons.RIGHT.getIcon());

            if (_expandedPanel != null)
                remove(_expandedPanel);
        }
    }

    /**
     * Create a button that toggles the display between expanded states
     * 
     * @return
     */
    private JButton createToggleDisplayButton()
    {
        JButton button = GUIUtility.createButton(Icons.RIGHT.getIcon());
        button.setToolTipText("Show Viewer");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                // Depending on the tooltip currently shown by the button, hide
                // or display the waveform plot.
                String tooltip = _toggleDisplayButton.getToolTipText();
                boolean expanded = tooltip.startsWith("Hide");
                setExpanded(!expanded);

                SwingUtilities.updateComponentTreeUI(NetModComponentViewer.this);
            }
        });


        return button;
    }
    
    /**
     * Make the dialog this viewer is contained within resizeable
     * 
     */
    private void makeResizeable()
    {
        addHierarchyListener(new HierarchyListener()
        {
            public void hierarchyChanged(HierarchyEvent e)
            {
                Window window = SwingUtilities.getWindowAncestor(NetModComponentViewer.this);
                if (window instanceof Dialog)
                {
                    Dialog dialog = (Dialog) window;
                    if (!dialog.isResizable())
                    {
                        dialog.setResizable(true);
                    }
                }
            }
        });
    }
    
    /**
     * Create a button that will display the map layer on the map.
     * Add the button the provided group that only allows a single
     * button to be selected at a time.
     * 
     * @param group
     * @return
     */
    protected AbstractButton createDisplayOnMapButton(ButtonGroup group)
    {
        return createDisplayOnMapButton(_nmc, group);
    }

    /**
     * Create a button that will display the map layer on the map.
     * Add the button the provided group that only allows a single
     * button to be selected at a time.
     * 
     * @param group
     * @return
     */
    protected AbstractButton createDisplayOnMapButton(final NetModComponent nmc, ButtonGroup group)
    {
        AbstractButton button = GUIUtility.createToggleButton(Icons.MAP.getIcon());
        button.setToolTipText("Display on map");
        
        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                // Get the button selection
                AbstractButton button = (AbstractButton) event.getSource();

                //  Get the map layer
                Map map = NetMOD.getMap();
                if ( map == null )
                    return;
                
                Layer<?> layer = nmc.getMapLayer();
                
                //  Unselect button if no layer to draw
                if (layer == null)
                {
                    button.setSelected(false);
                    return;
                }

                //  Remove or add the layer
                if (button.isSelected())
                {
                    layer.setVisible(true);
                    if ( !map.contains(layer) )                   
                    	map.addLayer(layer);
                }
                else
                {
                	if ( map.contains(layer) )
                		map.remove(layer);
                }
                
                map.refresh();
                refresh();
            }
        });
        
        //  Add the button to the provided group
        if ( group != null )
            group.add(button);

        return button;
    }
    
    protected void registerControls(Collection<? extends JComponent> components)
    {
        registerControls(components.toArray(new JComponent[components.size()]));
    }
    
    /**
     * Replace the item in the combobox that has the same class
     * as the provided object and select it. 
     * 
     * @param comboBox
     * @param o
     */
    protected void setComboBoxSelection(JComboBox comboBox, Object o)
    {
        if ( o == null )
        {
            comboBox.setSelectedIndex(0);
            return;
        }
        
        DefaultComboBoxModel model = (DefaultComboBoxModel) comboBox.getModel();
        
        int N = model.getSize();
        for (int i=0; i<N; i++)
        {
            Object o2 = model.getElementAt(i);
            
            if ( o2.getClass() == o.getClass() )
            {
                if ( !o2.equals(o) )
                {
                    model.removeElementAt(i);
                    model.insertElementAt(o,  i);
                }
                
                model.setSelectedItem(o);
                
                return;
            }
        }
        
        comboBox.setSelectedIndex(0);
        return;
    }
}
