/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.NumericUtility;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.probability.rules.Criteria;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author bjmerch
 *
 */
public class NetworkDetectionMC extends NetworkDetection
{
    private static String _type = "Monte Carlo";
    static
    {
        NetworkDetectionPlugin.getPlugin().registerComponent(_type, NetworkDetectionMC.class);
    }

    private int _numberMonteCarlo = 500;
    private int _monteCarloSeed = -1;
    private StationDetectionMC _stationDetection;
    
    public NetworkDetectionMC(NetModComponent parent)
    {
        super(parent, _type);
        _stationDetection = new StationDetectionMC(parent);        
    }
    
    @Override
    public double computeDetectionProbability(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Time time, Magnitude magnitude,
            SignalAmplitude signal, NoiseAmplitude noise)
    {
        startIntrospection();
        recordIntrospection("Network Detection Probability of Moment (log): ", magnitude);
        
        //  Construct a random number generator
        PRNG prng = new PRNG(_monteCarloSeed);

        //  Construct the detection criteria
        Criteria criteria = getDetectionCriteria();

        //  Determine the phases to detect
        Set<Phase> phases = criteria.getPhases();
        
        //  Get the set of stations
        Set<Station> stations = receivers.getSelectedStations();

        //  Allocate storage for each of the network averaged probability
        TreeMap<Phase, ObjectDoubleMap<String>> averageNetworkProbability = new TreeMap<Phase, ObjectDoubleMap<String>>();
        for (Phase phase : phases)
            averageNetworkProbability.put(phase,  new ObjectDoubleOpenHashMap<String>(stations.size(), 1.0f));

        //  Allocate storage for each of the monte carlo iterations
        TreeMap<Phase, ObjectDoubleMap<String>>[] networkProbabilities = new TreeMap[_numberMonteCarlo];
        for (int i=0; i<_numberMonteCarlo; i++)
        {
            //  Initialize the map to hold all of the probabilities
            networkProbabilities[i] = new TreeMap<Phase, ObjectDoubleMap<String>>();
            for (Phase phase : phases)
                networkProbabilities[i].put(phase,  new ObjectDoubleOpenHashMap<String>(stations.size(), 1.0f));
        }
        
        //  Initialize buffers for results
        int Nfreq = _stationDetection.getFrequencies().length;
        
        //  Iterate over each station and phase
        startIntrospection();
        recordIntrospection("Stations");
        
        for (Station station : stations)
        {
            startIntrospection();
            recordIntrospection(station);

            Distance distance = Distance.computeDistance(epicenter, station.getLocation());
            String group = station.getGroup();

            for (Phase phase : phases)
            {
                startIntrospection();
                recordIntrospection("Phase ", phase);

                //  Compute the station detection probability
                double[] probabilities = _stationDetection.computeDetectionProbability(sources, paths, receivers, epicenter, station, distance, time, magnitude, phase, signal, noise,
                        _numberMonteCarlo, prng);

                //  Because this is a MC simulation, only definite detections count
                for (int i = 0; i < _numberMonteCarlo; i++)
                    if (probabilities[i] < 1.0)
                        probabilities[i] = 0.0;

                double avg_probability = NumericUtility.mean(probabilities);
                
                //  Check whether there is a group defined with a greater probability
                if ( avg_probability > averageNetworkProbability.get(phase).get(group) )
                {
                    averageNetworkProbability.get(phase).put(group, avg_probability);
                    
                    //  Store the result for this station/phase
                    for (int i = 0; i < _numberMonteCarlo; i++)
                        networkProbabilities[i].get(phase).put(group, probabilities[i]);
                }
                else
                    recordIntrospection("Retaining prior probability for group: ", group);

                recordIntrospection("Probabilitities: ", probabilities);
                stopIntrospection();
                
                //  Check introspection because this performs an auto-box
                if ( isIntrospection() )
                    recordIntrospection(phase, ": ", avg_probability);
            }
            
            stopIntrospection();
        }
        stopIntrospection();
        
        //  Count the number of network detections
        startIntrospection();
        recordIntrospection("Detection Criteria");
        int Ndetections = 0;
        for (int i=0; i<_numberMonteCarlo; i++)
        {
            //  Use the detection criteria to compute the overall probability
            double probability = criteria.getProbability(networkProbabilities[i]);
            if ( probability == 1.0 )
                Ndetections++;
        }
        
        //  Compute the final probability
        double probability = ((double) Ndetections) / _numberMonteCarlo;
        recordIntrospection("Iterations: ", _numberMonteCarlo);
        recordIntrospection("Detections: ", Ndetections);
        recordIntrospection("Probability: ", probability);
        
        stopIntrospection();
        stopIntrospection();

        return probability;
    }
    
    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        if (children.size() == 0)
        {
            children.add(getDetectionCriteria());
            children.add(getStationDetection());
        }

        return children;
    }

    /**
     * @return the monteCarloSeed
     */
    public int getMonteCarloSeed()
    {
        return _monteCarloSeed;
    }

    /**
     * @return the numberMonteCarlo
     */
    public int getNumberMonteCarlo()
    {
        return _numberMonteCarlo;
    }

    /**
     * @return the stationDetection
     */
    public StationDetectionMC getStationDetection()
    {
        return _stationDetection;
    }

    @Override
    public NetworkDetectionMCViewer getViewer()
    {
        return new NetworkDetectionMCViewer(this);
    }

    /**
     * @param monteCarloSeed the monteCarloSeed to set
     */
    public void setMonteCarloSeed(int monteCarloSeed)
    {
        _monteCarloSeed = monteCarloSeed;
    }

    /**
     * @param numberMonteCarlo the numberMonteCarlo to set
     */
    public void setNumberMonteCarlo(int numberMonteCarlo)
    {
        _numberMonteCarlo = numberMonteCarlo;
    }

    /**
     * @param stationDetection the stationDetection to set
     */
    public void setStationDetection(StationDetection stationDetection)
    {
        if ( stationDetection instanceof StationDetectionMC )
            _stationDetection = (StationDetectionMC) stationDetection;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setMonteCarloSeed(parameters.get(NetSimParameters.monteCarloSeed));
        setNumberMonteCarlo(parameters.get(NetSimParameters.numMonteCarloIter));
        
        getStationDetection().load(parameters);
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);

        parameters.set(NetSimParameters.monteCarloSeed, getMonteCarloSeed());
        parameters.set(NetSimParameters.numMonteCarloIter, getNumberMonteCarlo());
        
        getStationDetection().save(parameters, files, reset);
    }
}
