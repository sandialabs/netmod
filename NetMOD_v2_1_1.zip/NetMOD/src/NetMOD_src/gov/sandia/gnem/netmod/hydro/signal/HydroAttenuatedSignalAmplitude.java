/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.hydro.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.signal.RegionalBodywave;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * Extend signal amplitudes for hydro acoustics that require
 * that all signal amplitudes are computed regionally.
 * Compare the attenuation along the major and minor paths
 * and use the path with the least attenuation.
 * 
 * @author bjmerch
 *
 */
public class HydroAttenuatedSignalAmplitude extends RegionalBodywave
{
    public static final String TYPE = "Attenuated";
    static
    {
        //  Don't register this module as it is not for use.
        //HydroSignalAmplitudePlugin.getPlugin().registerComponent(TYPE, HydroAttenuatedSignalAmplitude.class);
    }

    protected HydroAttenuatedSignalAmplitude(NetModComponent parent, String type, String name)
    {
        super(parent, type, name);
    }
    
    public HydroAttenuatedSignalAmplitude(NetModComponent parent)
    {
        super(parent, TYPE, "Attenuated Hydro ");
    }
    
    /**
     * Hydroacoustic simulations do not have a media constant
     * 
     * @return
     */
    @Override
    protected double computeLogMediaConstant(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        double mediaConstant = 0;

        recordIntrospection("Media Constant (log10 Amplitude): ", mediaConstant);
        recordIntrospection("No material correction for Hydroacoustic.");
        
        stopIntrospection();
        
        return mediaConstant;
    }

    @Override
    public Spectra computeAttenuationSpreading(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        //  Check the major and minor attenuation paths
        Spectra attenuationMinor = getPathAttenuation(sources, paths, epicenter, station, distance, phase, frequency, true);
        Spectra attenuationMajor = getPathAttenuation(sources, paths, epicenter, station, distance, phase, frequency, false);
        
        Spectra attenuation = null;
        if ( attenuationMinor.getMeanLog() > attenuationMajor.getMeanLog() )
        {
            attenuation = attenuationMinor.toMonteCarlo(prng, N);
            recordIntrospection("Path Attenuation (log10): ", attenuation);
            recordIntrospection("Minor Great-Circle Path open");
        }
        else
        {
            attenuation = attenuationMajor.toMonteCarlo(prng, N);
            recordIntrospection("Path Attenuation (log10): ", attenuation);
            
            if ( attenuation.getMeanLog() > -999 )
                recordIntrospection("Major Great-Circle Path open");
        }
        
        stopIntrospection();
        
        return attenuation;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new HydroAttenuatedSignalAmplitudeViewer(this);
    }
}
