/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

/**
 * @author bjmerch
 *
 */
public class NumericUtility
{
	public static Double[] toDoubleArray(double[] values)
	{
		int N = values.length;
		Double[] values1 = new Double[N];
		
		for (int i=0; i<N; i++)
			values1[i] = values[i];
		
		return values1;
	}

	/**
	 * Add a constant value to the provided array of values
	 * 
	 * @param values
	 * @param value
	 */
	public static double[] add(double[] values, double value)
    {
		return add(values, 0, values.length, value);
    }
	
	/**
	 * Add a constant value to the provided array of values
	 * 
	 * @param values
	 * @param start
	 * @param end
	 * @param value
	 */
	public static double[] add(double[] values, int start, int end, double value)
    {
		if ( value == 0 )
			return values;
		
        int N = values.length;

        if (N == 0)
            return values;

        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);
        
		for (int i=start; i<end; i++)
			values[i] += value;
		
		return values;
    }
	
    /**
     * Check whether the two arrays of double values are equal to within a fraction expressed as epsilon such
     * that each entry satisfies the following condition:
     * 
     *     values1[i] * ( 1 - epsilon ) <= values2[i] <= values1[i] * ( 1 + epsilon )
     * 
     * @param values1
     * @param values2
     * @param epsilon
     * @return
     */
    public static final boolean equals(double[] values1, double[] values2, double epsilon)
    {
        int N = values1.length;
        if ( values1.length != N )
            return false;
        
        for (int i=0; i<N; i++)
            if (!equals(values1[i], values2[i], epsilon))
            {
                System.out.println("Array element " + i + " not equal: " + values1[i] + ", " + values2[i] + ", " + epsilon);
                return false;
            }
        
        return true;
    }
    
    /**
     * Check whether the two  double values are equal to within a fraction expressed as epsilon such
     * that each entry satisfies the following condition:
     * 
     *     values1 * ( 1 - epsilon ) <= values2 <= values1 * ( 1 + epsilon )
     *     
     * @param value1
     * @param value2
     * @param epsilon
     * @return
     */
    public static final boolean equals(double value1, double value2, double epsilon)
    {
    	return equalsAbsolute(value1, value2, Math.abs(value2 * value1));
    }
    
    /**
     * Check whether the two  double values are equal to within an absolute amount such
     * that each entry satisfies the following condition:
     * 
     *     values1 - delta <= values2 <= values1 + delta
     *     
     * @param value1
     * @param value2
     * @param delta
     * @return
     */
    public static final boolean equalsAbsolute(double value1, double value2, double delta)
    {
        double min = value1 - delta;
        double max = value1 + delta;
        
        return value2 >= min && value2 <= max;
    }
    
    /**
     * Find the index of the largest value within the array
     * that is less than or equal to the provided value.
     * Assumes that the values are in sorted order.
     * 
     * @param values
     * @param value
     * @return
     */
    public static final int findIndexAscending(double[] values, double value)
    {
        int start = 0;
        int end = values.length - 1;
        
        //  Check the extremes
        if ( values[start] >= value )
            return start;
        
        if ( values[end] <= value )
            return end;
        
        int mid = (start + end) / 2;

        while (start != mid)
        {
            //  Perform a binary search
            if (values[mid] > value)
            {
                end = mid;
                mid = (start + end) / 2;
            }
            else
            {
                start = mid;
                mid = (start + end) / 2;
            }
        }

        if (values[end] <= value)
            return end;

        return mid;
    }

    /**
     * Check if the array contains a constant value
     * 
     * @param array
     * @return
     */
    public static boolean isConstant(double[] array)
    {
        int N = array.length;
        if (N == 0)
            return true;
        
        double value = array[0];
        
        for (int i=1; i<N; i++)
            if ( array[i] != value )
                return false;
        
        return true;
    }

    /**
     * Generate a sequence of N values linearly spaced between d1 and d2.
     * 
     * @param d1
     * @param d2
     * @param N
     * @return
     */
    public static double[] linearspace(double d1, double d2, int N)
    {
        int i;
        double[] data = new double[N];

        double d = (d2 - d1) / (N - 1);

        data[0] = d1;
        for (i = 1; i < N; i++)
            data[i] = d * i + d1;
        data[N - 1] = d2;

        return data;
    }

    /**
     * Generate a sequence of N values logarithamically spaced between d1 and
     * d2.
     * 
     * @param d1
     * @param d2
     * @param N
     * @return
     */
    public static double[] logspace(double d1, double d2, int N)
    {
        int i;
        double[] data = linearspace(StrictMath.log10(d1), StrictMath.log10(d2), N);

        for (i = 0; i < N; i++)
            data[i] = StrictMath.pow(10, data[i]);

        return data;
    }

    /**
     * Determine the maximum x value
     * 
     * @param x
     * @return
     */
    public static final double max(double[] x)
    {
        return max(x, 0, x.length);
    }

    /**
     * Determine the maximum x value
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final double max(double[] x, int start, int end)
    {
        int N = x.length;
        if (N == 0)
            return 0;

        return x[maxIndex(x, start, end)];
    }

    /**
     * Determine the maximum x value
     * 
     * @param x
     * @return
     */
    public static final int max(int[] x)
    {
        return max(x, 0, x.length);
    }

    /**
     * Determine the maximum x value
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int max(int[] x, int start, int end)
    {
        int N = x.length;
        if (N == 0)
            return 0;

        return x[maxIndex(x, start, end)];
    }

    /**
     * Determine the index of the maximum x value
     * 
     * @param x
     * @return
     */
    public static final int maxIndex(double[] x)
    {
        return maxIndex(x, 0, x.length);
    }

    /**
     * Determine the index of the maximum x value
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int maxIndex(double[] x, int start, int end)
    {
        int N = x.length;

        if (N == 0)
            return -1;

        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        double max = -Double.MAX_VALUE;
        int max_i = start;

        for (int i = start; i < end; i++)
        {
            double value = x[i];
            
            if ( Double.isNaN(value) || Double.isInfinite(value) )
                continue;
            
            if (value > max)
            {
                max = value;
                max_i = i;
            }
        }

        return max_i;
    }

    /**
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int maxIndex(int[] x, int start, int end)
    {
        int N = x.length;

        if (N == 0)
            return -1;

        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        int max_i = start;
        int max = x[max_i];

        for (int i = start; i < end; i++)
        {
            int value = x[i];
            if (value > max)
            {
                max = value;
                max_i = i;
            }
        }

        return max_i;
    }

    /**
     * Compute the mean of the array over the provided index range.
     * 
     * @param array
     * @return
     */
    public static final double mean(double[] array)
    {
        return mean(array, 0, array.length);
    }

    /**
     * Compute the mean of the array.
     * 
     * @param array
     * @param start
     * @param end
     * @return
     */
    public static final double mean(double[] array, int start, int end)
    {
        int N = array.length;

        // Verify that both i1 and i2 are within the array size
        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        return sum(array, start, end) / (end - start);
    }

    /**
     * Compute the average value (mean) of the array
     * 
     * @param array
     * @return
     */
    public static final double mean(int[] array)
    {
        return mean(array, 0, array.length);
    }

    /**
     * Compute the average value (mean) of the array over the provided index
     * range.
     * 
     * @param array
     * @param start
     * @param end
     * @return
     */
    public static final double mean(int[] array, int start, int end)
    {
        int N = array.length;

        // Verify that both i1 and i2 are within the array size
        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        return ((double) sum(array, start, end)) / (end - start);
    }

    /**
     * Determine the minimum x value.
     */
    public static final double min(double[] x)
    {
        return min(x, 0, x.length);
    }

    /**
     * Determine the minimum x value
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final double min(double[] x, int start, int end)
    {
        int N = x.length;
        if (N == 0)
            return -1;

        return x[minIndex(x, start, end)];
    }

    /**
     * Determine the minimum x value
     * 
     * @param x
     * @return
     */
    public static final int min(int[] x)
    {
        return min(x, 0, x.length);
    }

    /**
     * Determine the minimum x value
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int min(int[] x, int start, int end)
    {
        int N = x.length;
        if (N == 0)
            return -1;

        return x[minIndex(x, start, end)];
    }

    /**
     * Determine the index of the maximum x value
     * 
     * @param x
     * @return
     */
    public static final int minIndex(double[] x)
    {
        return minIndex(x, 0, x.length);
    }

    /**
     * Determine the index of the minimum x value.
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int minIndex(double[] x, int start, int end)
    {
        int N = x.length;

        if (N == 0)
            return -1;

        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        int min_i = start;
        double min = Double.MAX_VALUE;

        for (int i = start; i < end; i++)
        {
            double value = x[i];
            
            if ( Double.isNaN(value) || Double.isInfinite(value) )
                continue;
            
            if (value < min)
            {
                min = value;
                min_i = i;
            }
        }

        return min_i;
    }

    /**
     * Determine the index of the minimum x value.
     * 
     * @param x
     * @param start
     * @param end
     * @return
     */
    public static final int minIndex(int[] x, int start, int end)
    {
        int N = x.length;

        if (N == 0)
            return -1;

        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        int min_i = start;
        int min = x[min_i];

        for (int i = start; i < end; i++)
        {
            int value = x[i];
            if (value < min)
            {
                min = value;
                min_i = i;
            }
        }

        return min_i;
    }

    /**
     * Multiply each element of the array by the provided value
     * 
     * @param values
     * @param value
     */
    public static void multiply(double[] values, double value)
    {
        int N = values.length;

        for (int i = 0; i < N; i++)
            values[i] *= value;
    }

    /**
     * Finds the sign of a double value.
     * @param value value for which to retrieve the sign
     * @return 1.0 if value is >= 0.0 and -1.0 otherwise
     */
    public static double sign(double value)
    {
        if (value >= 0.0)
            return 1.0;

        return -1.0;
    }

    /**
     * Compute the standard deviation of the provided values
     * 
     * @param values
     * @return
     */
    public static double std(double[] values)
    {
        return std(values, mean(values));
    }

    /**
     * Compute the standard deviation of the provided values
     * using the previously computed mean
     * 
     * @param values
     * @return
     */
    public static double std(double[] values, double mean)
    {
        double var = 0;

        for (double value : values)
        {
            double tmp = (value - mean);
            var += tmp * tmp;
        }
        var = var / values.length;

        return Math.sqrt(var);
    }

    /**
     * Sum the elements of the array spanning the range i1 to i2, exclusively.
     * 
     * @param array
     * @return the sum of the array elements
     */
    public static final double sum(double[] array)
    {
        return sum(array, 0, array.length);
    }

    /**
     * Sum the elements of the array spanning the range i1 to i2, exclusively.
     * 
     * @param array
     * @param start
     * @param end
     * @return the sum of the array elements
     */
    public static final double sum(double[] array, int start, int end)
    {
        int i;
        int N = array.length;

        // Verify that both i1 and i2 are within the array size
        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        // Sum the array elements
        double sum = 0;
        for (i = start; i < end; i++)
            sum += array[i];

        return sum;
    }

    /**
     * Sum the elements of the array spanning the range i1 to i2, exclusively.
     * 
     * @param array
     * @param start
     * @param end
     * @return the sum of the array elements
     */
    public static final long sum(int[] array, int start, int end)
    {
        int i;
        int N = array.length;

        // Verify that both i1 and i2 are within the array size
        start = getMinIndex(start, end, N);
        end = getMaxIndex(start, end, N);

        // Sum the array elements
        long sum = 0;
        for (i = start; i < end; i++)
            sum += array[i];

        return sum;
    }

    /**
     * Get the maximum index to an array
     * 
     * @param i1
     *            First index
     * @param i2
     *            Second index
     * @param N
     *            Number of elements in the array
     * @return
     */
    private static final int getMaxIndex(int i1, int i2, int N)
    {
        if (i2 > N)
            i2 = N;
        if (i2 < 0)
            i2 = 0;

        return i2;
    }

    /**
     * Get the minimum index to an array
     * 
     * @param i1
     *            First index
     * @param i2
     *            Second index
     * @param N
     *            Number of elements in the array
     * @return
     */
    private static final int getMinIndex(int i1, int i2, int N)
    {
        if (i1 >= N)
            i1 = N - 1;
        if (i1 < 0)
            i1 = 0;

        return i1;
    }

	/**
	 * Reverse the order of the provided array
	 * 
	 * @param array
	 */
	public static void reverse(double[] array)
    {
		int N = array.length;
		int N_2 = N/2;
		
		for (int i=0; i<N_2; i++)
		{
			double tmp = array[N-1-i];
			array[N-1-i] = array[i];
			array[i] = tmp;
		}
    }
}
