/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.plugin;

import gov.sandia.gnem.netmod.gui.GUIUtility;

import java.lang.reflect.Constructor;
import java.util.*;

/**
 * Abtract implementation of the Plugin architecture to use
 * for various component of a simulation.
 * <p>
 * This abstract class may be extended for the specific
 * plugin implementation of the type desired.  I.e.
 * SourcePlugin, PathPlugin, ReceiverPlugin 
 * 
 *   public class SourcePlugin extends Plugin<Source>
 *   {
 *     private static SourcePlugin _plugin = new SourcePlugin();
 *   
 *     public static SourcePlugin getPlugin()
 *     {
 *        return _plugin;
 *     }
 *   }
 * <p>
 * All NetModComponents that are registered with this Plugin framework
 * must have a null constructor that does not take any arguments.
 * <p>
 * Each NetModComponent that wishes to register itself with the desired plugin
 * should include something similar to the following:
 * 
 *      class EarthquakeSource implements Source
 *      {
 *        private static String _TYPE = "Earthquake";
 *   
 *         //  Register the plugin
 *         static
 *         {
 *           SourcePlugin.getPlugin().registerComponent(_TYPE, ExplosionSource.class);
 *         }
 *         
 *         ...
 * 
 * @author bjmerch
 *
 */
public abstract class Plugin<C extends NetModComponent>
{
    private static class CaseInsensitiveString implements Comparable<CaseInsensitiveString>
    {
        private String _string;
        private String _upperString;
        
        public CaseInsensitiveString(String string)
        {
            _string = string;
            _upperString = string.toUpperCase();
        }
        
        @Override
        public int hashCode()
        {
            return _upperString.hashCode();
        }
        
        @Override
        public boolean equals(Object o)
        {
        	if ( o == null )
        		return false;
        	
            if ( !(o instanceof CaseInsensitiveString) )
                return false;
            
            return _upperString.equals(((CaseInsensitiveString) o)._upperString);
        }

        @Override
        public int compareTo(CaseInsensitiveString value)
        {
            return _upperString.compareTo(value._upperString);
        }
        
        @Override
        public String toString()
        {
            return _upperString;
        }
        
        public String toOriginalString()
        {
            return _string;
        }
    }
    
    //  Map storing the plugin classes
    private Map<CaseInsensitiveString, Class<? extends C>> _map = new LinkedHashMap<CaseInsensitiveString, Class<? extends C>>();
    
    /**
     * Create a new instance of a plugin registery.
     * 
     */
    protected Plugin()
    {
    }

    /**
     * Get an instance of the NetModComponent
     * that is assigned to the provided type.
     * Returns null if there is no registered NetModComponent.
     * 
     * @param type
     * @return
     */
    public C getComponent(NetModComponent parent, String type)
    {
        return getComponent(parent, type, false);
    }

    /**
     * Get an instance of the NetModComponent
     * that is assigned to the provided type.
     * Returns null if there is no registered NetModComponent.
     * 
     * @param type
     * @param def  Return a default if none exists
     * @return
     */
    public C getComponent(NetModComponent parent, String type, boolean def)
    {
        if ( type == null )
        {
            System.out.println(getPluginName() + " Warning:  Cannot get plugin for null type.");
            return null;
        }
        
        Class<? extends C> c = _map.get(new CaseInsensitiveString(type));

        if (c == null)
        {
            if (def)
                return getComponent(parent, getDefaultType(), false);
            else
            {
                System.out.println(getPluginName() + " Warning:  No plugin class available for: '" + type + "'");
                return null;       
            }
        }

        //  Construct a blank component
        try
        {
            // Get the constructor that takes a NetModComponent
            Constructor<? extends C> constructor = c.getConstructor(NetModComponent.class);
            return constructor.newInstance(parent);
        }
        catch (Exception e)
        {
            GUIUtility.showExceptionDialog(null, "Error constructing a NetModComponent: " + c.getName() + " of type: " + type, e.getMessage(), e);
        }

        return null;
    }
    
    private String getPluginName()
    {
        return getClass().getName();
    }

    /**
     * Return the number of components
     * 
     * @return
     */
    public int getComponentCount()
    {
        return _map.size();
    }

    /**
     * Get the appropriate component for the provided object.
     * Each of the components is queries for whether it is valid.
     * Return the default component if there is no match.
     * 
     * @param o
     * @return
     */
    public C getComponentFor(NetModComponent parent, Object o)
    {
        return getComponentFor(parent, o, true);
    }

    /**
     * Get the appropriate component for the provided object.
     * Each of the components is queries for whether it is valid.
     * 
     * @param o
     * @param def if true, return the default component if there is no match.  Otherwise, return null.
     * @return
     */
    public C getComponentFor(NetModComponent parent, Object o, boolean def)
    {
        Set<C> components = getComponents(parent);

        //  Find the component that matches this object
        for (C component : components)
        {
            if ( component == null )
                continue;
            
            if ( component.isFor(o) )
                return component;
        }
        
        //  Find the default component
        if ( def )
            for (C component : components)
                if ( component != null )
                    return component;
        
        return null;
    }

    /**
     * Get the map of registered components
     * 
     * @return
     */
    public Map<String, C> getComponentMap(NetModComponent parent)
    {
        Map<String, C> components = new TreeMap<String, C>();

        for (String type : getTypes())
            components.put(type, getComponent(parent, type));

        return components;
    }

    /**
     * Get the set of registered components
     * 
     * @return
     */
    public Set<C> getComponents(NetModComponent parent)
    {
        Set<C> components = new TreeSet<C>();

        for (String type : getTypes())
        {
            C c = getComponent(parent, type);
            if ( c != null )
                components.add(c);
        }

        return components;
    }

    /**
     * @return
     */
    public C[] getComponentsArray(NetModComponent parent)
    {
        return (C[]) getComponents(parent).toArray();
    }
    
    /**
     * Get the default (first) component defined
     * within this plugin
     * 
     * @return
     */
    public C getDefaultComponent(NetModComponent parent)
    {
        return getComponent(parent, getDefaultType());
    }

    /**
     * Get the default (first) type defined
     * within this plugin
     * 
     * @return
     */
    public String getDefaultType()
    {
        for (String type : getTypes())
            return type;
        
        return "";
    }

    /**
     * Get the set of registered component types
     * 
     * @return
     */
    public Set<String> getTypes()
    {
        Set<String> set = new LinkedHashSet<String>();
        for (CaseInsensitiveString ciString : getPluginRegistry().keySet())
            set.add(ciString.toOriginalString());
        
        return set;
    }
    
    /**
     * Get an array of the available types
     * 
     * @return
     */
    public String[] getTypesArray()
    {
        return getTypes().toArray(new String[getComponentCount()]);
    }
    
    /**
     * Register the provided Class definition and assign it
     * the provided string type.
     * 
     * @param type
     * @param c
     */
    public void registerComponent(String type, Class<? extends C> c)
    {
        registerComponent(type, c, false);
    }

    /**
     * Register the provided Class definition and assign it
     * the provided string type.  Indicate if the registrated
     * item is the default
     * 
     * @param type
     * @param c
     * @param def
     */
    public void registerComponent(String type, Class<? extends C> c, boolean def)
    {
        try
        {
            //  Get the plugin map
            Map<CaseInsensitiveString, Class<? extends C>> map = getPluginRegistry();
            
            Class<? extends C> previous = map.put(new CaseInsensitiveString(type), c);
            
            //  Check for a previous type assignment
            if (previous != null)
                System.out.println(getPluginName() + " Warning: " + type + " is now associated with " + c.getName() + ", replacing " + previous.getClass().getName());
            
            //  Make the definition the default (first), if requested
            if ( def )
            {
                LinkedHashMap<CaseInsensitiveString, Class<? extends C>> newMap = new LinkedHashMap<CaseInsensitiveString, Class<? extends C>>();
                newMap.put(new CaseInsensitiveString(type), c);
                
                newMap.putAll(map);
                _map = newMap;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            GUIUtility.showExceptionDialog(null, "Error registering a NetModComponent: " + c.getName(), e.getMessage(), e);
        }
    }

    /**
     * Get the map that stores the register plugins.
     * 
     * @return
     */
    protected Map<CaseInsensitiveString, Class<? extends C>> getPluginRegistry()
    {
        return _map;
    }
}
