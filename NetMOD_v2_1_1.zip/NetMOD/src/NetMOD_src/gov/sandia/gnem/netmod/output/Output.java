/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.output;

import gov.sandia.gnem.netmod.gui.ColorModel;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.ParameterDef;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.NumericUtility;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.simulation.MagnitudeType;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

/**
 * Hierarchical container for organizing the output components within a
 * simulation.
 * 
 * @author bjmerch
 *
 */
public class Output extends AbstractNetModComponent
{
	/**
	 * Enum to control whether the color model is scaled linear or log to the
	 * chosen value
	 * 
	 * @author bjmerch
	 *
	 */
	public static enum COLOR_SCALING
	{
		LINEAR, LOG
	}

	public static final String simulKey = ".simul_key";
	public static final String simulSta = ".simul_sta";

	public static final String simulGrid = ".simul_grid";;

	/*
	 * SimulGrid
	 */
	public static final String[] SIMULGRID_LABELS = new String[] { "Latitude", "Longitude", "Magnitude", "Probability", "Fractional Location", "Semi-Major 1",
	        "Semi-Minor 1", "Strike 1", "Depth 1", "Semi-Major 2", "Semi-Minor 2", "Strike 2", "Depth 2", };

	public static final int SIMULGRID_LON = 0;
	public static final int SIMULGRID_LAT = 1;
	public static final int SIMULGRID_SIZE = 2;
	public static final int SIMULGRID_NETPROB = 3;
	public static final int SIMULGRID_FRACLOC = 4;
	public static final int SIMULGRID_SMAJ1 = 5;
	public static final int SIMULGRID_SMIN1 = 6;
	public static final int SIMULGRID_STRK1 = 7;
	public static final int SIMULGRID_DEPTH1 = 8;
	public static final int SIMULGRID_SMAJ2 = 9;
	public static final int SIMULGRID_SMIN2 = 10;
	public static final int SIMULGRID_STRK2 = 11;
	public static final int SIMULGRID_DEPTH2 = 12;
	public static final int SIMULGRID_COUNT = 13;
	/*
	 * SimulSta
	 */
	public static final int SIMULSTA_STA = 0;
	public static final int SIMULSTA_TECH = 1;
	public static final int SIMULSTA_LON = 2;
	public static final int SIMULSTA_LAT = 3;
	public static final int SIMULSTA_RELY = 4;
	public static final int SIMULSTA_NCHAN = 5;
	public static final int SIMULSTA_TYPE = 6;
	public static final int SIMULSTA_COUNT = 7;

	/*
	 * SimulKey
	 */
	public static final String SIMULKEY_SIMUL_BASELINE = "Simul-Baseline";

	public static final String SIMULKEY_SIMUL_TECHNOLOGY = "Simul-Technology";
	public static final String SIMULKEY_RUN_TYPE = "Run-Type";
	public static final String SIMULKEY_SUB_TYPE = "Sub-Type";
	public static final String SIMULKEY_FREQ_SAMPLING = "Freq-Sampling";
	public static final String SIMULKEY_FREQ_TYPE = "Freq-Type";
	public static final String SIMULKEY_SIGNAL_AMPLITUDE = "Signal-Amplitude";
	public static final String SIMULKEY_NOISE_AMPLITUDE = "Noise-Amplitude";
	public static final String SIMULKEY_EDC = "Event-Detection-Criteria";
	public static final String SIMULKEY_WIND_MODE = "Wind-Mode";

	public static final String SIMULKEY_WIND_DAY_OF_YEAR = "Wind-Day-Of-Year";
	public static final String SIMULKEY_WIND_TIME_OF_DAY = "Wind-Time-Of-Day";
	public static final String SIMULKEY_SIZE_TYPE = "Size-Type";
	public static final String SIMULKEY_EVENT_SIZE = "Event-Size";
	public static final String SIMULKEY_MIN_EVENT_SIZE = "Min-Event-Size";
	public static final String SIMULKEY_MAX_EVENT_SIZE = "Max-Event-Size";
	public static final String SIMULKEY_CONF = "conf";
	public static final String SIMULKEY_NUM_MC_ITER = "Num-MonteCarlo-Iter";
	public static final String SIMULKEY_EPI_MODEL = "Epi-Model";
	public static final String SIMULKEY_EPIGRID_MINLAT = "EpiGrid-MinLat";
	public static final String SIMULKEY_EPIGRID_MAXLAT = "EpiGrid-MaxLat";
	public static final String SIMULKEY_EPIGRID_MINLON = "EpiGrid-MinLon";
	public static final String SIMULKEY_EPIGRID_MAXLON = "EpiGrid-MaxLon";
	public static final String SIMULKEY_EPIGRID_DELLAT = "EpiGrid-DelLat";
	public static final String SIMULKEY_EPIGRID_DELLON = "EpiGrid-DelLon";
	public static final String SIMULKEY_EPIGRID_DEPTH = "EpiGrid-Depth";
	public static final String SIMULKEY_MIN_EPI_SIZE = "Min-Epi-Size";
	public static final String SIMULKEY_MAX_EPI_SIZE = "Max-Epi-Size";
	public static final String SIMULKEY_NET = "net";
	private String _outputFile = "";
	private double[][] _simulGrid = null;
	private int _simulGridContourIndex = -1;
	private double[] _simulGridContourLevels = null;
	private int _simulGridDisplayIndex = -2;
	private double _simulGridDisplayMin = 0;
	private double _simulGridDisplayMax = 1;
	private ColorModel _simulGridDisplayColorModel = ColorModel.JET;
	private COLOR_SCALING _colorScaling = null;
	private double _simulGridDisplayTransparency = 0.75;
	private List<String[]> _simulSta = null;
	private LinkedHashMap<String, String> _simulKey = null;

	/*
	 * Cached viewer objects
	 */
	transient private OutputViewer _viewer;
	private boolean[] _outputSet;
	private int[] _time;
	private int[] _iterations;

	public Output(NetModComponent parent)
	{
		super(parent);
		setName("Output");
	}

	public Output(NetModComponent parent, int N)
	{
		super(parent);
		setName("Output");
		_outputSet = new boolean[N];
		_time = new int[N];
		_iterations = new int[N];
		_simulGrid = new double[SIMULGRID_COUNT][N];
		for (int i = 0; i < SIMULGRID_COUNT; i++)
			Arrays.fill(_simulGrid[i], -1);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		_simulGrid = null;
		_simulSta = null;
		_simulKey = null;
	}

	@Override
	public boolean equals(Object o)
	{
    	if ( o == null )
    		return false;
    	
		if (!(o instanceof Output))
			return false;

		Output output = (Output) o;
		int N;

		// Verify SimulSta
		N = getNumberStations();
		if (getNumberStations() != N)
		{
			//System.out.println("SIMULSTA count not equal '" + N + "', '" + output.getNumberStations() + "'");
			return false;
		}

		for (int i = 0; i < N; i++)
			for (int j = 0; j < SIMULSTA_COUNT; j++)
				if (!getStationValue(i, j).equalsIgnoreCase(output.getStationValue(i, j)))
				{
					//System.out.println("SIMULSTA not equal '" + getStationValue(i, j) + "', '" + output.getStationValue(i, j) + "'");
					return false;
				}

		// Verify SimulKey
		for (String key : getSimulKeyKeys())
			if (!getSimulKeyValue(key).equalsIgnoreCase(output.getSimulKeyValue(key)))
			{
				//System.out.println("SIMULKEY not equal " + key + " = '" + getSimulKeyValue(key) + "', '" + output.getSimulKeyValue(key) + "'");
				return false;
			}

		// Verify SimulGrid
		N = getNumberEpicenters();
		if (output.getNumberEpicenters() != N)
		{
			//System.out.println("SIMULGRID count not equal '" + N + "', '" + output.getNumberEpicenters() + "'");
			return false;
		}

		for (int i = 0; i < N; i++)
			for (int j = 0; j < SIMULGRID_COUNT; j++)
			{
				if (!NumericUtility.equalsAbsolute(getEpicenterValue(i, j), output.getEpicenterValue(i, j), 0.005) )
				{
					//System.out.println("SIMULGRID not equal '" + getEpicenterValue(i, j) + "', '" + output.getEpicenterValue(i, j) + "'");
					return false;
				}
			}

		return true;
	}
	
	/**
	 * Print output
	 * 
	 * @return
	 */
	public String printString()
	{
		StringBuffer buf = new StringBuffer();
		
		//  Print out station details
		buf.append("Station Parameters:\n");
		int Nsta = getNumberStations();
		for (int i = 0; i < Nsta; i++)
		{
			for (int j = 0; j < SIMULSTA_COUNT; j++)
				buf.append("\t").append(getStationValue(i,j));
			
			buf.append("\n");
		}

		// Print Simulkey details
		buf.append("Simulation Parameters:\n");
		for (String key : getSimulKeyKeys())
			buf.append("\t").append(key).append("=").append(getSimulKeyValue(key));

		// Print Output results
		buf.append("Output Results:\n");
		int Nepi = getNumberEpicenters();
		for (int i = 0; i < Nepi; i++)
		{
			for (int j = 0; j < SIMULGRID_COUNT; j++)
				buf.append("\t").append(getEpicenterValue(i,j));
			buf.append("\n");
		}
		
		return buf.toString();
	}

	public String generateOutputName(NetSimParameters parameters)
	{
		String outputFilename = Property.OUTPUT_NAME.getValue();

		// If output name not defined, use the title
		if (outputFilename.isEmpty())
			outputFilename = getName().trim();

		// Scan the parameters for key matches
		for (ParameterDef<Object> parameter : parameters.getParameters())
		{
			String key = "$(" + parameter.getName() + ")";
			String value = parameters.get(parameter).toString();

			if (outputFilename.contains(key))
				outputFilename = outputFilename.replace(key, value);
		}

		// Append date/time stamp if using a GUI
		if (NetMOD.isGUI())
			outputFilename += new SimpleDateFormat("_yyyyMMdd_HHmm").format(new Date());

		return outputFilename;
	}

	/**
	 * @return the colorScaling
	 */
	public COLOR_SCALING getColorScaling()
	{
		if (_colorScaling == null)
		{
			MagnitudeType magnitude = MagnitudeType.valueOfIgnoreCase(getSimulKeyValue(Output.SIMULKEY_SIZE_TYPE));

			if (magnitude == null)
				_colorScaling = COLOR_SCALING.LINEAR;
			else
				_colorScaling = (magnitude.isLog() ? COLOR_SCALING.LOG : COLOR_SCALING.LINEAR);
		}

		return _colorScaling;
	}

	public int getContourIndex()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		return _simulGridContourIndex;
	}

	public double[] getContourLevels()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		if (_simulGridContourLevels == null)
		{
			if (getContourIndex() < 0)
				_simulGridContourLevels = new double[0];
			else
			{

			}
		}

		return _simulGridContourLevels;
	}

	/**
	 * Get the result value for the i'th epicenter. The valueIndex is from one
	 * of the SIMULGRID_* keys.
	 * 
	 * @param i
	 * @param valueIndex
	 * @return epicenter value
	 */
	public double getEpicenterValue(int i, int valueIndex)
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		if (i >= getNumberEpicenters() || valueIndex >= SIMULGRID_COUNT)
			return 0;

		return _simulGrid[valueIndex][i];
	}

	/**
	 * @param index
	 * @return number of iterations
	 */
	public int getIterations(int index)
	{
		return _iterations[index];
	}

	@Override
	public Layer<?> getMapLayer()
	{
		if (NetMOD.getMap() == null)
			return null;

		return NetMOD.getMap().createOutputLayer(this);
	}

	/**
	 * Return the index of the epicenter that is nearest to the provided
	 * latitude and longitude
	 * 
	 * @param lat
	 * @param lon
	 * @return index of the nearest epicenter
	 */
	public int getNearestEpicenter(double lat, double lon)
	{
		int nearest_index = -1;
		double distance = Double.MAX_VALUE;

		int N = getNumberEpicenters();
		for (int i = 0; i < N; i++)
		{
			double dlat = (lat - getEpicenterValue(i, SIMULGRID_LAT));
			double dlon = (lon - getEpicenterValue(i, SIMULGRID_LON));
			double d = Math.sqrt(dlat * dlat + dlon * dlon);

			if (d < distance)
			{
				distance = d;
				nearest_index = i;
			}
		}

		return nearest_index;
	}

	/**
	 * Get the number of epicenters
	 * 
	 * @return the number of epicenters
	 */
	public int getNumberEpicenters()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		if (_simulGrid.length > 0)
			return _simulGrid[0].length;

		return 0;
	}

	/**
	 * Get the number of epicenters
	 * 
	 * @return the number of stations
	 */
	public int getNumberStations()
	{
		if (_simulSta == null)
			readSimulSta(getOutputFile() + simulSta);

		return _simulSta.size();
	}

	/**
	 * @return the output file
	 */
	public String getOutputFile()
	{
		return _outputFile;
	}

	/**
	 * @param index
	 * @return boolean indicating whether the epicenter result has been set
	 */
	public boolean getOutputSet(int index)
	{
		return _outputSet[index];
	}

	/**
	 * @return the number of simulkeys
	 */
	public int getSimulKeyCount()
	{
		if (_simulKey == null)
			readSimulKey(getOutputFile() + simulKey);

		return _simulKey.size();
	}

	/**
	 * Get the simulation keys
	 * 
	 * @return the simulkey keys
	 */
	public Collection<String> getSimulKeyKeys()
	{
		if (_simulKey == null)
			readSimulKey(getOutputFile() + simulKey);

		return _simulKey.keySet();
	}

	/**
	 * Get the simulation value for the provided SIMULKEY
	 * 
	 * @param key
	 * @return the value of the requested simulkey
	 */
	public String getSimulKeyValue(String key)
	{
		if (_simulKey == null)
			readSimulKey(getOutputFile() + simulKey);

		String value = _simulKey.get(key);
		if (value == null)
			value = "";

		return value;
	}

	/**
	 * Get the result value for the i'th station. The valueIndex is from one of
	 * the SIMULSTA_* keys.
	 * 
	 * @param i
	 * @param valueIndex
	 * @return the station value
	 */
	public String getStationValue(int i, int valueIndex)
	{
		if (_simulSta == null)
			readSimulSta(getOutputFile() + simulSta);

		if (i >= getNumberStations() || valueIndex >= SIMULSTA_COUNT)
			return "";

		return _simulSta.get(i)[valueIndex];
	}

	/**
	 * @return the selected surface color model
	 */
	public ColorModel getSurfaceColorModel()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		return _simulGridDisplayColorModel;
	}

	/**
	 * Get the currently selected surface index
	 * 
	 * @return the current surface index
	 */
	public int getSurfaceIndex()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		if (_simulGridDisplayIndex < -1)
		{
			// Find the first non-constant index to display
			_simulGridDisplayIndex = SIMULGRID_NETPROB;
			int N = getNumberEpicenters();
			for (int index = SIMULGRID_SIZE; index < SIMULGRID_COUNT; index++)
			{
				double value = _simulGrid[index][0];
				for (int i = 1; i < N; i++)
				{
					if (_simulGrid[index][i] != value)
					{
						_simulGridDisplayIndex = index;
						resetDisplayMinMax();
						index = SIMULGRID_COUNT;
						break;
					}
				}
			}
		}

		return _simulGridDisplayIndex;
	}

	/**
	 * The maximum surface value
	 * 
	 * @return maximum surface value
	 */
	public double getSurfaceMax()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		return _simulGridDisplayMax;
	}

	/**
	 * The minimum surface value
	 * 
	 * @return minimum surface value
	 */
	public double getSurfaceMin()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		return _simulGridDisplayMin;
	}

	/**
	 * The surface transparency
	 * 
	 * @return surface transparency
	 */
	public double getSurfaceTransparency()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		return _simulGridDisplayTransparency;
	}

	public int getTime(int i)
	{
		return _time[i];
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		if (_viewer == null)
			_viewer = new OutputViewer(this);

		return _viewer;
	}

	@Override
	public int hashCode()
	{
		return getOutputFile().hashCode();
	}

	/**
	 * Read the simulgrid from the provided file
	 * 
	 * @param filename
	 */
	private void readSimulGrid(String filename)
	{
		FileInputStream fis = null;
		Scanner fin = null;
		try
		{
			File file = IOUtility.openFile(filename);
			if (!file.exists())
			{
				_simulGrid = new double[0][0];
				return;
			}

			// Open the file and read in the title
			fis = new FileInputStream(file);
			fin = new Scanner(fis);

			// Skip comments
			while (fin.hasNext("#"))
				fin.nextLine();

			// Read in the number of epicenters
			int N = fin.nextInt();

			// Read in the grid of values
			_simulGrid = new double[SIMULGRID_COUNT][N];
			for (int i = 0; i < N; i++)
				for (int j = 0; j < SIMULGRID_COUNT; j++)
					_simulGrid[j][i] = fin.nextDouble();

			resetDisplayMinMax();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fin != null )
				IOUtility.safeClose(fin);
			if ( fis != null )
				IOUtility.safeClose(fis);
		}
	}

	/**
	 * Read the simulkeys for the provided filename
	 * 
	 * @param filename
	 */
	private void readSimulKey(String filename)
	{
		FileInputStream fis = null;
		Scanner fin = null;
		try
		{
			_simulKey = new LinkedHashMap<String, String>();
			File file = IOUtility.openFile(filename);
			if (!file.exists())
				return;

			// Open the file and read in the title
			fis = new FileInputStream(file);
			fin = new Scanner(fis);

			// Skip comments
			while (fin.hasNext("#"))
				fin.nextLine();

			while (fin.hasNextLine())
			{
				// Trim and split on white space
				String[] line = fin.nextLine().trim().split("\\s*(=)\\s*");

				if (line.length >= 2)
					_simulKey.put(line[0], line[1]);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fin != null )
				IOUtility.safeClose(fin);
			if ( fis != null )
				IOUtility.safeClose(fis);
		}
	}

	/**
	 * Read the simulsta for the provided filename
	 * 
	 * @param filename
	 */
	private void readSimulSta(String filename)
	{
		FileInputStream fis = null;
		Scanner fin = null;
		try
		{
			File file = IOUtility.openFile(filename);
			if (!file.exists())
			{
				_simulSta = new ArrayList<String[]>();
				return;
			}

			// Open the file and read in the title
			fis = new FileInputStream(file);
			fin = new Scanner(fis);

			// Skip comments
			while (fin.hasNext("#"))
				fin.nextLine();

			List<String[]> stas = new ArrayList<String[]>();
			while (fin.hasNextLine())
			{
				// Trim and split on white space
				String[] line = fin.nextLine().trim().split("\\s*(\\s|,)\\s*");

				if (line.length >= SIMULSTA_COUNT)
					stas.add(line);
			}

			_simulSta = stas;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fin != null )
				IOUtility.safeClose(fin);
			if ( fis != null )
				IOUtility.safeClose(fis);
		}
	}

	/**
	 * Remove the files that store the output represented in this object
	 * 
	 */
	public boolean remove()
	{
		return remove(_outputFile);
	}

	/**
	 * Remove the files that store the output represented in this object
	 * 
	 * @param outputFile
	 * @return true if the file was deleted;
	 */
	private boolean remove(String outputFile)
	{
		//  Ensure the output is read in=
		readSimulKey(getOutputFile() + simulKey);
		readSimulSta(getOutputFile() + simulSta);
		readSimulGrid(getOutputFile() + simulGrid);
		
		boolean value = true;

		File file = IOUtility.openFile(outputFile + simulKey);
		if (file.exists())
			value &= file.delete();

		file = IOUtility.openFile(outputFile + simulSta);
		if (file.exists())
			value &= file.delete();

		file = IOUtility.openFile(outputFile + simulGrid);
		if (file.exists())
			value &= file.delete();

		return value;
	}

	/**
	 * Reset the minimum and maximum display values
	 */
	public void resetDisplayMinMax()
	{
		if (_simulGrid == null)
			readSimulGrid(getOutputFile() + simulGrid);

		int index = getSurfaceIndex();
		if (index < 0)
			return;

		// Determine the min and max of the data
		_simulGridDisplayMin = NumericUtility.min(_simulGrid[index]);
		_simulGridDisplayMax = NumericUtility.max(_simulGrid[index]);

		// Reset the color model
		if (index == SIMULGRID_NETPROB)
			_simulGridDisplayColorModel = ColorModel.REVERSE_JET;
		else
			_simulGridDisplayColorModel = ColorModel.JET;
	}

	/**
	 * Save the output to the output folder
	 */
	public boolean save()
	{
		boolean ret = save(getOutputFile());

		if (ret)
			clearCache();

		return ret;
	}

	/**
	 * Save the output files
	 * 
	 * @param outputFile
	 * @return true if sucessfully saved
	 */
	private boolean save(String outputFile)
	{
		boolean value = true;

		value &= writeSimulGrid(outputFile + simulGrid);
		value &= writeSimulKey(outputFile + simulKey);
		value &= writeSimulSta(outputFile + simulSta);

		return value;
	}

	/**
	 * @param colorScaling
	 *            the colorScaling to set
	 */
	public void setColorScaling(COLOR_SCALING colorScaling)
	{
		_colorScaling = colorScaling;
	}

	/**
	 * @param valueIndex
	 */
	public void setContourIndex(int valueIndex)
	{
		_simulGridContourIndex = valueIndex;
	}

	/**
	 * @param levels
	 */
	public void setContourLevels(double[] levels)
	{
		_simulGridContourLevels = levels;
	}

	/**
	 * @param i
	 * @param valueIndex
	 * @param value
	 */
	public void setEpicenterValue(int i, int valueIndex, double value)
	{
		if (i >= getNumberEpicenters() || valueIndex >= SIMULGRID_COUNT)
			return;

		_simulGrid[valueIndex][i] = value;
	}

	/**
	 * Set the number of iterations for the epicenter
	 * 
	 * @param index
	 *            index of the epicenter
	 * @param value
	 *            number of iterations
	 */
	public void setIterations(int index, int value)
	{
		_iterations[index] = value;
	}

	/**
	 * Set the output file
	 * 
	 * @param outputFile
	 */
	public void setOutputFile(String outputFile)
	{
		// Outputfile unchanged
		if (_outputFile.equals(outputFile))
			return;

		// Check for first initialization
		if (getOutputFile().isEmpty())
		{
			_outputFile = outputFile;
			setName(IOUtility.openFile(_outputFile).getName());
		}
		// Renaming of file
		else
		{
			// Ensure the current output file is loaded
			if (_simulGrid == null)
				readSimulGrid(getOutputFile() + simulGrid);

			// Attempt to save to the new file
			if (save(outputFile))
			{
				// Remove the old file on disk
				remove();

				// Set the new output file
				_outputFile = outputFile;
				setName(IOUtility.openFile(_outputFile).getName());
			}
			// Remove any intermediate files
			else
				remove(outputFile);
		}
	}

	/**
	 * Set the epicenter output set status
	 * 
	 * @param index
	 * @param value
	 */
	public void setOutputSet(int index, boolean value)
	{
		_outputSet[index] = value;
	}

	/**
	 * Set the SimulKey values from the parameter object
	 * 
	 * @param parameters
	 */
	public void setSimulKeyValues(NetSimParameters parameters)
	{
		if (_simulKey == null)
			_simulKey = new LinkedHashMap<String, String>();

		_simulKey.put(SIMULKEY_SIMUL_BASELINE, parameters.get(NetSimParameters.simulBaseline));
		_simulKey.put(SIMULKEY_SIMUL_TECHNOLOGY, parameters.get(NetSimParameters.simulTechnology).toString());
		_simulKey.put(SIMULKEY_RUN_TYPE, parameters.get(NetSimParameters.runType).toString());
		_simulKey.put(SIMULKEY_SUB_TYPE, parameters.get(NetSimParameters.subType).toString());

		_simulKey.put(SIMULKEY_FREQ_SAMPLING, parameters.get(NetSimParameters.freqSampling));
		_simulKey.put(SIMULKEY_FREQ_TYPE, parameters.get(NetSimParameters.freqType));
		_simulKey.put(SIMULKEY_SIGNAL_AMPLITUDE, parameters.get(NetSimParameters.signalAmplitude).toString());
		_simulKey.put(SIMULKEY_NOISE_AMPLITUDE, parameters.get(NetSimParameters.noiseAmplitude).toString());

		_simulKey.put(SIMULKEY_WIND_MODE, parameters.get(NetSimParameters.windMode).toString());
		_simulKey.put(SIMULKEY_WIND_DAY_OF_YEAR, parameters.get(NetSimParameters.windDayOfYear).toString());
		_simulKey.put(SIMULKEY_WIND_TIME_OF_DAY, parameters.get(NetSimParameters.windTimeOfDay).toString());

		_simulKey.put(SIMULKEY_EDC, parameters.get(NetSimParameters.eventDetectionCriteria));
		_simulKey.put(SIMULKEY_SIZE_TYPE, parameters.get(NetSimParameters.sizeType).toString());
		_simulKey.put(SIMULKEY_EVENT_SIZE, String.format("%-10.3f", parameters.get(NetSimParameters.eventSize)));
		_simulKey.put(SIMULKEY_MIN_EVENT_SIZE, String.format("%-10.3f", parameters.get(NetSimParameters.minEventSize)));
		_simulKey.put(SIMULKEY_MAX_EVENT_SIZE, String.format("%-10.3f", parameters.get(NetSimParameters.maxEventSize)));
		_simulKey.put(SIMULKEY_CONF, String.format("%-10.3f", parameters.get(NetSimParameters.conf)));
		_simulKey.put(SIMULKEY_NUM_MC_ITER, String.format("%d", parameters.get(NetSimParameters.numMonteCarloIter)));

		String epiModel = parameters.get(NetSimParameters.epiModel);
		_simulKey.put(SIMULKEY_EPI_MODEL, epiModel);

		ParTable epiSource = parameters.get(NetSimParameters.epiSource);

		_simulKey.put(SIMULKEY_EPIGRID_MINLAT, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_MIN_LAT));
		_simulKey.put(SIMULKEY_EPIGRID_MAXLAT, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_MAX_LAT));
		_simulKey.put(SIMULKEY_EPIGRID_MINLON, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_MIN_LON));
		_simulKey.put(SIMULKEY_EPIGRID_MAXLON, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_MAX_LON));
		_simulKey.put(SIMULKEY_EPIGRID_DELLAT, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_DEL_LAT));
		_simulKey.put(SIMULKEY_EPIGRID_DELLON, epiSource.getTableValue(epiModel, NetSimParameters.EPISOURCE_DEL_LON));
		_simulKey.put(SIMULKEY_EPIGRID_DEPTH, epiSource.getTableValue(epiModel,  NetSimParameters.EPISOURCE_DEPTH));

		// Compute the minimum and maximum thresholds
		double min = Double.MAX_VALUE;
		double max = -Double.MAX_VALUE;
		int N = getNumberEpicenters();

		for (int i = 0; i < N; i++)
		{
			double value = getEpicenterValue(i, SIMULGRID_SIZE);
			min = Math.min(min, value);
			max = Math.max(max, value);
		}

		_simulKey.put(SIMULKEY_MIN_EPI_SIZE, String.format("%-10.3f", min));
		_simulKey.put(SIMULKEY_MAX_EPI_SIZE, String.format("%-10.3f", max));
		_simulKey.put(SIMULKEY_NET, parameters.get(NetSimParameters.net));
	}

	public void setSimulKeyValues(String key, String value)
	{
		_simulKey.put(key, value);
	}

	/**
	 * Set the station values for the provided station
	 * 
	 * @param station
	 * @param reliability
	 *            default station reliability
	 */
	public void setStation(Station station, double reliability)
	{
		if (_simulSta == null)
			_simulSta = new ArrayList<String[]>();

		String[] sta = new String[SIMULSTA_COUNT];

		sta[SIMULSTA_STA] = station.getName();
		sta[SIMULSTA_TECH] = station.getTechnology();
		sta[SIMULSTA_LON] = String.format("%10.3f", station.getLongitude());
		sta[SIMULSTA_LAT] = String.format("%10.3f", station.getLatitude());
		sta[SIMULSTA_RELY] = String.format("%10.3f", (station.getReliability() <= 0 ? reliability : station.getReliability()));
		sta[SIMULSTA_NCHAN] = String.format("%d", station.getNumberChannels());
		sta[SIMULSTA_TYPE] = station.getStationType();

		_simulSta.add(sta);
	}

	/**
	 * @param colorModel
	 */
	public void setSurfaceColorModel(ColorModel colorModel)
	{
		_simulGridDisplayColorModel = colorModel;
	}

	/**
	 * @param valueIndex
	 */
	public void setSurfaceIndex(int valueIndex)
	{
		_simulGridDisplayIndex = valueIndex;
	}

	/**
	 * Set the desired maximum surface display value
	 * 
	 * @param max
	 */
	public void setSurfaceMax(double max)
	{
		_simulGridDisplayMax = max;
	}

	/**
	 * Set the desired minimum surface display value
	 * 
	 * @param min
	 */
	public void setSurfaceMin(double min)
	{
		_simulGridDisplayMin = min;
	}

	/**
	 * @param transparency
	 */
	public void setSurfaceTransparency(double transparency)
	{
		_simulGridDisplayTransparency = transparency;
	}

	/**
	 * Set the number of milliseconds for the epicenter
	 * 
	 * @param index
	 *            index of the epicenter
	 * @param value
	 *            number of iterations
	 */
	public void setTime(int index, int value)
	{
		_time[index] = value;
	}

	/**
	 * Set the SimulKey and SimulSta values from the output object
	 * 
	 * @param output
	 */
	public void setValues(Output output)
	{
		/*
		 * Set the simulKey values
		 */
		if (_simulKey == null)
			_simulKey = new LinkedHashMap<String, String>();

		// Force output to be read in;
		output.getSimulKeyValue("");

		for (Entry<String, String> entry : output._simulKey.entrySet())
			_simulKey.put(entry.getKey(), entry.getValue());

		// Compute the minimum and maximum thresholds
		double min = Double.POSITIVE_INFINITY;
		double max = Double.NEGATIVE_INFINITY;
		int N = getNumberEpicenters();

		for (int i = 0; i < N; i++)
		{
			double value = getEpicenterValue(i, SIMULGRID_SIZE);
			min = Math.min(min, value);
			max = Math.max(max, value);
		}

		_simulKey.put(SIMULKEY_MIN_EPI_SIZE, String.format("%-10.3f", min));
		_simulKey.put(SIMULKEY_MAX_EPI_SIZE, String.format("%-10.3f", max));

		/*
		 * Set the simulSta values
		 */
		output.getStationValue(0, 0);
		_simulSta = output._simulSta;
	}

	/**
	 * Write the simulgrid file
	 * 
	 * @param filename
	 * @return true if file is written
	 */
	private boolean writeSimulGrid(String filename)
	{
		boolean value = false;
		PrintWriter fout = null;
		try
		{
			int N = getNumberEpicenters();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(filename));

			// Write the number of epicenters
			fout.println(N);

			// Write out the values
			if (_simulGrid != null)
				for (int i = 0; i < N; i++)
				{
					for (int j = 0; j < SIMULGRID_COUNT; j++)
						fout.print(String.format("%-9.4g  ", _simulGrid[j][i]));
					fout.println();
				}

			value = true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		finally
		{
			if (fout != null)
				IOUtility.safeClose(fout);
		}

		return value;
	}

	/**
	 * Write the simulkey file
	 * 
	 * @param filename
	 * @return true if the file is sucesfully written
	 */
	private boolean writeSimulKey(String filename)
	{
		boolean value = false;
		PrintWriter fout = null;
		try
		{
			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(filename));

			// Write out the values
			if (_simulKey != null)
				for (String key : _simulKey.keySet())
					fout.println(String.format("%s=%s", key, _simulKey.get(key)));

			value = true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (fout != null)
				IOUtility.safeClose(fout);
		}

		return value;
	}

	/**
	 * Write the simulsta file
	 * 
	 * @param filename
	 * @return true if the file is succesfully written
	 */
	private boolean writeSimulSta(String filename)
	{
		boolean value = false;
		PrintWriter fout = null;
		try
		{
			int N = getNumberStations();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(filename));

			// Write out the values
			for (int i = 0; i < N; i++)
			{
				for (int j = 0; j < SIMULSTA_COUNT; j++)
					fout.print(String.format((j == 0 ? "%s" : "\t%s"), getStationValue(i, j)));
				fout.println();
			}

			value = true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (fout != null)
				IOUtility.safeClose(fout);
		}

		return value;
	}
}
