/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.media;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class PathMediaType extends AbstractNetModComponent
{
    private PhaseParameters<PathMediaPhaseParameter> _phaseParameters;

    private boolean _dirty;

    /**
     * @param parent
     * @param phases
     */
    public PathMediaType(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent);
        
        _phaseParameters = new PhaseParameters<PathMediaPhaseParameter>(this);
        setName("New Path Media");
        
        //  Initialize the set of phases
        if ( phases != null )
            for (Phase phase : phases)
                _phaseParameters.addParameter(new PathMediaPhaseParameter(_phaseParameters, phase));
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getPhaseParameters());

        return children;
    }

    /**
     * @return the dirty
     */
    public boolean getDirty()
    {
        boolean dirty = _dirty;

        for (PathMediaPhaseParameter pp : _phaseParameters.getParameters())
            dirty |= pp.getDirty();

        return dirty;
    }

    public PhaseParameters<PathMediaPhaseParameter> getPhaseParameters()
    {
        return _phaseParameters;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new PathMediaTypeViewer(this);
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof PhaseParameters)
                _phaseParameters = (PhaseParameters) child;
        }

        clearCache();
    }

    /**
     * @param dirty the dirty to set
     */
    public void setDirty(boolean dirty)
    {
        _dirty = dirty;

        for (PathMediaPhaseParameter pp : _phaseParameters.getParameters())
            pp.setDirty(dirty);
    }

    @Override
    public void setName(String name)
    {
        if (!getName().equalsIgnoreCase(name))
            setDirty(true);

        super.setName(name);
    }
}
