/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.IOUtility;
import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.encoders.EncoderUtil;
import org.jfree.chart.encoders.ImageFormat;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.ui.Layer;

import javax.swing.*;
import javax.swing.border.SoftBevelBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.*;
import javax.swing.text.rtf.RTFEditorKit;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.*;

/**
 * Collection of useful methods for supporting the GUI.
 * 
 * @author bjmerch
 * 
 */
public class GUIUtility
{
	/**
	 * A FileFilter for accepting a particular file type.
	 */
	private static class ExtensionFileFilter extends FileFilter
	{
		private String ext;

		ExtensionFileFilter(String ext)
		{
			this.ext = ext;
		}

		public boolean accept(File f)
		{
			if (f.isDirectory())
				return true;

			return f.getName().endsWith(ext);
		}

		public String getDescription()
		{
			return "*." + ext;
		}
	}

	/**
	 * Document handler that limits the string length
	 */
	@SuppressWarnings("serial")
	private static class TextFieldLimiter extends PlainDocument
	{
		int maxChar = -1;

		public TextFieldLimiter(int len)
		{
			maxChar = len;
		}

		public void insertString(int offs, String str, AttributeSet a) throws BadLocationException
		{
			if (str != null && maxChar > 0 && getLength() + str.length() > maxChar)
			{
				java.awt.Toolkit.getDefaultToolkit().beep();
				return;
			}
			super.insertString(offs, str, a);
		}
	}

	// For displaying dates
	static private SimpleDateFormat sdf_date = new SimpleDateFormat("yyyy/MM/dd");

	static private SimpleDateFormat sdf_time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

	static
	{
		sdf_date.setTimeZone(TimeZone.getTimeZone("GMT"));
		sdf_time.setTimeZone(TimeZone.getTimeZone("GMT"));
	}

	/*
	 * Code for adding rows to a GridBag panel.
	 */

	private static JFileChooser chooser;

	/**
	 * Add a row to the provided panel that uses the GridBagLayout.
	 * 
	 * @param panel  Panel to add a row to
	 * @param h      Height of the row, if GridBagConstraints.REMAINDER then take
	 *               the remaining vertical space in the panel
	 * @param fields Fields that make up the row
	 */
	public static void addRow(JPanel panel, int h, JComponent... fields)
	{
		if (fields.length == 0)
			return;

		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.weightx = 0.0;
		c.weighty = 1.0;

		if (h <= 0)
			c.weighty = 1000;

		int count = 0;
		for (JComponent field : fields)
		{
			count++;
			if (field == null)
				field = new JLabel();

			c.fill = GridBagConstraints.HORIZONTAL;
			c.anchor = GridBagConstraints.CENTER;

			if (field instanceof JButton || field instanceof JToolBar)
			{
				c.anchor = GridBagConstraints.CENTER;
				c.weightx = 0.0;
				// c.fill = GridBagConstraints.NONE;
				c.gridwidth = 1;
			}
			else if (field instanceof JComboBox)
			{
				c.anchor = GridBagConstraints.CENTER;
				c.weightx = 0.0;
				c.fill = GridBagConstraints.NONE;
				c.gridwidth = 1;
			}
			else if (field instanceof JLabel)
			{
				c.anchor = GridBagConstraints.NORTH;
				if (count == 1)
					((JLabel) field).setHorizontalAlignment(SwingConstants.RIGHT);
				else
					((JLabel) field).setHorizontalAlignment(SwingConstants.LEFT);
				((JLabel) field).setVerticalAlignment(SwingConstants.BOTTOM);
			}
			else if (field instanceof JTextField)
			{
				c.anchor = GridBagConstraints.CENTER;
				int width = Math.max(50, field.getPreferredSize().width);
				field.setPreferredSize(new Dimension(width, field.getPreferredSize().height));
			}
			else if (field instanceof JTextArea)
			{
				c.anchor = GridBagConstraints.FIRST_LINE_START;

				((JTextArea) field).setWrapStyleWord(true);
				((JTextArea) field).setLineWrap(true);
				((JTextArea) field).setOpaque(false);
			}
			else
			{
				c.anchor = GridBagConstraints.FIRST_LINE_START;
			}

			if (count == fields.length)
			{
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridwidth = GridBagConstraints.REMAINDER;
				c.weightx = 1.0;
			}

			if (fields.length == 1)
			{
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridwidth = GridBagConstraints.REMAINDER;
				c.weightx = 1.0;
			}

			if (h <= 0)
			{
				c.fill = GridBagConstraints.BOTH;
				c.gridwidth = GridBagConstraints.REMAINDER;
				c.gridheight = GridBagConstraints.REMAINDER;
			}

			panel.add(field, c);
			c.weightx = 1.0;
		}
	}

	/**
	 * Add a row to the provided panel that uses the GridBagLayout.
	 * 
	 * @param panel  Panel to add a row to
	 * @param fields Fields that make up the row
	 */
	public static void addRow(JPanel panel, JComponent... fields)
	{
		addRow(panel, 1, fields);
	}

	/**
	 * Process Component c, and all subcomponents, after generating image
	 * 
	 * @param c
	 * @param fromWaveformViewer
	 */
	private static void completeComponentForImage(Component c, boolean fromWaveformViewer)
	{
		// Chart panel
		if (c instanceof ChartPanel)
		{

			ChartPanel cp = (ChartPanel) c;
			cp.setOpaque(false);
			cp.getChart().setBackgroundPaint(new Color(255, 255, 255, 0));

			if (cp.getChart().getPlot() instanceof XYPlot)
			{
				if (((XYPlot) cp.getChart().getXYPlot()).getDomainMarkers(Layer.BACKGROUND) != null)
				{

					for (Object o : ((XYPlot) cp.getChart().getXYPlot()).getDomainMarkers(Layer.BACKGROUND))
					{
						if (o instanceof IntervalMarker)
						{
							IntervalMarker im = ((IntervalMarker) o);
							if (im.getPaint() instanceof Color && im.getOutlinePaint() instanceof Color)
							{
								Color color = (Color) im.getPaint();
								Color outlineColor = (Color) im.getOutlinePaint();
								Color newColor = new Color(color.getRed(), color.getGreen(), color.getBlue(),
										outlineColor.getAlpha()); // visible
								im.setPaint(newColor);
								im.setOutlineStroke(new BasicStroke(0.1f)); // original, thinner stroke
							}
						}
					}
				}
			}

		}
		// JPanel
		else if (c instanceof JPanel)
		{
			JPanel panel = (JPanel) c;
			for (Component c1 : panel.getComponents())
			{
				completeComponentForImage(c1, fromWaveformViewer); // recurse on components within JPanel
			}
			panel.setOpaque(false);
		}
		else if (c instanceof JComponent)
		{
			((JComponent) c).setOpaque(false);
		}

	}

	/**
	 * For JTrees (TOCs): Remove any paths that are descendants of other paths
	 * 
	 * @param paths
	 * @return
	 */
	public static List<TreePath> consolidatePaths(List<TreePath> paths)
	{
		ArrayList<TreePath> consolidatedPaths = new ArrayList<TreePath>();

		for (int i = 0; i < paths.size(); i++)
		{
			boolean add = true;

			for (int j = 0; j < paths.size(); j++)
			{
				if (i != j)
				{

					if (paths.get(j).isDescendant(paths.get(i)))
					{

						// Special case when paths are identical, but reference is to
						// a DIFFERENT object
						if (paths.get(i).equals(paths.get(j)) && paths.get(i).hashCode() != paths.get(j).hashCode())
						{
							continue;
						}
						add = false;
					}
				}
			}

			if (add)
				consolidatedPaths.add(paths.get(i));
		}

		return consolidatedPaths;
	}

	/**
	 * Copy the specified image to the system clipboard.
	 */
	public static void copyToClipboard(final Image image)
	{
		Transferable transferableImage = new Transferable()
		{
			@Override
			public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
			{
				if (!DataFlavor.imageFlavor.equals(flavor))
				{
					throw new UnsupportedFlavorException(flavor);
				}

				return image;
			}

			@Override
			public DataFlavor[] getTransferDataFlavors()
			{
				return new DataFlavor[] { DataFlavor.imageFlavor };
			}

			@Override
			public boolean isDataFlavorSupported(DataFlavor flavor)
			{
				return DataFlavor.imageFlavor.equals(flavor);
			}
		};

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(transferableImage, null);
	}

	/**
	 * Create a button that displays the provided icon
	 * 
	 * @param icon
	 * @return
	 */
	static public JButton createButton(Icon icon)
	{
		JButton button = new JButton(icon);

		button.setFocusable(false);
		button.setFocusPainted(false);
		button.setOpaque(false);
		button.setRolloverEnabled(true);
		button.setMargin(new Insets(0, 2, 0, 2));

		return button;
	}

	/**
	 * Create a panel containing buttons representing each of the provided actions.
	 * 
	 * @param actions
	 * @return
	 */
	static public JPanel createButtonPanel(Action... actions)
	{
		return createButtonPanel(true, actions);
	}

	/**
	 * Create a JPanel that contains an arbitrary number of actions.
	 * 
	 * @param etchedBorder Flag specifying whether the etched border should be
	 *                     displayed
	 * @param actions
	 * @return
	 */
	static public JPanel createButtonPanel(boolean etchedBorder, Action... actions)
	{
		JPanel buttonPanel = new JPanel();

		if (etchedBorder)
		{
			buttonPanel.setBorder(BorderFactory.createEtchedBorder());
		}

		for (Action action : actions)
			buttonPanel.add(new JButton(action));

		return buttonPanel;
	}

	/**
	 * Create and return a JTextField that does not allow more than the limit number
	 * of characters.
	 * 
	 * @param limit
	 * @return
	 */
	public static JTextField createTextField(int limit)
	{
		JTextField textField = new JTextField();
		textField.setDocument(new TextFieldLimiter(limit));

		return textField;
	}

	/**
	 * Create a toggle button with the provided icon
	 * 
	 * @param icon
	 * @return
	 */
	static public JToggleButton createToggleButton(Icon icon)
	{
		JToggleButton button = new JToggleButton(icon, false);

		button.setFocusable(false);
		button.setFocusPainted(false);
		button.setOpaque(false);
		button.setRolloverEnabled(true);
		button.setMargin(new Insets(0, 2, 0, 2));

		return button;
	}

	/**
	 * Create a platform specific toolbar that displays nicely.
	 * 
	 * @return
	 */
	static public JComponent createToolBar()
	{
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);
		toolBar.setRollover(true);
		toolBar.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		toolBar.setBorderPainted(false);
		toolBar.setOpaque(false);

		return toolBar;
	}

	/**
	 * De-select any toggle buttons contained within the hierarchy of the provided
	 * component
	 * 
	 * @param c
	 */
	static public void deselectToggleButtons(Component c)
	{
		if (c instanceof JToggleButton && ((JToggleButton) c).isSelected())
			((JToggleButton) c).doClick();
		else if (c instanceof Container)
			for (Component c2 : ((Container) c).getComponents())
				deselectToggleButtons(c2);
	}

	/**
	 * Format the provided double value as a string
	 * 
	 * @param value
	 * @return
	 */
	public static String format(double value)
	{
		double absValue = Math.abs(value);

		if (absValue > 0.01 && absValue < 100000)
			return String.format("%12.6f", value);
		else
			return String.format("%7.4g", value);
	}

	/**
	 * Format the provided value as a string
	 * 
	 * @param o
	 * @return
	 */
	public static String format(Object o)
	{
		if (o == null)
			return "";

		if (o instanceof Number)
			return GUIUtility.format(((Number) o).doubleValue());

		return o.toString();
	}

	/**
	 * Format the provided array of doubles as a comma delimited string.
	 * 
	 * @param values
	 * @return
	 */
	public static String formatDoubles(double[] values)
	{
		return formatDoubles(values, ", ");
	}

	/**
	 * Format the provided array of doubles using the provided separator
	 * 
	 * @param values
	 * @param separator
	 * @return
	 */
	public static String formatDoubles(double[] values, String separator)
	{
		StringBuffer str = new StringBuffer();
		for (double value : values)
		{
			str.append(GUIUtility.format(value));
			str.append(separator);
		}

		// Remove the final separator
		if (str.length() > 0)
			str.delete(str.length() - separator.length(), str.length());

		return str.toString();
	}

	/**
	 * Format the provided array of doubles using the provided separator
	 * 
	 * @param values
	 * @param separator
	 * @return
	 */
	public static String formatDoubles(double[] values, String separator, String format)
	{
		StringBuffer str = new StringBuffer();
		for (double value : values)
		{
			str.append(String.format(format, value));
			str.append(separator);
		}

		// Remove the final separator
		if (str.length() > 0)
			str.delete(str.length() - separator.length(), str.length());

		return str.toString();
	}

	/**
	 * Format the provided array of doubles as a comma delimited string.
	 * 
	 * @param values
	 * @return
	 */
	public static String formatDoublesReadable(double[] values, String separator)
	{
		StringBuffer str = new StringBuffer();
		for (double value : values)
		{
			str.append((float) value);
			str.append(separator);
		}

		// Remove the final separator
		if (str.length() > 0)
			str.delete(str.length() - separator.length(), str.length());

		return str.toString();
	}

	/**
	 * Get the default set of colors for chart lines
	 * 
	 * @return
	 */
	public static Color[] getChartLineColors()
	{
		final Color[] colors = { ChartColor.VERY_DARK_RED, ChartColor.VERY_DARK_BLUE, ChartColor.VERY_DARK_GREEN,
				ChartColor.VERY_DARK_YELLOW, ChartColor.VERY_DARK_MAGENTA, ChartColor.VERY_DARK_CYAN,
				ChartColor.DARK_GRAY, ChartColor.LIGHT_RED, ChartColor.LIGHT_BLUE, ChartColor.LIGHT_GREEN,
				ChartColor.LIGHT_YELLOW, ChartColor.LIGHT_MAGENTA, ChartColor.LIGHT_CYAN };
		return colors;
	}

	/**
	 * Return a Color used to draw an interval marker at the specified index, and
	 * given the total number of rows/markers/colors that are needed.
	 * 
	 * @param index
	 * @param count
	 * @return
	 */
	public static Color getColor(int index, int count)
	{
		int a = 130;
		final Color[] colors = { new Color(0, 0, 128, a), new Color(0, 0, 143, a), new Color(0, 0, 159, a),
				new Color(0, 0, 175, a), new Color(0, 0, 191, a), new Color(0, 0, 207, a), new Color(0, 0, 223, a),
				new Color(0, 0, 239, a), new Color(0, 0, 255, a), new Color(0, 16, 255, a), new Color(0, 32, 255, a),
				new Color(0, 48, 255, a), new Color(0, 64, 255, a), new Color(0, 80, 255, a), new Color(0, 96, 255, a),
				new Color(0, 112, 255, a), new Color(0, 128, 255, a), new Color(0, 143, 255, a),
				new Color(0, 159, 255, a), new Color(0, 175, 255, a), new Color(0, 191, 255, a),
				new Color(0, 207, 255, a), new Color(0, 223, 255, a), new Color(0, 239, 255, a),
				new Color(0, 255, 255, a), new Color(16, 255, 239, a), new Color(32, 255, 223, a),
				new Color(48, 255, 207, a), new Color(64, 255, 191, a), new Color(80, 255, 175, a),
				new Color(96, 255, 159, a), new Color(112, 255, 143, a), new Color(128, 255, 128, a),
				new Color(143, 255, 112, a), new Color(159, 255, 96, a), new Color(175, 255, 80, a),
				new Color(191, 255, 64, a), new Color(207, 255, 48, a), new Color(223, 255, 32, a),
				new Color(239, 255, 16, a), new Color(255, 255, 0, a), new Color(255, 239, 0, a),
				new Color(255, 223, 0, a), new Color(255, 207, 0, a), new Color(255, 191, 0, a),
				new Color(255, 175, 0, a), new Color(255, 159, 0, a), new Color(255, 143, 0, a),
				new Color(255, 128, 0, a), new Color(255, 112, 0, a), new Color(255, 96, 0, a),
				new Color(255, 80, 0, a), new Color(255, 64, 0, a), new Color(255, 48, 0, a), new Color(255, 32, 0, a),
				new Color(255, 16, 0, a), new Color(239, 0, 0, a), new Color(223, 0, 0, a), new Color(207, 0, 0, a),
				new Color(191, 0, 0, a), new Color(175, 0, 0, a), new Color(159, 0, 0, a), new Color(143, 0, 0, a),
				new Color(128, 0, 0, a), };

		if (count > colors.length)
		{
			return colors[index % colors.length];
		}
		else
		{
			double stepSize = ((double) colors.length) / count;
			int finalIndex = (int) (stepSize * (index + 0.5));

			return colors[finalIndex];
		}
	}

	/**
	 * Get the default date format
	 * 
	 * @return
	 */
	public static DateFormat getDateFormat()
	{
		return sdf_date;
	}

	/**
	 * Return a list of components of the specified type that has the specified root
	 * as an ancestor.
	 * 
	 * @param root
	 * @param clazz
	 * @return
	 */
	public static <U extends Component> List<U> getDescendantComponents(Component root, Class<U> clazz)
	{
		List<U> result = new ArrayList<U>();

		if (clazz.isAssignableFrom(root.getClass()))
		{
			result.add((U) root);
		}

		if (root instanceof Container)
		{
			for (Component c : ((Container) root).getComponents())
			{
				result.addAll(getDescendantComponents(c, clazz));
			}
		}

		return result;
	}

	/**
	 * Get the internal frame that contains the provided gui component.
	 * 
	 * @param c
	 * @return
	 */
	static public JDialog getDialog(Component c)
	{
		return (JDialog) SwingUtilities.getAncestorOfClass(JDialog.class, c);
	}

	/**
	 * Get the frame that contains the provided gui component.
	 * 
	 * @param c
	 * @return
	 */
	static public Frame getFrame(Component c)
	{
		return (Frame) SwingUtilities.getAncestorOfClass(Frame.class, c);
	}

	/**
	 * Get the internal frame that contains the provided gui component.
	 * 
	 * @param c
	 * @return
	 */
	static public JInternalFrame getInternalFrame(Component c)
	{
		return (JInternalFrame) SwingUtilities.getAncestorOfClass(JInternalFrame.class, c);
	}

	/**
	 * Get the NetMOD notice string
	 * 
	 * @return
	 */
	public static String getNotice()
	{
		StringBuilder sb = new StringBuilder();

		sb.append(NetMOD.name + "\n");
		sb.append("Version " + NetMOD.version + "\n");
		sb.append("\n");

		// Add the notices.txt file to the about message
		try
		{
			File file = IOUtility.findFile(IOUtility.openFile("notices", "NOTICE.txt"));

			for (String line : Files.readAllLines(Paths.get(file.getPath())))
				sb.append(line).append("\n");
		}
		catch (Exception e)
		{
		}

		return sb.toString();
	}

	/**
	 * Get the default set of colors for psd lines
	 * 
	 * @return
	 */
	public static Color[] getPSDLineColors()
	{
		final Color[] colors = { ChartColor.VERY_DARK_RED, ChartColor.VERY_DARK_BLUE, ChartColor.VERY_DARK_GREEN,
				ChartColor.VERY_DARK_YELLOW, ChartColor.VERY_DARK_MAGENTA, ChartColor.VERY_DARK_CYAN,
				ChartColor.DARK_GRAY, ChartColor.LIGHT_RED, ChartColor.LIGHT_BLUE, ChartColor.LIGHT_GREEN,
				ChartColor.LIGHT_YELLOW, ChartColor.LIGHT_MAGENTA, ChartColor.LIGHT_CYAN };
		return colors;
	}

	/**
	 * get the default set of colors for psd models
	 * 
	 * @return
	 */
	public static Color[] getPSDModelLineColors()
	{
		final Color[] colors = { ChartColor.VERY_LIGHT_RED, ChartColor.VERY_LIGHT_BLUE, ChartColor.VERY_LIGHT_GREEN,
				ChartColor.VERY_LIGHT_YELLOW, ChartColor.VERY_LIGHT_MAGENTA, ChartColor.VERY_LIGHT_CYAN };
		return colors;
	}

	/**
	 * Extract the RTF Text from the provided JTextPane
	 * 
	 * @param textPane
	 * @return
	 */
	public static String getRTFText(JTextPane textPane)
	{
		OutputStream out = new ByteArrayOutputStream();

		EditorKit editorKit = textPane.getEditorKit();
		Document document = textPane.getDocument();

		try
		{
			editorKit.write(out, document, 0, document.getLength());
		}
		catch (Exception e)
		{
			showExceptionDialog(null, "Error getting text", e.getMessage(), e);
		}

		return out.toString();
	}

	/**
	 * Get a formatter for times
	 * 
	 * @return
	 */
	public static DateFormat getTimeFormat()
	{
		return sdf_time;
	}

	/**
	 * Generate a timestamp for the current time formatted as YYYY/MM/DD
	 * hh:mm:ss.sss
	 * 
	 * @return
	 */
	public static String getTimestamp()
	{
		return getTimeFormat().format(new Date());
	}

	private static void initChooser(Component parent, String path, String title, int mode, boolean multiSelection,
			String[] fileTypes, JComponent accessory)
	{
		if (chooser == null)
			chooser = new JFileChooser();

		// Set the current directory based on property value
		chooser.setSelectedFile(IOUtility.openFile("")); // clear selected files
		chooser.setAccessory(accessory);
		chooser.setDialogTitle(title);
		chooser.setFileSelectionMode(mode);
		chooser.setMultiSelectionEnabled(multiSelection);

		if (path == null || path.isEmpty())
			chooser.setCurrentDirectory(IOUtility.openFile(Property.FILE_CHOOSER_DIRECTORY.getValue()));
		else
			chooser.setCurrentDirectory(IOUtility.openFile(path));

		// Add the file choosers
		chooser.resetChoosableFileFilters();
		if (fileTypes != null && fileTypes.length > 0)
		{
			chooser.setAcceptAllFileFilterUsed(false);
			for (String str : fileTypes)
				chooser.addChoosableFileFilter(new ExtensionFileFilter(str));
		}
		else
		{
			chooser.setAcceptAllFileFilterUsed(true);
		}
	}

	/**
	 * Process Component c, and all subcomponents, prior to generating image
	 * 
	 * @param c
	 * @param fromWaveformViewer
	 */
	private static void initComponentForImage(Component c, boolean fromWaveformViewer)
	{
		// Chart panel
		if (c instanceof ChartPanel)
		{
			ChartPanel cp = (ChartPanel) c;
			cp.setOpaque(false);
			cp.getChart().setBackgroundPaint(new Color(255, 255, 255, 255));
		}
		// JPanel
		else if (c instanceof JPanel)
		{
			JPanel panel = (JPanel) c;
			for (Component c1 : panel.getComponents())
			{
				initComponentForImage(c1, fromWaveformViewer); // recurse on components within JPanel
			}
			panel.setOpaque(false);
		}
		else if (c instanceof JComponent)
		{
			((JComponent) c).setOpaque(false);
		}

	}

	/**
	 * Check whether the provided string name contains only valid characters
	 * 
	 * @param name
	 * @return
	 */
	public static boolean isValidName(String name)
	{
		int N = name.length();

		for (int i = 0; i < N; i++)
		{
			char c = name.charAt(i);

			// Check for control characters
			if (c < 32)
				return false;

			// Check for various filesystem reserved characters
			if (c == '/' || c == '\\' || c == '?' || c == '%' || c == '*' || c == ':' || c == '|' || c == '"'
					|| c == '<' || c == '>')
				return false;

			// Check for extended characters
			if (c > 125)
				return false;
		}

		return true;
	}

	/**
	 * Create and return a BufferedImage of the specified component as it appears
	 * on-screen.
	 */
	public static BufferedImage makeImage(Component c, boolean fromWaveformViewer)
	{
		initComponentForImage(c, fromWaveformViewer);

		if (c.getWidth() == 0 && c.getHeight() == 0)
		{
			return null;
		}

		BufferedImage image = new BufferedImage(c.getWidth(), c.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = image.createGraphics();

		g2.fillRect(0, 0, c.getWidth(), c.getHeight());

		// Pain the graphics object!
		c.paint(g2);

		completeComponentForImage(c, fromWaveformViewer);

		// Dispose of graphics object
		g2.dispose();

		return image;
	}

	/**
	 * Parse comma or space delimited double values from the provided string
	 * 
	 * @param str
	 * @return
	 */
	public static double[] parseDoubles(String str)
	{
		String[] strings = str.trim().split("\\s*(\\s|,)\\s*");
		double[] frequencies = new double[strings.length];
		int count = 0;
		for (String value : strings)
		{
			try
			{
				frequencies[count] = Double.parseDouble(value);
				count++;
			}
			catch (Exception e)
			{
			}
		}

		return Arrays.copyOf(frequencies, count);

	}

	/**
	 * Parse comma or space delimited double values from the provided string
	 * 
	 * @param str
	 * @param N   Length of the returned array
	 * @return
	 */
	public static double[] parseDoubles(String str, int N)
	{
		return Arrays.copyOf(parseDoubles(str), N);
	}

	/**
	 * Pad the start of the string to ensure that it has atleast the number of
	 * specified characters
	 * 
	 * @param string
	 * @return
	 */
	public static String prePad(String string, int count)
	{
		if (string.length() >= count)
			return string;

		StringBuffer sb = new StringBuffer();

		for (int i = string.length(); i < count; i++)
			sb.append(' ');
		sb.append(string);

		return sb.toString();
	}

	/**
	 * Print out the provided array
	 * 
	 * @param values array of values
	 * @param pw     print writer
	 */
	public static void printArray(double[] values, PrintWriter pw)
	{
		printArray(values, pw, " %17.3f");
	}

	/**
	 * Print out the provided array
	 * 
	 * @param values array of values
	 * @param pw     print writer
	 * @param format format string for each value
	 */
	public static void printArray(double[] values, PrintWriter pw, String format)
	{
		printArray(values, pw, format, 8);
	}

	/**
	 * Print out the provided array
	 * 
	 * @param values  array of values
	 * @param pw      print writer
	 * @param format  format string for each value
	 * @param lineMax maximum values per line
	 */
	public static void printArray(double[] values, PrintWriter pw, String format, int lineMax)
	{
		int N = values.length;

		for (int i = 0; i < N; ++i)
		{
			if (i % lineMax == 0 && i != 0)
				pw.println();

			pw.print(String.format(format, values[i]));
		}
	}

	/**
	 * Bring up a file chooser and save this viewer's waveform plot(s) and
	 * information fields as a PNG image.
	 */
	public static void saveImageAsPNG(BufferedImage image) throws IOException
	{
		File file = GUIUtility.showSaveDialog(null, "", "Save image as PNG", JFileChooser.FILES_ONLY,
				new String[] { "png" }, null);
		if (file == null)
			return;

		if (!file.getName().endsWith(".png"))
		{
			String filename = file.getAbsolutePath();
			file.delete();
			file = IOUtility.openFile(filename + ".png");
		}
		
		FileOutputStream fos = null;
		OutputStream out = null;
		try
		{
			fos = new FileOutputStream(file);
			out = new BufferedOutputStream(fos);
			
			EncoderUtil.writeBufferedImage(image, ImageFormat.PNG, out);
		}
		finally
		{
			if ( out != null )
				IOUtility.safeClose(out);
			if ( fos != null )
				IOUtility.safeClose(fos);
		}
	}

	/**
	 * Set the background for all components contained within the hierarchy of the
	 * provided component
	 * 
	 * @param c
	 * @param background
	 */
	public static void setBackground(Component c, Color background)
	{
		if (c == null || c instanceof JTextField || c instanceof JComboBox)
			return;

		c.setBackground(background);

		if (c instanceof Container)
			for (Component child : ((Container) c).getComponents())
				setBackground(child, background);
	}

	/**
	 * Set the default look and feel for the GUI
	 */
	public static void setDefaultLAF()
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		// Set the default font
		Font font = new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue());
		UIManager.getLookAndFeelDefaults().put("defaultFont", font);
		for (Object key : UIManager.getDefaults().keySet())
		{
			if (key.toString().toLowerCase().contains("font"))
				UIManager.put(key, font);
		}
		for (Object key : UIManager.getLookAndFeelDefaults().keySet())
		{
			if (key.toString().toLowerCase().contains("font"))
				UIManager.getLookAndFeelDefaults().put(key, font);
		}
	}

	/**
	 * Recursively set the enabled flag for all components within the hierarchy.
	 * 
	 * @param c
	 * @param value
	 */
	public static void setEnabled(Component c, boolean value)
	{
		if (c instanceof JLabel)
		{
			((JLabel) c).setEnabled(value);
			return;
		}
		else if (c instanceof JTextField)
		{
			if (((JTextField) c).isEditable())
				((JTextField) c).setEnabled(value);
			return;
		}
		else if (c instanceof JTabbedPane)
		{
			int N = ((JTabbedPane) c).getComponentCount();
			for (int i = 0; i < N; i++)
				setEnabled(((JTabbedPane) c).getComponentAt(i), value);

			return;
		}
		else if (c instanceof JTable)
		{
			((JTable) c).getTableHeader().setEnabled(value);

			return;
		}
		else if (c instanceof AbstractButton && ((AbstractButton) c).getAction() != null)
			((AbstractButton) c).getAction().setEnabled(value);
		else if (!(c instanceof JPanel))
		{
			c.setEnabled(value);
		}

		if (c instanceof Container)
			for (Component c2 : ((Container) c).getComponents())
				setEnabled(c2, value);
	}

	/**
	 * Set the font for all components contained within the hierarchy of the
	 * provided component
	 * 
	 * @param c
	 * @param font
	 */
	public static void setFont(Component c, Font font)
	{
		if (c == null)
			return;

		c.setFont(font);

		if (c instanceof Container)
			for (Component child : ((Container) c).getComponents())
				setFont(child, font);
	}

	/**
	 * Set the rich text for the provided JTextPane.
	 * 
	 * @param textPane
	 * @param text
	 */
	public static void setRTFText(JTextPane textPane, String text)
	{
		if (text == null)
			return;

		textPane.setEditorKit(new RTFEditorKit());
		textPane.setDocument(new DefaultStyledDocument());
		InputStream in = new ByteArrayInputStream(text.getBytes());

		EditorKit editorKit = textPane.getEditorKit();
		Document document = textPane.getDocument();

		try
		{
			editorKit.read(in, document, text.length());
		}
		catch (Exception e)
		{
			showExceptionDialog(null, "Error setting text", e.getMessage(), e);
		}
	}

	/**
	 * Show the provided viewer in a dialog
	 * 
	 * @param parent
	 * @param viewer
	 * @param title
	 * @return
	 */
	public static JFrame showDialog(JFrame parent, JPanel viewer, String title)
	{
		final JFrame dialog = new JFrame(title);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(viewer, BorderLayout.CENTER);
		panel.add(GUIUtility.createButtonPanel(new AbstractAction("Close")
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				dialog.setVisible(false);
				dialog.dispose();
			}
		}), BorderLayout.SOUTH);

		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setContentPane(panel);
		dialog.pack();
		dialog.setLocationRelativeTo(parent);
		dialog.setVisible(true);

		return dialog;
	}

	/**
	 * Display the specified message and exception stack trace in a
	 * {@link DetailsDialog} on the event-dispatching thread.
	 * 
	 * @param parent
	 * @param title
	 * @param message
	 * @param e
	 */
	public static String showExceptionDialog(Component parent, String title, String message, Throwable e)
	{
		Window parentWindow = (parent == null || parent instanceof Window) ? (Window) parent
				: SwingUtilities.getWindowAncestor(parent);
		Icon icon = UIManager.getIcon("OptionPane.errorIcon");

		// Convert the exception's stack trace to a string.
		Writer result = new StringWriter();
		if (e != null)
		{
			PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace();
			e.printStackTrace(printWriter);
		}
		String stackTrace = result.toString();

		if (NetMOD.isGUI())
		{
			// Message is composed of main exception message plus caused-by messages
			// Use a linked hash set so we do not include duplicate messages.
			StringBuilder stringBuilder = new StringBuilder((message == null ? "" : message));
			while (true)
			{
				if (e == null)
					break;
				e = e.getCause();
				if (e == null || e.getMessage() == null)
					break;

				stringBuilder.append(e.getMessage());
				stringBuilder.append("<br>");
			}

			final DetailsDialog dd = new DetailsDialog(parentWindow, title, icon, stringBuilder.toString(), stackTrace);

			if (SwingUtilities.isEventDispatchThread())
			{
				dd.setVisible(true);
			}
			else
			{
				SwingUtilities.invokeLater(new Runnable()
				{
					@Override
					public void run()
					{
						dd.setVisible(true);
					}
				});
			}
		}
		else
		{
			System.out.println(stackTrace);
		}

		return stackTrace;
	}

	/**
	 * Create a message dialog
	 * 
	 * @param parent
	 * @param viewer
	 * @param title
	 * @return
	 */
	public static JDialog showMessageDialog(JFrame parent, JPanel viewer, String title)
	{
		final JDialog dialog = new JDialog(parent, title);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(viewer, BorderLayout.CENTER);
		panel.add(GUIUtility.createButtonPanel(new AbstractAction("Ok")
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				dialog.setVisible(false);
				dialog.dispose();
			}
		}), BorderLayout.SOUTH);

		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setContentPane(panel);
		dialog.pack();
		dialog.setLocationRelativeTo(parent);
		dialog.setVisible(true);

		return dialog;
	}

	/**
	 * Show the Open Dialog for a JFileChooser using the provided parameters.
	 * Returns the selected file.
	 */
	public static File[] showOpenDialog(Component parent, String path, String title, int mode, boolean multiSelection,
			String[] fileTypes, JComponent accessory)
	{
		initChooser(parent, path, title, mode, multiSelection, fileTypes, accessory);

		if (accessory instanceof PropertyChangeListener)
			chooser.addPropertyChangeListener(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY,
					(PropertyChangeListener) accessory);
		else
			chooser.addPropertyChangeListener(null);

		int ret = chooser.showOpenDialog(parent);
		if (ret == JFileChooser.APPROVE_OPTION)
		{
			// Save selected current directory to property value
			Property.FILE_CHOOSER_DIRECTORY.setValue(chooser.getCurrentDirectory().getPath());
			Property.saveProperties();

			return multiSelection ? chooser.getSelectedFiles() : new File[] { chooser.getSelectedFile() };
		}

		return null;
	}

	/**
	 * Show the Save Dialog for a JFileChooser using the provided parameters Returns
	 * the selected file.
	 * 
	 * @param parent
	 * @param title
	 * @param mode
	 * @param fileTypes
	 * @return
	 */
	public static File showSaveDialog(Component parent, String path, String title, int mode, String[] fileTypes,
			JComponent accessory)
	{
		initChooser(parent, path, title, mode, false, fileTypes, accessory);

		int ret = chooser.showSaveDialog(parent);

		// Display the dialog
		if (ret == JFileChooser.APPROVE_OPTION)
		{
			// Save selected current directory to property value
			Property.FILE_CHOOSER_DIRECTORY.setValue(chooser.getCurrentDirectory().getPath());
			Property.saveProperties();

			return chooser.getSelectedFile();
		}

		return null;
	}

	/**
	 * Create a message dialog
	 * 
	 * @param parent
	 * @param viewer
	 * @param title
	 * @return
	 */
	public static JFrame showViewerDialog(JFrame parent,
			final NetModComponentViewer<? extends AbstractNetModFile> viewer, String title)
	{
		final JFrame dialog = new JFrame(title);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(viewer, BorderLayout.CENTER);
		panel.add(GUIUtility.createButtonPanel(new AbstractAction("Close")
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				dialog.setVisible(false);
				dialog.dispose();
			}
		}, new AbstractAction("Save")
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				viewer.getNetModComponent().write();
				viewer.refresh();
			}
		}, new AbstractAction("Reset")
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				viewer.getNetModComponent().read();
				viewer.refresh();
			}
		}), BorderLayout.SOUTH);

		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setContentPane(panel);
		dialog.pack();
		dialog.setLocationRelativeTo(parent);
		dialog.setVisible(true);

		return dialog;
	}

	public static Double[] toArrayDoubles(double[] values)
	{
		int N = values.length;
		Double[] array = new Double[N];

		for (int i = 0; i < N; i++)
			array[i] = values[i];

		return array;
	}
}
