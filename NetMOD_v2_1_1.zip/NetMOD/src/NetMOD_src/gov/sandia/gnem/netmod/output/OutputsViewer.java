/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.output;

import gov.sandia.gnem.netmod.gui.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 *
 */
public class OutputsViewer extends NetModComponentViewer<Outputs>
{
    private FileField _outputDir = new FileField("Simulation Output Directory", JFileChooser.DIRECTORIES_ONLY);
    private JPanel _outputPanel = new JPanel(new GridBagLayout());

    public OutputsViewer(Outputs nmc)
    {
        super(nmc, true, true);

        //  Update the viewer
        //reset(nmc);

        //  Register the controls that are monitored
        registerControls(_outputDir);
    }

    @Override
    public void apply(Outputs nmc)
    {
        nmc.setOutputDir(_outputDir.getText());
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            JComponent toolbar = GUIUtility.createToolBar();
            toolbar.add(createDifferenceButton());
            toolbar.add(createRefreshButton());
            toolbar.add(createDisplayButton());

            GUIUtility.addRow(panel, toolbar);
            GUIUtility.addRow(panel, new JLabel("Output Directory: "), _outputDir);
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, _outputPanel);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(Outputs nmc)
    {
        _outputDir.setText(nmc.getOutputDir());

        //  Remove any existing simulation viewers
        _outputPanel.removeAll();
        for (Output output : nmc.getOutputs())
        {
            NetModComponentViewer<?> viewer = output.getViewer();
            GUIUtility.addRow(_outputPanel, viewer);
        }
    }

    private JComponent createDisplayButton()
    {
        JButton button = GUIUtility.createButton(Icons.SETTINGS.getIcon());
        button.setToolTipText("Set display settings for all outputs");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
            	//  Get a default output viewer
            	Output output1 = null;
            	for (Output output2 : _nmc.getOutputs())
            	{
            		output1 = output2;
            		break;
            	}

            	if ( output1 == null )
            		return;
            	
            	OutputViewer viewer1 = new OutputViewer(output1);
            	viewer1.reset(output1);
            	
            	//  Display the output viewer Viewer
            	int result = JOptionPane.showConfirmDialog(null, viewer1.getExpandedPanel(), "Output Display Settings", JOptionPane.OK_CANCEL_OPTION);
            	if ( result != JOptionPane.OK_OPTION )
            		return;
            	
            	//  Apply the settings to all of the outputs
            	for (Output output2 : _nmc.getOutputs())
            	{
            		OutputViewer viewer2 = (OutputViewer) output2.getViewer();
            		viewer2.reset(output2);
            		
            		if ( viewer2 != null )
            			viewer2.sync(viewer1);	
            	}
            }
        });

        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.add(button);

        return toolBar;
    }

    private JComponent createDifferenceButton()
    {
        JButton button = GUIUtility.createButton(Icons.DIFFERENCE.getIcon());
        button.setToolTipText("Difference two outputs");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
            	new OutputDifferenceViewer(NetMOD.getFrame(), _nmc);
            }
        });

        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.add(button);

        return toolBar;
    }

    private JComponent createRefreshButton()
    {
        JButton button = GUIUtility.createButton(Icons.REFRESH.getIcon());
        button.setToolTipText("Refresh the outputs");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                _nmc.getOutputs().clear();

                //  Update the viewer
                refresh();
            }
        });

        JComponent toolBar = GUIUtility.createToolBar();
        toolBar.add(button);

        return toolBar;
    }
}
