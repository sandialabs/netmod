/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Hashtable;

/**
 * A JSlider that controls the transparency of an image.
 * Displays the selected transparency within a tooltip as the
 * slider is dragged.
 * 
 * @author bjmerch
 */
public class TransparencySlider extends JSlider
{
    private Hashtable<Integer, JLabel> labelTable = null;
    
    public TransparencySlider()
    {
        super(0, 100, 0);
        
        // Add a tooltip to the slider
        addChangeListener(new ChangeListener()
        {
            public void stateChanged(ChangeEvent ce)
            {
                //  Some platforms result in a NPE when first created
                try
                {
                    TransparencySlider.this.setToolTipText(getValue() + "%");

                    hideToolTip(TransparencySlider.this);
                    postToolTip(TransparencySlider.this);
                }
                catch (Exception e)
                {}
            }

            private void postToolTip(JComponent comp)
            {
                if ( comp == null )
                    return;
                
                Action action = comp.getActionMap().get("postTip");
                if (action == null) // no tooltip
                    return;
                
                ActionEvent ae = new ActionEvent(comp, ActionEvent.ACTION_PERFORMED, "postTip", EventQueue
                        .getMostRecentEventTime(), 0);
                action.actionPerformed(ae);
            }

            private void hideToolTip(JComponent comp)
            {
                if ( comp == null )
                    return;
                
                Action action = comp.getActionMap().get("hideTip");
                if (action == null) // no tooltip
                    return;
                
                ActionEvent ae = new ActionEvent(comp, ActionEvent.ACTION_PERFORMED, "hideTip", EventQueue
                        .getMostRecentEventTime(), 0);
                action.actionPerformed(ae);
            }
        });

        // Customize the slider labels
        labelTable = new Hashtable<Integer,JLabel>();
        labelTable.put(0, new JLabel("0%"));
        labelTable.put(25, new JLabel("25%"));
        labelTable.put(50, new JLabel("50%"));
        labelTable.put(75, new JLabel("75%"));
        labelTable.put(100, new JLabel("100%"));

        setLabelTable(labelTable);
        setPaintLabels(true);
        setMajorTickSpacing(25);
        setPaintTicks(true);
    }
    
    public void setEnabled(boolean value)
    {
        super.setEnabled(value);
        
        if ( labelTable != null )
            for (JLabel label : labelTable.values())
                label.setEnabled(value);
    }
    
    public void setTransparency(double value)
    {
        setValue((int) (100-value * 100));
    }
    
    public double getTransparency()
    {
        return (100-getValue()) / 100.0;
    }
}
