/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

/**
 * Represents a complex sequence
 * 
 * @author bjmerch
 * 
 */
public class ComplexArray implements Cloneable
{
    /**
     * Construct a complex array from the provided magnitude and phase values
     * 
     * @param magnitude
     * @param phase
     * @return
     */
    public static ComplexArray polar(double[] magnitude, double[] phase)
    {
        int N = Math.min(magnitude.length, phase.length);
        
        double[] real = new double[N];
        double[] imag = new double[N];
        
        for (int i=0; i<N; i++)
        {
            real[i] = Complex.getReal(magnitude[i], phase[i]);
            imag[i] = Complex.getImaginary(magnitude[i], phase[i]);
        }
        
        return new ComplexArray(real, imag);
    }
    /**
     * @param ps
     * @return
     */
    public static boolean test(PrintStream ps)
    {
        return true;
    }

    private double[] _real = null;

    private double[] _imag = null;

    /**
     * @param p11
     */
    public ComplexArray(ComplexArray ca)
    {
        this(Arrays.copyOf(ca.getReal(), ca.getLength()),
                Arrays.copyOf(ca.getImaginary(), ca.getLength()));
    }

    /**
     * @param data
     */
    public ComplexArray(double[] real)
    {
        this(real, new double[real.length]);
    }

    /**
     * Wrap the provided real and imaginary arrays in a complex array
     * 
     * @param real
     * @param imaginary
     */
    public ComplexArray(double[] real, double[] imag)
    {
        _real = real;
        _imag = imag;
    }

    /**
     * Create an uninitialized complex array
     * 
     * @param N
     */
    public ComplexArray(int N)
    {
        this(new double[N], new double[N]);
    }
    
    /**
     * Create a complex array from the list of complex values
     * 
     * @param values
     */
    public ComplexArray(List<Complex> values)
    {
        this(values.size());
        
        int N = values.size();
        for (int i=0; i<N; i++)
            set(i, values.get(i));
    }
    
    /**
     * Add the provided complex value to each of the values in this complex array
     * 
     * @param value
     */
    public final void add(Complex c)
    {
        int i;
        int N = getLength();

        double[] real1 = getReal();
        double[] imag1 = getImaginary();
        double real = c.getReal();
        double imag = c.getImaginary();
        
        for (i = 0; i < N; i++)
        {
            real1[i] += real;
            imag1[i] += imag;
        }
    }

    /**
     * Add the provided complex sequence to this complex sequence.
     * 
     * @param c
     */
    public void add(ComplexArray c)
    {
        add(c, c.getLength());
    }

    /**
     * Add the first N entries in the provided complex sequence to this complex sequence.
     * 
     * @param c
     */
    public final void add(ComplexArray c, int N)
    {
        int i;

        double[] real1 = getReal();
        double[] imag1 = getImaginary();
        
        double[] real2 = c.getReal();
        double[] imag2 = c.getImaginary();
        
        if (N > getLength() || N > c.getLength())
        {
            System.out.println("Error in Complex.add, the data vectors are shorter than the specified length");
            return;
        }

        for (i = 0; i < N; i++)
        {
            real1[i] += real2[i];
            imag1[i] += imag2[i];
        }
    }

    /**
     * Add the provided real value to the complex array.
     * 
     * @param value
     */
    public final void add(double value)
    {
        int i;
        double[] real = getReal();
        int N = real.length;

        for (i = 0; i < N; i++)
            real[i] += value;
    }

    /**
     * For each entry in the provided complex array, add the entry
     * value to this entire complex array, multiply the added sequence,
     * and then return the resulting array.
     * 
     * @param value
     * @return
     */
    public final ComplexArray addMultiply(ComplexArray value)
    {
        int N = value.getLength();
        int M = getLength();
        
        ComplexArray result = new ComplexArray(N);
        
        if ( M == 0 )
        {
            result.fill(1, 0);
            return result;
        }
        
        for (int i=0; i<N; i++)
        {   
            double v_r = value.getReal()[i];
            double v_i = value.getImaginary()[i];
            
            double x = _real[0] + v_r;
            double y = _imag[0] + v_i;

            for (int j=1; j<M; j++)
            {
                double a = _real[j] + v_r;
                double b = _imag[j] + v_i;
                double c = x;
                double d = y;
                
                x = a * c - b * d;
                y = a * d + b * c;
            }
            
            result.set(i, x, y);
        }
        
        return result;
    }

    /**
     * Clear out any values stored in this complex sequence
     */
    public final void clear()
    {
        Arrays.fill(getReal(), 0);
        Arrays.fill(getImaginary(), 0);
    }

    @Override
    public Object clone()
    {
    	ComplexArray ca;
		try
		{
			ca = (ComplexArray) super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			ca = new ComplexArray(this);
		} 
    	
    	ca._real = Arrays.copyOf(_real, _real.length);    	
    	ca._imag = Arrays.copyOf(_imag, _imag.length);
    	
    	return ca;
    }

    /**
     * Conjugage this complex sequence.  The
     * method returns a reference to this object.
     * 
     * @return this
     */
    public final ComplexArray conjugate()
    {
        int i;
        
        double[] imag = getImaginary();
        int N = imag.length;
        
        for (i = 0; i < N; i++)
            imag[i] = -imag[i];
        
        return this;
    }
    
    /**
     * Divide this complex sequence by the provided complex sequence.
     * 
     * @param c
     * @return
     */
    public final void divide(ComplexArray complex)
    {
        int i;
        int N = getLength();

        if (N != complex.getLength())
        {
            System.out.println("Error in ComplexArray.divide, the data vectors (" + N + "," + complex.getLength() + ") are not the same length.");
            return;
        }

        double[] r1 = getReal();
        double[] i1 = getImaginary();
        double[] r2 = complex.getReal();
        double[] i2 = complex.getImaginary();

        for (i = 0; i < N; i++)
        {
            double a = r1[i];
            double b = i1[i];
            double c = r2[i];
            double d = i2[i];
            
            double den = 1.0 / ( c * c + d * d );
            
            r1[i] = ( a * c + b * d ) * den;
            i1[i] = ( b * c - a * d ) * den;
        }
    }

    /**
     * Divide the i'th entry in the complex array by the provided complex value.
     * 
     * @param i
     * @param c
     */
    public final void divide(int i, Complex c)
    {
        set(i, get(i).divide(c));
    }

    /**
     * Divide this complex sequence by the complex conjugate of the provided complex sequence.
     * 
     * @param c
     * @return
     */
    public final void divideConjugate(ComplexArray complex)
    {
        int i;
        int N = getLength();
        
        if (N != complex.getLength())
        {
            System.out.println("Error in Complex.divide, the data vectors are not the same length");
            return;
        }

        double[] r1 = getReal();
        double[] i1 = getImaginary();
        double[] r2 = complex.getReal();
        double[] i2 = complex.getImaginary();
        
        for (i = 0; i < N; i++)
        {
            double a = r1[i];
            double b = i1[i];
            double c = r2[i];
            double d = -i2[i];
            
            double den = 1.0 / ( c * c + d * d );
            
            r1[i] = ( a * c + b * d ) * den;
            i1[i] = ( b * c - a * d ) * den;
        }
    }
    
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (!(o instanceof ComplexArray))
            return false;

        ComplexArray c = (ComplexArray) o;
        
        return Arrays.equals(getReal(), c.getReal()) && 
        		Arrays.equals(getImaginary(), c.getImaginary());
    }

    /**
     * Compute the expotential value of each entry in the complex array, e to the X.
     * 
     */
    public final void exp()
    {
        int i;
        int N = getLength();
        
        double real[] = getReal();
        double imag[] = getImaginary();

        for (i = 0; i < N; i++)
        {
            double a = real[i];
            double b = imag[i];

            double r = StrictMath.exp(a);
            
            real[i] = r * StrictMath.cos(b);
            imag[i] = r * StrictMath.sin(b);
        }
    }

    /**
     * Fill the complex array with the provided complex value
     * 
     * @param c
     */
    public final void fill(Complex c)
    {
        fill(c.getReal(), c.getImaginary());
    }

    /**
     * Fill the complex array with the provided complex value
     * 
     * @param real
     * @param imag
     */
    public final void fill(double real, double imag)
    {
        Arrays.fill(getReal(), real);
        Arrays.fill(getImaginary(), imag);
    }

    /**
     * Get the complex value at index i
     * 
     * @param i
     * @return
     */
    public final Complex get(int i)
    {
        return new Complex(getReal()[i], getImaginary()[i]);
    }
    
    /**
     * Get the array containing the imaginary portion of the complex series.
     * 
     * @return
     */
    public final double[] getImaginary()
    {
        return _imag;
    }

    /**
     * @return
     */
    public final int getLength()
    {
        return getReal().length;
    }

    /**
     * @return
     */
    public final double[] getMagnitude()
    {
        return getMagnitude(0, getLength());
    }

    /**
     * @param i
     * @return
     */
    public final double getMagnitude(int i)
    {
        return Complex.getMagnitude(_real[i], _imag[i]);
    }

    /**
     * Get the magnitude of this complex array
     * 
     * @param start
     * @param end
     * @return
     */
    public final double[] getMagnitude(int start, int end)
    {
        int i;
        end = StrictMath.min(end, getLength());
        int N = end-start;
        if ( N < 0 )
            return new double[0];
        
        double[] real = getReal();
        double[] imag = getImaginary();
        
        double[] mag = new double[N];
        for (i=start; i<end; i++)
            mag[i-start] = Complex.getMagnitude(real[i], imag[i]);
        
        return mag;
    }

    /**
     * Get the phase of this complex array
     * 
     * @return
     */
    public final double[] getPhase()
    {
        int i;
        int N = getLength();
        
        double[] real = getReal();
        double[] imag = getImaginary();
        
        double[] phase = new double[N];
        for (i=0; i<N; i++)
            phase[i] = Complex.getPhase(real[i], imag[i]);
        
        return phase;
    }
    
    /**
     * @param i
     * @return
     */
    public final double getPhase(int i)
    {
        return Complex.getPhase(_real[i], _imag[i]);
    }
    
    /**
     * Get the array containing the real portion of the complex series.
     * 
     * @return
     */
    public final double[] getReal()
    {
        return _real;
    }

    /**
     * Convert this complex array to its inverse
     */
    public final void inverse()
    {
        int i;
        int N = getLength();
        double[] real = getReal();
        double[] imag = getImaginary();

        for (i = 0; i < N; i++)
        {
            double c = real[i];
            double d = imag[i];
            
            double den = c * c + d * d;
            
            if ( den > 0 )
            {
                real[i] = c / den;
                imag[i] = -d / den;
            }
        }
    }
    
    /**
     * Multiply all of the elements in this complex array and return the complex result
     * 
     * @return
     */
    public final Complex multiply()
    {
        int i;
        int N = getLength();
        
        if ( N == 0 )
            return new Complex(1,0);
        
        double[] real = getReal();
        double[] imag = getImaginary();
        
        double x = real[0];
        double y = imag[0];

        for (i = 1; i < N; i++)
        {
            double a = real[i];
            double b = imag[i];
            double c = x;
            double d = y;
            
            x = a * c - b * d;
            y = a * d + b * c;
        }
        
        return new Complex(x, y);
    }
    
    /**
     * Multiply this complex valued sequence by the provided complex valued
     * sequence
     * 
     * @param tmp2
     */
    public final void multiply(ComplexArray complex)
    {
        int i;
        int N = getLength();

        if (N != complex.getLength())
        {
            System.out.println("Error in ComplexArray.multiply, the data vectors (" + N + "," + complex.getLength() + ") are not the same length.");
            return;
        }
        
        double[] real1 = getReal();
        double[] imag1 = getImaginary();
        double[] real2 = complex.getReal();
        double[] imag2 = complex.getImaginary();

        for (i = 0; i < N; i++)
        {
            double a = real1[i];
            double b = imag1[i];
            double c = real2[i];
            double d = imag2[i];
            
            real1[i] = a * c - b * d;
            imag1[i] = a * d + b * c;
        }
    }

    /**
     * Multiply this complex valued sequence by the provided real value.
     * 
     * @param value
     */
    public final void multiply(double value)
    {
        int i;
        int N = getLength();

        double[] real = getReal();
        double[] imag = getImaginary();

        for (i = 0; i < N; i++)
        {
            real[i] *= value;
            imag[i] *= value;
        }
    }
    
    /**
     * Multiply the i'th entry in the complex array by the provided value
     * 
     * @param i
     * @param c
     */
    public final void multiply(int i, Complex c)
    {
        multiply(i, c.getReal(), c.getImaginary());
    }


    /**
     * Multiply the i'th entry in the complex array by the provided double value
     * 
     * @param i index
     * @param value value
     */
    public final void multiply(int i, double value)
    {
        getReal()[i] *= value;
        getImaginary()[i] *= value;
    }

    /**
     * Multiply the i'th entry in the complex array by the provided value
     * 
     * @param i
     * @param real
     * @param imag
     */
    public final void multiply(int i, double real, double imag)
    {
        double a = getReal()[i];
        double b = getImaginary()[i];
        
        getReal()[i] = real * a - imag * b;
        getImaginary()[i] = real * b + imag * a;
    }

    /**
     * Multiply this complex valued sequence by the complex conjuage of the provided complex valued
     * sequence
     * 
     * @param tmp2
     */
    public final void multiplyConjugate(ComplexArray complex)
    {
        int i;
        int N = getLength();

        if (N != complex.getLength())
        {
            System.out.println("Error in ComplexArray.multiplyConjugate, the data vectors are not the same length");
            return;
        }
        
        double[] real1 = getReal();
        double[] imag1 = getImaginary();
        double[] real2 = complex.getReal();
        double[] imag2 = complex.getImaginary();

        for (i = 0; i < N; i++)
        {
            double a = real1[i];
            double b = imag1[i];
            double c = real2[i];
            double d = - imag2[i];
            
            real1[i] = a * c - b * d;
            imag1[i] = a * d + b * c;
        }
    }


    /**
     * Negate the array
     */
    public final void negate()
    {
        int i;
        int N = getLength();
        
        double[] real = getReal();
        double[] imag = getImaginary();

        for (i = 0; i < N; i++)
        {
            real[i] = - real[i];
            imag[i] = - imag[i];
        }
    }


    /**
     * Compute the norm of the complex vector
     * 
     * @return
     */
    public final double norm()
    {
        int i;
        int N = getLength();
        
        double[] real = getReal();
        double[] imag = getImaginary();
        double norm = 0;
        
        for (i=0; i<N; i++)
        {
            double a = real[i];
            double b = imag[i];
            
            norm += a * a + b * b;
        }
        
        norm = StrictMath.sqrt(norm);
        
        return norm;
    }
    
    /**
     * Set this complex array to the same values as the provided complex array
     * 
     * @param fT1
     */
    public final void set(ComplexArray value)
    {
        set(0, value, 0);
    }

    /**
     * Set the complex value at index i
     * 
     * @param i
     * @param complex
     */
    public final void set(int i, Complex c)
    {
        set(i, c.getReal(), c.getImaginary());
    }
    
    /**
     * Set this complex array to the same values as the provided complex array
     * 
     * @param i Starting index in this complex array
     * @param value Complex array to copy from
     * @param j Starting index in the comples array to copy from
     */
    public final void set(int i, ComplexArray value, int j)
    {
        int N = StrictMath.min(getLength()-i, value.getLength()-j);
        
        System.arraycopy(value._real, j, _real, i, N);
        System.arraycopy(value._imag, j, _imag, i, N);
    }

    /**
     * Set the complex value at index i
     * 
     * @param i
     * @param real
     * @param imaginary
     */
    public final void set(int i, double real, double imaginary)
    {
        getReal()[i] = real;
        getImaginary()[i] = imaginary;
    }

    /**
     * Take the square root of this complex sequence
     */
    public final void sqrt()
    {
        int i;
        int N = getLength();

        double[] real = getReal();
        double[] imag = getImaginary();
        
        for (i = 0; i < N; i++)
        {
            double r = Complex.getMagnitude(real[i], imag[i]);
            double theta = Complex.getPhase(real[i], imag[i]);
            
            r = StrictMath.sqrt(r);
            theta = theta / 2.0;
            
            real[i] = Complex.getReal(r, theta);
            imag[i] = Complex.getImaginary(r, theta);
        }
    }

    /**
     * Subtract the provided complex array from this complex array
     * 
     * @param complex
     */
    public final void subtract(ComplexArray complex)
    {
        int i;
        int N = getLength();

        if (N != complex.getLength())
        {
            System.out.println("Error in Complex.subtract, the data vectors are not the same length");
            return;
        }

        N = StrictMath.min(N, complex.getLength());
        
        double[] real1 = getReal();
        double[] imag1 = getImaginary();
        double[] real2 = complex.getReal();
        double[] imag2 = complex.getImaginary();
        
        for (i = 0; i < N; i++)
        {
            real1[i] -= real2[i];
            imag1[i] -= imag2[i];
        }
    }
    
    /**
     * Return the sum of the complex sequence
     * 
     * @return
     */
    public final Complex sum()
    {
        int i;
        int N = getLength();
        
        double real[] = getReal();
        double imag[] = getImaginary();
        
        double a = 0;
        double b = 0;

        for (i = 0; i < N; i++)
        {
            a += real[i];
            b += imag[i];
        }
        
        return new Complex(a, b);
    }

    /**
     * Add the first array times the complex conjugate of the second array to this array:
     * 
     *   this += array1 * conjugate(array2);
     * 
     * @param array1 first array
     * @param array2 second array
     */
    public final void sumMultiplyConjugate(ComplexArray array1, ComplexArray array2, int N)
    {
        int i;
        
        if (N > getLength() || N > array1.getLength() || N > array2.getLength())
        {
            System.out.println("Error in Complex.sumConjugateMultiply, the requested array length operation is longer than the available arrays");
            return;
        }

        double[] real = getReal();
        double[] imag = getImaginary();
        double[] real1 = array1.getReal();
        double[] imag1 = array1.getImaginary();
        double[] real2 = array2.getReal();
        double[] imag2 = array2.getImaginary();
        
        for (i = 0; i < N; i++)
        {
            double a = real1[i];
            double b = imag1[i];
            double c = real2[i];
            double d = - imag2[i];
            
            real[i] += a * c - b * d;
            imag[i] += a * d + b * c;
        }
    }

    @Override
    public String toString()
    {
        StringBuilder str = new StringBuilder();
        int N = getLength();
        
        str.append("Complex Array of length ").append(N).append('\n');
        for (int i=0; i<N; i++)
            str.append("  (").append(_real[i]).append(",").append(_imag[i]).append(")").append('\n');
        
        return str.toString();
    }
	@Override
    public int hashCode()
    {
		return Arrays.hashCode(getReal()) + Arrays.hashCode(getImaginary());
    }
}
