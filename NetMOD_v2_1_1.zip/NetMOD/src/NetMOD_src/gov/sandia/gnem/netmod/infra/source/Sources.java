package gov.sandia.gnem.netmod.infra.source;

import java.util.Collection;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.ExplosionType;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

public class Sources extends gov.sandia.gnem.netmod.source.Sources
{
    private ExplosionType _explosionType = ExplosionType.CHEMICAL;
    
	public Sources(NetModComponent parent, Collection<? extends Phase> phases)
	{
		super(parent, phases);
	}

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new SourcesViewer(this);
    }

    public ExplosionType getExplosionType()
    {
	    return _explosionType;
    }

	public void setExplosionType(ExplosionType explosionType)
    {
	    _explosionType = explosionType;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setExplosionType(parameters.get(NetSimParameters.explosionType));
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);

        parameters.set(NetSimParameters.explosionType, getExplosionType());
    }
}
