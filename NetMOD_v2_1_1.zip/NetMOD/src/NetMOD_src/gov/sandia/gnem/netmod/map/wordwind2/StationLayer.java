/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.AnnotationAttributes;
import gov.nasa.worldwind.render.GlobeAnnotation;
import gov.nasa.worldwind.render.PatternFactory;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Set;

/**
 * @author bjmerch
 *
 */
class StationLayer extends RenderableLayer implements Layer<Receivers>
{
    private Receivers _receivers;
    private DISPLAY _display = DISPLAY.ALL;
    
    protected StationLayer(Receivers data)
    {
        
        setPickEnabled(true);
        
        //  Set the data
        setNMC(data);
    }
    
    @Override
    public DISPLAY getDisplay()
    {
        return _display;
    }
    
    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public String getName()
    {
        return "Stations";
    }

    @Override
    public Receivers getNMC()
    {
        return _receivers;
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
        _display = display;
    }

    @Override
    public void setNMC(Receivers data)
    {
        _receivers = data;

        Color disabledColor = Property.MAP_STATION_DISABLED_COLOR.getColorValue();
        Color enabledColor = Property.MAP_STATION_ENABLED_COLOR.getColorValue();
        int enabledSize = (int) Property.MAP_STATION_ENABLED_POINTSIZE.getFloatValue();
        int disabledSize = (int) Property.MAP_STATION_DISABLED_POINTSIZE.getFloatValue();
        Font font = new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue());
        
        //  Update the renderer attributes
        AnnotationAttributes rendererAttributes = new AnnotationAttributes();
        rendererAttributes.setAdjustWidthToText(AVKey.SIZE_FIT_TEXT);
        rendererAttributes.setBorderWidth(0);
        rendererAttributes.setCornerRadius(0);
        rendererAttributes.setBackgroundColor(new Color(0,0,0,0));
        rendererAttributes.setScale(1); 
        rendererAttributes.setImageRepeat(AVKey.REPEAT_NONE);       
        rendererAttributes.setFont(font);
        
        BufferedImage station_ss_enabled = PatternFactory.createPattern(PatternFactory.PATTERN_CIRCLE, new Dimension(Math.max(enabledSize - 4, 1), Math.max(enabledSize - 4, 1)), 1f, enabledColor);
        BufferedImage station_ss_disabled = PatternFactory.createPattern(PatternFactory.PATTERN_CIRCLE, new Dimension(Math.max(disabledSize - 4, 1), Math.max(disabledSize - 4, 1)), 1f, disabledColor);
        BufferedImage station_ar_enabled = PatternFactory.createPattern(PatternFactory.PATTERN_TRIANGLE_UP, new Dimension(enabledSize, enabledSize), 1f, enabledColor);
        BufferedImage station_ar_disabled = PatternFactory.createPattern(PatternFactory.PATTERN_TRIANGLE_UP, new Dimension(disabledSize, disabledSize), 1f,  disabledColor);
        
        //  Remove all renderables
        removeAllRenderables();
        
        //  Get the list of station names included in the network
        Set<Station> included = _receivers.getNetwork().getStations();
        
        //  Re-add any features
        for (Station station : _receivers.getStations().getStations())
        {
            Point.Double p = station.getLocation();
            Position position = Position.fromDegrees(p.getLatitude(), p.getLongitude());

            boolean isArray = station.getStationType().equalsIgnoreCase("ar") || station.getStationType().equalsIgnoreCase("hydrophone");
         
            GlobeAnnotation ga = new GlobeAnnotation(station.getName(), position, rendererAttributes);
            
            ga.setValue("Name", station.getName());
            ga.setValue("Latitude", position.getLatitude());
            ga.setValue("Longitude", position.getLongitude());
            ga.setValue("StationType", station.getStationType());

            ga.getAttributes().setLeader( isArray ? PatternFactory.PATTERN_TRIANGLE_UP : PatternFactory.PATTERN_CIRCLE );
            
            if ( included.contains(station) )
            {
            	ga.getAttributes().setImageOffset(new java.awt.Point(enabledSize, 0));
                ga.getAttributes().setInsets(new Insets(0, 2 * enabledSize, 0, 0));
                ga.getAttributes().setDrawOffset(new java.awt.Point(enabledSize,-enabledSize));
                ga.getAttributes().setTextColor(Property.MAP_STATION_ENABLED_LABEL_COLOR.getColorValue());
            	
                if ( isArray )           
                    ga.getAttributes().setImageSource(station_ar_enabled);
                else
                    ga.getAttributes().setImageSource(station_ss_enabled);

                if ( _display == DISPLAY.ALL || _display == DISPLAY.SELECTED )
                    addRenderable(ga);
            }
            else
            {
            	ga.getAttributes().setImageOffset(new java.awt.Point(disabledSize, 0));
                ga.getAttributes().setInsets(new Insets(0, 2 * disabledSize, 0, 0));
                ga.getAttributes().setDrawOffset(new java.awt.Point(disabledSize,-disabledSize));
                ga.getAttributes().setTextColor(Property.MAP_STATION_DISABLED_LABEL_COLOR.getColorValue());
            	
                if ( isArray )     
                    ga.getAttributes().setImageSource(station_ar_disabled);   
                else                   
                    ga.getAttributes().setImageSource(station_ss_disabled);       
                
                if ( _display == DISPLAY.ALL || _display == DISPLAY.NOT_SELECTED )
                    addRenderable(ga);
            }
        }
    }

    @Override
    public void setVisible(boolean value)
    {
        setEnabled(value);
    }
}
