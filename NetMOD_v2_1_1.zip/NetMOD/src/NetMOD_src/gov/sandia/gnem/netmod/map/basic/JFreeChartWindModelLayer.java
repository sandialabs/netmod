/**
 * 
 */
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.geometry.Point.Double;
import gov.sandia.gnem.netmod.gui.AbstractVisibleXYDataset;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.renderer.xy.VectorRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.Vector;
import org.jfree.data.xy.VectorXYDataset;
import org.jfree.data.xy.XYDataset;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class JFreeChartWindModelLayer extends AbstractVisibleXYDataset implements VectorXYDataset, Layer<WindModel>, JFreeChartLayer<WindModel>
{
    private VectorRenderer _renderer = new VectorRenderer();
    private WindModel _windModel;
    private List<Point.Double> _locations = new ArrayList<Point.Double>();
    private List<Vector> _vectors = new ArrayList<Vector>();

    protected JFreeChartWindModelLayer(WindModel data)
    {
        //  Set the data
        setNMC(data);
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public int getItemCount(int arg0)
    {
        if ( !isVisible() )
            return 0;
        
        return _locations.size();
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public WindModel getNMC()
    {
        return _windModel;
    }

    /**
     * @return
     */
    public XYItemRenderer getRenderer(int index)
    {
        _renderer.setSeriesPaint(0, Property.MAP_BOUNDARIES_LINE_COLOR.getColorValue());
        _renderer.setBaseItemLabelsVisible(false);
        _renderer.setBaseToolTipGenerator(new XYToolTipGenerator()
        {
            @Override
            public String generateToolTip(XYDataset dataset, int series, int item)
            {
                if ( dataset instanceof JFreeChartWindModelLayer )
                {
                    Vector v = _vectors.get(item);
                    return "<html>N: " + (Math.round(v.getY()*1000.0)/1000.0) + " m/s<br>E: " + 
                    (Math.round(v.getX()*1000.0)/1000.0) + " m/s</html>";
                }
                
                return null;
            }});
        
        return _renderer;
    }

    @Override
    public int getSeriesCount()
    {
        return 1;
    }

    @Override
    public Comparable getSeriesKey(int series)
    {
        return "Wind Model";
    }

    @Override
    public Vector getVector(int series, int item)
    {
        return new Vector(getVectorXValue(series, item), getVectorYValue(series, item));
    }

    @Override
    public double getVectorXValue(int series, int item)
    {
        Vector v = _vectors.get(item);
        double scale = v.getLength();
        scale = 2 * Math.log(scale+1) / scale;
        
        return scale * v.getX();
    }

    @Override
    public double getVectorYValue(int series, int item)
    {
        Vector v = _vectors.get(item);
        double scale = v.getLength();
        scale = 2 * Math.log(scale+1) / scale;
        
        return scale * v.getY();
    }

    @Override
    public Number getX(int series, int item)
    {
        return _locations.get(item).getLongitude();
    }
    
    @Override
    public Number getY(int series, int item)
    {
        return _locations.get(item).getLatitude();
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
    }

    @Override
    public void setNMC(WindModel data)
    {
        _windModel = data;
        
        _locations.clear();
        _vectors.clear();

        //  Generate a set of locations and vetors across the globe
        List<Complex> vectors = new ArrayList<Complex>();
        for (double lon = -180; lon <= 180; lon += 10)
            for (double lat = -80; lat <= 80; lat += 10)
            {
            	Double p = new Point.Double(lat, lon);
            	
            	_locations.add(p);
            	vectors.add(_windModel.getWindVelocity(WindModel.ALTITUDE_KM, p));
            }
        
        //  Compute the JFreeChart vectors
        int N = _locations.size();
        for (int i=0; i<N; i++)
        {
            Complex v = vectors.get(i);
            
            _vectors.add(new Vector(v.getReal(), v.getImaginary()));
        }
    }
}

