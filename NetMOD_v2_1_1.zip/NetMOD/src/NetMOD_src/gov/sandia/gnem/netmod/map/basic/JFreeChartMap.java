/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.Map;
import gov.sandia.gnem.netmod.map.MapPlugin;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import org.jfree.chart.annotations.XYDataImageAnnotation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Basic Map based upon JFreeChart
 * 
 * @author bjmerch
 *
 */
public class JFreeChartMap extends AbstractNetModComponent implements Map
{
    private class JFreeChartMapViewer extends NetModComponentViewer<JFreeChartMap>
    {
        Component leftGlue = new JLabel(" ");
        Component rightGlue = new JLabel(" ");
        Component topGlue = new JLabel(" ");
        Component bottomGlue = new JLabel(" ");

        /**
         * @param nmc
         */
        public JFreeChartMapViewer(JFreeChartMap map)
        {
            super(map);

            _chartViewer = new ChartViewer(true, true, true, false, true, true);
            XYPlot plot = _chartViewer.getPlot();
            
            //  Configure the axis
            ValueAxis domain = plot.getDomainAxis();
            domain.setLabel("Longitude (degrees)");
            domain.setRange(-180, 180);
            plot.setDomainGridlinesVisible(true);

            ValueAxis range = plot.getRangeAxis();
            range.setLabel("Latitude (degrees)");
            range.setRange(-90, 90);
            plot.setRangeGridlinesVisible(true);

            //  Add a listener to force the map to be equally spaced in latitude and longitude
            _chartViewer.getChart().getLegend().setVisible(false);
            _chartViewer.getChartPanel().addComponentListener(new ComponentAdapter()
            {
                public void componentResized(ComponentEvent e)
                {
                    rescaleMap();
                }
            });
            
            domain.addChangeListener(new AxisChangeListener()
            {

                @Override
                public void axisChanged(AxisChangeEvent arg0)
                {
                    rescaleMap();
                }
                
            });
            
            range.addChangeListener(new AxisChangeListener()
            {

                @Override
                public void axisChanged(AxisChangeEvent arg0)
                {
                    rescaleMap();
                }
                
            });

            //  Add topography layer
            try
            {
                //  Get the topography file
                File file = IOUtility.findFile(IOUtility.openFile(Property.MAP_TOPOGRAPHY.getValue()));

                //  Load the file, if it exists
                if (file.exists())
                {
                    Image image = Toolkit.getDefaultToolkit().createImage(file.toURI().toURL());
                    
                    XYDataImageAnnotation topo = new XYDataImageAnnotation(image, -180, -90, 360, 180, true);
                    
                    DefaultXYDataset dataset = new DefaultXYDataset();
                    XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
                    renderer.addAnnotation(topo, org.jfree.ui.Layer.BACKGROUND);

                    _chartViewer.getPlot().setDataset(0, dataset);
                    _chartViewer.getPlot().setRenderer(0, renderer);
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            SwingUtilities.updateComponentTreeUI(JFreeChartMapViewer.this);
                        }

                    });
                }
            }
            catch (Exception e)
            {
                System.out.println("Error adding topography to map..." + e.getMessage());
                e.printStackTrace();
            }
            
            JPanel mapPanel = new JPanel(new BorderLayout());
            mapPanel.add(_chartViewer, BorderLayout.CENTER);
            mapPanel.add(topGlue, BorderLayout.NORTH);
            mapPanel.add(bottomGlue, BorderLayout.SOUTH);
            mapPanel.add(leftGlue, BorderLayout.WEST);
            mapPanel.add(rightGlue, BorderLayout.EAST);

            setLayout(new BorderLayout());
            add(_chartViewer.getToolBar(), BorderLayout.NORTH);
            add(mapPanel, BorderLayout.CENTER);
        }

        @Override
        public JPanel getExpandedPanel()
        {
            return new JPanel();
        }
        
        /**
         * Rescale the map to keep the axes square
         * 
         */
        private void rescaleMap()
        {
            Dimension dim = JFreeChartMapViewer.this.getSize();

            XYPlot plot = _chartViewer.getPlot();
            ValueAxis domain = plot.getDomainAxis();
            ValueAxis range = plot.getRangeAxis();

            double xResolution = domain.getRange().getLength() / dim.width;
            double yResolution = range.getRange().getLength() / dim.height;

            double resolution = Math.max(xResolution, yResolution);

            //  Set the map dimensions
            int height = (int) (range.getRange().getLength() / resolution);
            int width = (int) (domain.getRange().getLength() / resolution);

            _chartViewer.setSize(width, height);

            //  Allocate the remaining height and width to the glue

            topGlue.setPreferredSize(new Dimension(dim.width, (dim.height - height) / 2));
            bottomGlue.setPreferredSize(new Dimension(dim.width, (dim.height - height) / 2));
            rightGlue.setPreferredSize(new Dimension((dim.width - width) / 2, height));
            leftGlue.setPreferredSize(new Dimension((dim.width - width) / 2, height));
            
            _chartViewer.getChart().fireChartChanged();
            SwingUtilities.updateComponentTreeUI(JFreeChartMapViewer.this);
        }
    }

    static String _type = "Basic";

    static
    {
        MapPlugin.getPlugin().registerComponent(_type, JFreeChartMap.class);
    }

    private ChartViewer _chartViewer;
    
    private List<Layer> _layers = new ArrayList<Layer>();

    //  Cache layer references
    private Layer<EpicenterGrid> _epicenterLayer = null;
    private Layer _mediaGridLayer = null;
    private Layer<Output> _outputLayer = null;
    private Layer<Receivers> _stationLayer = null;
    private Layer<WindModel> _windModelLayer = null;

    /**
     * @param parent
     */
    public JFreeChartMap(NetModComponent parent)
    {
        super(parent);
    }

    @Override
    public void addLayer(Layer<?> layer)
    {
    	_layers.remove(layer);
    	_layers.add(layer);
        
        refresh();
    }

    @Override
    public boolean contains(Layer<?> layer)
    {
    	return _layers.contains(layer);
    }

    @Override
    public Layer<EpicenterGrid> createEpicenterLayer(EpicenterGrid epicenterGrid)
    {
        if (_epicenterLayer == null)
            _epicenterLayer = new JFreeChartEpicenterLayer(epicenterGrid);

        _epicenterLayer.setNMC(epicenterGrid);

        return _epicenterLayer;
    }

    @Override
    public <TYPE extends NetModComponent> Layer<MediaGrid<TYPE>> createMediaGridLayer(MediaGrid<TYPE> mediaGrid)
    {
        if (_mediaGridLayer == null)
            _mediaGridLayer = new JFreeChartMediaGridLayer(mediaGrid);

        _mediaGridLayer.setNMC(mediaGrid);

        return _mediaGridLayer;
    }

    @Override
    public <TYPE extends NetModComponent> Action createMediaGridSelectionTool(MediaGrid<TYPE> mediaGrid)
    {
        return new JFreeChartMediaGridSelectionTool(_chartViewer, (MediaGrid<NetModComponent>) mediaGrid);
    }

    @Override
    public Layer<Output> createOutputLayer(Output output)
    {
        if (_outputLayer == null )
            _outputLayer = new JFreeChartOutputLayer(output);

        _outputLayer.setNMC(output);

        return _outputLayer;
    }

    @Override
    public Action createSourceSelectionTool(Sources sources)
    {
        return new JFreeChartSourceSelectionTool(_chartViewer, sources);
    }

    @Override
    public Layer<Receivers> createStationLayer(Receivers receivers)
    {
        if (_stationLayer == null)
            _stationLayer = new JFreeChartStationLayer(receivers);

        _stationLayer.setNMC(receivers);

        return _stationLayer;
    }

    @Override
    public Action createStationSelectionTool(Receivers receivers)
    {
        return new JFreeChartStationSelectionTool(_chartViewer, receivers);
    }

    @Override
    public Layer<WindModel> createWindModelLayer(WindModel nmc)
    {
        if (_windModelLayer == null)
            _windModelLayer = new JFreeChartWindModelLayer(nmc);

        _windModelLayer.setNMC(nmc);

        return _windModelLayer;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new JFreeChartMapViewer(this);
    }

    @Override
    public void refresh()
    {
        _chartViewer.getChart().fireChartChanged();

        XYPlot plot = _chartViewer.getPlot();
        
        //  Clear all datasets
        int N = plot.getDatasetCount();
        for (int i=1; i<N; i++)
        {
			plot.setDataset(i, null);
			plot.setRenderer(i, null);
        }
        
        //  Re-add all of the layers, in reverse order
        int index = 1;
        for (int i=_layers.size(); --i>= 0;)
        {
        	Layer layer = _layers.get(i);
        	
            if (layer instanceof XYDataset)
            {
            	XYDataset dataset = (XYDataset) layer;

                //  Set the dataset
                plot.setDataset(index, dataset);

                //  Set the renderer
                if (layer instanceof JFreeChartLayer)
                    plot.setRenderer(index, ((JFreeChartLayer) layer).getRenderer(0));

                index++;
            }
            else if (layer instanceof List)
            {
                List<XYDataset> list = (List<XYDataset>) layer;

                for (int j = 0; j < list.size(); j++)
                {
                	XYDataset dataset = list.get(j);

                    //  Set the dataset
                    plot.setDataset(index, dataset);

                    //  Set the renderer
                    if (layer instanceof JFreeChartLayer)
                        plot.setRenderer(index, ((JFreeChartLayer) layer).getRenderer(j));
                    
                    index++;
                }
            }  
        }
    }

    @Override
    public void remove(Layer<?> layer)
    {
    	_layers.remove(layer);
    }
}
