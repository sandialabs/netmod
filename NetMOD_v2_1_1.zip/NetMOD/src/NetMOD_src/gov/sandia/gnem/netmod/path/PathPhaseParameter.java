/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.path.codadecay.CodaDecay;
import gov.sandia.gnem.netmod.path.codadecay.CodaDecayPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameter;
import gov.sandia.gnem.netmod.plugin.PhaseParameterViewer;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class PathPhaseParameter extends PhaseParameter
{
    private Collection<? extends Phase> _phases;
    private double _timeWindowLength = 0;
    private double _lowGroupVelocity = -1;
    private double _highGroupVelocity = -1;
    private Phase _priorPhase = null;
    private String _codaDecayFile = "";
    private CodaDecay _codaDecay;
    
    /**
     * @param parent
     * @param phase
     */
    public PathPhaseParameter(NetModComponent parent, Collection<? extends Phase> phases, Phase phase)
    {
        super(parent, phase);
        
        _phases = phases;
        _codaDecay = CodaDecayPlugin.getPlugin().getDefaultComponent(this);        
    }
    
    @Override
    public PhaseParameterViewer<?> getViewer()
    {
        return new PathPhaseParameterViewer(this, _phases);
    }

    /**
     * @return the priorPhase
     */
    public Phase getPriorPhase()
    {
        return _priorPhase;
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getCodaDecay());

        return children;
    }

    /**
     * @return the codaDecay
     */
    public CodaDecay getCodaDecay()
    {
        if (_codaDecay == null)
        {
            _codaDecay = CodaDecayPlugin.getPlugin().getComponentFor(this, getCodaDecayFile());
            _codaDecay.setFilename(getCodaDecayFile());
        }

        return _codaDecay;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof CodaDecay)
                _codaDecay = (CodaDecay) child;
        }

        clearCache();
    }

    /**
     * @param codaDecay the codaDecay to set
     */
    public void setCodaDecay(CodaDecay codaDecay)
    {
        _codaDecay = codaDecay;

        clearCache();
    }

    /**
     * @param priorPhase the priorPhase to set
     */
    public void setPriorPhase(Phase priorPhase)
    {
        _priorPhase = priorPhase;
    }

    /**
     * @param codaDecayFile the codaDecayFile to set
     */
    public void setCodaDecayFile(String codaDecayFile)
    {
        if (_codaDecayFile.equals(codaDecayFile))
            return;
        
        //  If file exists, load it
        if ( IOUtility.openFile(codaDecayFile).exists() )
        {
            _codaDecayFile = codaDecayFile;
            setCodaDecay(null);
        }
        //  Otherwise, save to it
        else if ( getCodaDecay().isAvailable() )
        {
            CodaDecay codaDecay = getCodaDecay();
            codaDecay.read();
            codaDecay.setFilename(codaDecayFile);
            codaDecay.write();
            _codaDecayFile = codaDecay.getFilename();
        }
    }

    /**
     * @return the codaDecayFile
     */
    public String getCodaDecayFile()
    {
        return _codaDecayFile;
    }

    /**
     * Get the time window for the provided pair of locations
     * 
     * @param location1
     * @param location2
     * @return
     */
    public double getTimeWindow(Point.Double location1, Point.Double location2)
    {
        double windowLength = getTimeWindowLength();
        if ( windowLength >= 0 )
            return windowLength;

        //  Get the high and low group velocity
        double groupVelHigh = getHighGroupVelocity();
        double groupVelLow = getHighGroupVelocity();
        
        //  Get the distance in kilometers
        Distance ad = Distance.computeDistance(location1, location2);
        double distance_km = ad.getDistanceKilometers();
        
        double T = Math.abs(distance_km / groupVelLow - distance_km / groupVelHigh);
        
        return T;
    }

    /**
     * @return the timeWindowLength
     */
    public double getTimeWindowLength()
    {
        return _timeWindowLength;
    }

    /**
     * @return the lowGroupVelocity
     */
    public double getLowGroupVelocity()
    {
        return _lowGroupVelocity;
    }

    /**
     * @return the highGroupVelocity
     */
    public double getHighGroupVelocity()
    {
        return _highGroupVelocity;
    }

    /**
     * @param timeWindowLength the timeWindowLength to set
     */
    public void setTimeWindowLength(double timeWindowLength)
    {
        _timeWindowLength = timeWindowLength;
    }

    /**
     * @param lowGroupVelocity the lowGroupVelocity to set
     */
    public void setLowGroupVelocity(double lowGroupVelocity)
    {
        _lowGroupVelocity = lowGroupVelocity;
    }

    /**
     * @param highGroupVelocity the highGroupVelocity to set
     */
    public void setHighGroupVelocity(double highGroupVelocity)
    {
        _highGroupVelocity = highGroupVelocity;
    }
}
