package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

/**
 * Interface for methods of writing out the results of a simulation
 * 
 * @author bjmerch
 *
 */
public interface SimulationOutput extends NetModComponent
{

	/**
	 * Wait until the SimulationOutput has fully completed
	 */
	void join();

	/**
	 * Start outputting the results of the simulation to standard output.
	 * 
	 * @param pd
	 * @param output
	 * @param epicenters
	 */
	void start(ProgressDialog pd, Output output, EpicenterGrid epicenters);

}
