package gov.sandia.gnem.netmod.receiver.attenuation;


import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.TripleCacheMap;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

import static gov.sandia.gnem.netmod.numeric.Distance.computeDistance;

/**
 * Station Specific Transmission Loss Model
 * 
 * Defined as the precomputed transmission loss in units of log10 attenuation over azimuth, range, frequency, and percentiles.
 * Stored in a structured text file format.
 * 
 * @author bjmerch
 *
 */
public class StationTransmissionLossModelTextFile extends AbstractNetModFile implements StationAttenuation
{
	public static final PDF NO_RESULT = NormalPDF.NEGATIVE_999;
	public static final SpectraPDF NO_RESULT_SPECTRA = new SpectraPDF(NO_RESULT);
	private static final String _type = "Station Transmission Loss Model text file";

	// Register Plugin
	static
	{
		StationAttenuationPlugin.getPlugin().registerComponent(_type, StationTransmissionLossModelTextFile.class);
	}
	
	private double[] _azimuths = null;
	private double[] _ranges = null;
	private double[] _frequencies = null;
	private double[] _percentiles = null;
	
	private double[][][][] _tlm = null;  //  Nazimuths x Nrange x Nfrequencies x Npercentiles

	// Cache frequently requested frequencies
	private transient TripleCacheMap<Frequency, Distance, Distance, SpectraPDF> _cache = new TripleCacheMap<Frequency, Distance, Distance, SpectraPDF>(
			null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_DISTANCE, CacheMap.CACHE_DISTANCE);
	public StationTransmissionLossModelTextFile(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();
		
		//  Clear read in objects
		_azimuths = null;
		_ranges = null;
		_frequencies = null;
		_percentiles = null;
		_tlm = null;
		
		//  Clear the cache
		_cache.clear();
		this.getName();
	}

	@Override
	public Spectra getAttenuation(Point.Double start, Point.Double end, Distance distance, Frequency frequency)
	{
		startIntrospection();
		recordIntrospection("Amplitude Attenuation from file: '", getFilename(), "'");
		recordIntrospection("at frequency: ", frequency);
		recordIntrospection("at Start Location: ", start, " , End Location: ", end);

		// calculate distance
		Distance distance_start_end = computeDistance(start, end);
		recordIntrospection("at back azimuth (deg): ", distance.getBackAzimuth());
		recordIntrospection("at distance (deg): ", distance_start_end);

		SpectraPDF a = _cache.get(frequency, distance, distance_start_end);
		if (a != null)
		{
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			stopIntrospection();
			return a;
		}

		/*
		 * Check for no attenuation defined
		 */
		double[] frequencies = getFrequencies();

		if (distance_start_end.getDistance() == 0)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Start and End equal, no amplitude attenuation defined");
			stopIntrospection();

			return a;
		}

		/*
		 * Check for no attenuation defined
		 */
		if (frequencies == null || frequencies.length == 0 || start == null || end == null)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("No attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();

			return a;
		}

		// Identify the evaluation frequencies
		double[] f_eval = getEvaluationFrequencies(frequency, _frequencies);
		int N = f_eval.length;

		// Check that the range overlaps the available frequencies
		if (N == 0)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Frequency outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return a;
		}

		a = new SpectraPDF(N);
		for (int i = 0; i < N; i++)
		{
			a.setValue(i, f_eval[i], computeAttenuation(distance.getBackAzimuth(), distance_start_end.getDistance(),
					distance.getDistance(), f_eval[i]));
		}

		// Cache the results for the next call
		_cache.put(frequency, distance, distance_start_end, a);

		recordIntrospection("Amplitude Attenuation (log10): ", a);
		stopIntrospection();

		return a;

	}

	/**
	 * Compute the attenuation distribution for a specific range, distance, and frequency
	 * 
	 * @param range
	 * @param segment_distance
	 * @param total_distance
	 * @param frequency
	 * @return
	 */
	private PDF computeAttenuation(double azimuth, double segment_distance,
			double total_distance, double frequency)
	{
		startIntrospection();

		double[] az = getAzimuths();
		double[] r = getRanges();
		double[] freqs = getFrequencies();
		double[] percentiles = getPercentiles();
		double[][][][] tlm = getTLM();
		
		int Np = getNPercentiles();
		
		//  Compute the transmission loss at each percentile
		double[] tl = new double[Np];
		
		for (int i=0; i<Np; i++)
			tl[i] = Interpolation.interpolateQuadquadratic(az, r, freqs, percentiles, tlm, azimuth, total_distance, frequency, percentiles[i]);

		PDF attn = null;
		//  Defined only by a mean value (50%)
		if ( Np == 1 && percentiles[0] == 0.5 )
		{
			attn = new NormalPDF(tl[0], 0.0);
		}
		//  Defined by a mean and standard deviation (50%, 68%)
		else if ( Np == 2 && percentiles[0] == 0.5 && percentiles[1] == 0.68 )
		{
			attn = new NormalPDF(tl[0], tl[1]);
		}
		//  Full CDF
		else
		{
			attn = new NonParametricCDF(tl, percentiles);
		}

		recordIntrospection("Attenuation (log10): ", attn);
		recordIntrospection("Azimuth (deg): ", azimuth);
		recordIntrospection("Range (deg): ", total_distance);
		recordIntrospection("Frequency (Hz): ", frequency);
		
		stopIntrospection();

		return attn;
	}


	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		// Check if the file exists
		if (file == null || !file.exists())
			return false;

		// Amplitude Attenuation Text Files end with ".tlm"
		return IOUtility.endsWith(file, ".tlm");
	}

	@Override
	public boolean read()
	{
		boolean value = false;
		synchronized (_type)
		{
			FileInputStream fis = null;
			Scanner fin = null;

			try
			{
				// Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);
						
                setName(fin.nextLine());

                //  Skip comments
                skipComments(fin);
                
                //  Read in the azimuths
                int Naz = fin.nextInt();
                skipComments(fin);
                _azimuths = new double[Naz];
                for (int i = 0; i < Naz; i++)
                	_azimuths[i] = fin.nextDouble();
                
                //  Check if first and last azimuths are not the same
                boolean lastAzimuth = ( _azimuths[0] == -180 && _azimuths[Naz-1] != 180 );
                
                //  Skip comments
                skipComments(fin);
                
                //  Read in the ranges
                int Nr = fin.nextInt();
                skipComments(fin);
                _ranges = new double[Nr];
                for (int i = 0; i < Nr; i++)
                	_ranges[i] = fin.nextDouble();

                //  Skip comments
                skipComments(fin);
                
                //  Read in the frequencies
                int Nf = fin.nextInt();
                skipComments(fin);
                _frequencies = new double[Nf];
                for (int i = 0; i < Nf; i++)
                	_frequencies[i] = fin.nextDouble();
                
                //  Skip comments
                skipComments(fin);
                
                //  Read in the percentiles
                int Np = fin.nextInt();
                skipComments(fin);
                _percentiles = new double[Np];
                for (int i = 0; i < Np; i++)
                	_percentiles[i] = fin.nextDouble();

                // Read in and store all of the transmission loss values
                if ( lastAzimuth)
                {
                	_azimuths = Arrays.copyOf(_azimuths, Naz+1);
                	_azimuths[Naz] = 180;
                	
                	_tlm = new double[Naz+1][Nr][Nf][Np];
                	
                	//  Shallow reference between -180 and +180
                	_tlm[Naz] = _tlm[0];
                }
                else
                	_tlm = new double[Naz][Nr][Nf][Np];
                
    			for (int i=0; i<Naz; i++)
    			{
    				double[][][] _tlm_i = _tlm[i];
    				
    				for (int j=0; j<Nr; j++)
    				{
        				double[][] _tlm_ij = _tlm_i[j];
    					
    					for(int k=0; k<Nf; k++)
    					{
            				double[] _tlm_ijk = _tlm_ij[k];

        					skipComments(fin);
    						for (int l=0; l<Np; l++)
    						{
    							//  Limit values to be < 1.0 as they mess things up.
    							_tlm_ijk[l] = Math.min(1.0, fin.nextDouble());
    						}
    					}
    				}
    			}

				value = true;

			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					System.out.println("Unable to read amplitude attenuation file: '" + getFilename() + "'");
					e.printStackTrace();
				}
				
				_azimuths = new double[0];
				_ranges = new double[0];
				_frequencies = new double[0];
				_percentiles = new double[0];
				_tlm = new double[0][0][0][0];
			}
			finally
			{
				if ( fin != null )
					IOUtility.safeClose(fin);
				if ( fis != null )
					IOUtility.safeClose(fis);
			}

		}

		return value;
	}

	@Override
	public void setFilename(String name)
	{
		super.setFilename(name);

	}
	
	public void setFrequencies(double[] frequencies)
	{
		_frequencies = frequencies;
	}

	@Override
	public double[] getFrequencies()
	{
		if (_frequencies == null)
		{
			read();
		}
		return _frequencies;
	}

	@Override
	public StationTransmissionLossModelTextFileViewer getViewer()
	{
		return new StationTransmissionLossModelTextFileViewer(this);
	}

	public int findClosestIndex(Point.Double point, Point.Double[] LatLon)
	{

		double distanceLat = Math.abs(point.getLatitude() - LatLon[0].getLatitude());
		double distanceLon = Math.abs(point.getLongitude() - LatLon[0].getLongitude());

		int idx = 0;
		for (int c = 1; c < LatLon.length; c++)
		{
			double cdistanceLat = Math.abs(point.getLatitude() - LatLon[c].getLatitude());
			double cdistanceLon = Math.abs(point.getLongitude() - LatLon[c].getLongitude());

			if (cdistanceLat <= distanceLat && cdistanceLon <= distanceLon)
			{
				idx = c;
				distanceLat = cdistanceLat;
				distanceLon = cdistanceLon;
			}
		}
		return idx;
	}

	@Override
	public boolean write()
	{
		// Get the File to write to
		File file = IOUtility.openFile(getFilename());

		// Don't write if not needed
		if (!getDirty() && file.exists())
			return true;

		// Test whether there is no file to write to
		if (isEmpty(file.getPath()))
			return true;

		PrintWriter fout = null;
		try
		{
			// Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));
			fout.println(getName());
			
			int Naz = getNAzimuths();
			double[] az = getAzimuths();
			
			int Nr = getNRanges();
			double[] r = getRanges();
			
			int Nf = getNFrequencies();
			int Np = getNPercentiles();

			// Azimuths
			fout.println("#  Azimuths");
			fout.println(Naz);
            GUIUtility.printArray(az, fout, "\t%8.3f", az.length);
			fout.println();

			// Ranges
			fout.println("#  Ranges");
			fout.println(Nr);
            GUIUtility.printArray(r, fout, "\t%8.3f", r.length);
			fout.println();

			// Frequencies
			fout.println("#  Frequencies");
			fout.println(Nf);
            GUIUtility.printArray(getFrequencies(), fout, "\t%8.3f", r.length);
			fout.println();

			// Percentiles
			fout.println("#  Percentiles");
			fout.println(Np);
            GUIUtility.printArray(getPercentiles(), fout, "\t%8.3f", r.length);
			fout.println();

			// Transmission Loss Model
			double[][][][] tlm = getTLM();
			
			for (int i=0; i<Naz; i++)
			{
				for (int j=0; j<Nr; j++)
				{
					fout.println();
					fout.println("# Transmission Loss at azimuth " + String.format("%8.3f", az[i]) + " and range " + String.format("%8.3f", r[j]) + " across frequencies and percentiles");
					
					for(int k=0; k<Nf; k++)
			            GUIUtility.printArray(tlm[i][j][k], fout, "\t%8.3f", Np);
				}
			}

			setDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		finally
		{
			if ( fout != null )
				IOUtility.safeClose(fout);
		}

		return true;
	}

	protected double[][][][] getTLM()
	{
		if ( _tlm == null )
			read();
		
		return _tlm;
	}

	protected double[] getPercentiles()
	{
		if ( _percentiles == null )
			read();
		
		return _percentiles;
	}

	protected int getNPercentiles()
	{
		if ( _percentiles == null )
			read();
		
		return _percentiles.length;
	}

	protected int getNFrequencies()
	{
		if ( _frequencies == null )
			read();
		
		return _frequencies.length;
	}

	protected double[] getRanges()
	{
		if ( _ranges == null )
			read();
		
		return _ranges;
	}

	protected int getNRanges()
	{
		if ( _ranges == null )
			read();
		
		return _ranges.length;
	}

	protected double[] getAzimuths()
	{
		if ( _azimuths == null )
			read();
		
		return _azimuths;
	}

	protected int getNAzimuths()
	{
		if ( _azimuths == null )
			read();
		
		return _azimuths.length;
	}
}
