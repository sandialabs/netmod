/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.*;

/**
 * Group a combobox with a panel below it.
 * Switch between the viewers of the selected NetModComponent.
 * This construct is used often throughout the NetModComponentViewers
 * 
 * @author bjmerch
 *
 */
public class NetModComboBox<NMC extends NetModComponent> extends JPanel
{
    private JComboBox _comboBox = new JComboBox();
    private Map<NMC, NetModComponentViewer> _viewers = new HashMap<NMC, NetModComponentViewer>();

    public NetModComboBox(Collection<NMC> objects, JComponent... components)
    {
        super(new BorderLayout());

        //  Add a listener to switch between the cards
        _comboBox.addItemListener(new ItemListener()
        {
            @Override
            public void itemStateChanged(ItemEvent ie)
            {
                if (ie.getStateChange() != ItemEvent.SELECTED)
                    return;

                //  Get the existing viewer
                NetModComponentViewer oldViewer = null;
                for (Component c : getComponents())
                    if (c instanceof NetModComponentViewer)
                    {
                        //  Get the expanded state of the previous component
                        oldViewer = (NetModComponentViewer<NMC>) c;

                        //  Remove the existing components
                        NetModComboBox.this.remove(c);
                    }

                //  Get the new component
                NetModComponentViewer viewer = _viewers.get(ie.getItem());
                if (viewer == null)
                {
                    viewer = ((NMC) ie.getItem()).getViewer();
                    _viewers.put((NMC) ie.getItem(), viewer);
                }

                //  Switch to the selected component
                if (viewer != null)
                {
                    //  Apply the expanded state to all of the items
                    setExpandedState(oldViewer, viewer);

                    NetModComboBox.this.add(viewer, BorderLayout.CENTER);
                    NetModComboBox.this.validate();
                    viewer.refresh();
                }
            }
        });

        JPanel comboBoxPanel = new JPanel(new GridBagLayout());

        if (components.length > 0)
        {
            JComponent toolBar = GUIUtility.createToolBar();

            for (JComponent c : components)
                toolBar.add(c);

            //  Group the combobox and buttons together
            GUIUtility.addRow(comboBoxPanel, toolBar, _comboBox);
        }
        else
            GUIUtility.addRow(comboBoxPanel, _comboBox);

        //  Group the combobox and card panels
        add(comboBoxPanel, BorderLayout.NORTH);

        setItems(objects);
    }

    /**
     * Add an item listener for changes in the combo box selection
     * 
     * @param il
     */
    public void addItemListener(ItemListener il)
    {
        _comboBox.addItemListener(il);
    }

    /**
     * Add the netmod component
     * 
     * @param nmc
     */
    public void addNetModComponent(NMC nmc)
    {
        if (nmc == null)
            return;

        ((DefaultComboBoxModel) _comboBox.getModel()).addElement(nmc);
    }

    /**
     * Get the items in the combo box
     * 
     * @return
     */
    public Collection<NMC> getItems()
    {
        Set<NMC> components = new TreeSet<NMC>();

        int N = _comboBox.getItemCount();
        for (int i = 0; i < N; i++)
            if (_comboBox.getItemAt(i) instanceof NetModComponent)
                components.add((NMC) _comboBox.getItemAt(i));

        return components;
    }

    /**
     * Get the selected netmod component
     * 
     * @return
     */
    public NMC getSelectedItem()
    {
        return (NMC)_comboBox.getSelectedItem();
    }

    /**
     * Update the current viewer
     * 
     */
    public void refresh()
    {
        //  Get the current viewer
        NetModComponentViewer viewer = _viewers.get(_comboBox.getSelectedItem());

        if (viewer != null)
            viewer.refresh();
    }

    /**
     * Remove the netmod component
     * 
     * @param nmc
     */
    public void removeNetModComponent(NetModComponent nmc)
    {
        if (nmc == null)
            return;

        //  Remove the component from the comboBox
        ((DefaultComboBoxModel) _comboBox.getModel()).removeElement(nmc);
        _viewers.remove(nmc);
    }

    /**
     * Set the items displayed within the combo box
     * 
     * @param objects
     */
    public void setItems(Collection<NMC> objects)
    {
        //  Check if the set of items are the same
        if (contains(objects))
            return;

        //  Get the selected
        NetModComponent selected = getSelectedItem();

        //  Remove all existing items
        _comboBox.removeAllItems();
        _viewers.clear();

        //  add all of the items
        if (objects != null)
            for (NMC nmc : objects)
                addNetModComponent(nmc);

        //  Set the selected item
        setSelectedItem(selected);
    }

    /**
     * Set the selected netmod component
     * 
     * @param nmc
     */
    public void setSelectedItem(NetModComponent nmc)
    {
        //  Select the corrected item
        _comboBox.setSelectedItem(nmc);

        //  Ensure a valid selection was made
        if (_comboBox.getSelectedIndex() < 0 && _comboBox.getItemCount() > 0)
            _comboBox.setSelectedIndex(0);
    }

    /**
     * Set the selected netmod component to be the
     * one with the same type as the provided component.
     * Replace the existing element with the provided component.
     * 
     * @param nmc
     */
    public void setSelectedType(NMC nmc)
    {
        if (nmc == null)
            return;

        DefaultComboBoxModel model = (DefaultComboBoxModel) _comboBox.getModel();
        Class<? extends NetModComponent> c = nmc.getClass();

        int N = model.getSize();
        for (int i = 0; i < N; i++)
        {
            Object o2 = model.getElementAt(i);

            if (o2.getClass() == c)
            {
                if (o2 != nmc)
                {
                    //  Update the element within the combo box
                    model.removeElementAt(i);
                    model.insertElementAt(nmc, i);
                }
                setSelectedItem(nmc);

                return;
            }
        }
    }

    /**
     * Check if the combobox already contains the provided objects
     * 
     * @param objects
     * @return
     */
    private boolean contains(Collection<? extends NetModComponent> objects)
    {
        if (objects == null)
            return false;

        int N = _comboBox.getItemCount();
        if (_comboBox.getItemCount() != objects.size())
            return false;

        Object[] array = objects.toArray();

        for (int i = 0; i < N; i++)
            if (array[i] != _comboBox.getItemAt(i))
                return false;

        return true;
    }

    /**
     * Transfer the expanded state from viewer1 to viewer2
     * 
     * @param viewer1
     * @param viewer2
     */
    private void setExpandedState(NetModComponentViewer viewer1, NetModComponentViewer viewer2)
    {
        if (viewer1 == null || viewer2 == null)
            return;

        //  Transfer the expanded state
        viewer2.setExpanded(viewer1.isExpanded());

        //  Search for any sub-viewers
        if (viewer1.isExpanded())
        {
            JComponent panel1 = viewer1.getExpandedPanel();
            JComponent panel2 = viewer2.getExpandedPanel();

            int N = Math.min(panel1.getComponentCount(), panel2.getComponentCount());
            for (int i = 0; i < N; i++)
            {
                if (panel1.getComponent(i) instanceof NetModComponentViewer && panel2.getComponent(i) instanceof NetModComponentViewer)
                {
                    setExpandedState((NetModComponentViewer) panel1.getComponent(i), (NetModComponentViewer) panel2.getComponent(i));
                }
            }
        }
    }
}
