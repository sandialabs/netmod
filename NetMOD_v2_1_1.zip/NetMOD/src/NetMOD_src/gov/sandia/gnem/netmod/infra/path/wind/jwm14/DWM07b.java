/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 * 
 * Notice: This computer software was prepared by Sandia Corporation, 
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are 
 * reserved by DOE on behalf of the United States Government and the 
 * Contractor as provided in the Contract. You are authorized to use this 
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE 
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY 
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

/**
 * @author aceaste
 *
 */
public class DWM07b
{
	private double[] vshTerms0; // VSH basis values
	private double[] vshTerms1; // VSH basis values
	private double[] termval0; // Term values to which coefficients are applied
	private double[] termval1; // Term values to which coefficients are applied

	private double[][] dpbar; // Associated legendre fns
	private double[][] dvbar;
	private double[][] dwbar;
	private double[] mltTerms0; // MLT Fourier terms
	private double[] mltTerms1; // MLT Fourier terms

	// Storage for previous values in order to limit recalculations when values
	// don't change
	private double mltLast;
	private double mlatLast;
	private double kpLast;
	private double glatLast = 1.0e16;
	private double glonLast = 1.0e16;
	private double dayLast = 1.0e16;
	private double utLast = 1.0e16;
	private double apLast = 1.0e16;

	private double mmpwind = 0; // Meridional disturbance wind (+north, QD
							// coordinates)

	private double mzpwind = 0; // Zonal disturbance wind (+east, QD coordinates)
	public double[][] f; // Coefficients
	private double[] kpTerms; //
	private double[] mlat_mlon; //

	private final double talt = 125.0;

	public GD2QD gdqd;

	//  Coefficients used in latwgt2
	private final double[] latwgt2_coeff = new double[] { 65.7633, -4.60256, -3.53915, -1.99971, -0.752193, 0.972388 };

	// Coefficients used in ap2kp
	private final double[] ap2kp_apgrid = new double[] { 0.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 9.0, 12.0, 15.0, 18.0, 22.0, 27.0, 32.0, 39.0, 48.0, 56.0, 67.0, 80.0, 94.0, 111.0, 132.0,
	        154.0, 179.0, 207.0, 236.0, 300.0, 400.0 };

	//  Coefficients used in ap2kp
	private final double[] ap2kp_kpgrid = new double[] { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0,
	        23.0, 24.0, 25.0, 26.0, 27.0 };
	{
		for (int i=0; i<ap2kp_kpgrid.length; i++)
			ap2kp_kpgrid[i] = ap2kp_kpgrid[i] / 3.0;
	}

	// nodes values used in kpsl3
	private final double[] kpspl3_node = new double[] { -10.0, -8.0, 0.0, 2.0, 5.0, 8.0, 18.0, 20.0 };
	
	//  Internal array used in kpsl
	private double[] kpspl = new double[7];

	public DWM07b()
	{
		DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();

		mltLast = (Double.MAX_VALUE);
		mlatLast = (Double.MAX_VALUE);
		kpLast = (Double.MAX_VALUE);
		glatLast = (Double.MAX_VALUE);
		glonLast = (Double.MAX_VALUE);
		dayLast = (Double.MAX_VALUE);
		utLast = (Double.MAX_VALUE);
		apLast = (Double.MAX_VALUE);

		termval0 = new double[dwm07b_data.nterm];
		termval1 = new double[dwm07b_data.nterm];
		dpbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
		dvbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
		dwbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
		mltTerms0 = new double[dwm07b_data.mmax + 1];
		mltTerms1 = new double[dwm07b_data.mmax + 1];
		vshTerms0 = new double[dwm07b_data.nvshterm];
		vshTerms1 = new double[dwm07b_data.nvshterm];

		f = new double[][] { { 0, 0 }, { 0, 0 } };
		kpTerms = new double[3];
		mlat_mlon = (new double[] { 0, 0 });

		gdqd = new GD2QD();

	}

	/**
	 * Converts ap values to Kp values, via linear interpolation on the lookup
	 * table.
	 */
	private double ap2kp(double ap0)
	{
		double ap;
		int i;

		ap = ap0;
		if (ap < 0)
			ap = 0;
		if (ap > 400)
			ap = 400;

		for (i = 0; ap > ap2kp_apgrid[i]; i++)
			;

		if (ap == ap2kp_apgrid[i])
		{
			return ap2kp_kpgrid[i];
		}

		return (ap2kp_kpgrid[i - 1] + (ap - ap2kp_apgrid[i - 1]) / (3.0 * (ap2kp_apgrid[i] - ap2kp_apgrid[i - 1])));
	}

	/**
	 * Using HWM inputs, computes Quasi-dipole latitude and local time, and Kp.
	 * Retrieves DWM results for these conditions, converts to geographic
	 * directions, and applies artificial height profile.
	 */
	public void dwm07(int iyd, double sec, double alt, double glat, double glon, double[] ap, double[] dw, ALF alf) throws Exception
	{
		DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();
		
		double ut;
		double day;

		// Convert AP to KP
		double kp = kpLast;
		if (ap[1] != apLast)
		{
			kp = ap2kp(ap[1]);
		}

		// Convert Geo Lat/Lon to QD Lat/Lon
		if ((glat != glatLast) || (glon != glonLast))
		{
			try
			{
				gdqd.gd2qd(glat, glon, mlat_mlon, f, alf);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}

		// Compute QD magnetic local time (low precision)
		day = iyd % 1000;
		ut = sec / 3600.0;
		double mlt = mltLast;
		if (day != dayLast || ut != utLast || glat != glatLast || glon != glonLast)
		{
			mlt = mltCalc(mlat_mlon, day, ut, alf);
		}

		// Retrieve DWM winds
		if (mlat_mlon[0] != mlatLast || mlt != mltLast || kp != kpLast)
		{
			dwm07b(mlt, mlat_mlon[0], kp, alf);
		}

		// Convert to geographic coordinates
		dw[0] = (double) (f[1][1] * mmpwind + f[0][1] * mzpwind);
		dw[1] = (double) (f[1][0] * mmpwind + f[0][0] * mzpwind);

		// Apply height profile
		double scale = 1.0 / (1.0 + Math.exp(-(alt - talt) / dwm07b_data.twidth));
		dw[0] *= scale;
		dw[1] *= scale;

        /*
         * Debugging statements
		System.out.println("");
		System.out.println("dwm07");
		System.out.println("mmpwind = " + mmpwind);
		System.out.println("mzpwind = " + mzpwind);
		System.out.println("scale = " + scale);
		*/

		kpLast = kp;
		glatLast = glat;
		glonLast = glon;
		dayLast = day;
		utLast = ut;
		apLast = ap[1];

	}
	/**
	 * Evaluates the disturbance wind model.
	 */
	public void dwm07b(double mlt, double mlat, double kp, ALF alf) throws Exception
	{
		DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();

		double latwgtTerm;
		int ivshterm;

		// Compute Latitude part of VSH terms
		if (mlat != mlatLast)
		{
			double theta = Math.toRadians(90.0 - mlat);
			alf.ALFBasis(theta, dpbar, dvbar, dwbar);
		}

		// Compute MLT part of VSH terms
		if (mlt != mltLast)
		{
			double phi = Math.toRadians(mlt) * 15.0;
			for (int m = 0; m <= dwm07b_data.mmax; m++)
			{
				double mphi = m * phi;
				mltTerms0[m] = Math.cos(mphi);
				mltTerms1[m] = Math.sin(mphi);
			}
		}

		// Compute VSH terms
		if ((mlat != mlatLast) || (mlt != mltLast))
		{
			ivshterm = 0;

			for (int n = 1; n <= dwm07b_data.nmax; n++)
			{
				double[] dvbar_n = dvbar[n];
				double[] dwbar_n = dwbar[n];
				
				vshTerms0[ivshterm] = -dvbar_n[0] * mltTerms0[0];
				vshTerms0[ivshterm + 1] = dwbar_n[0] * mltTerms0[0];
				vshTerms1[ivshterm] = -vshTerms0[ivshterm + 1];
				vshTerms1[ivshterm + 1] = vshTerms0[ivshterm];
				ivshterm += 2;

				for (int m = 1; m <= dwm07b_data.mmax; m++)
				{
					if (m > n)
						continue;
					
					vshTerms0[ivshterm] = -dvbar_n[m] * mltTerms0[m];
					vshTerms0[ivshterm + 1] = dvbar_n[m] * mltTerms1[m];
					vshTerms0[ivshterm + 2] = dwbar_n[m] * mltTerms1[m];
					vshTerms0[ivshterm + 3] = dwbar_n[m] * mltTerms0[m];
					vshTerms1[ivshterm] = -vshTerms0[ivshterm + 2];
					vshTerms1[ivshterm + 1] = -vshTerms0[ivshterm + 3];
					vshTerms1[ivshterm + 2] = vshTerms0[ivshterm];
					vshTerms1[ivshterm + 3] = vshTerms0[ivshterm + 1];
					ivshterm += 4;
				}
			}
		}

		// Compute KP terms
		if (kp != kpLast)
		{
			kpspl3(kp, kpTerms);
		}

		// Compute Latitudinal Weighting Terms
		latwgtTerm = latwgt2(mlat, mlt, kp, dwm07b_data.twidth);

		// Generate Coupled terms
		for (int i = 0; i < dwm07b_data.nterm; i++)
		{
			int t0 = dwm07b_data.termarr0[i];
			int t1 = dwm07b_data.termarr1[i];
			int t2 = dwm07b_data.termarr2[i];
			
			double termval_temp0 = 1;
			double termval_temp1 = 1;

			if (t0 != 999)
			{
				termval_temp0 *= vshTerms0[t0];
				termval_temp1 *= vshTerms1[t0];
			}
			if (t1 != 999)
			{
				termval_temp0 *= kpTerms[t1];
				termval_temp1 *= kpTerms[t1];
			}
			if (t2 != 999)
			{
				termval_temp0 *= latwgtTerm;
				termval_temp1 *= latwgtTerm;
			}
			termval0[i] = termval_temp0;
			termval1[i] = termval_temp1;
		}

		// Apply coefficients
		mmpwind = (mathutil.dot_product(dwm07b_data.coeff, termval0, dwm07b_data.nterm));
		mzpwind = (mathutil.dot_product(dwm07b_data.coeff, termval1, dwm07b_data.nterm));

        /*
         * Debugging statements
		System.out.println("");
		System.out.println("dwm07b");
		System.out.println("mltTerms0 = " + Arrays.toString(mltTerms0));
		System.out.println("mltTerms1 = " + Arrays.toString(mltTerms1));
		System.out.println("vshTerms0 = " + Arrays.toString(vshTerms0));
		System.out.println("vshTerms1 = " + Arrays.toString(vshTerms1));
		System.out.println("kpTerms = " + Arrays.toString(kpTerms));
		System.out.println("latwgtTerm = " + latwgtTerm);
		System.out.println("termval0 = " + Arrays.toString(termval0));
		System.out.println("termval1 = " + Arrays.toString(termval1));
         */

		mlatLast = mlat;
		mltLast = mlt;
		kpLast = kp;
	}

	/**
	 * @return the mmpwind
	 */
	public double getMmpwind()
	{
		return mmpwind;
	}

	/**
	 * @return the mzpwind
	 */
	public double getMzpwind()
	{
		return mzpwind;
	}

	/**
	 * Computes a quadratic spline basis for the Kp dependence. Covers the
	 * interval [0,8], with 2 interior nodes at Kp = 2 and 5. The basis is
	 * constrained to have zero slope at the bounds.
	 */
	private void kpspl3(double kp, double[] kpTerms)
	{
		double x;

		x = Math.min(Math.max(kp, 0.0), 8.0);

		kpTerms[0] = 0.0;
		kpTerms[1] = 0.0;
		kpTerms[2] = 0.0;

		for (int i = 0; i < 7; i++)
		{
			kpspl[i] = 0;
			if ((x >= kpspl3_node[i]) && (x < kpspl3_node[i + 1]))
			{
				kpspl[i] = 1.0;
			}
		}
		for (int j = 2; j <= 3; j++)
		{
			for (int i = 0; i < 8 - j; i++)
			{
				kpspl[i] = kpspl[i] * (x - kpspl3_node[i]) / (kpspl3_node[i + j - 1] - kpspl3_node[i]) + kpspl[i + 1] * (kpspl3_node[i + j] - x) / (kpspl3_node[i + j] - kpspl3_node[i + 1]);
			}
		}

		kpTerms[0] = kpspl[0] + kpspl[1];
		kpTerms[1] = kpspl[2];
		kpTerms[2] = kpspl[3] + kpspl[4];

	}

	/**
	 * Computes a latitude dependent weighting function that goes to Zero at low
	 * latitudes and one at high latitudes. The transition Is an exponential
	 * s-curve, with the transition latitude determined by a MLT/Kp model.
	 */
	private double latwgt2(double mlat, double mlt, double kp0, double twidth)
	{
		double mltrad = Math.toRadians(mlt * 15.0);
		double sinmlt = Math.sin(mltrad);
		double cosmlt = Math.cos(mltrad);
		double kp = Math.min(Math.max(kp0, 0.0), 8.0);
		double tlat = latwgt2_coeff[0] + latwgt2_coeff[1] * cosmlt + latwgt2_coeff[2] * sinmlt + kp * (latwgt2_coeff[3] + latwgt2_coeff[4] * cosmlt + latwgt2_coeff[5] * sinmlt);

        /*
         * Debugging statements
		System.out.println("");
		System.out.println("latwgt2");
		System.out.println("mlat = " + mlat);
		System.out.println("mlt = " + mlt);
		System.out.println("kp0 = " + kp0);
		System.out.println("twidth = " + twidth);
		System.out.println("mltrad = " + mltrad);
		System.out.println("sinmlt = " + sinmlt);
		System.out.println("cosmlt = " + cosmlt);
		System.out.println("kp = " + kp);
		System.out.println("tlat = " + tlat);
		*/
		
		return (1.0 / (1.0 + Math.exp(-(Math.abs(mlat) - tlat) / twidth)));
	}

	/**
	 * Low-precision calculation of magnetic local time.
	 */
	private double mltCalc(double[] qCoord, double day, double ut, ALF alf) throws Exception
	{
		double asunglat, asunglon, asunqlon, theta, phi;
		double mphi, cosmphi, sinmphi, x, y;
		int i;

		// Compute Geographic coordinates of anti-sunward direction (low
		// precision)
		asunglat = -Math.toDegrees(Math.asin(Math.sin(Math.toRadians(day + ut / 24.0 - 80.0)) * GD2QD_Data.sineps));
		asunglon = -ut * 15.0;

		// Compute Magnetic coordinates of anti-sunward direction
		theta = Math.toRadians(90.0 - asunglat);
		alf.ALFBasisSBar(theta);
		phi = Math.toRadians(asunglon);

		GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();

		double[] spbar_0 = alf.spbar[0];
		i = 0;
		for (int n = 0; n <= gd2qd_data.nmax; n++)
		{
			gdqd.sh[i] = spbar_0[n];
			i++;
		}
		for (int m = 1; m <= gd2qd_data.mmax; m++)
		{
			double[] spbar_m = alf.spbar[m];
			
			mphi = m * phi;
			cosmphi = Math.cos(mphi);
			sinmphi = Math.sin(mphi);

			for (int n = m; n <= gd2qd_data.nmax; n++)
			{
				gdqd.sh[i] = spbar_m[n] * cosmphi;
				gdqd.sh[i + 1] = spbar_m[n] * sinmphi;
				i += 2;
			}
		}

		x = mathutil.dotProduct(gdqd.sh, gd2qd_data.xcoeff);
		y = mathutil.dotProduct(gdqd.sh, gd2qd_data.ycoeff);
		asunqlon = Math.toDegrees(Math.atan2(y, x));

		// Compute mlt
		return ((qCoord[1] - asunqlon) / 15.0);
	}

}
