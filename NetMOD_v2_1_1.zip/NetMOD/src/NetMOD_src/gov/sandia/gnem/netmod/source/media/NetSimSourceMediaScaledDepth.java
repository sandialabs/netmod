package gov.sandia.gnem.netmod.source.media;

import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.simulation.DetectionPhase;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

public class NetSimSourceMediaScaledDepth extends SourceMedia
{

	private static String _type = "NetSIM Source Media Scaled Depth";

	// Register the plugin
	static
	{
		SourceMediaPlugin.getPlugin().registerComponent(_type, NetSimSourceMediaScaledDepth.class, true);
	}

	private String _sourceGridFile = "";
	private String _sourceMediaFile = "";
	private Collection<? extends Phase> _phases;

	public NetSimSourceMediaScaledDepth(NetModComponent parent)
	{
		super(parent, _type);

		setName("Source Media Scaled Depth");
	}

	@Override
	public boolean canContain(NetModComponent component)
	{
		return (component instanceof SourceMediaType);
	}

	@Override
	public List<NetModComponent> getChildren()
	{
		List<NetModComponent> children = new ArrayList<NetModComponent>();
		if (children.size() == 0)
		{
			children.addAll(getMediaTypes());
		}

		return children;
	}

	@Override
	public Layer<?> getMapLayer()
	{
		if (NetMOD.getMap() == null)
			return null;

		return NetMOD.getMap().createMediaGridLayer(this);
	}

	@Override
	public boolean getMediaDirty()
	{
		boolean dirty = false;

		for (SourceMediaType media : getMediaTypes())
			dirty |= media.getDirty();

		return dirty;
	}

	@Override
	public Collection<? extends Phase> getPhases()
	{
		return _phases;
	}

	/**
	 * @return the sourceGridFile
	 */
	@Override
	public String getSourceGridFile()
	{
		return _sourceGridFile;
	}

	/**
	 * @return the sourceMediaFile
	 */
	@Override
	public String getSourceMediaFile()
	{
		return _sourceMediaFile;
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		return new SourceMediaViewer(this);
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		// Check if the file exists
		if (file == null || !file.exists())
			return false;

		// Source Media Text Files end with ".smd"
		return IOUtility.endsWith(file, ".smd_sd");
	}

	@Override
	public void setChildren(List<NetModComponent> children)
	{
		for (NetModComponent child : children)
		{
			if (child instanceof SourceMediaType)
				addMediaType((SourceMediaType) child);
		}

		clearCache();
	}

	@Override
	public void setMediaDirty(boolean mediaDirty)
	{
		for (SourceMediaType media : getMediaTypes())
			media.setDirty(mediaDirty);
	}

	@Override
	public void setPhases(Collection<? extends Phase> phases)
	{
		_phases = phases;

		// Clear the existing source media, retaining reference
		{
			getMediaTypes().clear();

			// Define the reference media type
			SourceMediaType mediaType = new SourceMediaType(this, getPhases());
			mediaType.setName(MediaGrid.REFERENCE);
			addMediaType(mediaType);
		}
	}

	/**
	 * @param sourceGridFile the sourceGridFile to set
	 */
	@Override
	public void setSourceGridFile(String sourceGridFile)
	{
		if (_sourceGridFile.equals(sourceGridFile))
			return;

		_sourceGridFile = sourceGridFile;
		setGridDirty(true);

		if (IOUtility.openFile(sourceGridFile).exists())
			readSourceGrid();
		else
			writeSourceGrid();
	}

	/**
	 * @param sourceMediaFile the sourceMediaFile to set
	 */
	@Override
	public void setSourceMediaFile(String sourceMediaFile)
	{
		if (_sourceMediaFile.equals(sourceMediaFile))
			return;

		_sourceMediaFile = sourceMediaFile;
		setMediaDirty(true);

		if (IOUtility.openFile(sourceMediaFile).exists())
			readSourceMedia();
		else
			writeSourceMedia();
	}

	@Override
	public boolean write()
	{
		writeSourceMedia();
		writeSourceGrid();

		return true;
	}

	private void readSourceGrid()
	{
		readGrid(getSourceGridFile());
	}

	private void readSourceMedia()
	{
		// Clear the existing source media, retaining reference
		{
			getMediaTypes().clear();

			// Define the reference media type
			SourceMediaType mediaType = new SourceMediaType(this, getPhases());
			mediaType.setName(MediaGrid.REFERENCE);
			addMediaType(mediaType);
		}

		// Read the media types from the file
		FileInputStream fis = null;
		Scanner fin = null;
		try
		{
			// Open file
			File sourceMediaFile = IOUtility.openFile(getSourceMediaFile());
			fis = new FileInputStream(sourceMediaFile);
			fin = new Scanner(fis);

			// Read the title
			fin.nextLine();

			// Skip comments
			while (fin.hasNext("#"))
				fin.nextLine();

			// Read the source spectra directory
			String sourceSpectraDirectory = skipBlanksComments(fin).trim();

			// Read in and store all of the source media types
			int numTypes = Integer.parseInt(skipBlanksComments(fin).trim());
            int numPhases = DetectionPhase.size();
			for (int i = 0; i < numTypes; i++)
			{
				String name = skipBlanksComments(fin).trim().toLowerCase();
				SourceMediaType smt = getMediaType(name);
				if (smt == null)
				{
					smt = new SourceMediaType(this, getPhases());
					smt.setName(name);
					addMediaType(smt);
				}

				// Store the reference to source spectra
				String sourceSpectraFilename = skipBlanksComments(fin).trim();
				File sourceSpectraFile = IOUtility.openFile(sourceSpectraDirectory, sourceSpectraFilename);

				// If it doesn't exist check if the path is relative to the source media file
				// path
				if (!sourceSpectraFile.exists())
					sourceSpectraFile = IOUtility.openFile(sourceMediaFile.getParent(), sourceSpectraFile.getPath());

				// If it still doesn't exist check if the file is located in the same path as
				// the source media file
				if (!sourceSpectraFile.exists())
					sourceSpectraFile = IOUtility.openFile(sourceMediaFile.getParent(), sourceSpectraFilename);

				if (sourceSpectraFile.exists())
					smt.setSourceSpectraFile(sourceSpectraFile.getCanonicalPath());

				// Store the media density
				smt.setDensity(Double.parseDouble(skipBlanksComments(fin).trim()));

				// Store Beta 3,4,5
				smt.setBeta3(Double.parseDouble(skipBlanksComments(fin).trim().trim()));
				smt.setBeta4(Double.parseDouble(skipBlanksComments(fin).trim().trim()));
				smt.setBeta5(Double.parseDouble(skipBlanksComments(fin).trim().trim()));

				// Store the Log Moment conversion values
                double[] esc_values = GUIUtility.parseDoubles(skipBlanksComments(fin));
				EventSizeConversion esc = smt.getEventSizeConversion();
				int N_esc = Math.min(esc_values.length / 2, esc.getConversionCount());
				for (int i_esc = 0; i_esc < N_esc; i_esc++)
					esc.set(esc.getMagnitudeType(i_esc), esc_values[i_esc * 2], esc_values[i_esc * 2 + 1]);

                //  Extract the excitation factors
                double[] excitationFactor = GUIUtility.parseDoubles(skipBlanksComments(fin), numPhases);

                //  Extract the media velocities
                double[] velocity = GUIUtility.parseDoubles(skipBlanksComments(fin), numPhases);

				// Store the excitation factors and media velocities
				PhaseParameters<SourceMediaPhaseParameter> phaseParameters = smt.getPhaseParameters();

				for (int j = 0; j < numPhases; ++j)
				{
					SourceMediaPhaseParameter pp = phaseParameters.getPhaseParameter(DetectionPhase.indexToPhase(j));
					if (pp != null)
					{
						pp.setExcitationFactor(excitationFactor[j]);
						pp.setMediaVelocity(velocity[j]);
					}
				}
			}

			setMediaDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fin != null )
				IOUtility.safeClose(fin);
			if ( fis != null )
				IOUtility.safeClose(fis);
		}
	}

	private void writeSourceGrid()
	{
		writeGrid(_sourceGridFile);
	}

	private void writeSourceMedia()
	{
		PrintWriter fout = null;
		try
		{
			String sourceMediaFile = getSourceMediaFile();
			if (sourceMediaFile.isEmpty())
				return;

			File file = IOUtility.openFile(sourceMediaFile);

			if (!getMediaDirty() && file.exists())
				return;

			// Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));

			// Write the title
			fout.println(getName());

			// Directory for attenuation and travel time files, relative to this file
			fout.println("." + File.separator);
			String parent = IOUtility.fixPathSeparator(file.getParent() + File.separator);

			// Number of path media types
			fout.println(String.format("%d", getMediaTypes().size()));

            int numPhases = DetectionPhase.size();
            String phases = DetectionPhase.getPhasesString();

			// Write each media type
			for (SourceMediaType mediaType : getMediaTypes())
			{
				// Write out the source spectra file
				mediaType.getSourceSpectra().write();

				// Media type name
				fout.println(mediaType.getName());

				// Write the source spectra
				mediaType.getSourceSpectra().write();

				// Source file name
				String filename = IOUtility.fixPathSeparator(mediaType.getSourceSpectraFile()).replace(parent, "")
						.trim();
				if (filename.isEmpty())
					filename = "-";
				fout.println(filename);

				// Source media density
				fout.println("#  Media Density (kg/m^3)");
				fout.println(String.format("%.3f", mediaType.getDensity()));

				// Beta 3,4,5
				fout.println("#  Source Depth Correction  (beta3, beta4, and beta5)");
				fout.println(String.format("%.3f", mediaType.getBeta3()));
				fout.println(String.format("%.3f", mediaType.getBeta4()));
				fout.println(String.format("%.3f", mediaType.getBeta5()));

                //  Magnitude conversion a/b terms
                EventSizeConversion esc = mediaType.getEventSizeConversion();
                fout.print("# Event Size Conversion (slope and y-intercept): ");
                for (int i = 0; i < esc.getConversionCount(); i++)
                {
                    fout.print(esc.getMagnitudeType(i).toESCString());
                    fout.print(" ");
                }
                fout.println();
                
                for (int i = 0; i < esc.getConversionCount(); i++)
                    fout.print(String.format("%10.3f %10.3f ", esc.getSlope(i), esc.getYIntercept(i)));
                fout.println();
                
                //  Write out the source excitation factors for each phase
                fout.println("%  Excitation Factors:  " + phases);
                for (int i = 0; i < numPhases; i++)
                {
                    SourceMediaPhaseParameter pp = mediaType.getPhaseParameters().getPhaseParameter(DetectionPhase.indexToPhase(i));
                    fout.print(String.format("%10.3f ", (pp == null ? 0 : pp.getExcitationFactor())));
                }
                fout.println();

                //  Write out the source media velocities for each phase
                fout.println("%  Media Velocity (m/s) Factors:  " + phases);
                for (int i = 0; i < numPhases; i++)
                {
                    SourceMediaPhaseParameter pp = mediaType.getPhaseParameters().getPhaseParameter(DetectionPhase.indexToPhase(i));
                    fout.print(String.format("%10.3f ", (pp == null ? 0 : pp.getMediaVelocity())));
                }
                fout.println();
			}

			setMediaDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (fout != null)
				IOUtility.safeClose(fout);
		}
	}

	@Override
	public boolean isAvailable()
	{
		return false;
	}

	@Override
	public boolean read()
	{
		readSourceGrid();
		readSourceMedia();

		return true;
	}
}
