package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

public class g2s_flags {
  /*
   *   Switches: to turn on and off particular variations use these switches.
   *   0 is off, 1 is on, and 2 is main effects off but cross terms on.
   *
   *   Standard values are 0 for switch 0 and 1 for switches 1 to 23. The
   *   array "switches" needs to be set accordingly by the calling program.
   *   The arrays sw and swc are set internally.
   *
   *   switches[i]:
   *    i - explanation
   *   -----------------
   *    0 - output in meters and kilograms instead of centimeters and grams
   *    1 - F10.7 effect on mean
   *    2 - time independent
   *    3 - symmetrical annual
   *    4 - symmetrical semiannual
   *    5 - asymmetrical annual
   *    6 - asymmetrical semiannual
   *    7 - diurnal
   *    8 - semidiurnal
   *    9 - daily ap [when this is set to -1 (!) the pointer
   *                  ap_a in struct nrlmsise_input must
   *                  point to a struct ap_array]
   *   10 - all UT/long effects
   *   11 - longitudinal
   *   12 - UT and mixed UT/long
   *   13 - mixed AP/UT/LONG
   *   14 - terdiurnal
   *   15 - departures from diffusive equilibrium
   *   16 - all TINF var
   *   17 - all TLB var
   *   18 - all TN1 var
   *   19 - all S var
   *   20 - all TN2 var
   *   21 - all NLB var
   *   22 - all TN3 var
   *   23 - turbo scale height var
   */

  public static int[] switches = new int[25];
  public static double[] sw = new double[25];
  public static double[] swc = new double[25];
  public static double[] isw = new double[1];
}
