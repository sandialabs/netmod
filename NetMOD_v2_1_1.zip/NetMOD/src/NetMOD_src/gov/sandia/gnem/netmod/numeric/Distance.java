/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.numeric;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import com.carrotsearch.hppc.cursors.ObjectCursor;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.TupleCacheMap;

import java.util.Arrays;
import java.util.Iterator;

/**
 * Class for computing and caching the azimuthal distances, azimuths, and back azimuths
 * 
 * @author bjmerch
 *
 */
public class Distance
{
    private static class PointDistance implements Comparable<PointDistance>
    {
        private Point.Double _point;

        private double _distance;

        public PointDistance(Point.Double point, double distance)
        {
            _point = point;
            _distance = distance;
        }
        @Override
        public int compareTo(PointDistance p)
        {
            return Double.compare(_distance, p._distance);
        }
        
        /**
         * @return the distance
         */
        public double getDistance()
        {
            return _distance;
        }

        /**
         * @return the point
         */
        public Point.Double getPoint()
        {
            return _point;
        }
        
        @Override
        public boolean equals(Object o)
        {
        	if ( o == null )
        		return false;
        	
            if (this == o)
                return true;

            if (!(o instanceof PointDistance))
                return false;

            PointDistance pd = (PointDistance) o;

            return pd._distance == _distance && pd._point.equals(_point);
        }

        @Override
        public int hashCode()
        {
            return _point.hashCode();
        }
    }
    
    private final static double DISTANCE_EPS = 1e-10;
    public final static double MEAN_EARTH_RADIUS = 6371;
    public final static double KM_PER_DEGREE = 111.19493;

    /**
     *  Cache the requests for azimuthal distances as they repeat often.
     *  
     *  Use a synchronized map since the cache may be accessed in a multi-threaded environment
     */
    private static TupleCacheMap<Point.Double, Point.Double, Distance> _cache = 
            new TupleCacheMap<Point.Double, Point.Double, Distance>(null, CacheMap.CACHE_SOURCE, CacheMap.CACHE_RECEIVER);

    /**
     * Get an azimuthal distance for the two points
     * 
     * @param p1
     * @param p2
     * @return
     */
    public static Distance computeDistance(Point.Double p1, Point.Double p2)
    {
        //  Check for a reference to the cached AzimuthalDistance object
        Distance ad = _cache.get(p1, p2);
        if (ad == null)
        {
            ad = new Distance(p1, p2);

            _cache.put(p1,  p2, ad);
        }

        //  Return the azimuthal distance
        return ad;
    }

    public static final double degToKm(double deg)
    {
        return deg * KM_PER_DEGREE;
    }

    public static final double kmToDeg(double km)
    {
        return km / KM_PER_DEGREE;
    }

    private Point.Double _p1;
    private Point.Double _p2;
    private double _distance;
    private double _azimuth;
    private double _backAzimuth;

    /**
     * Construct a simple distance without any defining data points.
     * 
     * @param distance
     */
    public Distance(double distance)
    {
        _distance = distance;
    }

    /**
     * Construct an azimuthal distance between two data points
     * 
     * @param p1
     * @param p2
     */
    public Distance(Point.Double p1, Point.Double p2)
    {
        _p1 = p1;
        _p2 = p2;

        double rtod = 180 / Math.PI;
        double dtor = Math.PI / 180;

        double rlat1 = dtor * p1.getLatitude();
        double rlat2 = dtor * p2.getLatitude();
        double rdlon = dtor * (p2.getLongitude() - p1.getLongitude());

        double clat1 = Math.cos(rlat1);
        double clat2 = Math.cos(rlat2);
        double slat1 = Math.sin(rlat1);
        double slat2 = Math.sin(rlat2);
        double cdlon = Math.cos(rdlon);
        double sdlon = Math.sin(rdlon);

        double cdel = slat1 * slat2 + clat1 * clat2 * cdlon;
        cdel = Math.min(cdel, 1.0);
        cdel = Math.max(cdel, -1.0);
        double yazi = sdlon * clat2;
        double xazi = clat1 * slat2 - slat1 * clat2 * cdlon;
        double ybaz = -sdlon * clat1;
        double xbaz = clat2 * slat1 - slat2 * clat1 * cdlon;

        double delta = rtod * Math.acos(cdel);
        double azi = rtod * Math.atan2(yazi, xazi);
        double baz = rtod * Math.atan2(ybaz, xbaz);

        if (azi < 0)
            azi += 360;
        if (baz < 0)
            baz += 360;

        _distance = delta;
        _azimuth = azi;
        _backAzimuth = baz;
    }
    
    /**
     * Compute the distance along the great circle path between the two
     * points for the provided latitude
     * 
     * @param latitude
     * @return distance in degrees
     */
    private double computeGCDistanceLatitude1(Point.Double p, double latitude)
    {
        //  Compute terms
        //double stationDist = Math.toRadians(getDistance());
        double stationAzimuth = Math.toRadians(getAzimuth());
        //double sinAzimuth = Math.sin(stationAzimuth);
        double cosAzimuth = Math.cos(stationAzimuth);

        double theta0 = Math.toRadians((90.0 - p.getLatitude()));
        double sinTheta0 = Math.sin(theta0);
        double cosTheta0 = Math.cos(theta0);
        //double cosAzimuthCosTheta0 = cosAzimuth * cosTheta0;
        double cosAzimuthSinTheta0 = cosAzimuth * sinTheta0;

        // double sign = NumericUtility.sign(sinAzimuth);
        //double sinTheta1 = sign * sinTheta0;
        //double cosAzimuthCosTheta01 = sign * cosAzimuthCosTheta0;
        //double sinAzimuth1 = sign * sinAzimuth;

        //  Compute the distance in degrees
        double lTheta = latitude;
        double lCosTheta = Math.cos(Math.toRadians(90.0 - lTheta));
        double lQ = (cosAzimuthSinTheta0 * cosAzimuthSinTheta0) + (cosTheta0 * cosTheta0) - (lCosTheta * lCosTheta);

        if (lQ < 0.0)
            return Double.NaN;

        double lSqrtQ = Math.sqrt(lQ);

        double lTerm1 = (lCosTheta * cosAzimuthSinTheta0) + (cosTheta0 * lSqrtQ);
        double lTerm2 = (lCosTheta * cosTheta0) - (cosAzimuthSinTheta0 * lSqrtQ);

        if (lTerm1 == 0 || lTerm2 == 0)
            return Double.NaN;

        return Math.toDegrees(Math.atan2(lTerm1, lTerm2));
    }
    
    /**
     * Compute the distance along the great circle path between the two
     * points for the provided latitude
     * 
     * @param latitude
     * @return distance in degrees
     */
    private double computeGCDistanceLatitude2(Point.Double p, double latitude)
    {
        //  Compute terms
        //double stationDist = Math.toRadians(getDistance());
        double stationAzimuth = Math.toRadians(getAzimuth());
        //double sinAzimuth = Math.sin(stationAzimuth);
        double cosAzimuth = Math.cos(stationAzimuth);

        double theta0 = Math.toRadians((90.0 - p.getLatitude()));
        double sinTheta0 = Math.sin(theta0);
        double cosTheta0 = Math.cos(theta0);
        //double cosAzimuthCosTheta0 = cosAzimuth * cosTheta0;
        double cosAzimuthSinTheta0 = cosAzimuth * sinTheta0;

        //double sign = NumericUtility.sign(sinAzimuth);
        //double sinTheta1 = sign * sinTheta0;
        //double cosAzimuthCosTheta01 = sign * cosAzimuthCosTheta0;
        //double sinAzimuth1 = sign * sinAzimuth;

        //  Compute the distance in degrees
        double lTheta = latitude;
        double lCosTheta = Math.cos(Math.toRadians(90.0 - lTheta));
        double lQ = (cosAzimuthSinTheta0 * cosAzimuthSinTheta0) + (cosTheta0 * cosTheta0) - (lCosTheta * lCosTheta);

        if (lQ < 0.0)
            return Double.NaN;

        double lSqrtQ = Math.sqrt(lQ);

        double lTerm1 = (lCosTheta * cosAzimuthSinTheta0) - (cosTheta0 * lSqrtQ);
        double lTerm2 = (lCosTheta * cosTheta0) + (cosAzimuthSinTheta0 * lSqrtQ);

        if (lTerm1 == 0 || lTerm2 == 0)
            return Double.NaN;

        return Math.toDegrees(Math.atan2(lTerm1, lTerm2));
    }

    /**
     * Compute the distance along the great circle path between the two
     * points for the provided longitude.
     * 
     * @param longitude longitude in degrees
     * @return distance in degrees
     */
    private double computeGCDistanceLongitude(Point.Double p, double longitude)
    {
        //  Compute terms
        //double stationDist = Math.toRadians(getDistance());
        double stationAzimuth = Math.toRadians(getAzimuth());
        double sinAzimuth = Math.sin(stationAzimuth);
        double cosAzimuth = Math.cos(stationAzimuth);

        double theta0 = Math.toRadians((90.0 - p.getLatitude()));
        double sinTheta0 = Math.sin(theta0);
        double cosTheta0 = Math.cos(theta0);
        double cosAzimuthCosTheta0 = cosAzimuth * cosTheta0;
        //double cosAzimuthSinTheta0 = cosAzimuth * sinTheta0;

        double sign = NumericUtility.sign(sinAzimuth);
        double sinTheta1 = sign * sinTheta0;
        double cosAzimuthCosTheta01 = sign * cosAzimuthCosTheta0;
        double sinAzimuth1 = sign * sinAzimuth;

        // compute the distance in degrees
        double lDeltaPhi = longitude - p.getLongitude();

        if (lDeltaPhi <= -180.0)
            lDeltaPhi = lDeltaPhi + 360.0;
        if (lDeltaPhi > 180.0)
            lDeltaPhi = lDeltaPhi - 360.0;

        double lSinPhi = Math.sin(Math.toRadians(lDeltaPhi));
        double lTerm1 = lSinPhi * sinTheta1;
        double lTerm2 = (lSinPhi * cosAzimuthCosTheta01) + Math.cos(Math.toRadians(lDeltaPhi)) * sinAzimuth1;

        return Math.toDegrees(Math.atan2(lTerm1, lTerm2));
    }

    /**
     * Compute a latitude location for a given distance along
     * the GC path from p1 to p2.
     * 
     * @param distance distance in degrees
     * @return
     */
    public double computeLatitude(double distance)
    {
        //double lon = Math.toRadians(_p1.getLongitude());
        double lat = Math.toRadians(_p1.getLatitude());
        double az = Math.toRadians(getAzimuth());
        double dist = Math.toRadians(distance);

        double s_lat = Math.sin(lat);
        double c_lat = Math.cos(lat);
        double s_d = Math.sin(dist);
        double c_d = Math.cos(dist);
        //double s_a = Math.sin(az);
        double c_a = Math.cos(az);

        double new_lat = Math.toDegrees(Math.asin(s_lat * c_d + c_lat * s_d * c_a));
        //double new_lon = Math.toDegrees(lon + Math.atan2(s_d * s_a, c_lat * c_d - s_lat * s_d * c_a));
        //
        //if ( new_lon < -180 )
        //    new_lon += 360;
        //if ( new_lon > 180 )
        //    new_lon -= 360;

        return new_lat;
    }

    /**
     * Compute a longitude for a given distance along
     * the GC path from p1 to p2.
     * 
     * @param distance distance in degrees
     * @return
     */
    public double computeLongitude(double distance)
    {
        double lon = Math.toRadians(_p1.getLongitude());
        double lat = Math.toRadians(_p1.getLatitude());
        double az = Math.toRadians(getAzimuth());
        double dist = Math.toRadians(distance);

        double s_lat = Math.sin(lat);
        double c_lat = Math.cos(lat);
        double s_d = Math.sin(dist);
        double c_d = Math.cos(dist);
        double s_a = Math.sin(az);
        double c_a = Math.cos(az);

        //double new_lat = Math.toDegrees(Math.asin(s_lat * c_d + c_lat * s_d * c_a));
        double new_lon = Math.toDegrees(lon + Math.atan2(s_d * s_a, c_lat * c_d - s_lat * s_d * c_a));

        if (new_lon <= -180)
            new_lon += 360;
        if (new_lon > 180)
            new_lon -= 360;

        return new_lon;
    }


    /**
     * Compute a point that is "distance" degrees from the starting point along the great circle path
     * between the two points
     * 
     * @param distance in degrees
     * @return
     */
    public Point.Double computePoint(double distance)
    {
        double lon = Math.toRadians(_p1.getLongitude());
        double lat = Math.toRadians(_p1.getLatitude());
        double az = Math.toRadians(getAzimuth());
        double dist = Math.toRadians(distance);

        double s_lat = Math.sin(lat);
        double c_lat = Math.cos(lat);
        double s_d = Math.sin(dist);
        double c_d = Math.cos(dist);
        double s_a = Math.sin(az);
        double c_a = Math.cos(az);

        double new_lat = Math.toDegrees(Math.asin(s_lat * c_d + c_lat * s_d * c_a));
        double new_lon = Math.toDegrees(lon + Math.atan2(s_d * s_a, c_lat * c_d - s_lat * s_d * c_a));

        if (new_lon <= -180)
            new_lon += 360;
        if (new_lon > 180)
            new_lon -= 360;

        return new Point.Double(new_lat, new_lon);
    }

    /**
     * Compute the set of points and their distances that intersect the grid defined by
     * the provided longitude and latitude values.  
     * 
     * @param longitudes
     * @param latitudes
     * @param minor  True to follow the minor great circle path, false to follow the major great circle path
     * @return
     */
    public ObjectDoubleMap<Point.Double> computePoints(double[] longitudes, double[] latitudes, boolean minor)
    {
        ObjectDoubleMap<Point.Double> distances = new ObjectDoubleOpenHashMap<Point.Double>();

        //  Check if the path from p1 -> p2 crosses the -180/180 meridian 
        boolean meridian = ( minor == Math.abs(_p2.getLongitude() - _p1.getLongitude()) > 180 );

        double minLon = Math.min(_p1.getLongitude(), _p2.getLongitude());
        double maxLon = Math.max(_p1.getLongitude(), _p2.getLongitude());
        
        double total_distance = getDistance();
        if ( !minor )
            total_distance = 360 - total_distance;
        
        //  Ensure the points include the start and end
        distances.put(_p1, 0);
        distances.put(_p2, total_distance);

        //  Iterate over the possible longitudes
        for (int i = 0; i < longitudes.length; i++)
        {
            double lon = longitudes[i];
            
            //  Determine if we wish to examine this longitude, depending on whether the path crosses the meridian
            if ( (  meridian && ( lon <= minLon || lon >= maxLon ) ) ||
                 ( !meridian && ( lon <= maxLon && lon >= minLon ) ) )
            {
                //  Compute the latitude for this longitude, along the GC path
                double distance_p1 = computeGCDistanceLongitude(_p1, lon);
                double lat = computeLatitude(distance_p1);
                Point.Double p = new Point.Double(lat, lon);

                //  Check the distance for the major path length
                if ( !minor )
                {
                	distance_p1 = Math.abs(distance_p1);
                    double distance_p2 = Math.abs(computeGCDistanceLongitude(_p2, lon));
                    
                    //  Check for crossing the meridian
                    if ( distance_p1 + distance_p2 < (total_distance - DISTANCE_EPS) &&
                    		distance_p2 < distance_p1 )
                        distance_p1 = 360 - distance_p1;
                }

                distances.put(p, distance_p1);
            }
        }

        //  Sort the points in increasing distance from p1 to p2
        Point.Double[] points = sortPoints(distances);

        //  Insert any points that are needed for latitude crossings
        for (int i = 1; i < points.length; i++)
        {
            double previous_latitude = points[i-1].getLatitude();
            double previous_longitude = points[i-1].getLongitude();
            double latitude = points[i].getLatitude();
            double longitude = points[i].getLongitude();

            //  Iterate over the latitudes between the previous point and this point
            double minLat = Math.min(previous_latitude, latitude);
            double maxLat = Math.max(previous_latitude, latitude);
            minLon = Math.min(previous_longitude, longitude);
            maxLon = Math.max(previous_longitude, longitude);
            meridian = Math.abs(maxLon - minLon) > 180;

            for (int j = 0; j < latitudes.length; j++)
            {
                double lat = latitudes[j];
                if (lat <= minLat || lat >= maxLat)
                    continue;
                
                //  Determine the longitude for the intermediary latitude steps
                double distance_p1 = computeGCDistanceLatitude1(_p1, lat);
                if (!Double.isNaN(distance_p1))
                {
                    double lon = computeLongitude(distance_p1);
                    Point.Double p = new Point.Double(lat, lon);

                    if (( meridian && (lon < minLon || lon >= maxLon)) || 
                        (!meridian && (lon < maxLon && lon >= minLon)))
                    {
                        //  Check the distance for the major path length
                        if ( !minor )
                        {
                        	distance_p1 = Math.abs(distance_p1);
                            double distance_p2 = Math.abs(computeGCDistanceLongitude(_p2, lon));
                            
                            if ( distance_p1 + distance_p2 < (total_distance - DISTANCE_EPS) &&
                            		distance_p2 < distance_p1 )
                                distance_p1 = 360 - distance_p1;
                        }
                        
                        distances.put(p, distance_p1);
                    }
                }

                distance_p1 = computeGCDistanceLatitude2(_p1, lat);
                if (!Double.isNaN(distance_p1))
                {
                    double lon = computeLongitude(distance_p1);
                    Point.Double p = new Point.Double(lat, lon);
                    
                    if (( meridian && (lon <= minLon || lon >= maxLon)) || 
                        (!meridian && (lon <= maxLon && lon >= minLon)))
                    {
                        //  Check the distance for the major path length
                        if ( !minor )
                        {
                        	distance_p1 = Math.abs(distance_p1);
                            double distance_p2 = Math.abs(computeGCDistanceLongitude(_p2, lon));

                            //  
                            if ( distance_p1 + distance_p2 < (total_distance - DISTANCE_EPS) &&
                            		distance_p2 < distance_p1 )
                                distance_p1 = 360 - distance_p1;
                        }
                        
                        distances.put(p, distance_p1);
                    }
                }
            }
        }

        return distances;
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (this == o)
            return true;

        if (!(o instanceof Distance))
            return false;

        Distance d = (Distance) o;

        boolean equals = _distance == d._distance;
        if ( getLocation1() != null )
            equals = equals && getLocation1().equals(d.getLocation1());
        if ( getLocation2() != null )
            equals = equals && getLocation2().equals(d.getLocation2());

        return equals;
    }

    /**
     * @return the azimuth in degrees
     */
    public double getAzimuth()
    {
        return _azimuth;
    }

    /**
     * @return the backAzimuth in degrees
     */
    public double getBackAzimuth()
    {
        return _backAzimuth;
    }

    /**
     * @return the distance in degrees
     */
    public double getDistance()
    {
        return _distance;
    }

    /**
     * @return the distance in meters
     */
    public double getDistanceMeters()
    {
        return degToKm(getDistance()) * 1000;
    }

    /**
     * @return the distance in kilometers
     */
    public double getDistanceKilometers() {
        return degToKm(getDistance());
    }

    /**
     * @return the first location
     */
    public Point.Double getLocation1()
    {
        return _p1;
    }

    /**
     * @return the second location
     */
    public Point.Double getLocation2()
    {
        return _p2;
    }

    @Override
    public int hashCode()
    {
    	int hashcode = (int) Double.doubleToLongBits(getDistance());
    	
    	if ( getLocation1() != null )
    		hashcode += getLocation1().hashCode();
    	if ( getLocation2() != null )
    		hashcode += getLocation2().hashCode();
    	
    	return hashcode;
    }

    /**
     * Sorted points in order of increasing distance
     * 
     * @param distances
     * @return
     */
    static public Point.Double[] sortPoints(final ObjectDoubleMap<Point.Double> distances)
    {
        final int N = distances.size();
        
        //  Associate the points and their distances
        //  Do this to avoid frequent Map.get calls
        PointDistance[] pd = new PointDistance[N];
        Iterator<ObjectCursor<Point.Double>> iter = distances.keys().iterator();
        for (int i=0; i<N; i++)
        {
            Point.Double p = iter.next().value;
            pd[i] = new PointDistance(p, distances.get(p));
        }
        
        //  Sort the associated values based upon their distances
        Arrays.sort(pd);
        
        //  Fix any issues with bouncing between -180/180 longitude
        for (int i=1; i<N-1; i++)
        {
        	PointDistance pd1 = pd[i-1];
        	PointDistance pd2 = pd[i];
        	PointDistance pd3 = pd[i+1];
        	
        	//  Crossing -180/180 heading eastward, swap points 2 and 3
        	if ( pd1.getPoint().getLongitude() > 0  &&
        			pd2.getPoint().getLongitude() == -180 && 
        			pd3.getPoint().getLongitude() == 180)
        	{
        		pd[i] = pd3;
        		pd[i+1] = pd2;
        	}
        	
        	//  Crossing -180/180 heading westward, swap points 2 and 3
        	if ( pd1.getPoint().getLongitude() < 0  &&
        			pd2.getPoint().getLongitude() == 180 && 
        			pd3.getPoint().getLongitude() == -180)
        	{
        		pd[i] = pd3;
        		pd[i+1] = pd2;
        	}
        }
        
        //  Extract the points
        Point.Double[] points = new Point.Double[pd.length];
        for (int i=0; i<N; i++)
            points[i] = pd[i].getPoint();

        return points;
    }

    @Override
    public String toString()
    {
        return Float.toString((float) _distance);
    }
}
