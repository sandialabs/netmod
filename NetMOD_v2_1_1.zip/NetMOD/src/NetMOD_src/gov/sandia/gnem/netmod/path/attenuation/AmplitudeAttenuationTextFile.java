/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.attenuation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import static gov.sandia.gnem.netmod.numeric.Distance.computeDistance;

/**
 * @author bjmerch
 */
public class AmplitudeAttenuationTextFile extends AbstractNetModFile implements AmplitudeAttenuation
{
	public static final Double NO_RESULT = -99999.0;
	public static final SpectraDouble NO_RESULT_SPECTRA = new SpectraDouble(NO_RESULT);
	private static final String _type = "Amplitude Attenuation Text File";

	//  Register the plugin
	static
	{
		AmplitudeAttenuationPlugin.getPlugin().registerComponent(_type, AmplitudeAttenuationTextFile.class);
	}

	private double[] _frequencies;
	private double[] _distances;
	private double[][] _attenuations;

	//  Cache frequently requested frequencies
	private transient TupleCacheMap<Frequency, Distance, SpectraDouble> _cache = new TupleCacheMap<Frequency, Distance, SpectraDouble>(null,
	        CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_DISTANCE);

	public AmplitudeAttenuationTextFile(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		_frequencies = null;
		_distances = null;
		_attenuations = null;
		_cache.clear();
	}

	@Override
	public SpectraDouble getAttenuation(Point.Double start, Point.Double end, Distance distance, Frequency frequency)
	{
		startIntrospection();
		recordIntrospection("Amplitude Attenuation from file: '", getFilename(), "'");
		recordIntrospection("at frequency: ", frequency);
		recordIntrospection("at distance: ", distance);

		//  Check the cache
		SpectraDouble a = _cache.get(frequency, distance);
		if (a != null)
		{
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			stopIntrospection();
			return a;
		}

		/*
		 * Check for no attenuation defined
		 */
		double[] frequencies = getFrequencies();
		double[] distances = getDistances();
		double[][] attenuations = getAttenuations();
		if (frequencies == null || frequencies.length == 0 || distances == null || distances.length == 0 || attenuations == null)
		{
			a = NO_RESULT_SPECTRA;

			recordIntrospection("No attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();

			return a;
		}

		//  Check distance bounds
		if (distance.getDistance() < distances[0] || distance.getDistance() > distances[distances.length - 1])
		{
			a = NO_RESULT_SPECTRA;

			recordIntrospection("Distance outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			stopIntrospection();

			return a;
		}

		//  Identify the evaluation frequencies
		double[] f_eval = getEvaluationFrequencies(frequency, _frequencies);
		int N = f_eval.length;

		// Check that the range overlaps the available frequencies
		if (N == 0)
		{
			a = NO_RESULT_SPECTRA;

			recordIntrospection("Frequency outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return a;
		}

		a = new SpectraDouble(N);
		for (int i = 0; i < N; i++)
		{
			double attn = Interpolation.interpolateBiquadratic(distances, frequencies, attenuations, distance.getDistance(), f_eval[i]);
			a.setValue(i, f_eval[i], attn);
		}

		/*
		 * Cache the results for the next call
		 */
		_cache.put(frequency, distance, a);

		recordIntrospection("Amplitude Attenuation (log10): ", a);
		stopIntrospection();

		return a;
	}

	/**
	 * @return
	 */
	public double[] getDistances()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_distances == null)
				read();
		}

		return _distances;
	}

	/**
	 * @param distances
	 */
	private void setDistances(double[] distances)
	{
		_distances = distances;
	}

	/**
	 * @return
	 */
	@Override
	public double[] getFrequencies()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
				read();
		}

		return _frequencies;
	}

	/**
	 * @param frequencies
	 */
	private void setFrequencies(double[] frequencies)
	{
		_frequencies = frequencies;
	}

	/**
	 * @return
	 */
	public double[][] getAttenuations()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_attenuations == null)
				read();
		}

		return _attenuations;
	}

	@Override
	public AmplitudeAttenuationTextFileViewer getViewer()
	{
		return new AmplitudeAttenuationTextFileViewer(this);
	}

	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		//  Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		//  Check if the file exists
		if (file == null || !file.exists())
			return false;

		//  Amplitude Attenuation Text Files end with ".atn"
		return IOUtility.endsWith(file, ".atn");
	}

	@Override
	public boolean read()
	{
		boolean value = false;

		//  Synchronize on the type to prevent errors if simultaneously reading from the same file
		synchronized (_type)
		{
			FileInputStream fis = null;
			Scanner fin = null;
			
			try
			{
				// Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);
				
				setName(fin.nextLine());

				//  Skip comments
				skipComments(fin);

				// Read in the frequencies
				int Nfrequencies = fin.nextInt();
				double[] frequencies = new double[Nfrequencies];
				for (int i = 0; i < Nfrequencies; i++)
					frequencies[i] = fin.nextDouble();
				setFrequencies(frequencies);

				//  Skip comments
				skipComments(fin);

				// Read in the distances
				int Ndistances = fin.nextInt();
				double[] distances = new double[Ndistances];
				for (int i = 0; i < Ndistances; i++)
					distances[i] = fin.nextDouble();
				setDistances(distances);

				//  Skip comments
				skipComments(fin);

				// For each frequency, read in the attenuation amplitude
				// at each distance
				_attenuations = new double[Ndistances][Nfrequencies];
				for (int i = 0; i < Nfrequencies; i++)
				{
					fin.skip("\\s");
					while (fin.nextLine().trim().equals(""))
						;

					for (int j = 0; j < Ndistances; j++)
					{
						// Clamp the amplitudes
						double attenuation = fin.nextDouble();
						if (attenuation < NO_RESULT)
							attenuation = NO_RESULT;

						_attenuations[j][i] = attenuation;
					}
				}

				value = true;
				setDirty(false);
			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					System.out.println("Unable to read amplitude attenuation file: '" + getFilename() + "'");
					e.printStackTrace();
				}

				setFrequencies(new double[0]);
				setDistances(new double[0]);
				_attenuations = new double[0][0];
			}
			finally
			{
				if ( fin != null )
					IOUtility.safeClose(fin);
				if ( fis != null )
					IOUtility.safeClose(fis);
			}
		}

		return value;
	}

	/**
	 * Remove all attenuations for the provided distance
	 *
	 * @param distance
	 */
	public void removeAttenuationDistance(double distance)
	{
		//  Find the index of the existing distance
		int index = Arrays.binarySearch(getDistances(), distance);
		if (index < 0)
			return;

		//  Create copies of the arrays, excluding the index
		_distances = removeIndex(_distances, index);
		_attenuations = removeIndex(_attenuations, index);

		_cache.clear();

		setDirty(true);
	}

	/**
	 * Remove all attenuations for the provided frequency
	 *
	 * @param frequency
	 */
	public void removeAttenuationFrequency(double frequency)
	{
		//  Find the index of the existing frequency
		int index = Arrays.binarySearch(getFrequencies(), frequency);
		if (index < 0)
			return;

		//  Create copies of the arrays, excluding the index
		_frequencies = removeIndex(_frequencies, index);
		for (int i = 0; i < _attenuations.length; i++)
			_attenuations[i] = removeIndex(_attenuations[i], index);

		_cache.clear();

		setDirty(true);
	}

	/**
	 * Set the attenuation at the provided distance and frequency
	 *
	 * @param distance
	 * @param frequency
	 */
	public void setAttenuation(double distance, double frequency, double attenuation)
	{
		int d_index = findIndex(getDistances(), distance);
		int f_index = findIndex(getFrequencies(), frequency);

		if (d_index >= _distances.length || _distances[d_index] != distance)
		{
			_distances = insertIndex(_distances, d_index, distance);

			//  Insert new distance entry for all frequencies
			_attenuations = insertIndex(_attenuations, d_index, new double[_frequencies.length]);
		}

		if (f_index >= _frequencies.length || _frequencies[f_index] != frequency)
		{
			_frequencies = insertIndex(_frequencies, f_index, frequency);

			//  Create a new frequency entry for all distances
			for (int i = 0; i < _distances.length; i++)
				_attenuations[i] = insertIndex(_attenuations[i], f_index, 0);
		}

		//  Insert attenuation at location
		_attenuations[d_index][f_index] = attenuation;

		setDirty(true);
	}

	@Override
	public boolean write()
	{
		// Get the File to write to
		File file = IOUtility.openFile(getFilename());

		//  Don't write if not needed
		if (!getDirty() && file.exists())
			return true;

		//  Test whether there is no file to write to
		if (isEmpty(file.getPath()))
			return true;

		PrintWriter fout = null;
		try
		{
			double[] frequencies = getFrequencies();
			double[] distances = getDistances();

			//  Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));
			fout.println(getName());

			// Write the frequencies
			fout.println("# Frequencies");
			fout.println("  " + frequencies.length);
			GUIUtility.printArray(frequencies, fout, "\t%10.3f");

			// Write the distances
			fout.println();
			fout.println("# Distances");
			fout.println("  " + distances.length);
			GUIUtility.printArray(distances, fout, "\t%10.3f");
			fout.println();

			// For each frequency, write out the corresponding attenuation amplitudes
			for (int i = 0; i < frequencies.length; i++)
			{
				fout.println(String.format("Attenuation for frequency:  %.3f", frequencies[i]));

				for (int j = 0; j < distances.length; j++)
				{
					double attenuation = _attenuations[j][i];

					if (j % 8 == 0 && j != 0)
						fout.println();

					fout.print(String.format("\t%10.3f", attenuation));
				}
				fout.println();
			}

			setDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		finally
		{
			if ( fout != null )
				IOUtility.safeClose(fout);
		}

		return true;
	}
}
