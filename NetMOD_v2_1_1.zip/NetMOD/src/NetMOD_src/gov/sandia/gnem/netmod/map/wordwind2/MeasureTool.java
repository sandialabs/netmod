/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.util.UnitsFormat;
import gov.nasa.worldwind.util.measure.MeasureToolController;
import gov.sandia.gnem.netmod.numeric.Distance;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Allow for making measurements on the map
 * 
 * @author bjmerch
 *
 */
public class MeasureTool implements ActionListener
{
    private gov.nasa.worldwind.util.measure.MeasureTool tool = null;
    private JPopupMenu popup;
    RenderableLayer layer = new RenderableLayer();
    private WorldWindow _wwd; 


    public MeasureTool(WorldWindow wwd)
    {
        _wwd = wwd;
    }
    
    private class MeasureAction extends AbstractAction
    {
        private UnitsFormat _unit;
        private String _shape;
        private JToggleButton _button;

        private MeasureAction(JToggleButton button, String name, String shape, UnitsFormat unit)
        {
            putValue(NAME, name);
            _shape = shape;
            _unit = unit;
            _button = button;
        }

        @Override
        public void actionPerformed(ActionEvent arg0)
        {
            if ( tool != null )
                tool.dispose();
            
            tool = new gov.nasa.worldwind.util.measure.MeasureTool(_wwd);

            tool.setController(new MeasureToolController());
            tool.setMeasureShapeType(_shape);
            tool.setUnitsFormat(_unit);
            tool.setArmed(true);
            
            _button.setSelected(true);
        }
    }

    @Override
    public void actionPerformed(ActionEvent event)
    {
        JToggleButton button = (JToggleButton) event.getSource();
        if ( button.isSelected() )
        {
            button.setSelected(false);
            //  Create the popup
            if (popup == null)
            {
                popup = new JPopupMenu();
                
                
                UnitsFormat unit_degrees = new UnitsFormat(UnitsFormat.FORMAT_DECIMAL_DEGREES, UnitsFormat.SQUARE_KILOMETERS)
                {
                    @Override
                    public String length(String label, double meters)
                    {
                        return String.format("%s %,12.4f %s", label, meters/(Distance.KM_PER_DEGREE*1000), "degrees");
                    }
                    
                };
                UnitsFormat unit_kilometers = new UnitsFormat(UnitsFormat.KILOMETERS, UnitsFormat.SQUARE_KILOMETERS);
                UnitsFormat unit_miles = new UnitsFormat(UnitsFormat.MILES, UnitsFormat.SQUARE_MILES);
                
                
                String[][] shapes = new String[][] { 
                	{ "Line", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_LINE}, 
                	{ "Circle", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_CIRCLE},
                	{ "Ellipse", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_ELLIPSE}, 
                	{ "Path", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_PATH},
                	{ "Polygon", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_POLYGON}, 
                	{ "Rectangle", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_QUAD},
                	{ "Square", gov.nasa.worldwind.util.measure.MeasureTool.SHAPE_SQUARE }};
                	
                for (int i=0; i<shapes.length; i++)
                {
                	String name = shapes[i][0];
                	String shape = shapes[i][1];
                	
                	JMenu menu = new JMenu(name);
                	
                    menu.add(new JMenuItem(new MeasureAction(button, "Degrees", shape, unit_degrees)));
                    menu.add(new JMenuItem(new MeasureAction(button, "Kilometers", shape, unit_kilometers)));
                    menu.add(new JMenuItem(new MeasureAction(button, "Miles", shape, unit_miles)));
                    
                    popup.add(menu);
                }
            }

            //  Display the popup
            popup.show(button, 0, button.getSize().height);
        }
        else if ( tool != null )
        {
            tool.dispose();
            tool = null;
        }
        
    }

}
