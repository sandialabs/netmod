/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Icons;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

/**
 * @author bjmerch
 *
 */
public class NetworkViewer extends NetModComponentViewer<Network>
{
    private JTextField _name = new JTextField();
    private JList _all = new JList(new StationListModel());
    private JList _included = new JList(new StationListModel());

    /**
     * Represent a set of stations to a JList
     * 
     * @author bjmerch
     *
     */
    private class StationListModel implements ListModel
    {
    	private Set<ListDataListener> _listeners = new HashSet<ListDataListener>();
    	private Set<Station> _stations = new HashSet<Station>();
    	
    	public StationListModel()
    	{
    	}
    	
    	public void setStations(Set<Station> stations)
    	{
    		_stations = stations;
    		
    		fireStationsChanged();
    	}
    	
    	private void fireStationsChanged()
    	{
    		ListDataEvent e = new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, getSize());
    		
    		for (ListDataListener l : _listeners)
    			l.contentsChanged(e);
    	}

		@Override
        public int getSize()
        {
			return _stations.size();
        }

		@Override
        public Station getElementAt(int index)
        {
			int count = 0;
			
			for (Station station : _stations )
			{
				if ( count == index )
					return station;
				
				count++;
			}
			
			return null;
        }

		@Override
        public void addListDataListener(ListDataListener l)
        {
			_listeners.add(l);
        }

		@Override
        public void removeListDataListener(ListDataListener l)
        {
			_listeners.remove(l);
        }

		public int indexOf(Object o)
        {
			int count = 0;
			
			for (Station station : _stations )
			{
				if ( station == o )
					return count;
				
				count++;
			}
			
			return -1;
        }
    }
    
    
    public NetworkViewer(Network nmc)
    {
        super(nmc, true, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored
        registerControls(_name);
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Organize the include / exclude panel
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
            buttonPanel.add(createIncludeButton());
            buttonPanel.add(createExcludeButton());

            registerControls(buttonPanel);

            //  Organize the list panel
            Dimension d = new Dimension(50, 200);
            JScrollPane sp1 = new JScrollPane(_all);
            sp1.setBorder(BorderFactory.createTitledBorder("All"));
            sp1.setPreferredSize(d);
            sp1.setMinimumSize(d);

            JScrollPane sp2 = new JScrollPane(_included);
            sp2.setBorder(BorderFactory.createTitledBorder("Included"));
            sp2.setPreferredSize(d);
            sp1.setMinimumSize(d);

            JPanel listPanel = new JPanel();
            listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.X_AXIS));
            listPanel.add(sp1);
            listPanel.add(buttonPanel);
            listPanel.add(sp2);

            GUIUtility.addRow(panel, new JLabel("Name:"), _name);
            GUIUtility.addRow(panel, listPanel);
            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    private JComponent createIncludeButton()
    {
        JButton button = GUIUtility.createButton(Icons.FORWARD.getIcon());
        button.setToolTipText("Include in network");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Add the station names to the network 
                Set<Station> stations = _nmc.getStations();
                for (Object o : _all.getSelectedValues())
                    stations.add((Station) o);
                
                _nmc.setStations(stations);
                
                NetMOD.refresh(_nmc);
            }
        });

        JComponent toolbar = GUIUtility.createToolBar();
        toolbar.add(button);
        return toolbar;
    }

    private JComponent createExcludeButton()
    {
        JButton button = GUIUtility.createButton(Icons.BACKWARD.getIcon());
        button.setToolTipText("Exclude from network");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Add the station names to the network 
                Set<Station> stations = _nmc.getStations();
                for (Object o : _included.getSelectedValues())
                    stations.remove(o);
                
                _nmc.setStations(stations);
                
                NetMOD.refresh(_nmc);
            }
        });

        JComponent toolbar = GUIUtility.createToolBar();
        toolbar.add(button);
        return toolbar;
    }

    @Override
    public void apply(Network nmc)
    {
        nmc.setName(_name.getText());
    }

    @Override
    public void reset(Network nmc)
    {
        _name.setText(nmc.getName());
        
        //  Get the stations that are currently selected
        Set<Station> selected = new HashSet<Station>();
        for (Object o : _included.getSelectedValues())
        	selected.add((Station) o);
        for (Object o : _all.getSelectedValues())
        	selected.add((Station) o);

        StationListModel includedModel = (StationListModel) _included.getModel();
        StationListModel excludedModel = (StationListModel) _all.getModel();
        
        //  Update the contents
        includedModel.setStations(nmc.getStations());
        excludedModel.setStations(nmc.getAvailableStations().getStations());

        for (Object o : selected)
        {
            int index = includedModel.indexOf(o);
            if (index >= 0)
                _included.addSelectionInterval(index, index);
            
            index = excludedModel.indexOf(o);
            if (index >= 0)
                _all.addSelectionInterval(index, index);
        }
    }
}
