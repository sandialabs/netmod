/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.geometry;

import java.awt.geom.Point2D;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Defines a 2D point that is used to describe grid locations
 * as a (latitude, longitude) pair.  These values can be either
 * indices or actual latitudes and longitudes.  
 * 
 * The locations are immutable once created.
 * 
 * @author bjmerch
 *
 */
abstract public class Point implements Comparable<Point>
{
    public final static double EPSILON = 1e-10;

    /**
     * Point represented by double valued latitude and longitude values
     * 
     * @author bjmerch
     *
     */
    public static class Double extends Point
    {
        private double _latitude;
        private double _longitude;
        private double _elevation;
        private int _hashCode;

        /**
         * Construct a new point
         * 
         * @param latitude
         * @param longitude
         */
        public Double(double latitude, double longitude)
        {
        	this(latitude, longitude, 0.0);
        }

        public Double(double latitude, double longitude, double elevation) 
        {
            _latitude = latitude;
            _longitude = longitude;
            _elevation = elevation;
            
            int lat_index = (int) Math.abs(Math.rint(_latitude));
            int lon_index = (int) Math.abs(Math.rint(_longitude));
            
            _hashCode = 100 * lat_index + lon_index;
        }

        /**
         * Construct a new point copied from the provided point
         * 
         * @param p
         */
        public Double(Point p)
        {
            this(p.getLatitude(), p.getLongitude(), p.getElevation());
        }

        /**
         * @return the latitude
         */
        @Override
        public double getLatitude()
        {
            return _latitude;
        }

        /**
         * @return the longitude
         */
        @Override
        public double getLongitude()
        {
            return _longitude;
        }

        @Override
        public double getElevation() {
            return _elevation;
        }

        @Override
        public int hashCode()
        {
        	return _hashCode;
        }

        @Override
        public boolean equals(Object o)
        {
        	if ( o == null )
        		return false;
        	
            if (this == o)
                return true;

            if (!(o instanceof Point.Double))
                return false;

            Point.Double p = (Point.Double) o;
            
            if ( _latitude == p._latitude && _longitude == p._longitude )
            	return true;

            return Math.abs(_latitude - p._latitude) < EPSILON && Math.abs(_longitude - p._longitude) < EPSILON;
        }

        /**
         * A very crude euclidian measure of distance.  Only used for a very rough estimate
         * of which points are closer or further.
         * 
         * @param point
         * @return
         */
        public double distance(Double point)
        {
            return Math.abs(point.getLatitude() - getLatitude()) + Math.abs(point.getLongitude() - getLongitude());
        }
    }

    /**
     * Point represented by integer values that specify latitude and longitude indicies
     * 
     * @author bjmerch
     *
     */
    public static class Integer extends Point
    {
        private int _latitude;
        private int _longitude;
		private int _hashCode;
        private int _elevation;

        /**
         * Create a new point from the provided values
         * 
         * @param latitude
         * @param longitude
         */
        public Integer(int latitude, int longitude)
        {
        	this(latitude, longitude, 0);
        }

        public Integer(int latitude, int longitude, int elevation) 
        {
            _latitude = latitude;
            _longitude = longitude;
            _elevation = elevation;
            
            _hashCode = 100 * _latitude + _longitude;
        }

        /**
         * Create a new point as a copy of the provided point
         * 
         * @param p
         */
        public Integer(Point p)
        {
            this((int) p.getLatitude(), (int) p.getLongitude(), (int) p.getElevation());
        }

        /**
         * @return the latitude
         */
        @Override
        public double getLatitude()
        {
            return _latitude;
        }

        @Override
        public double getElevation() {
            return _elevation;
        }

        /**
         * @return the latitude
         */
        public int getLatitudeInt()
        {
            return _latitude;
        }

        /**
         * @return the longitude
         */
        @Override
        public double getLongitude()
        {
            return _longitude;
        }

        /**
         * @return the longitude
         */
        public int getLongitudeInt()
        {
            return _longitude;
        }

        @Override
        public int hashCode()
        {
        	return _hashCode;
        }

        @Override
        public boolean equals(Object o)
        {
        	if ( o == null )
        		return false;
        	
            if (this == o)
                return true;

            if (!(o instanceof Point.Integer))
                return false;

            Point.Integer p = (Point.Integer) o;

            return _latitude == p._latitude && _longitude == p._longitude;
        }
    }

    /**
     * Get a Point<Double> out of the provided string.  If the string is of the form returned by {@linkplain Point#toString()} then
     * a true object is returned.  If the string is not of that form then the returned point has two NaN's.
     * @param aString get a point from this string
     * @return Point<Double> out of the input string
     */
    public static Point.Double fromString(String aString)
    {
        if (aString != null && !aString.isEmpty())
        {
            // Get the number regular expression and the string
            String lNumberPattern = getNumberRegEx();
            String lPoint = aString.trim();

            // If the string matches the patterned returned by toString, then continue
            if (lPoint.matches("\\(" + lNumberPattern + ", " + lNumberPattern + "\\)" + ".*"))
            {
                // Build a matcher
                Pattern lPatternMatches = Pattern.compile(lNumberPattern);
                Matcher lMatcher = lPatternMatches.matcher(aString);

                // Pull out the first number
                lMatcher.find();
                String lFirst = lMatcher.group(0);

                // Pull out the second number
                lMatcher.find();
                String lSecond = lMatcher.group(1);

                // Return the point
                return new Point.Double(java.lang.Double.parseDouble(lFirst), java.lang.Double.parseDouble(lSecond));
            }
        }

        return new Point.Double(java.lang.Double.NaN, java.lang.Double.NaN);
    }

    /**
     * @return regular expression accepting integers and real numbers.  They can have
     * signs, decimal points, and be in scientific notation.
     */
    private static String getNumberRegEx()
    {
        return "((-|\\+)?[0-9]+(\\.[0-9]+)?([eE](-|\\+)?[0-9]+)?){1}";
    }

    @Override
    public int compareTo(Point aOther)
    {
        double lThisLat = getLatitude();
        double lThisLon = getLongitude();
        double lThatLat = aOther.getLatitude();
        double lThatLon = aOther.getLongitude();

        if (lThisLat < lThatLat)
            return -1;
        else if (lThisLat > lThatLat)
            return 1;
        else if (lThisLon < lThatLon)
            return -1;
        else if (lThisLon > lThatLon)
            return 1;

        return 0;
    }

    /**
     * @return this point's latitude
     */
    abstract public double getLatitude();

    abstract public double getElevation();

    /**
     * @return this point's longitude
     */
    abstract public double getLongitude();

    public Point2D toPoint2D()
    {
        return new Point2D.Double(getLongitude(), getLatitude());
    }

    @Override
    public String toString()
    {
        return "(" + getLongitude() + ", " + getLatitude() + ")";
    }
}
