package gov.sandia.gnem.netmod.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JColorChooser;

public class JColorButton extends JButton implements ActionListener
{
    private int buffer = 5;
    private Color _color = Color.WHITE;

    public JColorButton()
    {
        this(35, 30);
    }

    public JColorButton(int w, int h)
    {
        addActionListener(this);
        setIcon(new ColorIcon());
        setPreferredSize(new Dimension(w + buffer, h + buffer));
    }

    public void setColor(Color c)
    {
        _color = c;
    }

    public Color getColor()
    {
        return _color;
    }

    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        Color newColor = JColorChooser.showDialog(this, "Choose color", _color);
        if (newColor != null)
        {
            _color = newColor;
        }
    }

    public class ColorIcon implements Icon
    {

        public void paintIcon(Component c, Graphics g, int x, int y)
        {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(_color);
            g2d.fillRect(x, y, getIconWidth(), getIconHeight());
            g2d.dispose();
        }

        public int getIconWidth()
        {
            return JColorButton.this.getSize().width-buffer;
        }

        public int getIconHeight()
        {
            return JColorButton.this.getSize().height-buffer;
        }
    }

}