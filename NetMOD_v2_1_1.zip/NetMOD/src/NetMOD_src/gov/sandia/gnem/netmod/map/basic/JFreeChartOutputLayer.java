/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.gui.VisibleXYDataset;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.map.MapUtility;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.output.Output.COLOR_SCALING;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.AbstractXYZDataset;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.RectangleAnchor;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.IndexColorModel;
import java.util.List;
import java.util.*;

/**
 * @author bjmerch
 *
 */
public class JFreeChartOutputLayer extends AbstractList<XYDataset> implements Layer<Output>, JFreeChartLayer<Output>
{
    private class ContourOutputDataset extends DefaultXYDataset implements VisibleXYDataset
    {
        private Output _output;
        private boolean _visible = true;
        
        @Override
        public int getItemCount(int series)
        {
            if ( !isVisible() )
                return 0;
            
            return super.getItemCount(series);
        }

        @Override
        public boolean isVisible()
        {
            return _visible;
        }

        public void setNMC(Output output)
        {
            //  Remove any old series
            for (int i=getSeriesCount(); --i>=0; )
                removeSeries(getSeriesKey(i));
            
            _output = output;
            if ( _output == null )
                return;
            
            int index = _output.getContourIndex();
            if (index < 0)
                return;

            //  Assemble the data to be displayed
            int Ntotal = _output.getNumberEpicenters();
            Map<Point.Double, List<Double>> values = new TreeMap<Point.Double, List<Double>>();
            for (int i = 0; i < Ntotal; i++)
            {
                List<Double> row = new ArrayList<Double>();
                row.add(_output.getEpicenterValue(i, index));

                values.put(new Point.Double(_output.getEpicenterValue(i, Output.SIMULGRID_LAT), _output.getEpicenterValue(i, Output.SIMULGRID_LON)), row);
            }

            //  Ensure the data is a regular grid
            values = MapUtility.interpolateIfNecessary(values);

            //  Sort the points to ensure correct ordering
            List<Point.Double> points = new ArrayList<Point.Double>(values.keySet());
            Collections.sort(points);
            Ntotal = points.size();

            //  Determine the extent of the grid
            double minLat = Double.POSITIVE_INFINITY;
            double maxLat = Double.NEGATIVE_INFINITY;
            double minLon = Double.POSITIVE_INFINITY;
            double maxLon = Double.NEGATIVE_INFINITY;

            for (int i = 0; i < Ntotal; i++)
            {
                Point.Double p = points.get(i);

                minLat = Math.min(minLat, p.getLatitude());
                maxLat = Math.max(maxLat, p.getLatitude());
                minLon = Math.min(minLon, p.getLongitude());
                maxLon = Math.max(maxLon, p.getLongitude());
            }

            //  Determine the dimensions of the grid
            int tmp;
            for (tmp = 1; tmp < Ntotal; tmp++)
                if (points.get(tmp).getLatitude() != points.get(tmp - 1).getLatitude())
                    break;

            int M = tmp;
            int N = points.size() / M;

            //  Extract the data
            int count = 0;
            double[][] data = new double[M][N];
            for (int j = 0; j < N; j++)
                for (int i = 0; i < M; i++)
                    data[i][j] = values.get(points.get(count++)).get(0);

            //  Define the latitudes and longitudes
            double[] latitudes = new double[N];
            double[] longitudes = new double[M];

            double dLat = (maxLat - minLat) / (N - 1);
            for (int i = 0; i < N; i++)
                latitudes[i] = minLat + i * dLat;

            double dLon = (maxLon - minLon) / (M - 1);
            for (int i = 0; i < M; i++)
                longitudes[i] = minLon + i * dLon;
            
            //  Add the new series
            for (double contourLevel : _output.getContourLevels())
            {
                int seriesKey = 0;
                
                //  Compute the contours
                Collection<List<Point.Double>> contourLines = MapUtility.generateContours(latitudes, longitudes, data, contourLevel);

                //  Generate lines for each of the contours
                for (List<Point.Double> linePoints : contourLines)
                {
                    //  Convert the points arrays
                    double[][] pointsArray = new double[2][linePoints.size()];
                    for (int i = 0; i < linePoints.size(); i++)
                    {
                        pointsArray[0][i] = linePoints.get(i).getLongitude();
                        pointsArray[1][i] = linePoints.get(i).getLatitude();
                    }

                    //  Build the polyline
                    addSeries(String.format("%4.2f_%d", contourLevel, seriesKey++), pointsArray);
                }
            }
            
            fireDatasetChanged();
        }
        
        @Override
        public void setVisible(boolean visible)
        {
            _visible = visible;
            
            fireDatasetChanged();
        }
    }
    
    private class SurfaceOutputDataset extends AbstractXYZDataset implements VisibleXYDataset
    {
        private Output _output;
        private boolean _visible = true;
        
        @Override
        public int getItemCount(int series)
        {
            if ( !isVisible() )
                return 0;
            
            return _output.getNumberEpicenters();
        }

        @Override
        public int getSeriesCount()
        {
            return  ( _output.getSurfaceIndex() < 0 ? 0 : 1 );
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return _output.getName();
        }

        @Override
        public Number getX(int series, int item)
        {
            return _output.getEpicenterValue(item, Output.SIMULGRID_LON);
        }

        @Override
        public Number getY(int series, int item)
        {
            return _output.getEpicenterValue(item, Output.SIMULGRID_LAT);
        }

        @Override
        public Number getZ(int series, int item)
        {
            return _output.getEpicenterValue(item, _output.getSurfaceIndex());
        }

        @Override
        public boolean isVisible()
        {
            return _visible;
        }

        public void setNMC(Output output)
        {
            _output = output;
            fireDatasetChanged();
        }

        @Override
        public void setVisible(boolean visible)
        {
            _visible = visible;
            
            fireDatasetChanged();
        }
    }
    private XYBlockRenderer _surfaceRenderer = new XYBlockRenderer()
    {
        //  Override drawItems to not draw outlines
        public void drawItem(Graphics2D g2, XYItemRendererState state, Rectangle2D dataArea, PlotRenderingInfo info, XYPlot plot, ValueAxis domainAxis,
                ValueAxis rangeAxis, XYDataset dataset, int series, int item, CrosshairState crosshairState, int pass)
        {

            double x = dataset.getXValue(series, item);
            double y = dataset.getYValue(series, item);
            double z = 0.0;
            if (dataset instanceof XYZDataset)
            {
                z = ((XYZDataset) dataset).getZValue(series, item);
            }
            Paint p = getPaintScale().getPaint(z);
            double xx0 = domainAxis.valueToJava2D(x + this.getBlockWidth() / 2, dataArea, plot.getDomainAxisEdge());
            double yy0 = rangeAxis.valueToJava2D(y + this.getBlockHeight() / 2, dataArea, plot.getRangeAxisEdge());
            double xx1 = domainAxis.valueToJava2D(x + this.getBlockWidth() + this.getBlockWidth() / 2, dataArea, plot.getDomainAxisEdge());
            double yy1 = rangeAxis.valueToJava2D(y + this.getBlockHeight() + this.getBlockHeight() / 2, dataArea, plot.getRangeAxisEdge());
            Rectangle2D block;
            PlotOrientation orientation = plot.getOrientation();
            if (orientation.equals(PlotOrientation.HORIZONTAL))
            {
                block = new Rectangle2D.Double(Math.min(yy0, yy1), Math.min(xx0, xx1), Math.abs(yy1 - yy0), Math.abs(xx0 - xx1));
            }
            else
            {
                block = new Rectangle2D.Double(Math.min(xx0, xx1), Math.min(yy0, yy1), Math.abs(xx1 - xx0), Math.abs(yy1 - yy0));
            }
            g2.setPaint(p);
            g2.fill(block);
            //g2.setStroke(new BasicStroke(1.0f));
            //g2.draw(block);

            EntityCollection entities = state.getEntityCollection();
            if (entities != null)
            {
                addEntity(entities, block, dataset, series, item, 0.0, 0.0);
            }
        }
    };
    private XYItemRenderer _contourRenderer = new StandardXYItemRenderer(StandardXYItemRenderer.LINES);
    
    private PaintScale _paintScale = null;
    private Output _output;;

    private SurfaceOutputDataset _sod = new SurfaceOutputDataset();

    private ContourOutputDataset _cod = new ContourOutputDataset();

    protected JFreeChartOutputLayer(Output output)
    {
        //  Define a paint scale for the output layer
        _paintScale = new PaintScale()
        {

            @Override
            public double getLowerBound()
            {
                return _output.getSurfaceMin();
            }

            @Override
            public Paint getPaint(double value)
            {
                //  Get the color model
                IndexColorModel colorModel = _output.getSurfaceColorModel().getColorModel();

                //  Convert the value to an index
                double min = _output.getSurfaceMin();
                double max = _output.getSurfaceMax();

                boolean log = _output.getColorScaling() == COLOR_SCALING.LOG;

                if (log)
                {
                    min = Math.log10(min);
                    max = Math.log10(max);
                    value = Math.log10(value);
                }

                int index = Math.max(0, Math.min(255, (int) ((value - min) * 253 / (max - min)) + 1));

                //  Lookup the color for this index
                return new Color(colorModel.getRed(index), colorModel.getGreen(index), colorModel.getBlue(index),
                        (int) (255 * _output.getSurfaceTransparency()));
            }

            @Override
            public double getUpperBound()
            {
                return _output.getSurfaceMax();
            }
        };

        setNMC(output);
    }

    @Override
    public XYDataset get(int index)
    {
        if (index == 1)
            return _sod;
        else if (index == 0)
            return _cod;
        
        return null;
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public Output getNMC()
    {
        return _output;
    }

    /**
     * @return
     */
    public XYItemRenderer getRenderer(int index)
    {
        if (index == 1)
        {
            //  Determine the lat/lon epicenter spacing
            double latDelta = Double.POSITIVE_INFINITY;
            double lonDelta = Double.POSITIVE_INFINITY;

            int N = _output.getNumberEpicenters();
            for (int i = 1; i < N; i++)
            {
                double newLatDelta = Math.abs(_output.getEpicenterValue(i, Output.SIMULGRID_LAT) - _output.getEpicenterValue(i - 1, Output.SIMULGRID_LAT));

                if (newLatDelta == 0)
                    continue;
                else if (newLatDelta == latDelta)
                    break;
                else if (newLatDelta < latDelta)
                    latDelta = newLatDelta;
            }

            for (int i = 1; i < N; i++)
            {
                double newLonDelta = Math.abs(_output.getEpicenterValue(i, Output.SIMULGRID_LON) - _output.getEpicenterValue(i - 1, Output.SIMULGRID_LON));

                if (newLonDelta == 0)
                    continue;
                else if (newLonDelta == lonDelta)
                    break;
                else if (newLonDelta < lonDelta)
                    lonDelta = newLonDelta;
            }

            _surfaceRenderer.setBlockHeight(latDelta);
            _surfaceRenderer.setBlockWidth(lonDelta);
            _surfaceRenderer.setBlockAnchor(RectangleAnchor.CENTER);
            _surfaceRenderer.setPaintScale(_paintScale);
            _surfaceRenderer.setSeriesOutlinePaint(0, new Color(0,0,0,0));
            _surfaceRenderer.setSeriesOutlineStroke(0, new BasicStroke(0));
            _surfaceRenderer.setSeriesToolTipGenerator(0, new XYToolTipGenerator()
            {
                @Override
                public String generateToolTip(XYDataset dataset, int series, int item)
                {
                    if (dataset instanceof XYZDataset)
                    {
                        String label = ((XYZDataset) dataset).getZ(series, item).toString();
                        int displayIndex = _output.getSurfaceIndex();
                        if ( displayIndex == Output.SIMULGRID_SIZE)
                            label = label + " " + _output.getSimulKeyValue(Output.SIMULKEY_SIZE_TYPE);
                        
                        return label;
                    }

                    return null;
                }
            });

            return _surfaceRenderer;
        }
        else if (index == 0)
        {
            Color color = Property.MAP_OUTPUT_CONTOUR_COLOR.getColorValue();
            BasicStroke stroke = new BasicStroke(Property.MAP_OUTPUT_CONTOUR_WIDTH.getFloatValue());
            
            _contourRenderer.setBasePaint(color);
            _contourRenderer.setBaseStroke(stroke);
            _contourRenderer.setBaseToolTipGenerator(new XYToolTipGenerator()
            {
                @Override
                public String generateToolTip(XYDataset dataset, int series, int item)
                {
                    if (dataset instanceof XYDataset)
                    {
                        String str = ((XYDataset) dataset).getSeriesKey(series).toString();
                        int index = str.indexOf("_");
                        if ( index >= 0 )
                            str = str.substring(0, index);
                        
                        return str;
                    }

                    return null;
                }
            });
            
            int N = Math.max(100, _cod.getSeriesCount());
            for (int i=0; i<N; i++)
            {
                _contourRenderer.setSeriesPaint(i, color);
                _contourRenderer.setSeriesStroke(i, stroke);
            }
            
            return _contourRenderer;
        }

        return null;
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
    }

    @Override
    public void setNMC(Output output)
    {
        _output = output;
        _sod.setNMC(output);
        _cod.setNMC(output);
    }

    @Override
    public void setVisible(boolean value)
    {
    }

    @Override
    public int size()
    {
        return 2;
    }
}
