package gov.sandia.gnem.netmod.output;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.io.IOUtility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;

/**
 * Viewer for differencing outputs
 * 
 * @author bjmerch
 *
 */
public class OutputDifferenceViewer extends JDialog
{
	private Outputs _outputs;
	private JComboBox _output1;
	private JComboBox _output2;
	private JComboBox _difference = new JComboBox(new String[]{ "Difference", "Percent" });
	
	public OutputDifferenceViewer(JFrame frame, Outputs outputs)
	{
		super(frame, "Difference Outputs", true);
		_outputs = outputs;
		
		_output1 = new JComboBox(outputs.getOutputs().toArray());
		_output2 = new JComboBox(outputs.getOutputs().toArray());
		
		int N = outputs.getOutputs().size();
		if ( N > 1 )
		{
			_output1.setSelectedIndex(0);
			_output2.setSelectedIndex(0);
		}
		if ( N > 2 )
			_output2.setSelectedIndex(1);
		
		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		GUIUtility.addRow(panel, new JLabel("First Output: "), _output1);
		GUIUtility.addRow(panel, new JLabel("Second Output: "), _output2);
		GUIUtility.addRow(panel, new JLabel("Method: "), _difference);
		
        setLayout(new BorderLayout());
		add(panel, BorderLayout.CENTER);
		add(GUIUtility.createButtonPanel(new AbstractAction("Ok")
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
            	Output diff = difference();
            	
            	if ( diff != null )
            	{
                    //  Update the viewer
                    _outputs.getViewer().refresh();

                    //  Display on map
                    if (_outputs.getOutputs().size() > 0)
                    {
                        //  Expand the simulation Viewer
                    	_outputs.getParent().getViewer().setExpanded(true);

                        //  Expand the outputs viewer
                        _outputs.getViewer().setExpanded(true);

                        //  Display the output on the map
                        OutputViewer outputViewer = (OutputViewer) diff.getViewer();
                        outputViewer.setExpanded(true);
                        outputViewer.displayMap();
                    }
            		
            		setVisible(false);
            		dispose();
            	}
            }
        },
        new AbstractAction("Cancel")
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                dispose();
            }
        }), BorderLayout.SOUTH);
	
        pack();
        setLocationRelativeTo(null);
		setResizable(false);
        setVisible(true);
	}
	
	/**
	 * Difference the two methods
	 * 
	 * @return
	 */
	private Output difference()
	{
		//  Get the difference method
		boolean percent = _difference.getSelectedIndex() == 1;
		
        //  Select the first output
        Output output1 = (Output) _output1.getSelectedItem();
        if (output1 == null)
            return null;

        //  Select the second output
        Output output2 = (Output) _output2.getSelectedItem();
        if (output2 == null)
            return null;

        //  Determine the number of entries to compute
        int N = output1.getNumberEpicenters();
        if (N != output2.getNumberEpicenters())
            return null;


        //  Find a unique filename
        String filename = output1.getName() + " - " + output2.getName();
        File outputFile = IOUtility.openFile(_outputs.getOutputDir(), filename + Output.simulGrid);

        int outputFileCount = 1;
        while (outputFile.exists())
            outputFile = IOUtility.openFile(_outputs.getOutputDir(), filename + " " + (outputFileCount++) + Output.simulGrid);

        //  Compute the difference (output1 - output2)
        Output difference = new Output(_outputs, N);
        difference.setOutputFile(outputFile.getPath().replace(Output.simulGrid, ""));

        for (int i = 0; i < N; i++)
        {
            difference.setEpicenterValue(i, Output.SIMULGRID_LAT, output1.getEpicenterValue(i, Output.SIMULGRID_LAT));
            difference.setEpicenterValue(i, Output.SIMULGRID_LON, output1.getEpicenterValue(i, Output.SIMULGRID_LON));

            for (int j = 2; j < Output.SIMULGRID_COUNT; j++)
            {
            	double val1 = output1.getEpicenterValue(i, j);
            	double val2 = output2.getEpicenterValue(i, j);
            	
            	double val = val1 - val2;
            	if ( percent )
            		val = 100 * val / val1;
            	
                difference.setEpicenterValue(i, j, val);
            }
        }
        
        //  Copy parameter values from the first output
        difference.setValues(output1);
        
        if ( percent )
        	difference.setSimulKeyValues(Output.SIMULKEY_SIZE_TYPE, "%");
        
        //  Write the output to disk
        if ( difference.save() )
        	return difference;
        
        return null;
	}
}
