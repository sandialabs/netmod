/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.view.orbit.BasicOrbitView;
import gov.nasa.worldwindx.examples.lineofsight.PointGrid;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

import javax.swing.*;

import com.jogamp.opengl.GL2;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author bjmerch
 *
 */
class EpicenterLayer extends RenderableLayer implements Layer<EpicenterGrid>
{
    private class EpicenterPointGrid extends PointGrid
    {        
        /**
         * @param corners
         * @param positions
         * @param size
         * @param size2
         * @param color
         */
        public EpicenterPointGrid(List<Position> corners, List<Position> positions, int size, int pointSize, Color color)
        {
            super(corners, positions, size);
            Attributes attributes = new PointGrid.Attributes((double) pointSize, color);
            attributes.setEnablePointSmoothing(true);
            setAttributes(attributes);
        }        
        
        @Override
        protected void setPointSize(DrawContext dc, Double size)
        {
             GL2 gl = dc.getGL().getGL2();

            if (size == null)
                size = this.getActiveAttributes().getPointSize();

            if (size == null)
                size = DEFAULT_POINT_SIZE;

            if (dc.isPickingMode())
            {
                size *= 2; // makes points easier to pick
            }
            else
            {
                //  Reduce the size based on point density
                BasicOrbitView view = (BasicOrbitView) dc.getView();
                double dLat = 4 * view.getZoom();
                double dLon = 4 * view.getZoom();
                
                double newSize = Math.min(
                        dc.getDrawableHeight() * getExtent().getDiameter() / (dLat * Math.sqrt(getNumPositions()/4)),
                        dc.getDrawableWidth() * getExtent().getDiameter() / (dLon * Math.sqrt(getNumPositions()/4)));
                
                size = Math.min(size, newSize);
                size = Math.max(size, 1);
            }
            gl.glPointSize(size.floatValue());

            if (!dc.isPickingMode() && this.getActiveAttributes().isEnablePointSmoothing())
            {
                gl.glEnable(GL2.GL_POINT_SMOOTH);
                gl.glHint(GL2.GL_POINT_SMOOTH_HINT, GL2.GL_NICEST);
            }
        }
    }

    private EpicenterGrid _epicenterGrid;

    protected EpicenterLayer(EpicenterGrid data)
    {

        //  Set the data
        setNMC(data);
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }
    
    @Override
    public String getName()
    {
        return _epicenterGrid.getName();
    }

    @Override
    public EpicenterGrid getNMC()
    {
        return _epicenterGrid;
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
        //  Do nothing, all sources are displayed
    }

    @Override
    public void setNMC(EpicenterGrid data)
    {
        _epicenterGrid = data;

        //  Remove all renderables
        removeAllRenderables();

        int size = (int) Property.MAP_SOURCE_POINTSIZE.getFloatValue();
        Color color = Property.MAP_SOURCE_COLOR.getColorValue();

        //  Re-add any features
        double minLat = 90;
        double maxLat = -90;
        double minLon = 180;
        double maxLon = -180;
        List<Position> positions = new ArrayList<Position>();
        for (Iterator<Point.Double> iter = data.iterator(); iter.hasNext();)
        {
            Point.Double p = iter.next();
            Position position = Position.fromDegrees(p.getLatitude(), p.getLongitude());

            minLat = Math.min(minLat, position.getLatitude().getDegrees());
            maxLat = Math.max(maxLat, position.getLatitude().getDegrees());
            minLon = Math.min(minLon, position.getLongitude().getDegrees());
            maxLon = Math.max(maxLon, position.getLongitude().getDegrees());
            
            positions.add(position);
        }
        
        List<Position> corners = new ArrayList<Position>();
        corners.add(Position.fromDegrees(minLat, minLon));
        corners.add(Position.fromDegrees(maxLat, minLon));
        corners.add(Position.fromDegrees(maxLat, maxLon));
        corners.add(Position.fromDegrees(minLat, maxLon));
        
        EpicenterPointGrid pg = new EpicenterPointGrid(corners, positions, positions.size(), size, color);
        addRenderable(pg);
    }

    @Override
    public void setVisible(boolean value)
    {
        super.setEnabled(value);
    }
}
