/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.numeric.NumericUtility;

/**
 * A normally distributed Probability Density Function.
 * Note that the underlying variable is assumed to be in units
 * of Bels (log10).  This impacts some of the operations
 * that are performed.
 * 
 * @author bjmerch
 *
 */
public class NormalPDF extends AbstractPDF
{
    public static final NormalPDF ZERO = new NormalPDF(0,0);
    public static final NormalPDF NEGATIVE_999 =  new NormalPDF(-999,0);
    public static final NormalPDF NEGATIVE_INFINITY = new NormalPDF(Double.NEGATIVE_INFINITY, 0);
    
    private final double _mean;
    private final double _std;
    
    public NormalPDF(double mean, double std)
    {
        _mean = mean;
        _std = Math.abs(std);
    }

    @Override
    public PDF add(double x, PDF... pdfs)
    {
        //  Add the PDFs assuming that they are all normal
        double mean = getMean() + x;
        double var = getVariance();
        
        for (PDF pdf : pdfs)
        {
            mean += pdf.getMean();
            var += pdf.getVariance();
        }
        
        //  Check for no change
        if ( mean == getMean() && var == getVariance() )
            return this;
        
        return new NormalPDF(mean, Math.sqrt(var));
    }
    
    @Override
    public double computeCumulativeDistribution(double x)
    {
        double mean = getMean();
        double sd = getStandardDeviation();
        if ( sd <= 0 )
            return ( mean <= x ? 1 : 0 );
        
        return 0.5 * ( 1 + AbstractPDF.erf( ( x - mean ) / (_sqrt2 * sd) ) );
    }

    @Override
    public double computeProbabilityDensity(double x)
    {
        double mean = getMean();
        double sd = getStandardDeviation();
        
        double tmp = (x - mean) / sd;
        
        return Math.exp( - 0.5 * tmp * tmp ) / ( sd * _sqrt2PI );
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof NormalPDF) )
            return false;
        
        NormalPDF pdf = (NormalPDF) o;
        
        return NumericUtility.equals(_mean, pdf._mean, 1e-4) && NumericUtility.equals(_std, pdf._std,  1e-4);
    }

    @Override
    public String getDescription()
    {
        return "Normal";
    }
    
    @Override
    public double getMax()
    {
        return _mean + 3.0 * _std;
    }
    
    /**
     * @return the mean
     */
    @Override
    public double getMean()
    {
        return _mean;
    }
    
    @Override
    public double getMin()
    {
        return _mean - 3.0 * _std;
    }

    /**
     * @return the standardDeviation
     */
    @Override
    public double getStandardDeviation()
    {
        return _std;
    }

    /**
     * @return the standardDeviation
     */
    @Override
    public double getVariance()
    {
        return _std * _std;
    }

	@Override
    public int hashCode()
    {
		return (int) (Double.doubleToLongBits(getMean()) + Double.doubleToLongBits(getStandardDeviation()));
    }

    @Override
    public PDF log10()
    {
        return new NormalPDF(Math.log10(getMean()), Math.log10(getMean()+getStandardDeviation()) - Math.log10(getMean()));
    }

    @Override
    public PDF minus(PDF pdf)
    {
        if ( pdf instanceof NormalPDF )
        {
            double mean = getMean() - pdf.getMean();
            double sd = Math.sqrt(getVariance() + pdf.getVariance());
            
            if ( mean == getMean() && sd == getStandardDeviation() )
                return this;
            
            return new NormalPDF(mean, sd);
        }
        
        return AbstractPDF.minus(this, pdf);
    }

    @Override
    public PDF pow10()
    {
        return new LogNormalPDF(getMean(), getStandardDeviation());
    }

    @Override
    public PDF scale(double a, double b)
    {
        if ( a == 1.0 && b == 0.0 )
            return this;
        
        return new NormalPDF(a * getMean() + b, Math.abs(a) * getStandardDeviation());
    }

    @Override
    public String toString()
    {
        return "Normal(" + GUIUtility.format(_mean) + ", " + GUIUtility.format(_std) + " )";
    }

    /**
     * Check if the NormalPDF is equal to zero.
     * 
     * @return
     */
    public boolean isZero()
    {
        return _mean == 0.0 && _std == 0.0;
    }

	@Override
    public MonteCarloPDF toMonteCarlo(PRNG prng, int n)
    {
		MonteCarloPDF pdf = new MonteCarloPDF(prng, n);
		prng.nextNormals(pdf.getValues(), _mean, _std);
		
		return pdf;
    }

	@Override
    public PDF toSimplePDF()
    {
		return this;
    }
}
