/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.NormalPDF;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Text file implementation of a noise spectra defined as a cumulative
 * distribution function
 * 
 * @author bjmerch
 *
 */
public class NoiseSpectraTextCDF extends AbstractNetModFile implements NoiseSpectra
{
	private static final NormalPDF NO_RESULT = new NormalPDF(999, 0);
	private static final SpectraPDF NO_RESULT_SPECTRA = new SpectraPDF(NO_RESULT);
	private static String _type = "Noise Spectra CDF Text File";

	// Register the plugin
	static
	{
		NoiseSpectraPlugin.getPlugin().registerComponent(_type, NoiseSpectraTextCDF.class);
	}

	private double[] _frequencies;
	private double[] _percentiles;

	private double[] _mean;
	private double[] _std;

	// N_percentiles x N_frequencies
	private double[][] _cdf;

	/*
	 * Cache requested noise
	 */
	private CacheMap<Frequency, SpectraPDF> _cache = new CacheMap<Frequency, SpectraPDF>(CacheMap.CACHE_FREQUENCY);

	public NoiseSpectraTextCDF(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		_frequencies = null;
		_cdf = null;
		_cache.clear();
	}

	/**
	 * Get the frequencies over which the noise spectra is defined
	 * 
	 * @return
	 */
	@Override
	public double[] getFrequencies()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
				read();
		}

		return _frequencies;
	}

	/**
	 * Get the percentiles over which the noise spectra is defined
	 * 
	 * @return
	 */
	public double[] getPercentiles()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_percentiles == null)
				read();
		}

		return _percentiles;
	}

	/**
	 * Get the CDF values for the noise spectra
	 * 
	 * @return
	 */
	public double[][] getCDF()
	{
		return _cdf;
	}

	@Override
	public SpectraPDF getNoise(Frequency frequency, Time time)
	{
		startIntrospection();
		recordIntrospection("Noise Spectra from file: ", getFilename(), "'");
		recordIntrospection("at frequency (Hz): ", frequency);

		/*
		 * Check for a cached value
		 */
		SpectraPDF noise = _cache.get(frequency);
		if (noise != null)
		{
			recordIntrospection("Noise (log10 PSD): ", noise);
			stopIntrospection();
			return noise;
		}

		/*
		 * Check for no noise defined
		 */
		double[] frequencies = getFrequencies();
		if (frequencies == null || frequencies.length == 0)
		{
			noise = NO_RESULT_SPECTRA;

			recordIntrospection("No noise defined");
			recordIntrospection("Noise (log10 PSD): ", noise);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();

			return noise;
		}

		// Identify the evaluation frequencies
		double[] f_eval = getEvaluationFrequencies(frequency, _frequencies);
		int N = f_eval.length;

		// Check that the range overlaps the available frequencies
		if (N == 0)
		{
			noise = NO_RESULT_SPECTRA;

			recordIntrospection("Frequency outside bounds, no noise spectra defined");
			recordIntrospection("Noise (log10 PSD): ", noise);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return noise;
		}

		noise = new SpectraPDF(N);
		for (int i = 0; i < N; i++)
			noise.setValue(i, f_eval[i], computeNoise(f_eval[i]));

		recordIntrospection("Noise (log10 PSD): ", noise);
		stopIntrospection();

		/*
		 * Cache the results for the next call
		 */
		_cache.put(frequency, noise);

		return noise;
	}

	/**
	 * Low-level method for computing noise at a particular frequency
	 * 
	 * @param frequency
	 * @return
	 */
	private NonParametricCDF computeNoise(double frequency)
	{
		double mean = Interpolation.interpolateQuadratic(_frequencies, _mean, frequency);
		double sd = Interpolation.interpolateQuadratic(_frequencies, _std, frequency);

		double[] x = new double[_percentiles.length];
		for (int i = 0; i < x.length; i++)
			x[i] = Interpolation.interpolateQuadratic(_frequencies, _cdf[i], frequency);

		return new NonParametricCDF(x, _percentiles, mean, sd);
	}

	@Override
	public NoiseSpectraTextCDFViewer getViewer()
	{
		return new NoiseSpectraTextCDFViewer(this);
	}

	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		// Check if the file exists
		if (file == null || !file.exists())
			return false;

		// Noise Text Files end with ".noi"
		return IOUtility.endsWith(file, ".noi_cdf");
	}

	@Override
	public boolean read()
	{
		boolean value = false;

		// Synchronize on the type to prevent errors if simultaneously reading from the
		// same file
		synchronized (_type)
		{
			FileInputStream fis = null;
			Scanner fin = null;
			try
			{
				// Open the file and read in the title
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);
				
				setName(fin.nextLine());

				// Skip comments
				skipComments(fin);

				// Read in the number of CDF
				int numCDF = fin.nextInt();

				// Skip comments
				skipComments(fin);

				// Read in the CDF values
				_percentiles = new double[numCDF];
				for (int i = 0; i < numCDF; i++)
					_percentiles[i] = fin.nextDouble();

				// Skip comments
				skipComments(fin);

				// Read in and store all of the frequency/noise value pairs
				int numFrequencies = fin.nextInt();
				_frequencies = new double[numFrequencies];
				_mean = new double[numFrequencies];
				_std = new double[numFrequencies];
				_cdf = new double[numCDF][numFrequencies];
				for (int i = 0; i < numFrequencies; ++i)
				{
					// Read in the line and split on white space
					String[] line = skipBlanksComments(fin).trim().split("\\s*(\\s|,)\\s*");

					// Skip blank lines
					if (line.length < 2 + numCDF)
					{
						i--;
						continue;
					}

					_frequencies[i] = Double.parseDouble(line[0]);
					_mean[i] = Double.parseDouble(line[1]);
					_std[i] = Double.parseDouble(line[2]);

					// Reproduce NetSim bug
					if (Property.NETSIM_NOISE_SD_DB.getBooleanValue())
						_std[i] *= 0.1;

					for (int j = 0; j < numCDF; j++)
						_cdf[j][i] = Double.parseDouble(line[3 + j]);
				}

				value = true;
				setDirty(false);
			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					System.out.println("Unable to read noise spectra CDF text file: '" + getFilename() + "'");
					e.printStackTrace();
				}

				_frequencies = new double[0];
				_percentiles = new double[0];
				_mean = new double[0];
				_std = new double[0];
				_cdf = new double[0][0];
			}
			finally
			{
				if ( fin != null )
					IOUtility.safeClose(fin);
				if ( fis != null )
					IOUtility.safeClose(fis);
			}
		}

		return value;
	}

	/**
	 * Remove the noise value at the provided frequency
	 * 
	 * @param frequency
	 */
	public void removeNoise(double frequency)
	{
		// Find the index of the existing noise
		int index = Arrays.binarySearch(getFrequencies(), frequency);
		if (index < 0)
			return;

		// Create copies of the arrays, excluding the index
		_frequencies = removeIndex(_frequencies, index);
		_cdf = removeIndex(_cdf, index);

		_cache.clear();
		setDirty(false);
	}

	/**
	 * Set the noise value at the provided frequency and percentile
	 * 
	 * @param frequency
	 * @param percentile
	 * @param value
	 */
	public void setNoise(double frequency, double percentile, double value)
	{
		int p_index = findIndex(getPercentiles(), percentile);
		int f_index = findIndex(getFrequencies(), frequency);

		if (p_index >= _percentiles.length || _percentiles[p_index] != percentile)
		{
			_percentiles = insertIndex(_percentiles, p_index, percentile);

			// Insert new distance entry for all frequencies
			_cdf = insertIndex(_cdf, p_index, new double[_frequencies.length]);
		}

		if (f_index >= _frequencies.length || _frequencies[f_index] != frequency)
		{
			_frequencies = insertIndex(_frequencies, f_index, frequency);

			// Create a new frequency entry for all distances
			for (int i = 0; i < _percentiles.length; i++)
				_cdf[i] = insertIndex(_cdf[i], f_index, 0);
		}

		// Insert attenuation at location
		_cdf[p_index][f_index] = value;

		_cache.clear();
		setDirty(true);
	}

	@Override
	public boolean write()
	{
		// Get the File to write to
		File file = IOUtility.openFile(getFilename());

		// Don't write if not needed
		if (!getDirty() && file.exists())
			return true;

		// Test whether there is no file to write to
		if (isEmpty(file.getPath()))
			return true;

		PrintWriter fout = null;
		boolean value = true;
		try
		{
			// Get all frequencies used in the file and write how many are used
			double[] frequencies = getFrequencies();

			// Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));
			fout.println(getName());

			// Write the number of CDF
			fout.println("# CDF percentiles");
			fout.println(_cdf[0].length);
			GUIUtility.printArray(_percentiles, fout, "%8.3f\t");
			fout.println();

			// Write the number of frequencies
			fout.println("# Number of Frequencies");
			fout.println(frequencies.length);

			fout.println("# Frequency	Mean	Stdev	CDF Percentiles");
			// Write all frequencies and their associated noise values
			int N = frequencies.length;
			for (int i = 0; i < N; i++)
			{
				fout.print(String.format("%8.3f\t%8.3f\t%8.3f", frequencies[i], _mean[i], _std[i]));
				for (int j = 0; j < _cdf[i].length; j++)
					fout.print(String.format("\t%8.3f", _cdf[i][j]));
				fout.println();
			}

			setDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			value = false;
		}
		finally
		{
			if ( fout != null )
				IOUtility.safeClose(fout);
		}

		return value;
	}
}
