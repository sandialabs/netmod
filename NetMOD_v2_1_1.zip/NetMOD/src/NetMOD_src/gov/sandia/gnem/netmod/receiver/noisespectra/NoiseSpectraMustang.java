/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver.noisespectra;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.NormalPDF;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;

/**
 * Noise spectra dynamically obtained from the Mustang web app
 * 
 * @author bjmerch
 *
 */
public class NoiseSpectraMustang extends AbstractNetModFile implements NoiseSpectra
{
	private static final NormalPDF NO_RESULT = new NormalPDF(999, 0);
	private static final SpectraPDF NO_RESULT_SPECTRA = new SpectraPDF(NO_RESULT);
	private static String _type = "Noise Spectra Mustang";

	// Register the plugin
	static
	{
		NoiseSpectraPlugin.getPlugin().registerComponent(_type, NoiseSpectraMustang.class);
	}

	private double[] _frequencies;
	private double[] _percentiles;

	private double[] _mean;
	private double[] _std;

	// N_percentiles x N_frequencies
	private double[][] _cdf;

	/*
	 * Cache requested noise
	 */
	private CacheMap<Frequency, SpectraPDF> _cache = new CacheMap<Frequency, SpectraPDF>(CacheMap.CACHE_FREQUENCY);

	public NoiseSpectraMustang(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();

		_frequencies = null;
		_cdf = null;
		_cache.clear();
	}

	/**
	 * Get the frequencies over which the noise spectra is defined
	 * 
	 * @return
	 */
	@Override
	public double[] getFrequencies()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_frequencies == null)
				read();
		}

		return _frequencies;
	}

	/**
	 * Get the percentiles over which the noise spectra is defined
	 * 
	 * @return
	 */
	public double[] getPercentiles()
	{
		// Synchronize around read check to avoid multi-threaded collisions
		synchronized (this)
		{
			if (_percentiles == null)
				read();
		}

		return _percentiles;
	}

	/**
	 * Get the CDF values for the noise spectra
	 * 
	 * @return
	 */
	public double[][] getCDF()
	{
		return _cdf;
	}

	@Override
	public SpectraPDF getNoise(Frequency frequency, Time time)
	{
		startIntrospection();
		recordIntrospection("Noise Spectra from file: ", getFilename(), "'");
		recordIntrospection("at frequency (Hz): ", frequency);

		/*
		 * Check for a cached value
		 */
		SpectraPDF noise = _cache.get(frequency);
		if (noise != null)
		{
			recordIntrospection("Noise (log10 PSD): ", noise);
			stopIntrospection();
			return noise;
		}

		/*
		 * Check for no noise defined
		 */
		double[] frequencies = getFrequencies();
		if (frequencies == null || frequencies.length == 0)
		{
			noise = NO_RESULT_SPECTRA;

			recordIntrospection("No noise defined");
			recordIntrospection("Noise (log10 PSD): ", noise);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();

			return noise;
		}

		// Identify the evaluation frequencies
		double[] f_eval = getEvaluationFrequencies(frequency, _frequencies);
		int N = f_eval.length;

		// Check that the range overlaps the available frequencies
		if (N == 0)
		{
			noise = NO_RESULT_SPECTRA;

			recordIntrospection("Frequency outside bounds, no noise spectra defined");
			recordIntrospection("Noise (log10 PSD): ", noise);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return noise;
		}

		noise = new SpectraPDF(N);
		for (int i = 0; i < N; i++)
			noise.setValue(i, f_eval[i], computeNoise(f_eval[i]));

		recordIntrospection("Noise (log10 PSD): ", noise);
		stopIntrospection();

		/*
		 * Cache the results for the next call
		 */
		_cache.put(frequency, noise);

		return noise;
	}

	/**
	 * Low-level method for computing noise at a particular frequency
	 * 
	 * @param frequency
	 * @return
	 */
	private NonParametricCDF computeNoise(double frequency)
	{
		double mean = Interpolation.interpolateQuadratic(_frequencies, _mean, frequency);
		double sd = Interpolation.interpolateQuadratic(_frequencies, _std, frequency);

		double[] x = new double[_percentiles.length];
		for (int i = 0; i < x.length; i++)
			x[i] = Interpolation.interpolateQuadratic(_frequencies, _cdf[i], frequency);

		return new NonParametricCDF(x, _percentiles, mean, sd);
	}

	@Override
	public NoiseSpectraMustangViewer getViewer()
	{
		return new NoiseSpectraMustangViewer(this);
	}

	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a url from the object
		String url = null;
		if (o instanceof File)
			url = ((File) o).getPath();
		else if (o instanceof String)
			url = (String) o;
		else if (o instanceof URL)
			url = ((URL) o).toString();

		if (url == null)
			return false;

		return url.contains("mustang/noise-pdf");
	}

	@Override
	public boolean read()
	{
		boolean valid = false;

		// Synchronize on the type to prevent errors if simultaneously reading from the
		// same file
		synchronized (_type)
		{
			BufferedReader in = null;
			try
			{
				URL url = new URL(IOUtility.cleanString(getFilename()));
				in = new BufferedReader(new InputStreamReader(url.openStream()));

				// Map of Frequency -> ( Map of Percentile Column Name -> Percentile Value)
				Map<Double, ObjectDoubleMap<String>> cdfMap = new TreeMap<Double, ObjectDoubleMap<String>>();
				List<String> columns = new ArrayList<String>();

				String line;
				while ((line = in.readLine()) != null)
				{
					line = line.trim();
					Double frequency = null;

					/// Skip blank lines
					if (line.isEmpty())
					{
					}
					// Check for comments and handle a header line
					else if (line.startsWith("#"))
					{
						// Check for header line defining content, there can only be one header
						if (line.startsWith("#freq(hz)") && columns.size() == 0)
						{
							for (String str : line.split(","))
							{
								String column = str.trim().toLowerCase();
								columns.add(column);
							}
						}
					}
					else
					{
						// Parse each column of noise-pdf from the current line
						String[] strs = line.split(",");
						if (strs.length == 0)
							continue;

						int N = strs.length;
						for (int i = 0; i < N; i++)
						{
							String column = columns.get(i);
							String value = strs[i].trim();

							// Frequency
							if (column.equals("#freq(hz)"))
							{
								frequency = Double.parseDouble(value);
							}
							// Percentiles
							else if (column.endsWith("%"))
							{
								// Don't process percentiles with a bad frequency value
								if (frequency == null || frequency <= 0 || !Double.isFinite(frequency))
									continue;

								ObjectDoubleMap<String> percentileMap = cdfMap.get(frequency);
								if (percentileMap == null)
								{
									percentileMap = new ObjectDoubleOpenHashMap<String>();
									cdfMap.put(frequency, percentileMap);
								}

								double cdf = 0.1 * Double.parseDouble(value)
										+ 2.0 * Math.log10(1.0e9 / (4 * Math.PI * Math.PI * frequency * frequency));
								percentileMap.put(column, cdf);
							}
						}
					}
				}

				// Extract the percentile values
				List<String> percentileNames = new ArrayList<String>();
				Map<String, Double> percentileMap = new HashMap<String, Double>();
				for (String column : columns)
				{
					if (column.endsWith("%"))
					{
						double value = Double.parseDouble(column.substring(0, column.length() - 1).trim());
						value = value / 100.0;

						percentileNames.add(column);
						percentileMap.put(column, value);
					}
				}

				// Sort the percentiles in increasing value
				percentileNames.sort(new Comparator<String>()
				{
					@Override
					public int compare(String o1, String o2)
					{
						return percentileMap.get(o1).compareTo(percentileMap.get(o2));
					}
				});

				int Npercentiles = percentileNames.size();
				double[] percentiles = new double[Npercentiles];
				int i = 0;
				for (String percentileName : percentileNames)
					percentiles[i++] = percentileMap.get(percentileName);

				// Extract the frequencies and cdf values in sorted orders
				int Nfreq = cdfMap.size();

				double[][] cdf = new double[Npercentiles][Nfreq];
				double[] frequencies = new double[Nfreq];
				double[] mean = new double[Nfreq];
				double[] stdev = new double[Nfreq];

				// Temporary array to use for computing mean and stdev from CDF values
				double[] tmp_values = new double[Npercentiles];

				int i_freq = 0;
				for (Double frequency : cdfMap.keySet())
				{
					frequencies[i_freq] = frequency;

					// Map of column name to noise values
					ObjectDoubleMap<String> subMap = cdfMap.get(frequency);

					// Iterate over percentile columns in sorted order
					int i_percentile = 0;
					for (String columnName : percentileNames)
					{
						double value = subMap.get(columnName);

						cdf[i_percentile][i_freq] = value;
						tmp_values[i_percentile] = value;

						i_percentile++;
					}

					// Compute the mean and stdev at this frequency from the CDF
					NonParametricCDF nonparametric_cdf = new NonParametricCDF(tmp_values, percentiles);
					mean[i_freq] = nonparametric_cdf.getMean();
					stdev[i_freq] = nonparametric_cdf.getStandardDeviation();

					i_freq++;
				}

				_frequencies = frequencies;
				_percentiles = percentiles;
				_mean = mean;
				_std = stdev;
				_cdf = cdf;

				valid = true;
				setDirty(false);
			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					GUIUtility.showExceptionDialog(null, "Network Connection Error",
							"Unable to connect to Mustang server: '" + getFilename() + "'", e);
				}

				_frequencies = new double[0];
				_percentiles = new double[0];
				_mean = new double[0];
				_std = new double[0];
				_cdf = new double[0][0];
			}
			finally
			{
				IOUtility.safeClose(in);
			}
		}

		return valid;
	}

	/**
	 * Remove the noise value at the provided frequency
	 * 
	 * @param frequency
	 */
	public void removeNoise(double frequency)
	{
		// Find the index of the existing noise
		int index = Arrays.binarySearch(getFrequencies(), frequency);
		if (index < 0)
			return;

		// Create copies of the arrays, excluding the index
		_frequencies = removeIndex(_frequencies, index);
		_cdf = removeIndex(_cdf, index);

		_cache.clear();
		setDirty(false);
	}

	/**
	 * Set the noise value at the provided frequency and percentile
	 * 
	 * @param frequency
	 * @param percentile
	 * @param value
	 */
	public void setNoise(double frequency, double percentile, double value)
	{
		int p_index = findIndex(getPercentiles(), percentile);
		int f_index = findIndex(getFrequencies(), frequency);

		if (p_index >= _percentiles.length || _percentiles[p_index] != percentile)
		{
			_percentiles = insertIndex(_percentiles, p_index, percentile);

			// Insert new distance entry for all frequencies
			_cdf = insertIndex(_cdf, p_index, new double[_frequencies.length]);
		}

		if (f_index >= _frequencies.length || _frequencies[f_index] != frequency)
		{
			_frequencies = insertIndex(_frequencies, f_index, frequency);

			// Create a new frequency entry for all distances
			for (int i = 0; i < _percentiles.length; i++)
				_cdf[i] = insertIndex(_cdf[i], f_index, 0);
		}

		// Insert attenuation at location
		_cdf[p_index][f_index] = value;

		_cache.clear();
		setDirty(true);
	}

	@Override
	public boolean write()
	{
		// Can't write to a Mustang web-service
		return false;
	}
}
