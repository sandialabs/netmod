package gov.sandia.gnem.netmod.map.wordwind2;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.TreePath;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.avlist.AVList;
import gov.nasa.worldwind.event.SelectEvent;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable;
import gov.nasa.worldwind.formats.shapefile.ShapefileRenderable.Record;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.LayerList;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.pick.PickedObject;
import gov.nasa.worldwind.render.OrderedRenderable;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwindx.examples.util.LayerManagerLayer;
import gov.sandia.gnem.netmod.gui.GUIUtility;

public class NetMODLayerManagerLayer extends LayerManagerLayer
{
	public class LayerPopup extends JPopupMenu
	{
		WorldWindow _wwd = null;
		Layer _layer = null;
		

		private class DeleteAction extends AbstractAction
	    {
	        public DeleteAction()
	        {
	            putValue(NAME, "Delete");
	            putValue(SHORT_DESCRIPTION, "Delete selected layer");
	        }

	        public void actionPerformed(ActionEvent e)
	        {
	        	_wwd.getModel().getLayers().remove(_layer);
	        }

	        /**
	         * Control when this action is enabled. It is only enabled with a
	         * non-root selection.
	         */
	        public boolean isEnabled()
	        {
	        	return true;
	        }
	    }
		
		private class SaveAction extends AbstractAction
	    {
	        public SaveAction()
	        {
	            putValue(NAME, "Save KML ...");
	            putValue(SHORT_DESCRIPTION, "Save selected layer as a KML file");
	        }

	        public void actionPerformed(ActionEvent e)
	        {
                File file = GUIUtility.showSaveDialog((Component) wwd, null, "Save KML", JFileChooser.FILES_ONLY, null, null);
                if ( file == null )
                    return;
                
                KMLLayerLoader.save(file, (RenderableLayer) _layer);
	        }

	        /**
	         * Control when this action is enabled. It is only enabled with a
	         * non-root selection.
	         */
	        public boolean isEnabled()
	        {
	        	return _layer instanceof RenderableLayer;
	        }
	    }
		
		private class FeaturesAction extends AbstractAction
	    {
			private class FeatureTableModel extends AbstractTableModel
			{
				RenderableLayer _layer;
				List<AVList> _renderables = new ArrayList<AVList>();
				List<String> _columns = new ArrayList<String>();

				public FeatureTableModel(RenderableLayer layer)
				{
					_layer = layer;
					
					Set<String> columns = new TreeSet<String>();
					for (Renderable r : layer.getRenderables())
						addAllRenderables(r, _renderables, columns);
					
					_columns.addAll(columns);
				}
				
				/**
				 * Iteratively add all renderables as sometimes they are nested
				 * 
				 * @param r
				 * @param renderables
				 * @param columns
				 */
				private void addAllRenderables(Object r, List<AVList> renderables, Set<String> columns)
				{
					if ( r instanceof ShapefileRenderable )
					{
						ShapefileRenderable sr = (ShapefileRenderable) r;
						int N = sr.getRecordCount();
						for (int i=0; i<N; i++)
							addAllRenderables(sr.getRecord(i), renderables, columns);
					}
					else if ( r instanceof AVList )
					{
						renderables.add((AVList) r);
						for ( Entry<String, Object> entry : ((AVList) r).getEntries())
						{
							String key = entry.getKey();
							
							if ( key.startsWith("avlist") )
							{}
							else
								columns.add(entry.getKey());
						}
					}
				}

				@Override
				public int getRowCount()
				{
					return _renderables.size();
				} 
				
				public Class<?> getColumnClass(int columnIndex)
				{
					int N = getRowCount();
					for (int i=0; i<N; i++)
					{
						Object value = getValueAt(i, columnIndex);
						if ( value != null )
							return value.getClass();
					}
					
					return String.class;
			    }

				@Override
				public int getColumnCount()
				{
					return _columns.size();
				}

				@Override
				public String getColumnName(int columnIndex)
				{
					return _columns.get(columnIndex);
				}

				@Override
				public Object getValueAt(int rowIndex, int columnIndex)
				{
					AVList r = _renderables.get(rowIndex);

					if ( r instanceof AVList )
						return r.getValue(_columns.get(columnIndex));

					return null;
				}
			}
			
			
	        public FeaturesAction()
	        {
	            putValue(NAME, "Features ...");
	            putValue(SHORT_DESCRIPTION, "Display features in the selected layer");
	        }

	        public void actionPerformed(ActionEvent e)
	        {
	        	FeatureTableModel tableModel = new FeatureTableModel((RenderableLayer) _layer);
	        	JTable table = new JTable(tableModel);
	        	table.setAutoCreateRowSorter(true);
	        	JScrollPane scrollPane = new JScrollPane(table);
	        	
	        	JOptionPane pane = new JOptionPane(scrollPane);
	        	JDialog dialog = pane.createDialog((Component) _wwd, _layer.getName() + " Features");
	        	dialog.setResizable(true);
	        	dialog.setVisible(true);
	        }

	        /**
	         * Control when this action is enabled. It is only enabled with a
	         * non-root selection.
	         */
	        public boolean isEnabled()
	        {
	        	return _layer instanceof RenderableLayer;
	        }
	    }
		
		private class SymbolsAction extends AbstractAction
	    {
	        public SymbolsAction()
	        {
	            putValue(NAME, "Symbols ...");
	            putValue(SHORT_DESCRIPTION, "Configure symbols in the selected layer");
	        }

	        public void actionPerformed(ActionEvent e)
	        {
	        	SymbolPanel panel = new SymbolPanel();
	        	panel.setLayer((RenderableLayer) _layer);
	        	
	        	JOptionPane pane = new JOptionPane(panel, JOptionPane.PLAIN_MESSAGE, JOptionPane.OK_CANCEL_OPTION);
	        	JDialog dialog = pane.createDialog((Component) _wwd, _layer.getName() + " Symbols");
	        	dialog.setResizable(true);
	        	dialog.setVisible(true);
	        	
	        	Object value = pane.getValue();
	        	if ( value != null && ((Integer) value).intValue() == JOptionPane.OK_OPTION )
	        	{
	        		panel.getSymbols((RenderableLayer) _layer);
	        		_wwd.redraw();
	        	}	
	        }

	        /**
	         * Control when this action is enabled. It is only enabled with a
	         * non-root selection.
	         */
	        public boolean isEnabled()
	        {
	        	return _layer instanceof RenderableLayer;
	        }
	    }
		
	    public LayerPopup(WorldWindow wwd, Layer layer)
	    {
	    	_wwd = wwd;
	    	_layer = layer;

	    	add(new JMenuItem(new FeaturesAction()));
	    	add(new JMenuItem(new SymbolsAction()));
	    	addSeparator();
	    	add(new JMenuItem(new SaveAction()));
	    	add(new JMenuItem(new DeleteAction()));
	    }
	}

	public NetMODLayerManagerLayer(WorldWindow wwd)
	{
		super(wwd);
	}
	
    /**
     * Extend WorldWind LayerManager to add a right-click popupmenu
     */
    public void selected(SelectEvent event)
    {
    	super.selected(event);
    	
    	//  Show a popupmenu on a right-click
    	if ( event.getEventAction().equals(SelectEvent.RIGHT_CLICK))
    	{
            // Check for text or url
            PickedObject po = event.getTopPickedObject();
            if (po.getValue(AVKey.URL) != null)
            {
                int i = Integer.parseInt((String) po.getValue(AVKey.URL));

                LayerList layers = wwd.getModel().getLayers();
                if (i >= 0 && i < layers.size())
                {
                	Layer layer = layers.get(i);
                	
                	LayerPopup popup = new LayerPopup(wwd, layer);
                	popup.show(event.getMouseEvent().getComponent(), event.getMouseEvent().getX(), event.getMouseEvent().getY());
                }
            }
    	}
    }
}
