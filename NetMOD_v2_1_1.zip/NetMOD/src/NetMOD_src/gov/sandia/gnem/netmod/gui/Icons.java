/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * @author bjmerch
 *
 */
public enum Icons
{
    ADD("/oxygen/$SIZE$/actions/edit_add.png"),
    BACKWARD("/oxygen/$SIZE$/actions/back.png"),
    CAMERA("/oxygen/$SIZE$/devices/camera_photo.png"),
    COPY("/oxygen/$SIZE$/actions/editcopy.png"),
    CUT("/oxygen/$SIZE$/actions/editcut.png"),
    DEFAULT_PARAMETERS("/oxygen/$SIZE$/filesystems/folder_bookmarks.png"),
    DELETE("/oxygen/$SIZE$/actions/editdelete.png"),
    DELETE_USER("/oxygen/$SIZE$/actions/delete_user.png"),
    DETAILS("/oxygen/$SIZE$/actions/list.png"),
    DIFFERENCE("/oxygen/$SIZE$/actions/system_switch_user.png"),
    DOWN("/oxygen/$SIZE$/actions/1downarrow.png"),
    EDIT("/oxygen/$SIZE$/actions/editcopy.png"),
    EDIT_USER("/oxygen/$SIZE$/actions/edit_user.png"),
    EXPORT_DATA("/oxygen/$SIZE$/actions/document_save.png"),
    FOLDER("/oxygen/$SIZE$/filesystems/folder.png"),
    FORWARD("/oxygen/$SIZE$/actions/forward.png"),
    GENERATE("/oxygen/$SIZE$/apps/plasmagik.png"),
    HELP("/oxygen/$SIZE$/actions/help_about.png"),
    INTROSPECTION("/oxygen/$SIZE$/actions/view_tree.png"),
    LAYERS("/oxygen/$SIZE$/actions/view_list_tree.png"),
    LEFT("/oxygen/$SIZE$/actions/1leftarrow.png"),
    MAP("/oxygen/$SIZE$/actions/network.png"),
    MEASURE("/oxygen/$SIZE$/actions/measure.png"),
    MODEL_VISIBLE("/oxygen/$SIZE$/actions/list.png"),
    NEW("/oxygen/$SIZE$/actions/document_new.png"),
    NEW_USER("/oxygen/$SIZE$/actions/add_user.png"),
    OPEN("/oxygen/$SIZE$/actions/document_open_folder.png"),
    PAN("/oxygen/$SIZE$/actions/transform_move.png"),
    PREFERENCES("/oxygen/$SIZE$/apps/preferences_system.png"),
    REFRESH("/oxygen/$SIZE$/actions/view_refresh.png"),
    RESET("/oxygen/$SIZE$/actions/revert.png"),
    RIGHT("/oxygen/$SIZE$/actions/1rightarrow.png"),
    RUN("/oxygen/$SIZE$/actions/tools_wizard.png"),
    SAVE("/oxygen/$SIZE$/actions/document_save.png"),
    SELECT("/oxygen/$SIZE$/actions/select_rectangular.png"),
    SETTINGS("/oxygen/$SIZE$/apps/applications_systemg.png"),
    STATUS1("/oxygen/$SIZE$/actions/flag_red.png"), 
    STATUS2("/oxygen/$SIZE$/actions/flag_yellow.png"), 
    STATUS3("/oxygen/$SIZE$/actions/flag_green.png"), 
    STOP("/oxygen/$SIZE$/actions/stop.png"), 
    UP("/oxygen/$SIZE$/actions/1uparrow.png"),
    VALUE_MARKER_VISIBLE("/oxygen/$SIZE$/filesystems/user_desktop.png"), 
    VIEW("/oxygen/$SIZE$/actions/view_statistics.png"),
    VISIBLE("/oxygen/$SIZE$/actions/revert.png"), 
    WINDOW("/oxygen/$SIZE$/actions/frame_edit.png"),
    ZOOM("/oxygen/$SIZE$/actions/zoom_in.png");

    private static final String SIZE = "$SIZE$";
    
    private static final String LARGE = "32x32";
    private static final String MEDIUM = "22x22";
    private static final String SMALL = "16x16";
    
    /**
     * Load the specified icon file into an image for use on a button, label, or
     * menu item.
     * 
     * @param icon
     * @return
     */
    public static ImageIcon getIcon(String icon)
    {
        try
        {
            icon = icon.replace(SIZE, getIconSize());
            
            ImageIcon imageIcon = new ImageIcon(GUIUtility.class.getResource(icon));
            
            return imageIcon;
        }
        catch (Exception e)
        {
            GUIUtility.showExceptionDialog(null, "Error loading icon", "Unable to load icon: " + icon, e);
        }

        return null;
    }
    
    private static final String getIconSize()
    {
        String size = Property.ICON_SIZE.getValue();
        
        if ( size == null )
            return MEDIUM;
        if ( size.equalsIgnoreCase("small") )
            return SMALL;
        if ( size.equalsIgnoreCase("medium") )
            return MEDIUM;
        if ( size.equalsIgnoreCase("large") )
            return LARGE;

        return MEDIUM;
    }
    /**
     * Load the image referenced by the specified file into a cursor. Check and
     * account for any system default cursor sizes.
     * 
     * @param file
     * @return
     */
    static Cursor getCursor(String file)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Image icon = getIcon(file).getImage();

        // The custom cursor size
        Dimension d = tk.getBestCursorSize(icon.getWidth(null), icon.getHeight(null));

        // Rescale the image, if necessary
        if (d.getWidth() > icon.getWidth(null) || d.getHeight() > icon.getHeight(null))
        {
            Image icon2 = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_ARGB);
            icon2.getGraphics().drawImage(icon, 0, 0, null);

            icon = icon2;
        }

        return tk.createCustomCursor(icon, new Point(0, 0), file);
    }
    private Cursor _cursor = null;

    private ImageIcon _icon = null;

    private String _icon_path;

    private Icons(String icon_path)
    {
        _icon_path = icon_path;
    }

    public Cursor getCursor()
    {
        if (_cursor == null)
            _cursor = getCursor(_icon_path);

        return _cursor;
    }

    public ImageIcon getIcon()
    {
        if (_icon == null)
            _icon = getIcon(_icon_path);

        return _icon;
    }
}
