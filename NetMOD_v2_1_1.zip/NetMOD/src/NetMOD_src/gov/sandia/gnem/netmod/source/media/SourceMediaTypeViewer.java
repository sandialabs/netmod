/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.media;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.source.spectra.SourceSpectra;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 */
class SourceMediaTypeViewer extends NetModComponentViewer<SourceMediaType> {
    private JTextField _name = new JTextField();
    private FileField _sourceSpectra = new FileField("Source Spectra File", createSourceSpectraButton());
    private JFormattedTextField _density = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _beta3 = new JFormattedTextField(new DoubleRangeFormatter(-1000, Double.MAX_VALUE));
    private JFormattedTextField _beta4 = new JFormattedTextField(new DoubleRangeFormatter(-1000, Double.MAX_VALUE));
    private JFormattedTextField _beta5 = new JFormattedTextField(new DoubleRangeFormatter(-1000, Double.MAX_VALUE));

    SourceMediaTypeViewer(SourceMediaType nmc) {
        super(nmc, true, false);

        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);

        //  Register the controls that are monitored after updating
        registerControls(_name, _density, _beta3, _beta4, _beta5);
    }

    private JButton createSourceSpectraButton() {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Source Spectra");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                //  Get the noise spectra object
                SourceSpectra sourceSpectra = _nmc.getSourceSpectra();
                if (sourceSpectra == null || !sourceSpectra.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) sourceSpectra.getViewer();
                if (viewer == null)
                    return;

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Source Spectra - " + sourceSpectra.getName());
            }
        });

        return button;
    }

    @Override
    public void apply(SourceMediaType nmc) {
        nmc.setName(_name.getText());
        nmc.setDensity(((Number) _density.getValue()).doubleValue());
        nmc.setSourceSpectraFile(_sourceSpectra.getText());
        nmc.setBeta3(((Number) _beta3.getValue()).doubleValue());
        nmc.setBeta4(((Number) _beta4.getValue()).doubleValue());
        nmc.setBeta5(((Number) _beta5.getValue()).doubleValue());
    }

    @Override
    public JPanel getExpandedPanel() {
        if (_expandedPanel == null) {
            JPanel panel = new JPanel(new GridBagLayout());

            _density.setToolTipText("Source Media Density (kg/m^3)");

            //  Setup the panel
            GUIUtility.addRow(panel, new JLabel("Name: "), _name);
            GUIUtility.addRow(panel, new JLabel("Density: "), _density);
            GUIUtility.addRow(panel, new JLabel("Elevation Beta 3: "), _beta3);
            GUIUtility.addRow(panel, new JLabel("Elevation Beta 4: "), _beta4);
            GUIUtility.addRow(panel, new JLabel("Elevation Beta 5: "), _beta5);
            GUIUtility.addRow(panel, new JLabel("Source Spectra: "), _sourceSpectra);
            GUIUtility.addRow(panel, _nmc.getEventSizeConversion().getViewer());
            GUIUtility.addRow(panel, _nmc.getPhaseParameters().getViewer());

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(SourceMediaType nmc) {
        _name.setText(nmc.getName());
        _density.setValue(nmc.getDensity());
        _sourceSpectra.setText(nmc.getSourceSpectraFile());
        _beta3.setValue(nmc.getBeta3());
        _beta4.setValue(nmc.getBeta4());
        _beta5.setValue(nmc.getBeta5());
    }

}
