/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import java.util.*;
import java.util.Map.Entry;

/**
 * Map with a tuple key <K1, K2> to a single value V
 * Note that the key <K1, K2> is not equivalent to <K2, K1>
 * 
 * @author bjmerch
 *
 */
public class TupleMap<K1 extends Object, K2 extends Object, V extends Object>
{
    protected Map<K1, Map<K2, V>> _map = new HashMap<K1, Map<K2, V>>();
    private Class<V> _c = null;

    /**
     * Construct a tuple map with the provided class identifier
     * if the "get" is desired to automatically create and insert
     * a default value (using the empty constructor).  Other wise,
     * a get will return null if the map does not contain the desired keys
     * 
     * @param c
     */
    public TupleMap(Class<V> c)
    {
        _c = c;
    }
    
    public void clear()
    {
        _map.clear();
    }
    
    /**
     * Get the set of K1 keys
     * 
     * @return
     */
    public Set<K1> getKeys1()
    {
        return _map.keySet();
    }
    
    /**
     * Get the set of K2 keys
     * 
     * @return
     */
    public Set<K2> getKeys2()
    {
        Set<K2> keys = new HashSet<K2>();

        synchronized (_map)
        {
            for (Entry<K1, Map<K2, V>> entry : _map.entrySet())
                keys.addAll(entry.getValue().keySet());
        }
        
        return keys;
    }
    
    /**
     * Get the collection of values in the tuple map
     * 
     * @return
     */
    public Collection<V> getValues()
    {
        List<V> values = new ArrayList<V>();
        
        synchronized(_map)
        {
            for ( Entry<K1, Map<K2, V>> entry : _map.entrySet() )
                values.addAll(entry.getValue().values());
        }
        
        return values;
    }
    
    /**
     * Get the value attached to the provided keys
     * 
     * @param k1
     * @param k2
     * @return
     */
    public V get(K1 k1, K2 k2)
    {
        Map<K2, V> map2 = getMap2(k1);

        synchronized (map2)
        {
            V value = map2.get(k2);
            if (value == null && _c != null)
            {
                try
                {
                    value = _c.getConstructor().newInstance();
                    map2.put(k2, value);
                }
                catch (Exception e)
                {
                }
            }
            return value;
        }
    }
    
    /**
     * Put the value assigned to the provided keys
     * 
     * @param k1
     * @param k2
     * @param v
     */
    public void put(K1 k1, K2 k2, V v)
    {
        Map<K2, V> map2 = getMap2(k1);
        
        synchronized(map2)
        {
            map2.put(k2, v);
        }
    }
    
    /**
     * Get the second level of the map
     * 
     * @param k1
     * @return
     */
    private Map<K2, V> getMap2(K1 k1)
    {
        synchronized (_map)
        {
            Map<K2, V> map2 = _map.get(k1);
            if (map2 == null)
            {
                map2 = new HashMap<K2, V>();
                _map.put(k1, map2);
            }

            return map2;
        }
    }
}
