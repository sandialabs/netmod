/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.basic;

import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.gui.VisibleXYDataset;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.AbstractXYZDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.RectangleAnchor;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class JFreeChartMediaGridLayer extends AbstractXYZDataset implements Layer<MediaGrid<NetModComponent>>, JFreeChartLayer<MediaGrid<NetModComponent>>, VisibleXYDataset
{
    private XYBlockRenderer _renderer = new XYBlockRenderer();
    private PaintScale _paintScale = null;
    private MediaGrid<NetModComponent> _mediaGrid;
    private HashMap<NetModComponent, Integer> _mediaTypeMap = new HashMap<NetModComponent, Integer>();
    private boolean _visible = true;

    protected JFreeChartMediaGridLayer(MediaGrid grid)
    {
        //  Define a paint scale that encompasses the media grid palette
        _paintScale = new PaintScale()
        {

            @Override
            public double getLowerBound()
            {
                return 0;
            }

            @Override
            public Paint getPaint(double value)
            {
                Color c = getColor((int) value);
                return new Color(c.getRed(), c.getGreen(), c.getBlue(), 128);
            }

            @Override
            public double getUpperBound()
            {
                return _mediaTypeMap.size();
            }
        };
        
        setNMC(grid);
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }
    
    @Override
    public int getItemCount(int arg0)
    {
        if ( !isVisible() )
            return 0;
        
        return _mediaGrid.getLatitudeCount() * _mediaGrid.getLongitudeCount();
    }

    @Override
    public JPanel getLegendPanel()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        int count = 0;
        for (NetModComponent type : getNMC().getMediaTypes())
        {
            Color c = getColor(count++);
            
            GUIUtility.addRow(panel, new JLabel(""), generatePolygon(new Color(c.getRed(), c.getGreen(), c.getBlue(), 128), Color.BLACK, 1.0, type.toString()));
        }
        
        return panel;
    }

    @Override
    public MediaGrid<NetModComponent> getNMC()
    {
        return _mediaGrid;
    }

    /**
     * @return
     */
    public XYItemRenderer getRenderer(int index)
    {
        _renderer.setBlockHeight(_mediaGrid.getLatitudeDelta());
        _renderer.setBlockWidth(_mediaGrid.getLongitudeDelta());
        _renderer.setBlockAnchor(RectangleAnchor.BOTTOM_LEFT);
        _renderer.setBasePaint(getColor(0));
        _renderer.setPaintScale(_paintScale);
        _renderer.setBaseToolTipGenerator(new XYToolTipGenerator(){

            @Override
            public String generateToolTip(XYDataset dataset, int series, int item)
            {
                if ( dataset instanceof XYZDataset )
                {
                    int latIndex = getLatitudeIndex(item);
                    int lonIndex = getLongitudeIndex(item);
                    
                    NetModComponent mediaType = _mediaGrid.getMediaType(lonIndex, latIndex);
                    
                    return mediaType.getName();
                }
                
                return null;
            }});
        
        
        return _renderer;
    }
    @Override
    public int getSeriesCount()
    {
        return 1;
    }
    @Override
    public Comparable getSeriesKey(int series)
    {
        return _mediaGrid.getName();
    }

    @Override
    public Number getX(int series, int item)
    {
        int lonIndex = getLongitudeIndex(item);
        
        return _mediaGrid.getLongitude() + lonIndex * _mediaGrid.getLongitudeDelta();
    }

    @Override
    public Number getY(int series, int item)
    {
        int latIndex = getLatitudeIndex(item);
        
        return _mediaGrid.getLatitude() + latIndex * _mediaGrid.getLatitudeDelta();
    }

    @Override
    public Number getZ(int series, int item)
    {
        int latIndex = getLatitudeIndex(item);
        int lonIndex = getLongitudeIndex(item);
        
        return _mediaTypeMap.get(_mediaGrid.getMediaType(lonIndex, latIndex));
    }

    @Override
    public boolean isVisible()
    {
        return _visible;
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
    }

    @Override
    public void setNMC(MediaGrid<NetModComponent> data)
    {
        _mediaGrid = data;   
        
        _mediaTypeMap.clear();
        int i = 0;
        for ( NetModComponent nmc : _mediaGrid.getMediaTypes())
            _mediaTypeMap.put(nmc, i++);
        fireDatasetChanged();
    }
    
    @Override
    public void setVisible(boolean visible)
    {
        _visible = visible;
        
        fireDatasetChanged();
    }

    /**
     * Generate a label that uses the provided image as an icon
     * and uses the provided range as a label.
     * 
     * @param image
     * @param range
     * @return
     */

    private JLabel generateLabel(BufferedImage image, String text)
    {
        JLabel label = new JLabel();

        if (image != null)
            label.setIcon(new ImageIcon(image));

        label.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));

        if(text!=null) label.setText(text);
        else label.setText("");

        return label;
    }

    /**
     * Generate a label the represents a polygon symbology
     * 
     * @param fillType
     * @param fillPaint
     * @param range
     * @return
     */
    private JLabel generatePolygon(Paint fillPaint, Color lineColor, double width, String overridelabel)
    {
        BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g = image.createGraphics();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(fillPaint);
        g.fillRect(0, 0, 16, 16);

        g.setColor(lineColor);
        g.setStroke(new BasicStroke((float) width, BasicStroke.CAP_SQUARE, 1, BasicStroke.JOIN_MITER, null, 0));
        g.drawRect(0, 0, 15, 15);
        g.dispose();

        return generateLabel(image, overridelabel);
    }

    /**
     * Get the i'th color
     * 
     * @param i
     * @return
     */
    private Color getColor(int i)
    {
        List<Color> colors = Property.MEDIA_GRID_COLOR_PALETTE.getColorPaletteValue();
        
        return colors.get(i % colors.size());
    }

    private int getLatitudeIndex(int item)
    {
        return item % _mediaGrid.getLatitudeCount();
    }

    private int getLongitudeIndex(int item)
    {
        return item / _mediaGrid.getLatitudeCount();
    }
}
