/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.numeric.DiscreteFrequency;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.AbstractPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;

import java.util.List;

/**
 * @author bjmerch
 *
 */
abstract public class StationDetection extends AbstractNetModComponent
{
    public enum FrequencyType
    {
        /**
         * The probability of detection is the highest probability observed
         * at any of the individual frequencies.
         *
         */
        HIGH("Highest Probability")
        {
            @Override
            public PDF computeSNR(List<PDF> logSNRs, double threshold)
            {
            	if ( logSNRs.size() == 0 )
            		return null;
            	
            	//  Set the max SNR to the first one
                PDF maxSNR = logSNRs.get(0);
            	double maxP = maxSNR.computeProbabilityGTE(threshold);

                //  Compare against all of the SNRs
                for (PDF snr : logSNRs)
                {
                	double p = snr.computeProbabilityGTE(threshold);
                	
                    //  Check if SNR has a greater probability or if probabilities are equal, use the SNR with the higher mean value
                    if (p > maxP || (p == maxP && snr.getMean() > maxSNR.getMean() ))
                    {
                    	maxP = p;
                        maxSNR = snr;
                    }
                }

                return maxSNR;
            }

        },
        /**
         * The probability of detection is the second highest probability observed
         * at any of the individual frequencies.
         *
         */
        HIGH_2("2nd Highest Probability")
        {
            @Override
            public PDF computeSNR(List<PDF> logSNRs, double threshold)
            {
            	if ( logSNRs.size() == 0 )
            		return null;
            	
            	//  Set the max SNR to the first one
                PDF maxSNR = logSNRs.get(0);
            	double maxP = maxSNR.computeProbabilityGTE(threshold);
            	
            	//  Set the 2nd max to the same as the first
                PDF maxSNR2 = maxSNR;
            	double maxP2 = maxP;

                //  Compare against all of the SNRs
                for (PDF snr : logSNRs)
                {
                	double p = snr.computeProbabilityGTE(threshold);
                	
					// Check if SNR has a greater probability or if probabilities are equal, use the
					// SNR with the higher mean value
					if (p > maxP || (p == maxP && snr.getMean() > maxSNR.getMean()))
					{
						// Shift old highest to second highest
						maxP2 = maxP;
						maxSNR2 = maxSNR;

						// Set highest
						maxP = p;
						maxSNR = snr;
					}
					else
					{
						if ( p > maxP2 || (p == maxP2 && snr.getMean() > maxSNR2.getMean() ))
						{
							maxP2 = p;
							maxSNR2 = snr;
						}
					}
                }

                return maxSNR2;
            }
        },
        /**
         * The probability of detection is obtained from the average of the log SNR.
         *
         */
        AVERAGE("Averaged SNR")
        {
            @Override
            public PDF computeSNR(List<PDF> logSNRs, double threshold)
            {
                if (logSNRs.size() == 0)
                    return null;
                
                //  Average the SNR values
                return AbstractPDF.sum(logSNRs).scale(1.0 / logSNRs.size());
            }
        };
    	
    	private String _name;
    	private FrequencyType(String name)
    	{
    		_name = name;
    	}
    	
    	public String getName()
    	{
    		return _name;
    	}

        /**
         * Compute the overall SNR given the list of SNR distributions at various frequencies
         * 
         * @param logSNR
         * @param threshold
         * @return
         */
        abstract public PDF computeSNR(List<PDF> logSNR, double threshold);
    }

    private FrequencyType _frequencyType = FrequencyType.HIGH;
    private Frequency[] _frequencies = new Frequency[]{ new DiscreteFrequency(1.0) };

    /**
     * @param parent
     * @param type
     */
    public StationDetection(NetModComponent parent, String type)
    {
        super(parent, type);
    }
    
    /**
     * @return the frequencies
     */
    public Frequency[] getFrequencies()
    {
        return _frequencies;
    }

    public FrequencyType getFrequencyType()
    {
        return _frequencyType;
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setFrequencies(Frequency.parseFrequencies(parameters.get(NetSimParameters.freqSampling)));
        setFrequencyType(FrequencyType.valueOf(parameters.get(SeismicDetectionParameters.freqType).toUpperCase()));
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(NetSimParameters.freqSampling, Frequency.formatFrequencies(getFrequencies()));
        parameters.set(SeismicDetectionParameters.freqType, getFrequencyType().toString());
    }

    /**
     * @param frequencies the frequencies to set
     */
    public void setFrequencies(Frequency[] frequencies)
    {
        _frequencies = frequencies;
    }

    public void setFrequencyType(FrequencyType frequencyType)
    {
        _frequencyType = frequencyType;
    }
}
