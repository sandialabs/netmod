/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.detection;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.rules.Criteria;
import gov.sandia.gnem.netmod.probability.rules.CriteriaFactory;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;

/**
 * @author bjmerch
 *
 */
abstract public class NetworkDetection extends AbstractNetModComponent
{
    private String _detectionRule = "";
    private Map<String, String> _detectionRules = new LinkedHashMap<String, String>();
    private Criteria _detectionCriteria = null;
    private List<? extends Phase> _phases = new ArrayList<Phase>();

    /**
     * @param parent
     * @param type
     */
    public NetworkDetection(NetModComponent parent, String type)    
    {
        super(parent, type);
    }


    /**
     * Compute a network probability
     * 
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param time
     * @param magnitude
     * @param signal
     * @param noise
     * @return
     */
    abstract public double computeDetectionProbability(Sources sources, Paths paths, Receivers receivers, 
            Point.Double epicenter, Time time, Magnitude magnitude, SignalAmplitude signal, NoiseAmplitude noise);


    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        if (children.size() == 0)
        {
            children.add(getDetectionCriteria());
        }

        return children;
    }

    /**
     * Get the detection criteria based upon the provided
     * detection rule.
     * 
     * @return
     */
    public Criteria getDetectionCriteria()
    {
        if (_detectionCriteria == null)
            _detectionCriteria = CriteriaFactory.createCriteria(getPhases(), getDetectionRules().get(getDetectionRule()));

        return _detectionCriteria;
    }
    
    /**
     * @return the detectionRule
     */
    public String getDetectionRule()
    {
        return _detectionRule;
    }

    /**
     * @return
     */
    public Map<String,String> getDetectionRules()
    {
        return _detectionRules;
    }

    /**
     * @return
     */
    private List<? extends Phase> getPhases()
    {
        return _phases;
    }

    /**
     * Get the station detection method
     * 
     * @return
     */
    abstract public StationDetection getStationDetection();

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        //  Load the Event Detection Criteria
        setDetectionRule(parameters.get(NetSimParameters.eventDetectionCriteria).trim());
        
        //  Lookup the EDC
        read(parameters.get(NetSimParameters.EDCConversionFile));
        
        //  Load the EDC parameter table
		ParTable edcTable = parameters.get(NetSimParameters.edcTable);
		if (edcTable != null)
		{
			Set<String> rowNames = edcTable.getRowNames();
			if (edcTable.getRowCount() > 0)
				getDetectionRules().clear();

			for (String rowName : rowNames)
			{
				String key = edcTable.getTableValue(rowName, NetSimParameters.EDC_LABEL);
				String value = edcTable.getTableValue(rowName, NetSimParameters.EDC_RULE);

				_detectionRules.put(key, value);
			}
		}
    }

    /**
     * Load the detection rules form a separate file, as defined in earlier versions
     * 
     * @param filename
     * @return
     */
    private boolean read(String filename)
    {
        boolean returnValue = false;
        FileInputStream fis = null;
        Scanner fin = null;
        try
        {

        	File file = IOUtility.openFile(IOUtility.fixPathSeparator(filename));
        	if ( !file.exists() )
        		return returnValue;
        	
            filename = file.getAbsolutePath();
            _detectionRules.clear();
            
            // Open file and read the title
            fis = new FileInputStream(file);
            fin = new Scanner(fis);
            
            //  Skip comments
            while (fin.hasNext("#"))
                fin.nextLine();
            
            while ( fin.hasNextLine() )
            {
                //  Read the next line
                String str = fin.nextLine();

                //  Split up the user label and the detection criteria
                int index = str.indexOf('|');
                if ( index < 0 )
                    continue;
                
                String key = str.substring(0, index).trim().toUpperCase();
                String value = str.substring(index+1).trim();
                
                _detectionRules.put(key, value);
            }
            
            returnValue = true;
        }
        catch (IOException e)
        {
            if ( !filename.isEmpty() )
            {
                System.out.println("Unable to Event Detection Criteria file: '" + filename + "'");
                e.printStackTrace();
            }
        }
        finally
        {
        	if ( fis != null )
        		IOUtility.safeClose(fis);
        	if ( fin != null)
        		IOUtility.safeClose(fin);
        }
        
        return returnValue;
    }
    
    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        //  Set the current detection rule
        parameters.set(NetSimParameters.eventDetectionCriteria, getDetectionRule());
        
        //  Save the Event Detection Criteria
        ParTable edcTable = parameters.get(NetSimParameters.edcTable);
        
        for (Entry<String, String> entry : getDetectionRules().entrySet())
        {
        	String row = entry.getKey();
        	

        	edcTable.setTableValue(row, NetSimParameters.EDC_LABEL, entry.getKey());
        	edcTable.setTableValue(row, NetSimParameters.EDC_RULE, entry.getValue());
        }
        
//        if ( files )
//        {
//            if (reset) 
//            {
//                //  Ensure the existing file is read in
//                read();
//                
//                setFilename(new File(parameters.getNS_CONFIG(), "phases.edc").getPath());
//            }
//            
//            write();
//        }
//        
//        parameters.set(NetSimParameters.EDCConversionFile, IOUtility.fixPathSeparator(getFilename()));
    }

    /**
     * @param detectionRule the detectionRule to set
     */
    public void setDetectionRule(String detectionRule)
    {
        //  Reset the detection criteria
        if ( !_detectionRule.equals(detectionRule) )
            _detectionCriteria = null;
        
        _detectionRule = detectionRule;
    }

    /**
     * @param phases
     */
    public void setPhases(List<? extends Phase> phases)
    {
        _phases = phases;
    }
}
