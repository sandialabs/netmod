/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.*;

/**
 * SubCriteria represented by a single phase
 * 
 * @author bjmerch
 *
 */
public class PhaseSubCriteria extends SubCriteria
{
    private Phase _phase;

    public PhaseSubCriteria(Phase phase)
    {
        _phase = phase;
    }

    /**
     * @return the phase
     */
    public Phase getPhase()
    {
        return _phase;
    }

    @Override
    public Set<Phase> getPhases()
    {
        TreeSet<Phase> phases = new TreeSet<Phase>();
        phases.add(getPhase());
        
        return phases;
    }

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    public ObjectDoubleMap<String> getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        ObjectDoubleMap<String> result = probabilities.get(getPhase());
        if ( result == null )
        {
            result = new ObjectDoubleOpenHashMap<String>();
            probabilities.put(getPhase(), result);
        }
        
        if ( isIntrospection() )
        {
            startIntrospection();
            recordIntrospection(this);

            //  Get the station set from the first map
            List<String> stations = Arrays.asList(result.keys().toArray(String.class));
            Collections.sort(stations);
            
            //  Iterate over each station
            for (String station : stations)
            {
                double p = result.get(station);

                if ( p > 0 )
                    recordIntrospection(station, ": ", p);
            }
            
            stopIntrospection();
        }
        
        return result;
    }

    @Override
    public String toString()
    {
        return getPhase().toString();
    }

}
