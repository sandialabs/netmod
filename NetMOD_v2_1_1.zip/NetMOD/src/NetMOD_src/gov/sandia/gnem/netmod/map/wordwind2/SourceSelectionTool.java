/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.view.orbit.BasicOrbitView;
import gov.nasa.worldwindx.examples.util.SectorSelector;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

/**
 * @author bjmerch
 *
 */
public class SourceSelectionTool<TYPE extends NetModComponent> extends AbstractAction
{
    private WorldWindow _wwd;
    private Sources _sources;
    private SectorSelector _selector;

    public SourceSelectionTool(WorldWindow wwd, Sources sources)
    {
        _wwd = wwd;
        _sources = sources;
        _selector = new SectorSelector(wwd)
        {
            @Override
            public void mouseReleased(MouseEvent mouseEvent)
            {
                super.mouseReleased(mouseEvent);
                
                //  Get the sector selected
                Sector sector = _selector.getSector();
                
                //  Build a sector around click point if none provided
                if ( sector == null )
                {
                    //  Get the cursors current position
                    Position currentPos = getWwd().getCurrentPosition();
                    if ( currentPos == null )
                        return;
                    
                    //  Get the sector that defines the area +/- around the point
                    BasicOrbitView view = (BasicOrbitView) getWwd().getView();
                    double dLat = 2 * view.getZoom() / 50000000;
                    double dLon = 2 * view.getZoom() / 50000000;
                    
                    //  Determine the lat/lon points of those points
                    double minLat = currentPos.getLatitude().getDegrees() - dLat;
                    double maxLat = currentPos.getLatitude().getDegrees() + dLat;
                    double minLon = currentPos.getLongitude().getDegrees() - dLon;
                    double maxLon = currentPos.getLongitude().getDegrees() + dLon;

                    sector = Sector.fromDegrees(minLat, maxLat, minLon, maxLon);
                }
                
                //  Get the region selected
                double minLat = sector.getMinLatitude().degrees;
                double maxLat = sector.getMaxLatitude().degrees;
                double minLon = sector.getMinLongitude().degrees;
                double maxLon = sector.getMaxLongitude().degrees;
                
                //  Get the current epicenter grid
                EpicenterGrid grid = _sources.getEpicenterGrid();
                
                //  Get the defined deltas
                double deltaLat = grid.getLatitudeDelta();
                double deltaLon = grid.getLongitudeDelta();
                
                //  Resample the current grid onto the selected region
                int minLatIndex = (int) Math.ceil((minLat - grid.getLatitudeStart())/deltaLat);
                int minLonIndex = (int) Math.ceil((minLon - grid.getLongitudeStart())/deltaLon);
                int maxLatIndex = (int) Math.floor((maxLat - grid.getLatitudeStart())/deltaLat);
                int maxLonIndex = (int) Math.floor((maxLon - grid.getLongitudeStart())/deltaLon);
                
                //  insert the new values
                grid.setLatitude(grid.getLatitudeStart() + minLatIndex * deltaLat, grid.getLatitudeStart() + maxLatIndex * deltaLat, deltaLat);
                grid.setLongitude(grid.getLongitudeStart() + minLonIndex * deltaLon,  grid.getLongitudeStart() + maxLonIndex * deltaLon, deltaLon);
                
                NetMOD.refresh(grid);
                grid.getViewer().refresh();
                
                //  Keep the the selector enabled
                _selector.disable();
                _selector.enable();
            }
        };
    }

    /**
     * Override the action performed method to display a JPopupMenu.
     */
    public void actionPerformed(ActionEvent e)
    {
        boolean selected = (Boolean) getValue(SELECTED_KEY);
        
        if ( !selected )
        {
            //  Toggle selection off
            _selector.disable();
        }
        else
        {
            //  Toggle selection on
            _selector.disable();
            _selector.enable();
        }
    }
}
