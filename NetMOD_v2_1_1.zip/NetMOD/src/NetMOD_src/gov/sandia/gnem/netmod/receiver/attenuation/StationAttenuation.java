package gov.sandia.gnem.netmod.receiver.attenuation;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.io.NetModFile;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;

/**
* Interface for Station Specific Attenuation
* 
* @author bjmerch
*
*/
public interface StationAttenuation extends NetModFile
{
   
   /**
    * Get the frequencies over which the attenuation is defined
    * 
    * @return
    */
   public double[] getFrequencies();
   
   
   /**
    * Get the path to the amplitude file
    * 
    * @return
    */
   public String getFilename();
   
   /**
    * Set the path to the amplitude file
    * 
    */
   public void setFilename(String file);

   /**
    * Get the attenuation for the provided distance and frequency.
    * The attenuation values will be interpolated if there is not
    * a defined attenuation value for the provided parameters.
    * 
    * @param distance
    * @param frequency
    * @return
    */
   public Spectra getAttenuation(Point.Double start, Point.Double end, Distance distance, Frequency frequency);

   /**
    * Write the amplitude attenation
    */
   public boolean write();
   
   /**
    * Read the amplitude attenation
    */
   public boolean read();
}
