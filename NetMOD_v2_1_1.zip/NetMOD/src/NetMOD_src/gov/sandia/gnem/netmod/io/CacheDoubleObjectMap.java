/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import com.carrotsearch.hppc.DoubleObjectOpenHashMap;

/**
 * Map used for caching of computed objects.  Limits the map size
 * to the specified size so that the map doesn't get too large
 * 
 * @author bjmerch
 *
 * @param <V>
 */
public class CacheDoubleObjectMap<V>
{
    private DoubleObjectOpenHashMap<V> _cache;
    private int _size;
    
    //  Track the order of the keys
    private double[] _keys;
    private int _keyIndex;
    
    public CacheDoubleObjectMap(int size)
    {
        _size = size;
        _cache = new DoubleObjectOpenHashMap<V>(size);
        _keys = new double[size];
        _keyIndex = -1;
    }
    
    /**
     * Put the key/value pair into the map
     * 
     * @param key
     * @param value
     * @return
     */
    public V put(double key, V value)
    {
        synchronized (_cache)
        {
            //  Remove the oldest known key
            _keyIndex = (_keyIndex+1) % _size;
            if ( _cache.size() >= _size )
                _cache.remove(_keys[_keyIndex]);
            
            //  Track the new key
            _keys[_keyIndex] = key;
            
            //  Insert the value
            return _cache.put(key, value);
        }
    }
    
    /**
     * Get the value for the provided key
     * 
     * @param key
     * @return
     */
    public V get(double key)
    {
        synchronized(_cache)
        {
            return _cache.get(key);
        }
    }

    /**
     * Clear the contents of the map
     */
    public void clear()
    {
        synchronized(_cache)
        {
            _cache.clear();
        }
    }
}