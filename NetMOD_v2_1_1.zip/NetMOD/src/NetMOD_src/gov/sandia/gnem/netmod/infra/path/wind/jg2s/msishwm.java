package gov.sandia.gnem.netmod.infra.path.wind.jg2s;


public class msishwm {


  public static void getmsishwm(G2SDB g2sdb, EtmodDB etmodDB, double lati, double loni, double dzi,
      int nzi,
      double[] zi, double[] ti, double[] ui, double[] vi, double[] di, double[] pr) {
    //=========================================
    //Set internal
    //=========================================
    float boltz = 1.38066e-23f;
    double[] w = new double[2];

    //! =========================================
    //! Set internal
    //! =========================================

    int ccyyddd = g2sdb.info.year * 1000 + g2sdb.info.daynumber;
    float utsec = g2sdb.info.utc;

    double slt = utsec / 3600. + loni / 15.;
    double[] ap = new double[7];
    ap[0] = g2sdb.info.apd;
    ap[1] = g2sdb.info.apd;
    double f107a = g2sdb.info.f107a;
    double f107 = g2sdb.info.f107;

    //===========================================
    //Loop over altitude to build
    //===========================================
    for (int i = 0; i < nzi; i++) {
      float salt = (float) (i * dzi);
      nrlmsise
          .gtd7(etmodDB, ccyyddd, utsec, salt, lati, loni, slt, f107a, f107, ap, 48, etmodDB.d,
              etmodDB.t);
      try {
        g2sdb.hwm08.simulation(ccyyddd, utsec, salt, lati, loni, slt, f107a, f107, ap, w);
      } catch (Exception e) {
        System.out.println(e.getMessage());
      }

      zi[i] = salt;
      pr[i] = boltz * (etmodDB.d[0] + etmodDB.d[1] + etmodDB.d[2] + etmodDB.d[3] + etmodDB.d[4]
          + etmodDB.d[6] + etmodDB.d[7]) * etmodDB.t[1] * 10000;
      ti[i] = etmodDB.t[1];
      di[i] = etmodDB.d[5];
      ui[i] = w[1];
      vi[i] = w[0];

    }
  }

  static void getmsishwm2(G2SDB g2sdb, EtmodDB etmodDB, double lati, double loni, double dzi,
      int nzi,
      double[] zi, double[] ti, double[] ui, double[] vi, double[] di, double[] pr) {

    float boltz = 1.38066e-23f;

    //! =========================================
    //! Set internal
    //! =========================================

    int ccyyddd = g2sdb.info.year * 1000 + g2sdb.info.daynumber;
    float utsec = g2sdb.info.utc;

    double slt = utsec / 3600. + loni / 15.;
    double[] ap = new double[7];
    ap[0] = g2sdb.info.apd;
    ap[1] = g2sdb.info.apd;

    //! ==============================================================
    //! insure that the correct geomagnetic indicies are incorporated
    //! ==============================================================

    if (!g2sdb.override) {
      ap = geoindex.getGeoIndex(g2sdb, ccyyddd, utsec, false, ap);
//			System.out.println(Arrays.toString(ap));
    }

    //! ===========================================
    //! Loop over altitude to build
    //! ===========================================

    double f107a = g2sdb.info.f107a;
    double f107 = g2sdb.info.f107;

    double[] w = new double[2];

    for (int i = 0; i < nzi; i++) {
      float salt = (float) (i * dzi);
      nrlmsise
          .gtd7(etmodDB, ccyyddd, utsec, salt, lati, loni, slt, f107a, f107, ap, 48, etmodDB.d,
              etmodDB.t);
      try {
        g2sdb.hwm08.simulation(ccyyddd, utsec, salt, lati, loni, slt, f107a, f107, ap, w);
      } catch (Exception e) {
        System.out.println(e.getMessage());
      }
      zi[i] = salt;
      pr[i] = boltz * (etmodDB.d[0] + etmodDB.d[1] + etmodDB.d[2] + etmodDB.d[3]
          + etmodDB.d[4] + etmodDB.d[6] + etmodDB.d[7]) * etmodDB.t[1] * 1.0e4;
//			System.out.println(pr[i]);
//			System.out.println("d[0]: " + etmodDB.d[0]);
//      System.out.println("d[1]: " + etmodDB.d[1]);
//      System.out.println("d[2]: " + etmodDB.d[2]);
//      System.out.println("d[3]: " + etmodDB.d[3]);
//      System.out.println("d[4]: " + etmodDB.d[4]);
//      System.out.println("d[6]: " + etmodDB.d[6]);
//      System.out.println("d[7]: " + etmodDB.d[7]);
//      System.out.println("t[1]: " + etmodDB.t[1]);
      ti[i] = etmodDB.t[1];
      di[i] = etmodDB.d[5];
      ui[i] = w[1];
      vi[i] = w[0];
    }
//    System.out.println(Arrays.toString(zi));
//    System.out.println(Arrays.toString(pr));
//    System.out.println(Arrays.toString(ti));
//    System.out.println(Arrays.toString(di));
//    System.out.println(Arrays.toString(ui));
//    System.out.println(Arrays.toString(vi));
  }
}
