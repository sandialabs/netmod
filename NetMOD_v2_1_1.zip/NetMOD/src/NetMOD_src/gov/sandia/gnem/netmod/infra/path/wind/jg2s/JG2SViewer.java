package gov.sandia.gnem.netmod.infra.path.wind.jg2s;


import gov.sandia.gnem.netmod.gui.FileField;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;

import javax.swing.*;
import java.awt.*;

public class JG2SViewer extends NetModComponentViewer<JG2S> {

    private FileField _windModelFile = new FileField("Wind Model File");

    JG2SViewer(JG2S nmc){
        super(nmc, true, false);
        setExpanded(true);
        registerControls(_windModelFile);
    }

    @Override
    public void apply(JG2S nmc){
        super.apply(nmc);
        nmc.setWindModelFile(_windModelFile.getText());
    }

    @Override
    public JPanel getExpandedPanel(){
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());


            GUIUtility.addRow(panel, new JLabel("Wind Model File "), _windModelFile);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(JG2S nmc){
        _windModelFile.setText(nmc.getWindModelFile());
    }
}
