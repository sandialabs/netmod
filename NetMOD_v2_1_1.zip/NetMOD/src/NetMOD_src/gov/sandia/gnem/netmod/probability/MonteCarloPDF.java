package gov.sandia.gnem.netmod.probability;

import gov.sandia.gnem.netmod.numeric.NumericUtility;

import java.util.Arrays;

/**
 * Probability Density Function represented by Monte Carlo iterations
 * 
 * @author bjmerch
 *
 */
public class MonteCarloPDF extends AbstractPDF
{
	private PRNG _prng;
	private double[] _values;
	
	public MonteCarloPDF(PRNG prng, int N)
	{
		_prng = prng;
		_values = new double[N];
	}

	@Override
    public double computeCumulativeDistribution(double x)
    {
		int count = 0;
		
		//  Simply count the number of iterations that were less than or equal to the provided value
		for (int i=0; i<_values.length; i++)
			if ( _values[i] <= x )
				count++;
		
		return ((double) count) / _values.length;
    }

	@Override
    public double computeProbabilityDensity(double x)
    {
	    // TODO Auto-generated method stub
	    return 0;
    }

	@Override
    public String getDescription()
    {
		return "Monte Carlo";
    }

	@Override
    public double getMax()
    {
		return NumericUtility.max(getValues());
    }

	public int getValuesCount()
	{
		return _values.length;
	}
	
	protected double[] getValues()
    {
		return _values;
    }
	
	public double getValue(int index)
	{
		return getValues()[index];
	}
	
	public void setValue(int index, double value)
	{
		getValues()[index] = value;
	}

	@Override
    public double getMean()
    {
		return NumericUtility.mean(getValues());
    }

	@Override
    public double getMin()
    {
		return NumericUtility.min(getValues());
    }

	@Override
    public double getStandardDeviation()
    {
		return NumericUtility.std(getValues());
    }
	
	@Override
	public String toString()
	{
		return "Monte Carlo: " + Arrays.toString(getValues());
	}

	@Override
    public PDF add(double x, PDF... pdfs)
    {
        if ( pdfs.length == 0 )
            return add(x);

		int N = getValuesCount();
		
        //  Check if any aren't a MonteCarlo PDF
        for (int i=0; i<pdfs.length; i++)
            if ( !(pdfs[i] instanceof MonteCarloPDF) )
            	pdfs[i] = pdfs[i].toMonteCarlo(_prng, N);

        MonteCarloPDF pdf = new MonteCarloPDF(_prng, N);
		
		for (int i=0; i<N; i++)
		{
			double sum = x;
			for (int j=0; j<pdfs.length; j++)
				sum += ((MonteCarloPDF) pdfs[j]).getValue(i);
			
			pdf.setValue(i, sum);
		}

		return pdf;
    }

	@Override
    public double getVariance()
    {
		double std = NumericUtility.std(getValues());
		
		return std * std;
    }

	@Override
    public PDF log10()
    {
		int N = getValuesCount();
		MonteCarloPDF pdf = new MonteCarloPDF(_prng, N);
		
		for (int i=0; i<N; i++)
			pdf.setValue(i, Math.log10(getValue(i)));
		
		return pdf;
    }

	@Override
    public PDF minus(PDF pdf)
    {
		int N = getValuesCount();
		MonteCarloPDF new_pdf = new MonteCarloPDF(_prng, N);
		
		for (int i=0; i<N; i++)
			new_pdf.setValue(i, Math.pow(10.0, getValue(i)));
		
		return pdf;
    }

	@Override
    public PDF pow10()
    {
		int N = getValuesCount();
		MonteCarloPDF pdf = new MonteCarloPDF(_prng, N);
		
		for (int i=0; i<N; i++)
			pdf.setValue(i, Math.pow(10.0, getValue(i)));
		
		return pdf;
    }

	@Override
    public PDF scale(double a, double b)
    {
		int N = getValuesCount();
		MonteCarloPDF pdf = new MonteCarloPDF(_prng, N);
		
		for (int i=0; i<N; i++)
			pdf.setValue(i, a * getValue(i) + b );
		
		return pdf;
    }

	@Override
    public MonteCarloPDF toMonteCarlo(PRNG prng, int n)
    {
		return this;
    }

	@Override
    public PDF toSimplePDF()
    {
		//  Estimate empirical mean and standard deviation from the realizations
		
		double mean = getMean();
		double std = getStandardDeviation();
		
		return new NormalPDF(mean, std);
    }
}
