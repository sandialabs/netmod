/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.NumericUtility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Non-parametric representation of a probability distribution
 * defined with a cumulative distribute function
 * 
 * @author bjmerch
 *
 */
public class NonParametricCDF extends AbstractPDF
{
	private PDF _pdf;
    protected double[] _cdf;
    protected double[] _x;

    private String _str = null;
    
    protected NonParametricCDF()
    {
    	_pdf = new NormalPDF(0,0);
        _cdf = new double[0];
        _x = new double[0];
    }

    /**
     * Construct a non-parametric probability density function
     * from the provided density values.
     * 
     * @param x X values
     * @param cdf  Cumulative distribution values
     */
    public NonParametricCDF(double[] x, double[] cdf)
    {
        this(x, cdf, Double.NaN, Double.NaN);
    }

    
    /**
     * Construct a non-parametric probability density function
     * from the provided density values.
     * 
     * @param x X values
     * @param cdf  Cumulative distribution values
     * @param mean
     * @param std
     */
    public NonParametricCDF(double[] x, double[] cdf, double mean, double std)
    {
    	this(x, cdf, new NormalPDF(mean, std));
    }
    
    
    /**
     * Construct a non-parametric probability density function
     * from the provided density values.
     * 
     * @param x X values
     * @param cdf  Cumulative distribution values
     * @param pdf nominal PDF (mean and standard deviation)
     */
    public NonParametricCDF(double[] x, double[] cdf, PDF pdf)
    {
        int N = x.length;

        if (N == 0 || cdf == null)
        {
        	_pdf = new NormalPDF(0, 0);
            _x = new double[] { 0 };
            _cdf = new double[] { 1 };

            return;
        }
        
        _x = x;
        _cdf = cdf;
        _pdf = pdf;

        //  Compute the mean and standard deviation numerically, if needed
        if (pdf == null || Double.isNaN(pdf.getMean()) || Double.isNaN(pdf.getStandardDeviation()))
        {
            //  Check for and remove duplicate values within x or cdf,
        	//  limit cdf to 0.1 - 0.9, and values that are not monotonic
            {
            	int Nunique = 0;
            	for (int i=0; i<N; i++)
            		if ( cdf[i] >= 0.1 && cdf[i] <= 0.9 )
            		{
            			if ( i == 0 )
            				Nunique++;
            			else
            			{
                    		if ( x[i-1] != x[i] && cdf[i-1] != cdf[i] )
                    			Nunique++;
            			}
            		}
            	
            	if ( N != Nunique )
            	{
            		double[] x_unique = new double[Nunique];
            		double[] cdf_unique = new double[Nunique];
            		
            		int i_unique = 0;
                	for (int i=0; i<N; i++)
                		if ( cdf[i] >= 0.1 && cdf[i] <= 0.9 )
                		{
                			if ( i == 0 )
                			{
                    			x_unique[i_unique] = x[i];
                    			cdf_unique[i_unique] = cdf[i];
                				i_unique++;
                			}
                			else
                			{
                        		if ( x[i-1] != x[i] && cdf[i-1] != cdf[i] )
                        		{
                        			x_unique[i_unique] = x[i];
                        			cdf_unique[i_unique] = cdf[i];
                        			i_unique++;
                        		}
                			}
                		}
            		
            		x = x_unique;
            		cdf = cdf_unique;
            	}
            }
        	
            //  Range of x values
            double min = NumericUtility.min(x);
            double max = NumericUtility.max(x);
            double x_range = (max - min);
            double dx = x_range / 100;
            double cdf_range = NumericUtility.max(cdf) - NumericUtility.min(cdf);

//        	System.out.println("Computing sample mean and standard deviation from a CDF.");
//        	System.out.println("dx: " + dx + ", x_range: " + x_range + ", cdf_range: " + cdf_range);
//        	System.out.println("X, CDF, PDF, Mean Contribution");
            //  Mean
            double mean = 0;
            for (double value = min; value <= max; value += dx)
            {
            	double c = Interpolation.interpolateQuadratic(x, cdf, value);
                double p = Interpolation.interpolateQuadraticDerivative(x, cdf, value);
                double tmp = value * (p / cdf_range) * dx;
                //System.out.println(value + ", " + c + ", " + p + ", " + tmp);
                mean += tmp;
            }

            //  Standard Deviation
            double std = 0;
            for (double value = min; value <= max; value += dx)
            {
                double p = Interpolation.interpolateQuadraticDerivative(x, cdf, value);
                std += (value - mean) * (value - mean) * (p / cdf_range) * dx;
            }
            std = Math.sqrt(std);
            
            _pdf = new NormalPDF(mean, std);
        }
    }

    /**
     * Compute a non-parametric PDF from the
     * provided PDF
     * 
     * @param pdf
     */
    public NonParametricCDF(PDF pdf)
    {
        this(pdf, (pdf.getMax() - pdf.getMin()) / 999);
    }

    /**
     * Construct a non-parametric pdf from the provided PDF,
     * using the delta value as the spacing between sampled points
     * 
     * @param pdf
     * @param delta
     */
    public NonParametricCDF(PDF pdf, double delta)
    {
        //  Sample the PDF
        double min = pdf.getMin();
        double max = pdf.getMax();
        int N = (int) ((max - min) / delta + 1);

        _pdf = pdf;
        _x = new double[N];
        _cdf = new double[N];

        for (int i = 0; i < N; i++)
        {
            double value = min + delta * i;

            _x[i] = value;
            _cdf[i] = pdf.computeCumulativeDistribution(value);
        }
    }

    @Override
    public PDF add(double value)
    {
        return scale(1, value);
    }

    @Override
    public PDF add(double value, PDF... pdfs)
    {
        if (pdfs.length == 0)
            return add(value);

        //  Compute the resulting CDF of the sum of the random values 
        //  by convolving this CDF with each of the probability density functions.
        
        //  Initialize the CDF values for this distribution
        int N = 20;
        double min1 = getMin();
        double delta1 = (getMax() - min1) / (N - 1);
        System.out.println("Initial CDF size:  " + min1 + ", " + getMax() + ", " + delta1 + ", " + N);


        double[] x1 = new double[N];
        double[] c1 = new double[N];

        for (int i = 0; i < N; i++)
        {
            x1[i] = min1 + i * delta1;
            c1[i] = computeCumulativeDistribution(x1[i]);
        }
        
        //  Accumulate simple PDF values
        List<PDF> simplePDFs = new ArrayList<PDF>();

        //  Sum the provided PDF's
        for (PDF pdf : pdfs)
        {
        	if ( pdf == this )
        		continue;
        	
        	//  Update the simple pdf
        	simplePDFs.add(pdf.toSimplePDF());
        	
            //  Initialize the PDF values for the provided distribution
            double min2 = pdf.getMin();
            int M = (int) ((pdf.getMax() - min2) / delta1 + 1);
            
			if (M > 1)
			{
				double[] x2 = new double[M];
				double[] p2 = new double[M];

				for (int i = 0; i < M; i++)
				{
					x2[i] = min2 + i * delta1;
					p2[i] = pdf.computeProbabilityDensity(x2[i]);
				}

				// Convolve the CDF with the PDF to get the summed CDF
				double[] c3 = convolveCDF(c1, p2, delta1);

				// Limit the vectors to cdfs in the range of [0.0:1.0]
				int start = NumericUtility.findIndexAscending(c3, 0.0);
				int end = NumericUtility.findIndexAscending(c3, 1.0)+1;

				// Trim the CDF
				c1 = Arrays.copyOfRange(c3, start, end);

				// Compute the x values for the summed CDF
				if (x1.length != (end - start))
					x1 = new double[end - start];

				min2 += start * delta1;
			}
            
            for (int i = 0; i < x1.length; i++)
            	x1[i] = min1 + min2 + i * delta1;
            
            min1 = x1[0];
        }
        
        //  Add in the provided offset value
        NumericUtility.add(x1, value);
        
        //  Resample the values to the same CDF bins as before
        int Ncdf = _cdf.length;
        
        double[] x = new double[Ncdf];
        double[] cdf = new double[Ncdf];
        
        for (int i=0; i<Ncdf; i++)
        {
        	cdf[i] = _cdf[i];
        	x[i] = Interpolation.interpolateQuadratic(c1, x1, cdf[i]);
        }

        return new NonParametricCDF(x, cdf, _pdf.add(value, simplePDFs.toArray(new PDF[simplePDFs.size()])));
    }

    @Override
    public PDF add(PDF... pdfs)
    {
        return add(0, pdfs);
    }

    @Override
    public double computeCumulativeDistribution(double x)
    {
        //  Perform interpolation to find the cumulative probability
        double c = Interpolation.interpolateQuadratic(_x, _cdf, x);
        
        //  Check for an undefined CDF
        if ( Double.isNaN(c) )
        	c = _pdf.computeCumulativeDistribution(x);

        //  Limit the range of c to [0,1]
        if (c < 0)
            return 0;
        else if (c > 1)
            return 1;

        return c;
    }

    @Override
    public double computeProbabilityDensity(double x)
    {
        //  Perform interpolation to find the probability
        return Interpolation.interpolateQuadraticDerivative(_x, _cdf, x);
    }

    /**
     * Convolve the provided CDF and PDF, assume the CDF is zero before it starts and is one after it ends
     * 
     * @param cdf
     * @param pdf
     * @return
     */
    private double[] convolveCDF(double[] cdf, double[] pdf, double delta)
    {
        int Ncdf = cdf.length;
        int Npdf = pdf.length;
        int Nmin = Math.min(Ncdf,  Npdf);

        int N = Ncdf + Npdf - 1;
        double[] x = new double[N];
        int startCDF, endCDF, startPDF;
        
        for (int i = 0; i<N; i++)
        {
            double value = 0;

            //  start, accounting for either cdf or pdf being shorter
            if ( i < Nmin )
            {
            	startCDF = 0;
            	endCDF = i+1;
            	startPDF = Npdf - 1 - i;
            }
            //  end, accounting for either cdf or pdf being shorter
            else if ( i > Ncdf-1 )
            {
            	startCDF = Math.max(0, i - ( Npdf - 1 ));
            	endCDF = Ncdf;
            	
            	startPDF = Math.max(0, Npdf - 1 - i);
            }
            //  Middle, only reached when pdf shorter than cdf
            else
            {
            	startCDF = i - ( Npdf - 1 );
            	endCDF = i+1;
            	
            	startPDF = 0;
            }
            
            //  Convolve the portions of CDF and PDF that overlap
            for (int j = startCDF; j < endCDF; j++)
            {
            	double t1 = cdf[j];
            	double t2 = pdf[Npdf-1-(startPDF+j-startCDF)];
                value += t1 * t2;
            }
            
            //  Add in 1's past Ncdf
            for (int j = startPDF+endCDF-startCDF; j<Npdf; j++)
            {
            	value += pdf[Npdf-1-j];
            }

            x[i] = value * delta;
        }

        return x;
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof NonParametricCDF) )
            return false;
        
        NonParametricCDF pdf = (NonParametricCDF) o;
        
        return _pdf.equals(pdf._pdf) &&
                NumericUtility.equals(_x, pdf._x, 1e-4) && NumericUtility.equals(_cdf, pdf._cdf, 1e-4);
    }

    /**
     * Get the CDF value for the provided index
     * 
     * @param index
     * @return CDF
     */
    public double getCDF(int index)
    {
        return _cdf[index];
    }

    public double[] getCDFValues()
    {
		return _cdf;
    }

    /**
     * Get the number of non-parametric CDF values there are
     * 
     * @return CDF count
     */
    public int getCount()
    {
        return _x.length;
    }

    @Override
    public String getDescription()
    {
        return "Non-Parametric";
    }

    @Override
    public double getMax()
    {
        if (_x == null || _x.length == 0)
            return 0;

        return _x[_x.length - 1];
    }

    @Override
    public double getMean()
    {
        return _pdf.getMean();
    }

    @Override
    public double getMin()
    {
        if (_x == null || _x.length == 0)
            return 0;

        return _x[0];
    }

    @Override
    public double getStandardDeviation()
    {
        return _pdf.getStandardDeviation();
    }

    @Override
    public double getVariance()
    {
        double std = getStandardDeviation();

        return std * std;
    }

    /**
     * Get the X value for the provided index
     * 
     * @param index
     * @return value
     */
    public double getX(int index)
    {
        return _x[index];
    }

    public double[] getXValues()
    {
		return _x;
    }

    @Override
    public int hashCode()
    {
		return Arrays.hashCode(_x);
    }

    @Override
    public PDF log10()
    {
    	PDF pdf = _pdf.log10();

        int N = _x.length;

        double[] x = new double[N];
        double[] cdf = new double[N];

        for (int i = 0; i < N; i++)
        {
            x[i] = Math.log10(_x[i]);
            cdf[i] = _cdf[i];
        }

        return new NonParametricCDF(x, cdf, pdf);
    }

    @Override
    public PDF minus(PDF pdf)
    {
        return minus(this, pdf);
    }

    @Override
    public PDF pow10()
    {
    	PDF pdf = _pdf.pow10();

        int N = _x.length;

        double[] x = new double[N];
        double[] cdf = new double[N];

        for (int i = 0; i < N; i++)
        {
            x[i] = Math.pow(10, _x[i]);
            cdf[i] = _cdf[i];
        }

        return new NonParametricCDF(x, cdf, pdf);
    }

	@Override
    public PDF scale(double a)
    {
        return scale(a, 0);
    }

	@Override
    public PDF scale(double a, double b)
    {
        if (a == 1 && b == 0)
            return this;

        PDF pdf = _pdf.scale(a, b);
        
        int N = _x.length;

        double[] x = new double[N];
        double[] cdf = new double[N];

        if ( a < 0 )
        {
			for (int i = 0; i < N; i++)
			{
				x[i] = a * _x[i] + b;
				cdf[i] = 1.0 - _cdf[i];
			}

			NumericUtility.reverse(x);
			NumericUtility.reverse(cdf);
        }
		else
		{
			for (int i = 0; i < N; i++)
			{
				x[i] = a * _x[i] + b;
				cdf[i] = _cdf[i];
			}
		}

        return new NonParametricCDF(x, cdf, pdf);
    }

	@Override
    public String toString()
    {
        if (_str == null)
        {
            StringBuilder sb = new StringBuilder();

            sb.append("\tPDF: ").append(_pdf.toString());
            sb.append("\n\tCDF:\t[ ");
            sb.append(GUIUtility.formatDoubles(_cdf, ", ", "%8.3f"));

            sb.append(" ]\n\tVAL:\t[ ");
            sb.append(GUIUtility.formatDoubles(_x, ", ", "%8.3f"));
            sb.append(" ]\n");

            _str = sb.toString();
        }

        return _str;
    }

	@Override
    public MonteCarloPDF toMonteCarlo(PRNG prng, int n)
    {
        //  Declare early for optimization
        int i;
        
		MonteCarloPDF pdf = new MonteCarloPDF(prng, n);
        double[] values = pdf.getValues();
        
        //  Generate a uniform random values [0..1]
        prng.nextUniforms(values);

        //  Transform the random variable using the inverse CDF
        int N = values.length;
        for (i = 0; i < N; i++)
            values[i] = Interpolation.interpolateQuadratic(_cdf, _x, values[i]);
        
        return pdf;
    }

	@Override
    public PDF toSimplePDF()
    {
		return _pdf;
    }
}