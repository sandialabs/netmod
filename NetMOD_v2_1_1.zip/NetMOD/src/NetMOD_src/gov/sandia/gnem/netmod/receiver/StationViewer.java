/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.*;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectra;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectraPlugin;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectraViewerInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 *
 */
public class StationViewer extends NetModComponentViewer<Station>
{
    private JTextField _name;
    private JTextField _group;
    private JFormattedTextField _latitude;
    private JFormattedTextField _longitude;
    private JFormattedTextField _elevation;
    private JFormattedTextField _reliability;
    private JFormattedTextField _mediaDensity;
    private JTextField _stationType;
    private JTextField _technology;
    private JFormattedTextField _siteNoiseSD;
    private FileField _siteNoiseFile;
    private JFormattedTextField _numberChannels;

    public StationViewer(Station nmc)
    {
        super(nmc, false, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);
    }

    private JButton createSiteNoiseButton()
    {
        JButton button = GUIUtility.createButton(Icons.VIEW.getIcon());
        button.setToolTipText("Display Site Noise");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                //  Get the noise spectra object
                NoiseSpectra noiseSpectra = _nmc.getNoiseSpectra();
                if (noiseSpectra == null || !noiseSpectra.isAvailable())
                    return;

                //  Get the viewer
                NetModComponentViewer<? extends AbstractNetModFile> viewer = (NetModComponentViewer<? extends AbstractNetModFile>) noiseSpectra.getViewer();
                if (viewer == null)
                    return;
                
                if ( viewer instanceof NoiseSpectraViewerInterface )
                {
                    ((NoiseSpectraViewerInterface) viewer).addNoiseModels(NoiseSpectraPlugin.getNoiseModels(_nmc.getTechnology()));
                }

                //  Display the viewer within a dialog
                GUIUtility.showViewerDialog(null, viewer, "Noise Spectra - " + noiseSpectra.getName());
            }
        });

        return button;
    }

    @Override
    public void apply(Station nmc)
    {
        if (isExpanded())
        {
            nmc.setName(_name.getText());
            nmc.setGroup(_group.getText());
            nmc.setLatitude(((Number) _latitude.getValue()).doubleValue());
            nmc.setLongitude(((Number) _longitude.getValue()).doubleValue());
            nmc.setElevation(((Number) _elevation.getValue()).doubleValue());
            nmc.setReliability(((Number) _reliability.getValue()).doubleValue());
            nmc.setMediaDensity(((Number) _mediaDensity.getValue()).doubleValue());
            nmc.setStationType(_stationType.getText());
            nmc.setTechnology(_technology.getText());
            nmc.setNumberChannels(((Number) _numberChannels.getValue()).intValue());
            nmc.setNoiseSpectraSD(((Number) _siteNoiseSD.getValue()).doubleValue());
            nmc.setNoiseSpectraFile(_siteNoiseFile.getText());
        }
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            _name = new JTextField();
            _group = new JTextField();
            _latitude = new JFormattedTextField(new DoubleRangeFormatter(-90, 90));
            _longitude = new JFormattedTextField(new DoubleRangeFormatter(-180, 180));
            _elevation = new JFormattedTextField(new DoubleRangeFormatter());
            _reliability = new JFormattedTextField(new DoubleRangeFormatter(0, 1));
            _mediaDensity = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
            _stationType = new JTextField();
            _technology = new JTextField();
            _siteNoiseSD = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
            _siteNoiseFile = new FileField("Site Noise Spectra File", createSiteNoiseButton());
            _numberChannels = new JFormattedTextField(new IntegerRangeFormatter(1, Integer.MAX_VALUE));

            _group.setToolTipText("Stations within the same group are not independent");
            _elevation.setToolTipText("Station Elevation (meters)");
            _reliability.setToolTipText("Station Reliability [0..1]");
            _mediaDensity.setToolTipText("Station Media Density (kg/m^3)");
            _siteNoiseSD.setToolTipText("Site Noise Standard Deviation in log10 Spectral Amplitude");

            //  Setup the panel

            JPanel panel1 = new JPanel(new GridBagLayout());
            panel1.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));
            JPanel panel2 = new JPanel(new GridBagLayout());
            panel2.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
            JPanel panel3 = new JPanel(new GridLayout(1, 2));

            GUIUtility.addRow(panel1, new JLabel("Name: "), _name);
            GUIUtility.addRow(panel1, new JLabel("Group: "), _group);
            GUIUtility.addRow(panel1, new JLabel("Latitude: "), _latitude);
            GUIUtility.addRow(panel1, new JLabel("Longitude: "), _longitude);
            GUIUtility.addRow(panel1, new JLabel("Elevation: "), _elevation);
            GUIUtility.addRow(panel1, new JLabel("Site Noise SD: "), _siteNoiseSD);
            GUIUtility.addRow(panel1, GridBagConstraints.REMAINDER, new JLabel(""));

            GUIUtility.addRow(panel2, new JLabel("Station Type: "), _stationType);
            GUIUtility.addRow(panel2, new JLabel("Technology: "), _technology);
            GUIUtility.addRow(panel2, new JLabel("Channels: "), _numberChannels);
            GUIUtility.addRow(panel2, new JLabel("Media Density: "), _mediaDensity);
            GUIUtility.addRow(panel2, new JLabel("Reliability: "), _reliability);
            GUIUtility.addRow(panel2, GridBagConstraints.REMAINDER, new JLabel(""));

            panel3.add(panel1);
            panel3.add(panel2);

            GUIUtility.addRow(panel, panel3);
            GUIUtility.addRow(panel, new JLabel(" "));
            GUIUtility.addRow(panel, new JLabel("Site Noise: "), _siteNoiseFile);
            GUIUtility.addRow(panel, _nmc.getPhaseParameters().getViewer());

            //  Register the controls
            registerControls(_name, _latitude, _longitude, _elevation, _siteNoiseSD, _stationType, _technology, _numberChannels, _mediaDensity, _reliability,
                    _siteNoiseFile);

            _expandedPanel = panel;
        }

        return _expandedPanel;
    }

    @Override
    public void reset(Station nmc)
    {
        if (isExpanded())
        {
            _name.setText(nmc.getName());
            _group.setText(nmc.getGroup());
            _latitude.setValue(nmc.getLatitude());
            _longitude.setValue(nmc.getLongitude());
            _elevation.setValue(nmc.getElevation());
            _reliability.setValue(nmc.getReliability());
            _mediaDensity.setValue(nmc.getMediaDensity());
            _stationType.setText(nmc.getStationType());
            _technology.setText(nmc.getTechnology());
            _numberChannels.setValue(nmc.getNumberChannels());
            _siteNoiseSD.setValue(nmc.getNoiseSpectraSD());
            _siteNoiseFile.setText(nmc.getNoiseSpectraFile());
        }
    }
}
