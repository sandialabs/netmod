/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Dialog for displaying progress to the user.
 * Also allow the user to cancel an operation in progress.
 * 
 * @author bjmerch
 */
public class ProgressDialog extends JDialog
{
    private static ProgressDialog _progressDialog = new ProgressDialog(null, false);

    /**
     * Get the progress dialog.
     * 
     * Note, this method is intended to be called by a low-level computation object
     * to update the progress level and check if the cancel button has been selected.
     * 
     * @return
     */
    public static ProgressDialog getProgressDialog()
    {

        return _progressDialog;
    }

    public static ProgressDialog initProgressDialog(Component parent, String title)
    {
        return initProgressDialog(parent, title, false);
    }

    /**
     * Initialize the progress dialog with the provided title
     * and position it relative to the provided parent window.
     * Also, make it visible.
     * 
     * Note, this method is intended to be called by a high-level calling object
     * to setup and make visible the progress dialog.
     * 
     * @param parent
     * @param title
     */
    public static ProgressDialog initProgressDialog(final Component parent, String title, boolean sub)
    {
        final ProgressDialog pd = new ProgressDialog((NetMOD.isGUI() ? SwingUtilities.windowForComponent(parent) : null), sub);
        _progressDialog = pd;

        /*
         * Reset the cancel flag
         */
        pd.cancel = false;

        pd.setupProgressPanel();

        /*
         * Reset the appearance of the progress dialog
         */
        pd.setMainLabel(title);
        pd.setMainIndeterminate(true);
        pd.setSubLabel("");
        pd.setSubIndeterminate(true);

        //  Make the progress dialog visible in a separate thread so that it doesn't block  
        if (NetMOD.isGUI())
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    /*
                     * Reset the size and position of the progress dialog
                     */
                    pd.setModal(true);
                    pd.pack();
                    pd.setSize(300, _progressDialog.getSize().height);
                    pd.setLocationRelativeTo(pd.getParent());
                    pd.setVisible(true);
                }
            });

        return _progressDialog;
    }

    private JPanel prog_panel;
    private JProgressBar mainProgressBar;
    private JProgressBar subProgressBar;
    private JButton cancelBtn;
    private boolean cancel = false;

    private JLabel mainLabel = new JLabel("");
    private JLabel subLabel = new JLabel("");
    
    private int _mainValueAdd = 0;
    private int _subValueAdd = 0;

    private ProgressDialog(Window parent, boolean sub)
    {
        super(parent, "Progress");

        // Create the progress bar
        mainProgressBar = new JProgressBar();
        mainProgressBar.setStringPainted(false);

        if (sub)
        {
            subProgressBar = new JProgressBar();
            subProgressBar.setStringPainted(false);
        }

        // Create the cancel button
        cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                cancel();
            }
        });

        // add the close buttons
        JPanel buttonPanel = new JPanel();

        buttonPanel.add(cancelBtn);
        buttonPanel.setBorder(BorderFactory.createEtchedBorder());

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    public void cancel()
    {
        cancel = true;
        close();
    }

    public void close()
    {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                setVisible(false);
            }
        });
    }

    /**
     * Get the value of the main progress bar
     * 
     * @return
     */
    public int getMainValue()
    {
        return mainProgressBar.getValue() + _mainValueAdd;
    }

    /**
     * Get the value of the sub progress bar
     * 
     * @return
     */
    public int getSubValue()
    {
        return subProgressBar.getValue() + _subValueAdd;
    }

    /**
     * Increment the main progress bar by one.  
     * 
     * @return True if canceled, False otherwise
     */
    public boolean incrementMainProgressBar()
    {
        _mainValueAdd++;

        //  Determine whether it's enough to make it worth creating a thread
        if ( (100 * _mainValueAdd) / (mainProgressBar.getMaximum() - mainProgressBar.getMinimum()) >= 1)
        {
            EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    synchronized (mainProgressBar)
                    {
                        // Increment the main progress bar
                        mainProgressBar.setValue(mainProgressBar.getValue() + _mainValueAdd);
                        _mainValueAdd = 0;

                        // Reset the sub progress bar
                        if (subProgressBar != null)
                        {
                            subProgressBar.setIndeterminate(true);
                            subProgressBar.setValue(0);
                        }
                    }
                }
            });
        }

        return isCanceled();
    }

    /**
     * Increment the sub progress bar by one.  
     * 
     * @return True if canceled, False otherwise
     */
    public boolean incrementSubProgressBar()
    {
        return incrementSubProgressBar(1);
    }

    public boolean incrementSubProgressBar(int n)
    {
        if (subProgressBar == null)
            return isCanceled();
        
        _subValueAdd += n;
        
        //  Determine whether it's enough to make it worth creating a thread
        if ( (100 * _subValueAdd) / (subProgressBar.getMaximum() - subProgressBar.getMinimum()) >= 1)
        {
            EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    synchronized (subProgressBar)
                    {
                        subProgressBar.setValue(subProgressBar.getValue() + _subValueAdd);
                        _subValueAdd = 0;
                    }
                }
            });
        }

        return isCanceled();
    }

    public boolean isCanceled()
    {
        return cancel;
    }

    public void setMainIndeterminate(final boolean b)
    {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                mainProgressBar.setIndeterminate(b);
            }
        });
    }

    public void setMainLabel(final String str)
    {
        if (NetMOD.isGUI())
            EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    mainLabel.setText(str);
                }
            });
    }

    public void setMainValues(final int minValue, final int maxValue, final int value)
    {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                mainProgressBar.setIndeterminate(false);
                mainProgressBar.setMinimum(minValue);
                mainProgressBar.setMaximum(maxValue);
                mainProgressBar.setValue(value);
            }
        });
    }

    public void setSubIndeterminate(final boolean b)
    {
        if (subProgressBar == null)
            return;

        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                subProgressBar.setIndeterminate(b);
            }
        });
    }

    public void setSubLabel(final String str)
    {
        if (NetMOD.isGUI())
            EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    subLabel.setText(str);
                }
            });
    }

    public void setSubValues(final int minValue, final int maxValue, final int value)
    {
        if (subProgressBar == null)
            return;

        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                subProgressBar.setIndeterminate(false);
                subProgressBar.setMinimum(minValue);
                subProgressBar.setMaximum(maxValue);
                subProgressBar.setValue(value);
            }
        });
    }

    /**
     * Sleep for atleast the provided duration of time (seconds),
     * checking periodically for the user to click on the cancel button.
     * 
     * @param duration in seconds
     * @return true if the user clicked cancel, false otherwise
     */
    public boolean sleep(double duration)
    {
        long startTime = System.currentTimeMillis();
        long endTime = startTime + (long) (duration * 1000);
        long dt = endTime - startTime;

        while (System.currentTimeMillis() < endTime)
        {
            setSubValues(0, 100, (int) (100 * (System.currentTimeMillis() - startTime) / dt));

            try
            {
                Thread.sleep(10);
            }
            catch (Exception e)
            {
            }

            if (isCanceled())
                return true;
        }

        return false;
    }

    private void setupProgressPanel()
    {
        if (prog_panel != null)
            getContentPane().remove(prog_panel);

        // Create the panel
        prog_panel = new JPanel();
        prog_panel.setLayout(new GridLayout(0, 1, 5, 5));
        prog_panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        getContentPane().add(prog_panel, BorderLayout.CENTER);

        prog_panel.add(mainLabel);
        prog_panel.add(mainProgressBar);
        if (subProgressBar != null)
        {
            prog_panel.add(subLabel);
            prog_panel.add(subProgressBar);
        }
    }
}
