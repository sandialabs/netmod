/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io.libpar;

import java.awt.*;
import java.io.*;
import java.util.List;

import gov.sandia.gnem.netmod.io.IOUtility;

import java.util.*;

/**
 * Loads .par files and creates {@link LibParParameters} objects containing the
 * key-value pairs defined in the respective .par file.
 *
 */
public class ParLoader
{

	/**
	 * An Exception that can be thrown as a result of invalid syntax in a par file.
	 *
	 */
	public static class ParException extends Exception
	{
		private static final long serialVersionUID = -6563814587513084364L;

		/**
		 * Default constructor.
		 */
		public ParException()
		{
			super();
		}

		/**
		 * Constructor that takes another kind of exception and wraps a ParException
		 * around it.
		 * 
		 * @param baseException - The message that caused this exception to occur.
		 */
		public ParException(Exception baseException)
		{
			super(baseException);
		}

		/**
		 * Constructor that takes a message that is printed out in the stack trace.
		 * 
		 * @param message - The message about why this ParException is being thrown.
		 */
		public ParException(String message)
		{
			super(message);
		}
	}

	/**
	 * The maximum amount of levels that a recursive table can have.
	 */
	private static final int MAX_PAR_LEVEL = 8;

	/**
	 * Comment character for par files.
	 */
	protected static final String COMMENT = "#";

	/**
	 * Its an equals sign!
	 */
	protected static final String EQUALS = "=";

	/**
	 * The value for keys who don't have a defined value.
	 */
	protected static final String DEFAULT_VALUE = "TRUE";

	private static final String EMPTY = "";

	/**
	 * The identifier that means this line is the start of a table.
	 */
	public static final String TABLE_BEGIN = COMMENT + "!BeginTable";
	/**
	 * The identifier that means this lind is the end of a table.
	 */
	public static final String TABLE_END = COMMENT + "!EndTable";

	/**
	 * If this is the final token of a line, then it means that the next line should
	 * be appended to this one to make one complete line.
	 */
	protected static final String CONTINUATION_MARKER = "\\";

	/**
	 * The name id that means to recursively load the value in this key value pair.
	 */
	protected static final String PAR_NAME = "par";

	/**
	 * The identifier meaning the contents of the line this is found in is column
	 * names.
	 */
	protected static final String COLUMN_ID = "|";

	/**
	 * The identifier meaning the token is the name of a row.
	 */
	protected static final String ROW_NAME_ID = "@";

	/**
	 * The identifier meaning the token has a section that needs to be resolved to
	 * another value.
	 */
	public static final String EVAL_ID = "$(";

	/**
	 * Means the end of a statement such as $(SHELL).
	 */
	public static final char EVAL_END = ')';

	private static final char S_Q = '\'';
	private static final char D_Q = '"';

	private static final String MATH_PREFIX = "bc ";

	private static final int EVAL_ID_L = EVAL_ID.length();

	/**
	 * The identifier meaning the start of a for loop.
	 */
	public static final String FOR_BEGIN = "#!BeginFor";

	private static final String IN = "in";

	/**
	 * The identifier meaning the end of a for loop.
	 */
	public static final String FOR_END = "#!EndFor";

	/**
	 * Just a placeholder into the stack for nested loops.
	 */
	private static final Object DQ_MARK = new Object();

	/**
	 * Space between elements
	 */
	private static final String SPACE = " ";
	private static final String TAB = "\t";

	/**
	 * Loads the .par data from the given {@code File}. This data is should be the
	 * syntax described in {@link ParLoader}. A {@link LibParParameters} object is
	 * created with the read data, and returned.
	 * 
	 * @param f - the {@code File} to read from.
	 * @return the loaded {@code Parameters} object.
	 * @throws IOException  - If any IOException occurs while reading.
	 * @throws ParException - If any syntax error is found.
	 */
	public static LibParParameters load(File f) throws IOException, ParException
	{
		return load(f, new LibParParameters());
	}

	/**
	 * Loads the .par data from the given {@code File}. This data is should be the
	 * syntax described in {@link ParLoader}. A {@link LibParParameters} object is
	 * created with the read data, and returned.
	 * 
	 * @param f - the {@code File} to read from.
	 * @return the loaded {@code Parameters} object.
	 * @throws IOException  - If any IOException occurs while reading.
	 * @throws ParException - If any syntax error is found.
	 */
	public static LibParParameters load(File f, LibParParameters p) throws IOException, ParException
	{
		FileReader fr = null;
		BufferedReader br = null;

		try
		{
			fr = new FileReader(IOUtility.openFile(f.getPath()));
			br = new BufferedReader(fr);

			p = loadData(br, f, p);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( br != null )
				IOUtility.safeClose(br);
			if ( fr != null )
				IOUtility.safeClose(fr);
		}

		return p;
	}

	/**
	 * Loads the .par data from the given array of Strings. The elements can either
	 * represent one parameter each, or one line. This is done by making a
	 * {@link ListReader} using {@code Arrays.asList(args)}.
	 * 
	 * @param args           - The array of Strings to use as .par data.
	 * @param insertNewlines - Whether or not to insert a newline {@code '\n'}
	 *                       character in between each element in the array.
	 * @return the loaded {@code Parameters} object.
	 * @throws IOException  - If any IOException occurs while reading.
	 * @throws ParException - If any syntax error is found.
	 */
	public static LibParParameters load(String[] args, boolean insertNewlines) throws IOException, ParException
	{
		ListReader lr = null;
		BufferedReader br = null;
		LibParParameters p = new LibParParameters();

		try
		{
			lr = new ListReader(Arrays.asList(args), insertNewlines);
			br = new BufferedReader(lr);

			p = loadData(br, IOUtility.openFile("."), p);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( br != null )
				IOUtility.safeClose(br);
			if ( lr != null )
				IOUtility.safeClose(lr);
		}

		return p;
	}

	/**
	 * @param file
	 * @param parameters
	 */
	public static void save(File file, LibParParameters parameters)
	{
		FileWriter fw = null;
		BufferedWriter bw = null;

		try
		{
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);

			// Write all of the non-table parameters
			Set<String> names = parameters.getParameterNames();
			names.removeAll(parameters.getTableParameterNames());
			for (String key : names)
			{
				bw.write(key);
				bw.write(EQUALS);
				bw.write(parameters.get(key));
				bw.newLine();
			}

			bw.newLine();

			// Write all of the tables
			for (String tableName : parameters.getTableNames())
			{
				ParTable table = parameters.getTable(tableName);

				// Determine the appropriate width of each column
				List<String> columns = new ArrayList<String>(table.getColumnNames());
				Set<String> rows = table.getRowNames();

				int rowWidth = 1;
				int[] columnWidth = new int[columns.size()];
				for (int i = 0; i < columns.size(); i++)
					columnWidth[i] = columns.get(i).length();

				for (String row : rows)
				{
					rowWidth = Math.max(rowWidth, row.length());

					for (int i = 0; i < columns.size(); i++)
						columnWidth[i] = Math.max(columnWidth[i],
								table.getTableValue(row, columns.get(i)).trim().length());
				}

				// Write the begin table
				bw.write(TABLE_BEGIN);
				bw.write(SPACE);
				bw.write(tableName);
				bw.newLine();

				// Write the column headers
				for (int i = 0; i < columns.size(); i++)
				{
					if (i == 0)
					{
						write(bw, SPACE, rowWidth + 1);
						write(bw, SPACE, 3);
					}
					else
					{
						write(bw, SPACE, 1);
						write(bw, COLUMN_ID, 1);
						write(bw, SPACE, 1);
					}

					write(bw, columns.get(i), columnWidth[i]);
				}
				bw.newLine();

				// Write each of the rows
				for (String r : rows)
				{
					// Write the row identifier
					bw.write(ROW_NAME_ID);
					write(bw, r.replaceAll(" ", "_"), rowWidth);

					// Write each of the row/column pairs
					for (int i = 0; i < columns.size(); i++)
					{
						write(bw, SPACE, 3);

						String value = table.getTableValue(r, columns.get(i)).trim();

						// Check if it contains whitespace and enclose with quotes
						if (value.indexOf(" ") > 0)
							value = "\"" + value + "\"";

						write(bw, value, columnWidth[i]);
					}
					bw.newLine();
				}

				// Write the end table
				bw.write(TABLE_END);
				bw.newLine();
				bw.newLine();
			}

			// Write out the parameter file references
			for (String parfile : parameters.getParameterFiles())
			{
				bw.write(PAR_NAME);
				bw.write(EQUALS);
				bw.write(parfile);
				bw.newLine();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( bw != null )
				IOUtility.safeClose(bw);
			if ( fw != null )
				IOUtility.safeClose(fw);
		}
	}

	private static Object doMath(String m) throws ParException
	{
		try
		{
			// TODO Handle math string
			return 0;// return MATH.evaluate(MATH.parse(m));
		}
		catch (Exception e)
		{
			throw new ParException(e);
		}
	}

	private static ParTable getBuilder(String name, LibParParameters p)
	{
		ParTable tb = p.getTable(name);
		if (tb == null)
		{
			tb = new ParTable(name, p);
			p.addTable(tb);
		}
		return tb;
	}

	private static File getFileForPath(String path, File location)
	{
		File recur = IOUtility.openFile(path);
		if (!recur.isAbsolute())
		{
			File parent = location.getParentFile();
			if (parent == null)
				parent = location;
			recur = IOUtility.openFile(parent.getAbsolutePath() + File.separatorChar + recur.getPath());
		}
		return recur;
	}

	private static String getTableRecurFile(String line) throws ParException
	{
		List<String> toks = parseTokens(line);
		if (toks.size() != 2)
			throw new ParException("No name for #!File command: " + line);
		return toks.remove(1);
	}

	private static List<String> handleColumns(String line, ParTable tb, LibParParameters p) throws ParException
	{
		List<String> names = parseTokens(line);
		removeBars(names);
		tb.addColumns(names);
		return names;
	}

	private static void handleComment(LibParParameters p, BufferedReader br, String line, File location)
			throws IOException, ParException
	{
		if (line.startsWith(TABLE_BEGIN))
			handleTable(br, line, p, location);
		if (line.startsWith(FOR_BEGIN))
			handleFor(br, line, p, location);
	}

	private static void handleKeyValuePair(String left, String right, LibParParameters p, File location)
			throws ParException, IOException
	{
		left = resolve(left, p);
		right = removeQuotes(right);
		right = resolve(right, p);
		if (right != null && right.startsWith(MATH_PREFIX))
			right = "" + doMath(right.substring(MATH_PREFIX.length()));
		// If the name is "par" then recursively load the value, which should be the
		// path to a file.
		if (left.equals(PAR_NAME))
		{
			File f = getFileForPath(right, location);

			p = load(f, p);
			return;
		}
		// Otherwise it is just an ordinary key-value pair.
		// If the right side contains quotes at the start and end, then remove them.
		p.set(left, right);
	}

	/**
	 * Handles one line as per the .par syntax specifications. The usual case is one
	 * or more {@code <key>=<value>} pair.
	 * 
	 * @param p        - The parameters object to use.
	 * @param token    - The token to handle.
	 * @param location - The file location as to where the par file this token came
	 *                 from is.
	 * @throws ParException - If there was a syntax error with the token.
	 */
	private static void handleLine(String line, BufferedReader br, LibParParameters p, File location)
			throws ParException, IOException
	{
		line = line.trim();
		// If it is empty, then just skip
		if (line.length() == 0)
			return;
		// First check if it is a comment
		if (line.startsWith(COMMENT))
		{
			handleComment(p, br, line, location);
		}
		else
		{
			// Then it must be a key-value pair.
			handleKeyValue(p, removeComment(line, null), location);
		}
	}

	private static void handleRow(String line, ParTable tb, List<String> columns, LibParParameters p)
			throws ParException
	{
		List<String> elements = resolve(parseTokens(line), p);
		removeBars(elements);
		if (elements.size() == 0)
			return;
		String rowName = null;
		if (elements.get(0).startsWith(ROW_NAME_ID))
			rowName = elements.remove(0).substring(1);
		tb.addRow(columns, elements, rowName);
	}

	private static void handleToken(LibParParameters p, String token, File location) throws ParException, IOException
	{
		if (!token.contains(EQUALS))
		{
			// If there is no equals sign, then it doesn't have a value.
			p.set(token, EMPTY);
		}
		else
		{
			if (token.startsWith(EQUALS))
				throw new ParException("No name for equals sign: " + token);
			// if (token.endsWith(EQUALS))
			// throw new ParException("No value for key: " + token);
			String[] splits = token.split(EQUALS);
			if (splits.length > 2)
				throw new ParException("Too many equals signs in a token: " + token);
			String left = splits.length >= 1 ? splits[0] : null;
			String right = splits.length >= 2 ? splits[1] : null;
			handleKeyValuePair(left, right, p, location);
		}
	}

	private static void removeBars(List<String> names)
	{
		Iterator<String> i = names.iterator();
		while (i.hasNext())
		{
			if (i.next().equals(COLUMN_ID))
				i.remove();
		}
	}

	private static String removeComment(String line, Set<Point> qregions)
	{
		int indexOfComment = line.indexOf(COMMENT);
		if (indexOfComment == -1)
			return line;
		// If we aren't supplied the set of quoted regions, then make it.
		if (qregions == null)
			qregions = getQuotedRegions(line);
		for (Point p : qregions)
		{
			if (indexOfComment < p.y && indexOfComment > p.x)
			{
				// Then we need to recurse on the part of the line after the quoted comment
				// But if the quoted region the comment was found in is the last part of the
				// line,
				// then there can't be anymore so just return that.
				if (line.length() - 1 == p.y)
					return line;
				String first = line.substring(0, p.y + 1);
				String last = line.substring(p.y + 1);
				return first + removeComment(last, qregions);
			}
		}
		return line.substring(0, indexOfComment);
	}

	private static String removeQuotes(String line)
	{
		// If the string starts and ends with the same quote character (single or
		// double)
		// then don't keep those.
		if (line == null || line.length() < 1)
			return line;
		int end = line.length() - 1;
		if (line.charAt(0) == S_Q && line.charAt(end) == S_Q)
		{
			return line.substring(1, end);
		}
		else if (line.charAt(0) == D_Q && line.charAt(end) == D_Q)
		{
			return line.substring(1, end);
		}
		// Return the original if we don't change anything.
		return line;
	}

	/**
	 * Resolve any parameter references within the list of tokens
	 * 
	 * @param tokens
	 * @param p
	 * @return
	 * @throws ParException
	 */
	private static List<String> resolve(List<String> tokens, LibParParameters p) throws ParException
	{
		int N = tokens.size();
		for (int i = 0; i < N; i++)
			tokens.set(i, resolve(tokens.get(i), p));

		return tokens;
	}

	/**
	 * Resolve any parameter references within the provided token
	 * 
	 * @param token
	 * @param p
	 * @return
	 * @throws ParException
	 */
	private static String resolve(String token, LibParParameters p) throws ParException
	{
		if (token == null)
			return token;

		int index = token.indexOf(EVAL_ID);
		if (index == -1)
			return token;
		boolean hasMore = token.indexOf(EVAL_ID, index + EVAL_ID_L) != -1;
		if (hasMore)
			token = token.substring(0, index + EVAL_ID_L) + resolve(token.substring(index + EVAL_ID_L), p);
		int end = token.indexOf(EVAL_END, index);
		if (end == -1)
			throw new ParException("No end to evaluation: " + token);
		String name = token.substring(index + EVAL_ID_L, end);
		String val = p.get(name);
		if (val == null)
			val = System.getenv(name);
		if (val == null)
			val = "";
		return resolve(token.replace(EVAL_ID + name + EVAL_END, val), p);
	}

	/**
	 * Write the provided string to the writer. Write spaces to the writer to ensure
	 * that N characters are written
	 * 
	 * @param out
	 * @param str
	 * @param N
	 * @throws IOException
	 */
	private static final void write(Writer out, String str, int N) throws IOException
	{
		out.write(str);
		for (int i = str.length(); i < N; i++)
			out.write(' ');
	}

	/**
	 * Returns the next line from the given BufferedReader. This method will take
	 * into consideration lines that end with a {@code "\"} character, meaning the
	 * next line should be appended to the current one. This will happen until the
	 * first line that doesn't have a {@code "\"} on the end, or a comment is found.
	 * 
	 * @param br - The BufferedReader to read from.
	 * @return A single string containing multiple lines appended to each other as
	 *         detailed above. Or {@code null} if there was no data in the reader.
	 * @throws IOException - If an IOException occurs while reading.
	 */
	protected static String getLine(BufferedReader br) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		String currLine = br.readLine();
		if (currLine == null)
			return null;
		currLine = currLine.trim();
		while (currLine != null && shouldContinue(currLine))
		{
			// When we append the line, chop off the \ at the end.
			sb.append(currLine.substring(0, currLine.length() - 1));
			currLine = br.readLine();
			currLine = (currLine == null ? null : currLine.trim());
		}
		// Append the last line
		if (currLine != null)
			sb.append(currLine.substring(0, currLine.length()));
		return sb.toString();
	}

	/**
	 * Looks through the given string and returns a {@code Set} of {@code Point}
	 * objects where the {@code x} value is the start of a quoted region, and the
	 * {@code y} value is the corresponding end. Only complete regions are added, so
	 * incomplete quotes aren't added.
	 * 
	 * @param line - The String to get the quoted regions of.
	 * @return A {@code Set} containing the quoted regions.
	 */
	protected static Set<Point> getQuotedRegions(String line)
	{
		int size = line.length();
		boolean inQuote = false;
		char quote = 0;
		int start = -1;
		int end = -1;
		char[] cs = line.toCharArray();
		Set<Point> regions = new HashSet<Point>();
		for (int i = 0; i < size; i++)
		{
			char c = cs[i];
			if (inQuote)
			{
				if (c == quote)
				{
					quote = 0;
					end = i;
					regions.add(new Point(start, end));
					start = -1;
					end = -1;
					inQuote = false;
				}
			}
			else
			{
				if (c == S_Q || c == D_Q)
				{
					inQuote = true;
					quote = c;
					start = i;
				}
			}
		}
		return regions;
	}

	/**
	 * Loads .par syntax from the given {@code BufferedReader}. The location of the
	 * source is also given to this function so that recursive calls can use a
	 * relative path to other sources. In the case of command line arguments, or in
	 * program calls to this library then the current directory shall be used.
	 * Otherwise it is the absolute path to the file being loaded.
	 * 
	 * @param br       - The {@code BufferedReader} loaded up with the .par data.
	 * @param location - The location of the source in the file system.
	 * @return A {@link LibParParameters} object containing the loaded data.
	 * @throws IOException  - If any problem occurs while reading from the reader.
	 * @throws ParException - If any syntax errors are found.
	 */
	protected static LibParParameters loadData(BufferedReader br, File location, LibParParameters p)
			throws IOException, ParException
	{
		if (p == null)
			p = new LibParParameters();
		String line = null;
		while ((line = getLine(br)) != null)
		{
			handleLine(line, br, p, location);
		}
		return p;
	}

	/**
	 * Parses the given string into a list of tokens. The String is split up by
	 * whitespace, meaning the tokens are whitespace delimited. Unless there are
	 * quotation marks. Then anything in a matching pair of quotes is a single
	 * token. Double and single quotes are supported. The returned list will not
	 * contain empty Strings.
	 * 
	 * @param line - The line to parse.
	 * @return A list where each element is a single token found in the parsed
	 *         String.
	 * @throws ParException
	 */
	protected static List<String> parseTokens(String line) throws ParException
	{
		line = line.trim();
		char[] cs = line.toCharArray();
		int size = cs.length;
		List<String> list = new LinkedList<String>();
		int start = 0;
		int end = -1;
		for (int i = 0; i < size; i++)
		{
			char c = cs[i];
			// If we found quotes, then just travel to the end of them.
			if (c == D_Q)
			{
				if (start == -1)
					start = i;
				i++;
				for (; i < size; i++)
				{
					end = i;
					if (cs[i] == D_Q)
						break;
				}
				continue;
			}
			// Same deal with single quotes
			if (c == S_Q)
			{
				if (start == -1)
					start = i;
				i++;
				for (; i < size; i++)
				{
					end = i;
					if (cs[i] == S_Q)
						break;
				}
				continue;
			}
			// Whitespace means the end of a token, so add the current token to the list,
			// and start a new token.
			if (Character.isWhitespace(c))
			{
				if (end == -1)
					throw new ParException("Did not start with a token.");
				// If we haven't found a real character, just ignore this whitespace.
				if (start == -1)
					continue;
				end++;
				list.add(line.substring(start, end));
				start = -1;
			}
			else
			{
				// We found the start of a token.
				if (start == -1)
					start = i;
				// Advance the end of this token further.
				end = i;
			}
		}
		// Then take the last token, since there should be no whitespace after it.
		if (end != -1)
			list.add(line.substring(start, end + 1));

		// Remove un-needed quotes now.
		List<String> tmp = new LinkedList<String>();
		for (String s : list)
			tmp.add(removeQuotes(s));
		list = tmp;
		// Filter out empty strings
		Iterator<String> i = list.iterator();
		while (i.hasNext())
		{
			if (i.next().equals(EMPTY))
				i.remove();
		}

		return list;
	}

	/**
	 * Determines if the given line meets the requirements for including the next
	 * line as the continuation of the definition of the given line.
	 * 
	 * @param line - The line in question.
	 * @return {@code true} if the definition of this line should continue to the
	 *         next.
	 */
	protected static boolean shouldContinue(String line)
	{
		line = removeComment(line, null);
		return line.endsWith(CONTINUATION_MARKER);
	}

	/**
	 * Handles the for loop syntactical construct.
	 * 
	 * @param br   - The reader containing the definition of the for loop.
	 * @param line - The initial line of the for loop.
	 * @param p    - The Parameters object to store into and resolve with.
	 * @throws ParException If a syntax error occurs.
	 * @throws IOException  If there was a problem reading the .par file.
	 */
	static void handleFor(BufferedReader br, String line, LibParParameters p, File location)
			throws ParException, IOException
	{
		Deque<Object> nested = new LinkedList<Object>();
		ForBuilder fb = new ForBuilder();
		line = resolve(line, p);
		// Deal with the first line which should follow the format:
		// #!ForBegin <iteration-var-name> in <iterables>
		line = line.substring(FOR_BEGIN.length());
		String[] parts = line.split(IN);
		if (parts.length != 2)
		{
			throw new ParException("Invalid for begin statement: " + FOR_BEGIN + line + ", Should be of the form: "
					+ "#!ForBegin <iteration-var-name> in <iterables>");
		}
		fb.setIterationVar(parts[0].trim());
		fb.setIterables(parts[1].trim());
		nested.push(DQ_MARK);
		while ((line = getLine(br)) != null)
		{
			if (line.startsWith(FOR_BEGIN))
				nested.push(DQ_MARK);
			if (line.startsWith(FOR_END))
			{
				nested.pop();
				if (nested.isEmpty())
				{
					fb.executeLoop(p, location);
					return;
				}
			}
			fb.addBodyStatement(line);
		}
		throw new ParException("Unexpected EOF while reading For Loop Syntax");
	}

	/**
	 * Handles a line that only contains key-value pairs.
	 * 
	 * @param p        - The parameters object to store into and resolve with.
	 * @param line     - The line containing the key-value pairs.
	 * @param location - The location of what .par file the {@code line} originated
	 *                 from.
	 * @throws ParException If any syntax errors occurred.
	 */
	static void handleKeyValue(LibParParameters p, String line, File location) throws ParException, IOException
	{
		List<String> tokens = parseTokens(line);
		for (String token : tokens)
		{
			handleToken(p, token, location);
		}
	}

	/**
	 * Handles the table syntax starting with the given line.
	 * 
	 * @param br       - The reader holding the remains of the table definition.
	 * @param line     - The first line of the table definition.
	 * @param p        - The Parameters object to store into and resolve with.
	 * @param location - The location of what .par file the {@code line} originated
	 *                 from.
	 * @throws ParException If any syntax errors are found.
	 * @throws IOException  If the table is recursive, this indicates a problem with
	 *                      the IO of reading the new file.
	 */
	static void handleTable(BufferedReader br, String line, LibParParameters p, File location)
			throws ParException, IOException
	{
		// Take the tokens out of the first line.
		List<String> parts = resolve(parseTokens(line), p);
		// There should be 2: "#!BeginTable" and "<name>"
		if (parts.size() != 2)
			throw new ParException("Ill formatted table begin statement: " + line);
		// Get the <name>.
		String name = parts.get(1);
		// See if this table has already been started:
		ParTable tb = getBuilder(name, p);

		// Columns in this table
		List<String> columns = null;

		boolean firstLine = true;

		// Then handle the contents of the table.
		while ((line = getLine(br)) != null)
		{
			// If this is the end of the table, then proceed to the end.
			if (line.equals(TABLE_END))
				return;
			// Oops, someone must have forgotten to end the previous table
			if (line.startsWith(TABLE_BEGIN))
			{
				handleTable(br, line, p, location);
				return;
			}
			// If it's empty, then ignore it.
			if (line.equals(EMPTY))
				continue;

			// Remove the comment from the line now that it won't be #!EndTable.
			line = removeComment(line, null);
			// If it is the first line after the start, then it is a column definition
			if (firstLine)
			{
				columns = handleColumns(line, tb, p);
				firstLine = false;
			}
			else
			{
				// Otherwise it is a row definition.
				handleRow(line, tb, columns, p);
			}
		}
	}
}
