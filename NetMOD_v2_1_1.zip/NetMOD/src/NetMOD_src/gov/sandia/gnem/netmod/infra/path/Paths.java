
package gov.sandia.gnem.netmod.infra.path;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.WindMode;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.path.wind.WindModelPlugin;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.Collection;

/**
 * @author bjmerch
 */
public class Paths extends gov.sandia.gnem.netmod.path.Paths
{
	private WindModel _windModel = null;
    private WindMode _windMode = WindMode.PATH;
	private String _windModelType = "";

	public Paths(NetModComponent parent, Collection<? extends Phase> phases)
	{
		super(parent, phases);
	}

	@Override
	public NetModComponentViewer<?> getViewer()
	{
		return new PathsViewer(this);
	}

	public WindModel getWindModel()
	{
		if (_windModel == null)
		{
			_windModel = WindModelPlugin.getPlugin().getComponent(this, getWindModelType());
		}
		return _windModel;
	}

	public String getWindModelType()
	{
		return _windModelType;
	}

	public void setWindModel(WindModel windModel)
	{
		if (windModel != null)
		{
			_windModelType = windModel.getType();
		}

		_windModel = windModel;
	}

	public void setWindModelType(String windModelType)
	{
		if (_windModelType.equals(windModelType))
		{
			return;
		}

		_windModelType = windModelType;
		_windModel = null;
	}

    /**
     * @return the windMode
     */
    public WindMode getWindMode()
    {
        return _windMode;
    }

	/**
     * @param windMode the windMode to set
     */
    public void setWindMode(WindMode windMode)
    {
        _windMode = windMode;
    }

	@Override
	public void load(NetSimParameters parameters) throws Exception
	{
		super.load(parameters);

		setWindModelType(parameters.get(NetSimParameters.windModel));
		if (getWindModel() != null)
			getWindModel().load(parameters);
		setWindMode(parameters.get(NetSimParameters.windMode));
	}

	@Override
	public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
	{
		super.save(parameters, files, reset);

		parameters.set(NetSimParameters.windModel, getWindModelType());

		if (getWindModel() != null)
			getWindModel().save(parameters, files, reset);
		
        parameters.set(NetSimParameters.windMode, getWindMode());
	}
}
