/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

/**
 * Map used for caching two double values to computed objects.  Limits the map size
 * to the specified size so that the map doesn't get too large
 * 
 * @author bjmerch
 *
 * @param <V>
 */
public class CacheDoubleDoubleObjectMap<V>
{
    private int _size1, _size2;
    private CacheDoubleObjectMap<CacheDoubleObjectMap<V>> _cache;

    public CacheDoubleDoubleObjectMap(int size1, int size2)
    {
        _size1 = size1;
        _size2 = size2;

        _cache = new CacheDoubleObjectMap<CacheDoubleObjectMap<V>>(_size1);
    }

    public void clear()
    {
        _cache.clear();
    }

    public V get(double key1, double key2)
    {
        //  Check the first level of cache, synchronized
        CacheDoubleObjectMap<V> cache2 = _cache.get(key1);
        if (cache2 == null)
        {
            cache2 = new CacheDoubleObjectMap<V>(_size2);
            _cache.put(key1, cache2);
        }

        //  Check the second level of cache
        return cache2.get(key2);
    }

    public void put(double key1, double key2, V value)
    {
        //  Check the first level of cache, synchronized
        CacheDoubleObjectMap<V> cache2 = _cache.get(key1);
        if (cache2 == null)
        {
            cache2 = new CacheDoubleObjectMap<V>(_size2);
            _cache.put(key1, cache2);
        }

        cache2.put(key2, value);
    }
}