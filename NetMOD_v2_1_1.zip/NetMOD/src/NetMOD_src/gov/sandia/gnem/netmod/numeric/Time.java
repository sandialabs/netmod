/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

import gov.sandia.gnem.netmod.gui.GUIUtility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 * Container for time values
 * 
 * @author bjmerch
 *
 */
public class Time
{
    private long _time;
    
    /**
     * Create a new time value expressed as milliseconds of epoch time (since January 1, 1970)
     * 
     * @param time
     */
    public Time(long time)
    {
        _time = time;
    }

    /**
     * Create a new time value expressed as seconds of epoch time (since January 1, 1970)
     * 
     * @param time
     */
    public Time(double time)
    {
        _time = (long) (time * 1000.0);
    }
    
    /**
     * @param cal
     */
    public Time(Calendar cal)
    {
    	_time = cal.getTimeInMillis();
    }

    /**
     * Get the time in milliseconds of epoch time (since January 1, 1970)
     * 
     * @return
     */
    public long getTimeMilliseconds()
    {
        return _time;
    }
    
    /**
     * Get the time in seconds of epoch time (since January 1, 1970)
     * 
     * @return
     */
    public double getTimeSeconds()
    {
        return _time * 1000.0;
    }
    
    @Override
    public String toString()
    {
        return GUIUtility.getTimeFormat().format(getDate());
    }

    /**
     * @return
     */
    public Date getDate()
    {
        return new Date(getTimeMilliseconds());
    }

    /**
     * @return
     */
    public Calendar getCalendar()
    {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.setTimeInMillis(getTimeMilliseconds());
        
        return cal;
    }
    
    @Override
    public int hashCode()
    {
    	return (int) _time;
    	
    }
  
    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof Time) )
            return false;
        
        Time time = (Time) o;
        
        return _time == time._time;
    }

}
