/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.media;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.spectra.SourceSpectra;
import gov.sandia.gnem.netmod.source.spectra.SourceSpectraPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class SourceMediaType extends AbstractNetModComponent
{
    private double _density = 2.5e3;
    private String _sourceSpectraFile = "";
    private SourceSpectra _sourceSpectra;
    private EventSizeConversion _eventSizeConversion;
    private PhaseParameters<SourceMediaPhaseParameter> _phaseParameters;
    private double _beta3;
    private double _beta4;
    private double _beta5;
    
    private boolean _dirty = true;
    
    /**
     * @param parent
     * @param phases
     */
    public SourceMediaType(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent);
        
        _sourceSpectra = SourceSpectraPlugin.getPlugin().getDefaultComponent(this);
        _eventSizeConversion = new EventSizeConversion(this);
        
        //  Initialize the set of phases
        _phaseParameters = new PhaseParameters<SourceMediaPhaseParameter>(this);       
        if ( phases != null )
            for (Phase phase : phases)
                _phaseParameters.addParameter(new SourceMediaPhaseParameter(_phaseParameters, phase));
        
        setName("New Source Media");
    }
    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (!(o instanceof SourceMediaType))
            return false;

        SourceMediaType smt = (SourceMediaType) o;

        return getName().equalsIgnoreCase(smt.getName());
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getSourceSpectra());
        children.add(getEventSizeConversion());
        children.add(getPhaseParameters());

        return children;
    }

    /**
     * @return
     */
    public double getDensity()
    {
        return _density;
    }

    /**
     * @return the dirty
     */
    public boolean getDirty()
    {
        boolean dirty = _dirty;
        
        dirty |= _eventSizeConversion.getDirty();
        
        for (SourceMediaPhaseParameter pp : _phaseParameters.getParameters())
            dirty |= pp.getDirty();
        
        return dirty;
    }

    /**
     * @return the eventSizeConversion
     */
    public EventSizeConversion getEventSizeConversion()
    {
        return _eventSizeConversion;
    }

    /**
     * @return the phaseParameters
     */
    public PhaseParameters<SourceMediaPhaseParameter> getPhaseParameters()
    {
        return _phaseParameters;
    }

    public double getBeta3() {
        return _beta3;
    }

    public double getBeta4() {
        return _beta4;
    }

    public double getBeta5() {
        return _beta5;
    }

    /**
     * @return the sourceSpectra
     */
    public SourceSpectra getSourceSpectra()
    {
        if ( _sourceSpectra == null )
        {
            _sourceSpectra = SourceSpectraPlugin.getPlugin().getComponentFor(this, getSourceSpectraFile());
            if ( _sourceSpectra != null )
                _sourceSpectra.setFilename(getSourceSpectraFile());
        }
        
        return _sourceSpectra;
    }

    /**
     * @return the sourceSpectraFile
     */
    public String getSourceSpectraFile()
    {
        return _sourceSpectraFile;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new SourceMediaTypeViewer(this);
    }

    @Override
    public int hashCode()
    {
        return getName().hashCode();
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof SourceSpectra)
                _sourceSpectra = (SourceSpectra) child;
            else if (child instanceof EventSizeConversion)
                _eventSizeConversion = (EventSizeConversion) child;
            else if (child instanceof PhaseParameters)
                _phaseParameters = (PhaseParameters) child;
        }

        clearCache();
    }

    /**
     * @param value
     */
    public void setDensity(double value)
    {
        if ( _density == value )
            return;
        
        _density = value;
        setDirty(true);
    }

    /**
     * @param dirty the dirty to set
     */
    public void setDirty(boolean dirty)
    {
        _dirty = dirty;
        
        if ( _eventSizeConversion != null )
            _eventSizeConversion.setDirty(dirty);
        
        if ( _phaseParameters != null )
            for (SourceMediaPhaseParameter pp : _phaseParameters.getParameters())
                pp.setDirty(dirty);
    }
    
    /**
     * @param eventSizeConversion the eventSizeConversion to set
     */
    public void setEventSizeConversion(EventSizeConversion eventSizeConversion)
    {
        if ( _eventSizeConversion == eventSizeConversion )
            return;
        
        _eventSizeConversion = eventSizeConversion;
        setDirty(true);
    }
    
    @Override
    public void setName(String name)
    {
        if ( getName().equalsIgnoreCase(name) )
            setDirty(true);
        
        super.setName(name);
    }
    
    /**
     * @param phaseParameters the phaseParameters to set
     */
    public void setPhaseParameters(PhaseParameters<SourceMediaPhaseParameter> phaseParameters)
    {
        if ( _phaseParameters == phaseParameters )
            return;
        
        _phaseParameters = phaseParameters;
        setDirty(true);
    }

    /**
     * @param sourceSpectra the sourceSpectra to set
     */
    public void setSourceSpectra(SourceSpectra sourceSpectra)
    {
        if ( sourceSpectra != null )
            _sourceSpectraFile = sourceSpectra.getFilename();
                
        _sourceSpectra = sourceSpectra;
        setDirty(true);
    }

    public void setBeta3(double value) {
        if (_beta3 == value)
            return;
        _beta3 = value;
        setDirty(true);
    }

    public void setBeta4(double value) {
        if (_beta4 == value)
            return;
        _beta4 = value;
        setDirty(true);
    }

    public void setBeta5(double value) {
        if (_beta5 == value)
            return;
        _beta5 = value;
        setDirty(true);
    }

    /**
     * @param sourceSpectraFile the sourceSpectraFile to set
     */
    public void setSourceSpectraFile(String sourceSpectraFile)
    {
        if ( _sourceSpectraFile.equals(sourceSpectraFile) )
            return;
        
        //  If file exists, load it
        if ( IOUtility.openFile(sourceSpectraFile).exists() )
        {
            _sourceSpectraFile = sourceSpectraFile;
            setSourceSpectra(null);
        }
        //  Otherwise, save to it
        else
        {
            SourceSpectra sourceSpectra = getSourceSpectra();
            sourceSpectra.read();
            sourceSpectra.setFilename(sourceSpectraFile);
            sourceSpectra.write();
            _sourceSpectraFile = sourceSpectra.getFilename();
        }
        
        setDirty(true);
    }
}
