/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author bjmerch
 *
 */
public class Network extends AbstractNetModComponent
{
    private Set<Station> _stations = new TreeSet<Station>();

    //  Cache the viewer
    transient private NetworkViewer _viewer = null;
    transient private Stations _availableStations = null;

    public Network(NetModComponent parent, Stations stations)
    {
        super(parent);
        
        _availableStations = stations;
        setName("Network");
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if (!(o instanceof Network))
            return false;

        return o.toString().equals(toString());
    }

    /**
     * @return the stations
     */
    public Set<Station> getStations()
    {
        return _stations;
    }

    /**
     * Get the stations in this network as a
     * comma separated list of station names
     * 
     * @return
     */
    public String getStationsList()
    {
        StringBuilder sb = new StringBuilder();

        for (Station station : getStations())
            sb.append(station.getName()).append(',');

        if (sb.length() > 0)
            sb.deleteCharAt(sb.length() - 1);

        return sb.toString();
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        if (_viewer == null)
            _viewer = new NetworkViewer(this);
        else
            _viewer.refresh();

        return _viewer;
    }

    @Override
    public int hashCode()
    {
        return getName().hashCode();
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    /**
     * Set the stations from the provided comma separated list of stations
     * 
     * @param stations
     */
    public void setStations(String stations)
    {
    	Map<String, Station> stationMap = getAvailableStations().getStationMap();
    	
        TreeSet<Station> set_stations = new TreeSet<Station>();
        for (String name : stations.split("\\s*(\\s|,)\\s*"))
        {
        	Station station = stationMap.get(name);
        	if ( station != null )
        		set_stations.add(station);
        }
       
        setStations(set_stations);
    }

    /**
     * @param stations the stations to set
     */
    public void setStations(Set<Station> stations)
    {
		if (_stations != stations)
		{
			_stations.clear();
			_stations.addAll(stations);
		}

        if (_viewer != null)
            _viewer.refresh();

    }

    /**
     * Set the set of available stations to choose from
     * 
     * @param stations
     */
    private void setAvailableStations(Stations stations)
    {
        _availableStations = stations;
    }
    
    /**
     * Get the set of available stations to choose from
     * 
     * @return
     */
    public Stations getAvailableStations()
    {
        return _availableStations;
    }
}
