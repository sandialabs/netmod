/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.NetSimParameters.SizeType;
import gov.sandia.gnem.netmod.io.NetSimParameters.SubType;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.util.Arrays;

/**
 * Threshold Simulation in which the magnitude is identified
 * which has the desired probability associated with it.
 * 
 * @author bjmerch
 *
 */
public class SimulationTypeThreshold extends SimulationType
{
    private static final double EPS = 1e-3;
    private static final int MAX_ITER = 100;
    private static final int HISTORY_P = 1;
    private static final int HISTORY_M = 0;
    private static String _type = "Threshold";
    
    static
    {
        SimulationTypePlugin.getPlugin().registerComponent(_type, SimulationTypeThreshold.class);
    }

    private double _probability = 0.9;
    private MagnitudeType _magnitudeType = MagnitudeType.mb;
    private double _magnitudeMin = 0;
    private double _magnitudeMax = 6;

    public SimulationTypeThreshold(NetModComponent parent)
    {
        super(parent, _type);
    }

    @Override
    public double[][] getMagnitudeHistory()
    {
        double[][] history = new double[2][MAX_ITER];

        //  Initialize the history with the maximum value
        Arrays.fill(history[HISTORY_P], 1.0);
        Arrays.fill(history[HISTORY_M], getMagnitudeMax());

        //  Initialize the history with the minimum value
        history[HISTORY_P][0] = 0.0;
        history[HISTORY_M][0] = getMagnitudeMin();

        return history;
    }

    /**
     * Get the maximum magnitude
     * 
     * @return
     */
    public double getMagnitudeMax()
    {
        return _magnitudeMax;
    }

    /**
     * Get the minimum magnitude
     * 
     * @return
     */
    public double getMagnitudeMin()
    {
        return _magnitudeMin;
    }

    /**
     * Get the magnitude type
     * 
     * @return
     */
    @Override
    public MagnitudeType getMagnitudeType()
    {
        return _magnitudeType;
    }

    @Override
    public double getNextMagnitude(double magnitude, double probability, double[][] history, int iteration)
    {
        //  Check if initialization is needed
        if (Double.isNaN(probability))
        {
            //  No initial magnitude guess
            if (Double.isNaN(magnitude))
            {
                return (getMagnitudeMin() + getMagnitudeMax()) / 2;
            }
            //  Use an initial magnitude guess
            else
            {
                if (magnitude >= getMagnitudeMin() && magnitude <= getMagnitudeMax())
                    return magnitude;
                else
                    return (getMagnitudeMin() + getMagnitudeMax()) / 2;
            }
        }

        //  Declare done if the maximum number of iterations has been reached
        if (iteration >= MAX_ITER)
            return magnitude;

        //  Declare done if near the probability target
        double targetP = getProbability();
        double dP = probability - targetP;
        if (Math.abs(dP) < EPS && probability != 1.0 && probability != 0.0)
            return magnitude;

        //  Insert the previous iteration into the history
        //  Maintain the magnitude increasing monotonically
        int index = 0;
        for (index = 0; index < MAX_ITER; index++)
        {
            //  Replace an existing value
            if (magnitude == history[HISTORY_M][index])
            {
                history[HISTORY_M][index] = magnitude;
                history[HISTORY_P][index] = probability;

                break;
            }
            //  Insert the value
            else if (magnitude < history[HISTORY_M][index])
            {
                //  continue searching to sub-order by probability
                for (; magnitude == history[HISTORY_M][index] && probability < history[HISTORY_P][index] && index < MAX_ITER - 1; index++)
                    ;

                //  Shift the remaining values
                for (int j = MAX_ITER; --j > index;)
                {
                    history[HISTORY_P][j] = history[HISTORY_P][j - 1];
                    history[HISTORY_M][j] = history[HISTORY_M][j - 1];
                }

                //  Insert the new values
                history[HISTORY_P][index] = probability;
                history[HISTORY_M][index] = magnitude;

                break;
            }
        }

        //  Find the indicies of the probabilities that bound the desired probability
        //  Search from top-down to give preference to higher magnitude solutions
        int index_minus;
        for (index_minus = MAX_ITER - 1; index_minus > 0 && history[HISTORY_P][index_minus] > targetP; index_minus--);
        int index_plus = index_minus + 1;

        //  Determine the next magnitude
        double nextMagnitude = 0;
        if (iteration == 1 && ( probability > (1.0 - EPS) || probability < EPS ) )
        {
            //  Need to determine the probability of the extremes
            if (probability > targetP)
                nextMagnitude = getMagnitudeMin();
            else
                nextMagnitude = getMagnitudeMax();
        }
        //  try a proportional shift if close
        else if (iteration < 5)
        {
            if ( checkBounds(probability) )
            {
                double coefficient = (_magnitudeType.isLog() ? 4 : 0.25);
                
                //  Attempt to overshoot slightly so as to tighten the bounds
                nextMagnitude = magnitude * (1 - coefficient * dP / targetP);
                
                //  If shift has caused us to exceed existing bounds, then limit
                if (nextMagnitude >= history[HISTORY_M][index_plus] || nextMagnitude <= history[HISTORY_M][index_minus])
                {
                    //  Try bisection search with golden rule bias for higher magnitudes
                    double m1 = history[HISTORY_M][index_minus];
                    double m2 = history[HISTORY_M][index_plus];

                    nextMagnitude = m1 + (m2 - m1) *  0.618;
                }
            }
            else
            {
                //  Try bisection search with golden rule bias for higher magnitudes
                double m1 = history[HISTORY_M][index_minus];
                double m2 = history[HISTORY_M][index_plus];

                nextMagnitude = m1 + (m2 - m1) *  0.618;
            }
        }
        //  Try interpolation search
        else
        {
            //  Check if the bounds are valid
            if ( checkBounds(history[HISTORY_P][Math.max(0, index_minus-1)]) && 
                    checkBounds(history[HISTORY_P][index_minus]) &&
                    checkBounds(history[HISTORY_P][index_plus]) &&
                    checkBounds(history[HISTORY_P][Math.min(MAX_ITER-1,index_plus+1)]) )
            {
                //  Perform interpolation search
                double m1 = history[HISTORY_M][Math.max(0, index_minus-1)];
                double m2 = history[HISTORY_M][index_minus];
                double m3 = history[HISTORY_M][index_plus];
                double m4 = history[HISTORY_M][Math.min(MAX_ITER-1,index_plus+1)];
                
                double p1 = history[HISTORY_P][Math.max(0, index_minus-1)];
                double p2 = history[HISTORY_P][index_minus];
                double p3 = history[HISTORY_P][index_plus];
                double p4 = history[HISTORY_P][Math.min(MAX_ITER-1,index_plus+1)];
                
                nextMagnitude = Interpolation.quadratic(p1, p2, p3, p4, m1, m2, m3, m4, targetP);
            }
            else
            {
                //  Try bisection search with golden rule bias for higher magnitudes
                double m1 = history[HISTORY_M][index_minus];
                double m2 = history[HISTORY_M][index_plus];

                nextMagnitude = m1 + (m2 - m1) *  0.618;
            }
        }

        //  Clamp the magnitude to the min/max range
        nextMagnitude = Math.min(getMagnitudeMax(), Math.max(getMagnitudeMin(), nextMagnitude));
        
        //  Declare done if the magnitude change is too small
        if (Math.abs((magnitude - nextMagnitude) / magnitude) < EPS)
            return magnitude;

        return nextMagnitude;
    }
    
    /**
     * Check that the probability value is not at the extremes, [0..1]
     * 
     * @param probability
     * @return
     */
    private boolean checkBounds(double probability)
    {
        return probability > EPS && probability < ( 1.0 - EPS ) ;
    }

    /**
     * Get the desired probability
     * 
     * @return
     */
    public double getProbability()
    {
        return _probability;
    }

    @Override
    public double getResult(double magnitude, double probability)
    {
        return magnitude;
    }

    @Override
    public ResultType getResultType()
    {
        return ResultType.THRESHOLD;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new SimulationTypeThresholdViewer(this);
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        setMagnitudeType(MagnitudeType.valueOfIgnoreCase(parameters.get(NetSimParameters.sizeType).getName()));
        setMagnitudeMin(parameters.get(NetSimParameters.minEventSize));
        setMagnitudeMax(parameters.get(NetSimParameters.maxEventSize));
        setProbability(parameters.get(NetSimParameters.conf));
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(NetSimParameters.subType, SubType.valueOf(getType().toUpperCase()));
        parameters.set(NetSimParameters.sizeType, SizeType.valueOf(getMagnitudeType().toString().toUpperCase()));
        parameters.set(NetSimParameters.minEventSize, getMagnitudeMin());
        parameters.set(NetSimParameters.maxEventSize, getMagnitudeMax());
        parameters.set(NetSimParameters.conf, getProbability());
    }

    /**
     * Set the maximum magnitude
     * 
     * @param magnitudeMax
     */
    public void setMagnitudeMax(double magnitudeMax)
    {
        _magnitudeMax = magnitudeMax;
    }

    /**
     * Set the minimum magnitude
     * 
     * @param magnitudeMin
     */
    public void setMagnitudeMin(double magnitudeMin)
    {
        _magnitudeMin = magnitudeMin;
    }

    /**
     * Set the magnitude type
     * 
     * @param magnitude
     */
    @Override
    public void setMagnitudeType(MagnitudeType magnitude)
    {
        _magnitudeType = magnitude;
    }

    /**
     * Set the probability
     * 
     * @param probability
     */
    public void setProbability(double probability)
    {
        _probability = probability;
    }
}
