/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.noise;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Spectra;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.numeric.SpectraPDF;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.PathPhaseParameter;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * @author bjmerch
 *
 */
public class NetModBodywave extends NetSimBodywave
{
    private static final String _type = "NetMOD";
    static
    {
        NoiseAmplitudePlugin.getPlugin().registerComponent(_type, NetModBodywave.class);
    }

    public NetModBodywave(NetModComponent parent)
    {
        super(parent, _type, "NetMOD Noise Amplitude");
    }

    @Override
    public Spectra generateAmplitude(SignalAmplitude signal, Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        //  Get the site noise estimate in non-log PSD units
        Spectra siteNoiseLogPSD = getAmbientSiteNoise(signal, sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);

        //  Get the prior phase noise in non-log PSD units
        Spectra priorLogPSD = getPriorPhaseNoise(signal, sources, paths, receivers, epicenter, station, distance, magnitude, phase, frequency, time, N, prng);

        //  Sum the noise
        Spectra sumLogPSD = new SpectraPDF(siteNoiseLogPSD, 0);
        if (priorLogPSD != null)
        {
        	//  Create modifiable copies
        	priorLogPSD = new SpectraPDF(priorLogPSD, 0);
        	
        	//   Convert to nonlog and sum
        	sumLogPSD = sumLogPSD.pow10().add(priorLogPSD.pow10()); 
        	sumLogPSD.log10();
        }

        //  Convert back to log10 SA
        double Tk = paths.getPhaseParameters().getPhaseParameter(phase).getTimeWindow(epicenter, station.getLocation());
        Spectra sumLogSA = sumLogPSD.scale(0.5).add(0.5 * Math.log10(Tk));

        recordIntrospection("NetMOD Noise Amplitude (log10, SA): ", sumLogSA);
        recordIntrospection("Time Window length (sec): ", Tk);

        stopIntrospection();

        return sumLogSA;
    }

    /**
     * Get the ambient site noise in log PSD units.
     * 
     * @param signal
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param magnitude
     * @param station
     * @param phase
     * @param frequency
     * @return
     */
    private Spectra getAmbientSiteNoise(SignalAmplitude signal, Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        //  Get the estimate of the site noise
        Spectra logPSDSiteNoise = station.getNoiseSpectra().getNoise(frequency, time);

        //  Create a copy that will be modified, applying the station default standard deviation if none exists
        logPSDSiteNoise = new SpectraPDF(logPSDSiteNoise, 2 * station.getNoiseSpectraSD());
        
        //  Generate Monte Carlo values, if needed
        logPSDSiteNoise = logPSDSiteNoise.toMonteCarlo(prng, N);

        recordIntrospection("Ambient Site Noise (log PSD): ", logPSDSiteNoise);
        stopIntrospection();

        return logPSDSiteNoise;
    }

    /**
     * Get the prior phase noise in log PSD units
     * 
     * @param signal
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param magnitude
     * @param station
     * @param phase
     * @param frequency
     * @return
     */
    private Spectra getPriorPhaseNoise(SignalAmplitude signal, Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();
        
        //  Get the path phase parameters
        PathPhaseParameter pathPP = paths.getPhaseParameters().getPhaseParameter(phase);

        //  Identify the prior phase
        Phase priorPhase = pathPP.getPriorPhase();
        if (priorPhase == null)
        {
            recordIntrospection("No Prior Phase");
            stopIntrospection();
            return null;
        }

        //  Get the coda decay scale factor, copied so we don't modify the cached copy
        SpectraDouble codaDecayRate = new SpectraDouble(pathPP.getCodaDecay().getCodaDecay(distance, frequency));
        codaDecayRate.log10().scale(2.0);

        //  Get the time window
        double Tk_ = paths.getPhaseParameters().getPhaseParameter(priorPhase).getTimeWindow(epicenter, station.getLocation());

        //  Get the spectral amplitude of the prior phase
        Spectra logSijk_ = signal.generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, priorPhase, frequency, time, N, prng);

        //  Convert from SA to PSD
        SpectraPDF logSijk_PSD = new SpectraPDF(logSijk_, 0);
        logSijk_PSD.scale(2.0);
        logSijk_PSD.add(- Math.log10(Tk_));
        logSijk_PSD.add(codaDecayRate);
        
        //  Generate monte Carlo values, if needed
        logSijk_PSD = logSijk_PSD.toMonteCarlo(prng, N);

        recordIntrospection("Prior Phase Noise (log PSD): ", logSijk_PSD);
        recordIntrospection("Prior Phase: ", priorPhase);
        recordIntrospection("Coda Decay Rate Correction (2 * log10): ", codaDecayRate);
        recordIntrospection("Time Window length (sec): ", Tk_);

        stopIntrospection();

        return logSijk_PSD;
    }
}
