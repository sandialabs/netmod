/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.geometry;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import com.carrotsearch.hppc.cursors.ObjectCursor;

import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

/**
 * Geographic grid of media types.  A geographic region is divided into a regular
 * grid of cells.  Each cell can be assigned a specific media type (i.e. land or water)
 * that is unique to the media grid type (i.e. source media or path media).
 * 
 * @author bjmerch
 *
 */
public abstract class MediaGrid<TYPE extends NetModComponent> extends AbstractNetModFile
{
    /**
     *  Identifier for the reference media
     */
    public final static String REFERENCE = "reference";

    private double _latitude = -90;
    private double _longitude = -180;
    private double _latitudeDelta = 5;
    private double _longitudeDelta = 5;
    private int _longitudeCount = 72;
    private int _latitudeCount = 36;

    private Object[][] _mediaType = new Object[_longitudeCount][_latitudeCount];

    private Map<String, TYPE> _mediaTypes = new LinkedHashMap<String, TYPE>();
    private boolean _gridDirty = false;

    /*
     * Cache frequently referred to objects
     */
    transient private double[] _longitudes = null;
    transient private double[] _latitudes = null;

    /**
     *  Cache the requests for media weights
     *  
     *  Use a synchronized map since the cache may be accessed in a multi-threaded environment
     */
    transient private CacheMap<Distance, ObjectDoubleMap<TYPE>> _cacheMinor = new CacheMap<Distance, ObjectDoubleMap<TYPE>>(
            CacheMap.CACHE_SOURCE * CacheMap.CACHE_RECEIVER);
    transient private CacheMap<Distance, ObjectDoubleMap<TYPE>> _cacheMajor = new CacheMap<Distance, ObjectDoubleMap<TYPE>>(
            CacheMap.CACHE_SOURCE * CacheMap.CACHE_RECEIVER);

    /**
     * Create a new media grid that has the provided parent.  
     * Type type identifier of this media grid is provided.
     * 
     * @param parent
     * @param type
     */
    protected MediaGrid(NetModComponent parent, String type)
    {
        super(parent, type);
    }

    /**
     * Add a media type to the set of media types for this media grid
     * 
     * @param mediaType
     */
    public void addMediaType(TYPE mediaType)
    {
        _mediaTypes.put(mediaType.getName(), mediaType);
        setMediaDirty(true);
    }

    @Override
    public void clearCache()
    {
        super.clearCache();

        _cacheMinor.clear();
        _cacheMajor.clear();
    }

    /**
     * Check if the media grid is dirty, i.e. modified and needs to be saved to a file
     * 
     * @return the gridDirty
     */
    public boolean getGridDirty()
    {
        return _gridDirty;
    }

    /**
     * Get the starting latitude in degrees
     * 
     * @return the latitude
     */
    public double getLatitude()
    {
        return _latitude;
    }

    /**
     * Get the number of latitude cells
     * 
     * @return the latitudeCount
     */
    public int getLatitudeCount()
    {
        return _latitudeCount;
    }

    /**
     * Get the spacing between latitude cells
     * 
     * @return
     */
    public double getLatitudeDelta()
    {
        return _latitudeDelta;
    }

    /**
     * Get the starting longitude in degrees
     * 
     * @return the longitude
     */
    public double getLongitude()
    {
        return _longitude;
    }

    /**
     * Get the number of longitude cells
     * 
     * @return the longitudeCount
     */
    public int getLongitudeCount()
    {
        return _longitudeCount;
    }

    /**
     * Get the spacing between longitude cells
     * 
     * @return
     */
    public double getLongitudeDelta()
    {
        return _longitudeDelta;
    }

    /**
     * Get whether the media is dirty
     * 
     * @return
     */
    abstract public boolean getMediaDirty();

    /**
     * Get the names of the media types within this media grid
     * 
     * @return
     */
    public Set<String> getMediaNames()
    {
        Set<String> names = new LinkedHashSet<String>();

        for (TYPE type : getMediaTypes())
            names.add(type.toString());

        return names;
    }

    public ObjectDoubleMap<Point.Double> getAttenuationPoints(Distance distance, boolean minor) {
        ObjectDoubleMap<Point.Double> distances = distance.computePoints(getLongitudes(), getLatitudes(), minor);
        return distances;
    }

    /**
     * Get the media type defined at the specified longitude and latitude in degrees
     * 
     * @param longitude
     * @param latitude
     * @return
     */
    public TYPE getMediaType(double longitude, double latitude)
    {
        //  Ensure longitudes are [-180,180)
        if (longitude >= 180)
            longitude = ((longitude + 180) % 360) - 180;

        return getMediaType((int) ((longitude - getLongitude()) / getLongitudeDelta()), (int) ((latitude - getLatitude()) / getLatitudeDelta()));
    }

    /**
     * Get the media type for the specified longitude and latitude bin in cell counts from
     * the starting longitude and latitude bin
     * 
     * @param longitude
     * @param latitude
     * @return
     */
    public TYPE getMediaType(int longitude, int latitude)
    {
        if (longitude < 0 || longitude >= _longitudeCount || latitude < 0 || latitude >= _latitudeCount)
            return null;

        TYPE type = (TYPE) _mediaType[longitude][latitude];
        if (type == null)
            type = getMediaType(REFERENCE);

        return type;
    }

    /**
     * Get the media type for the provided location
     * 
     * @param location
     */
    public TYPE getMediaType(Point.Double location)
    {
        return getMediaType(location.getLongitude(), location.getLatitude());
    }

    /**
     * Get the media type for the segment bounded by the two
     * provided locations
     * 
     * @param location
     */
    public TYPE getMediaType(Point.Double location1, Point.Double location2)
    {
        return getMediaType(
        		Math.min(location1.getLongitude(), location2.getLongitude()),
        		Math.min(location1.getLatitude(),  location2.getLatitude()));
    }

    /**
     * Get the media for the provided type
     * 
     * @param type
     * @return
     */
    public TYPE getMediaType(String type)
    {
        return _mediaTypes.get(type);
    }

    /**
     * Get the set of media types that are defined for this media grid
     * 
     * @return
     */
    public Set<TYPE> getMediaTypes()
    {
        Set<TYPE> mediaTypes = new LinkedHashSet<TYPE>();

        //  List the remaining media types
        mediaTypes.addAll(_mediaTypes.values());

        return mediaTypes;
    }

    /**
     * Compute the percentage of the path between the two locations that falls
     * into each of the media types within this media grid. 
     * 
     * @param distance Distance object for the two source & receiver points
     * @param minor if true, compute the path along the minor arc.  If false, compute the path along the major arc
     * @return
     */
    public ObjectDoubleMap<TYPE> getMediaWeights(Distance distance, boolean minor)
    {
        CacheMap<Distance, ObjectDoubleMap<TYPE>> cache = _cacheMinor;
        if ( !minor )
            cache = _cacheMajor;
        
        //  Check for a reference to the cached bin weights
        ObjectDoubleMap<TYPE> weights = cache.get(distance);
        
        if (weights == null)
        {
            //  Compute all of the intermediary points along this media grid
            ObjectDoubleMap<Point.Double> distances = distance.computePoints(getLongitudes(), getLatitudes(), minor);
            
            //  Sort the points in order of distance from p1 to p2
            Point.Double[] points = Distance.sortPoints(distances);
            
            //  Compute the relative weight for each of the distance segments
            weights = new ObjectDoubleOpenHashMap<TYPE>();
            int N = points.length;
            for (int i=1; i<N; i++)
            {
                Point.Double p1 = points[i-1];
                Point.Double p2 = points[i];
                
                //  Get the media type of this segment
                TYPE type = getMediaType(p1, p2);
                
                //  Get the existing weight
                double weight = weights.get(type);
                
                //  Add to the weight
                double dist = Math.abs(distances.get(p2) - distances.get(p1));
                weight += dist;
                
                //  Set the new weight
                weights.put(type, weight);
            }
            
            //  Normalize the distances to sum to 1.0
            double total = 0;
            for (ObjectCursor<TYPE> entry : weights.keys())
                total += weights.get(entry.value);
            for (ObjectCursor<TYPE> entry : weights.keys())
                weights.put(entry.value, weights.get(entry.value) / total);
            
            //  Store a reference to the result in the cache
            cache.put(distance, weights);
        }

        return weights;
    }

    /**
     * Get the regions for this media grid.  The regions
     * define the longitude and latitude bounds for each of the
     * cells.
     * 
     * @return
     */
    public List<Region> getRegions()
    {
        List<Region> regions = new LinkedList<Region>();

        double startLatitude = getLatitude();
        int Nlatitude = getLatitudeCount();
        double deltaLatitude = getLatitudeDelta();
        
        double startLongitude = getLongitude();
        int Nlongitude = getLongitudeCount();
        double deltaLongitude = getLongitudeDelta();
        
        //  Create a 2D array of representative points
        Point.Double[][] representative = new Point.Double[Nlatitude+1][Nlongitude+1];
        for (int i=0; i<Nlatitude+1; i++)
            for (int j=0; j<Nlongitude+1; j++)
                representative[i][j] = new Point.Double(
                		startLatitude  + i*deltaLatitude,
                		startLongitude + j*deltaLongitude);
                
        //  Organize the representative points into regions
        for (int i=0; i<Nlatitude; i++)
            for (int j=0; j<Nlongitude; j++)
            {
                Region region = new Region();

                region.setRepresentative(representative[i][j]);
                
                region.addVertex(representative[i][j]);
                region.addVertex(representative[i+1][j]);
                region.addVertex(representative[i+1][j+1]);
                region.addVertex(representative[i][j+1]);

                regions.add(region);
            }

        return regions;
    }

    /**
     * Compute the cell index for the given geographic location.
     * 
     * @param location
     * @return
     */
    public Point.Integer gridIndex(Point.Double location)
    {
        return new Point.Integer((int) ((location.getLatitude() - getLatitude()) / getLatitudeDelta()),
                (int) ((location.getLongitude() - getLongitude()) / getLongitudeDelta()));
    }

    /**
     * Remove the provided media type from this media grid.
     * 
     * @param mediaType
     */
    public void removeMediaType(TYPE mediaType)
    {
        if (mediaType.getName().equals(REFERENCE))
            return;

        _mediaTypes.remove(mediaType.getName());
        setMediaDirty(true);
    }

    /**
     * Set the initial latitude in degrees
     * 
     * @param latitude the latitude to set
     */
    public void setLatitude(double latitude)
    {
        if (latitude == _latitude)
            return;

        _latitude = latitude;
        _latitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set the number of latitude cells
     * 
     * @param latitudeCount the latitudeCount to set
     */
    public void setLatitudeCount(int latitudeCount)
    {
        if (latitudeCount <= 0 || latitudeCount == _latitudeCount)
            return;

        _latitudeCount = latitudeCount;
        _latitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set the latitude cell spacing in degrees
     * 
     * @param latitudeDelta the latitudeDelta to set
     */
    public void setLatitudeDelta(double latitudeDelta)
    {
        if (latitudeDelta == _latitudeDelta)
            return;

        _latitudeDelta = latitudeDelta;
        _latitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set the initial longitude in degrees
     * 
     * @param longitude the longitude to set
     */
    public void setLongitude(double longitude)
    {
        if (longitude == _longitude)
            return;

        _longitude = longitude;
        _longitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set the number of longitude cells
     * 
     * @param longitudeCount the longitudeCount to set
     */
    public void setLongitudeCount(int longitudeCount)
    {
        if (longitudeCount <= 0 || longitudeCount == _longitudeCount)
            return;

        _longitudeCount = longitudeCount;
        _longitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set the longitude cell spacing in degrees
     * 
     * @param longitudeDelta the longitudeDelta to set
     */
    public void setLongitudeDelta(double longitudeDelta)
    {
        if (longitudeDelta == _longitudeDelta)
            return;

        _longitudeDelta = longitudeDelta;
        _longitudes = null;
        resampleMediaGrid();
    }

    /**
     * Set whether the media is dirty
     * 
     * @param dirty
     */
    abstract public void setMediaDirty(boolean dirty);

    /**
     * Set the media type for a geographic region defined by the mininum and maximum
     * longitude and latitude in degrees.
     * 
     * @param minLongitude
     * @param maxLongitude
     * @param minLatitude
     * @param maxLatitude
     * @param mediaType
     */
    public void setMediaType(double minLongitude, double maxLongitude, double minLatitude, double maxLatitude, TYPE mediaType)
    {
        int lon_start = (int) ((minLongitude - getLongitude()) / getLongitudeDelta());
        int lat_start = (int) ((minLatitude - getLatitude()) / getLatitudeDelta());

        int lon_end = (int) Math.ceil((maxLongitude - getLongitude()) / getLongitudeDelta());
        int lat_end = (int) Math.ceil((maxLatitude - getLatitude()) / getLatitudeDelta());

        for (int lon = lon_start; lon < lon_end; lon++)
            for (int lat = lat_start; lat < lat_end; lat++)
                setMediaType(lon, lat, mediaType);
    }

    /**
     * Set the media type at the provided longitude and latitude in degrees
     * 
     * @param longitude
     * @param latitude
     * @param mediaType
     */
    public void setMediaType(double longitude, double latitude, TYPE mediaType)
    {
        setMediaType(longitude, latitude, mediaType, true);
    }

    /**
     * Set the media type at the provided longitude and latitude cell
     * 
     * @param longitude
     * @param latitude
     * @param mediaType
     */
    public void setMediaType(int longitude, int latitude, TYPE mediaType)
    {
        setMediaType(longitude, latitude, mediaType, true);
    }

    /**
     * Set the media type at the provided location
     * 
     * @param location
     * @param mediaType
     */
    public void setMediaType(Point.Double location, TYPE mediaType)
    {
        setMediaType(location.getLongitude(), location.getLatitude(), mediaType);
    }

    /**
     * Get the array of latitude values that span the extend of the media grid
     * 
     * @return
     */
    public double[] getLatitudes()
    {
        if (_latitudes == null)
        {
            double latitude = getLatitude();
            int N = getLatitudeCount();
            double delta = getLatitudeDelta();

            double[] latitudes = new double[N];
            for (int i = 0; i < N; i++)
                latitudes[i] = latitude + i * delta;
            _latitudes = latitudes;
        }

        return _latitudes;
    }

    /**
     * Get the array of longitude values that span the extend of the media grid
     * 
     * @return
     */
    public double[] getLongitudes()
    {
        if (_longitudes == null)
        {
            double longitude = getLongitude();
            int N = getLongitudeCount();
            double delta = getLongitudeDelta();

            double[] longitudes = new double[N];
            for (int i = 0; i < N; i++)
                longitudes[i] = longitude + i * delta;
            _longitudes = longitudes;
        }

        return _longitudes;
    }

    /**
     * Resample the media grid, taking the values
     * from the prior media grid.
     */
    private void resampleMediaGrid()
    {
        Object[][] oldMediaType = _mediaType;
        _mediaType = new Object[_longitudeCount][_latitudeCount];

        //  Get the dimensions of the old media grid
        int oldLongitudeCount = oldMediaType.length;
        int oldLatitudeCount = 0;
        if (oldLongitudeCount > 0)
            oldLatitudeCount = oldMediaType[0].length;

        double oldLongitudeDelta = 360.0 / oldLongitudeCount;
        double oldLatitudeDelta = 180.0 / oldLatitudeCount;

        double longitudeDelta = 360.0 / _longitudeCount;
        double latitudeDelta = 180.0 / _latitudeCount;

        //  Fill the media type with prior values
        for (int i = 0; i < _longitudeCount; i++)
            for (int j = 0; j < _latitudeCount; j++)
            {
                TYPE type = null;

                int old_i = (int) Math.rint(i * longitudeDelta / oldLongitudeDelta);
                int old_j = (int) Math.rint(j * latitudeDelta / oldLatitudeDelta);

                if (old_i >= 0 && old_i < oldLongitudeCount && old_j >= 0 && old_j < oldLatitudeCount)
                    type = (TYPE) oldMediaType[old_i][old_j];
                else
                    type = getMediaType(REFERENCE);

                _mediaType[i][j] = type;
            }

        //  Clear any cached values
        clearCache();
        setGridDirty(true);
    }

    private void setMediaType(double longitude, double latitude, TYPE mediaType, boolean clear)
    {
        setMediaType((int) ((longitude - getLongitude()) / getLongitudeDelta()), (int) ((latitude - getLatitude()) / getLatitudeDelta()), mediaType, clear);
    }

    private void setMediaType(int longitude, int latitude, TYPE mediaType, boolean clear)
    {
        if (longitude < 0 || longitude >= _longitudeCount || latitude < 0 || latitude >= _latitudeCount)
            return;

        if (mediaType == null)
            mediaType = getMediaType(REFERENCE);

        if (_mediaType[longitude][latitude] == mediaType)
            return;

        _mediaType[longitude][latitude] = mediaType;

        //  Clear any cached values
        if ( clear )
            clearCache();
        setGridDirty(true);
    }

    /**
     * Clear this media grid
     */
    protected void clear()
    {
        //  Retain only the reference media type
        TYPE reference = getMediaType(REFERENCE);
        for (TYPE type : getMediaTypes())
            if (type != reference)
                removeMediaType(type);

        //  Reset the media grid
        _latitude = -90;
        _longitude = -180;
        _latitudeDelta = 5;
        _longitudeDelta = 5;
        _longitudeCount = 72;
        _latitudeCount = 36;
        _mediaType = new Object[_longitudeCount][_latitudeCount];

        clearCache();
    }

    /**
     * Read a grid file
     * 
     * @param gridFile
     */
    protected void readGrid(String gridFile)
    {
    	FileInputStream fis = null;
        Scanner fin = null;
        try
        {
            File file = IOUtility.openFile(gridFile);
            if (!file.exists())
                return;

            fis = new FileInputStream(file);
            fin = new Scanner(fis);

            //  Read the title
            fin.nextLine();

            //  Skip comments
            while (fin.hasNext("#"))
                fin.nextLine();

            setLatitudeCount(fin.nextInt());
            setLongitudeCount(fin.nextInt());
            setLatitude(fin.nextDouble());
            setLongitude(fin.nextDouble());
            setLatitudeDelta(fin.nextDouble());
            setLongitudeDelta(fin.nextDouble());

            int N = getLatitudeCount() * getLongitudeCount();
            for (int i = 0; i < N; i++)
            {
                String label = fin.next().toLowerCase();
                double latitude = fin.nextDouble();
                double longitude = fin.nextDouble();

                setMediaType(longitude, latitude, getMediaType(label), false);
            }

            clearCache();
            setGridDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
        	if ( fis != null )
        		IOUtility.safeClose(fis);
        	if ( fin != null)
        		IOUtility.safeClose(fin);
        }
    }

    /**
     * @param gridDirty the gridDirty to set
     */
    protected void setGridDirty(boolean gridDirty)
    {
        _gridDirty = gridDirty;
    }

    /**
     * Write out a grid file
     * 
     * @param gridFile
     */
    protected void writeGrid(String gridFile)
    {
        PrintWriter fout = null;
        try
        {
            if ( gridFile.isEmpty() )
                return;
            
            File file = IOUtility.openFile(gridFile);

            //  Don't write if not needed
            if (!(getGridDirty() || getMediaDirty()) && file.exists())
                return;

            //  Ensure the path to the file exists
            file.getParentFile().mkdirs();

            // Open the file and write the title
            fout = new PrintWriter(new FileWriter(file));

            //  Write the title
            fout.println(getName());

            //  Print the metadata
            fout.println(String.format("%8d\t%8d", getLatitudeCount(), getLongitudeCount()));
            fout.println(String.format("%13.8f\t%13.8f", getLatitude(), getLongitude()));
            fout.println(String.format("%13.8f\t%13.8f", getLatitudeDelta(), getLongitudeDelta()));

            //  Determine the longest media type
            int width = 10;
            for (TYPE type : getMediaTypes())
                width = Math.max(width, type.toString().length());

            //  Build a format string
            String format = "%-" + width + "s\t%13.8f\t%13.8f";

            //  Print the latitudes and longitude types
            double[] lats = getLatitudes();
            double[] lons = getLongitudes();

            for (int i = 0; i < lats.length; i++)
                for (int j = 0; j < lons.length; j++)
                    fout.println(String.format(format, getMediaType(lons[j], lats[i]), lats[i], lons[j]));

            setGridDirty(false);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (fout != null)
            	IOUtility.safeClose(fout);
        }
    }
}
