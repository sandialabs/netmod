/**
 * 
 */
package gov.sandia.gnem.netmod.path.wind;

import gov.sandia.gnem.netmod.plugin.Plugin;

/**
 * @author bjmerch
 *
 */
public class WindModelPlugin extends Plugin<WindModel>
{
    private static WindModelPlugin _plugin = new WindModelPlugin();
    
    /**
     * Get the plugin framework for Sources
     * 
     * @return
     */
    public static WindModelPlugin getPlugin()
    {
        return _plugin;
    }
}