/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map;

import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;

import javax.swing.*;

/**
 * Map interface that handles all interactions with the Map.
 * All implementation of Map routines are delegated to
 * the appropriate Map plugin.
 * 
 * @author bjmerch
 *
 */
public interface Map extends NetModComponent
{
    /**
     * Add the provided layer to the map
     * 
     * @param layer
     */
    public void addLayer(Layer<?> layer);
    
    /**
     * Check if the map contains the provided layer
     * 
     * @param layer
     * @return
     */
    public boolean contains(Layer<?> layer);
    
    
    /**
     * Add the provided epicenters to the Map.
     * 
     * @param epicenterGrid
     * @return
     */
    public Layer<EpicenterGrid> createEpicenterLayer(EpicenterGrid epicenterGrid);
    
    
    /**
     * Add a grid that represents either the Path or
     * Source media
     * 
     * @return
     */
    public <TYPE extends NetModComponent> Layer<MediaGrid<TYPE>> createMediaGridLayer(MediaGrid<TYPE> labeledGrid);

    /**
     * Create a selection tool for the provided media grid
     * 
     * @param mediaGrid
     * @return
     */
    public <TYPE extends NetModComponent> Action createMediaGridSelectionTool(MediaGrid<TYPE> mediaGrid);
    
    /**
     * Add a layer that represents the output of a simulation run
     * 
     */
    public Layer<Output> createOutputLayer(Output output);
    
    /**
     * Create a selection tool for sources
     * 
     * @param nmc
     * @return
     */
    public Action createSourceSelectionTool(Sources nmc);
    
    /**
     * Create a selection tool for the stations
     * 
     * @return
     */
    public Action createStationSelectionTool(Receivers nmc);
    
    /**
     * Add a layer that represents a wind model
     * 
     */
    public Layer<WindModel> createWindModelLayer(WindModel nmc);

    /**
     * Refresh the map
     */
    public void refresh();

    /**
     * Remove the provided layer from the map
     * 
     * @param layer
     */
    public void remove(Layer<?> layer);

    /**
     * @param receivers
     * @return
     */
    public Layer<Receivers> createStationLayer(Receivers receivers);
}
