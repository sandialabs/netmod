/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import java.util.Arrays;

/**
 * A PDF that represents the sum of
 * multiple independent random variables whose
 * PDFs are provided.
 * 
 * @author bjmerch
 *
 */
class SumPDF extends NonParametricCDF
{
    /**
     * Construct a PDF that represents the sum of two random variables whose
     * PDF's are provided
     * 
     * @param pdf1  PDF of the first random variable
     * @param pdf2  PDF of the second random variable 
     */
    SumPDF(PDF pdf1, PDF pdf2)
    {
        double min1 = pdf1.getMin();
        double max1 = pdf1.getMax();
        double min2 = pdf2.getMin();
        double max2 = pdf2.getMax();
        
        //  Identify a delta in common for both, targeting atleast 1000 data points each
        int N = 1000;
        double delta = Math.min(
                ( max1 - min1 ) / ( N - 1 ),
                ( max2 - min2 ) / ( N - 1 ));

        //  Sample the two PDF's
        NonParametricCDF npPDF1 = new NonParametricCDF(pdf1, delta);
        NonParametricCDF npPDF2 = new NonParametricCDF(pdf2, delta);
            
        //  Number of points in the convolved distribution
        N = Math.max(1, npPDF1._x.length + npPDF2._x.length - 1);
        
        //  Construct the value of x
        double[] x = new double[N];
        double min = min1 - min2 + delta;
        for (int i=0; i<N; i++)
            x[i] = min + i * delta;
        
        //  Construct the CDF by convolving the cdf's
        double[] c = convolve(npPDF1._cdf, npPDF2._cdf);
        
        //  Limit the vectors to some cdf threshold
        double p_start_threshold = 0.001;
        int start = 0;
        for (start=0; start<N; start++)
            if ( c[start] >= p_start_threshold )
                break;

        double p_end_threshold = 0.999;
        int end = N-1;
        for (end = N-1; end>=0; end--)
            if ( c[end] <= p_end_threshold )
                break;
        
        //  Trim the vectors
        _x = Arrays.copyOfRange(x,  start,  end+1);
        _cdf = Arrays.copyOfRange(c,  start,  end+1);
    }

    /**
     * Convolve the two vectors
     * 
     * @param x1
     * @param x2
     * @return
     */
    private double[] convolve(double[] x1, double[] x2)
    {
        int N1 = x1.length;
        int N2 = x2.length;
        
        int N = Math.max(1, N1+N2-1);
        double[] x = new double[N];
        
        for (int i=-N2; i<N1; i++)
        {
            double value = 0;
            
            int start = Math.max(0, i-N2+1);
            int end = Math.min(N1, i+1);
            
            for (int j=start; j<end; j++)
                value += x1[j] * x2[i-j];
            
            x[i+N2] = value;
        }
        
        return x;
    }
}
