/**
 * 
 */
package gov.sandia.gnem.netmod.infra.signal;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.NetSimParameters.ExplosionType;
import gov.sandia.gnem.netmod.io.NetSimParameters.WindMode;
import gov.sandia.gnem.netmod.io.TupleCacheMap;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.path.wind.WindModel;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.signal.TeleseismicBodywave;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract infrasound signal amplitude class that provides a method
 * for calculating wind vectors along the propagation path.
 * 
 * @author bjmerch
 *
 */
abstract public class AbstractInfrasoundSignalAmplitude extends TeleseismicBodywave
{
    /**
     * @param parent
     * @param type
     * @param name
     */
    public AbstractInfrasoundSignalAmplitude(NetModComponent parent, String type, String name)
    {
        super(parent, type, name);
    }

    /**
     * Infrasound simulations do not have a media constant
     * 
     * @return
     */
    @Override
    protected double computeLogMediaConstant(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        double mediaConstant = 0;

        recordIntrospection("Media Constant (log10 Amplitude): ", mediaConstant);
        recordIntrospection("No material correction for Infrasound.");
        
        stopIntrospection();
        
        return mediaConstant;
    }
    
    /**
     * Compute the wind velocity along the great-circle
     * path between the source and the receiver.
     * 
     * @param sources
     * @param paths
     * @param receivers
     * @param epicenter
     * @param station
     * @param magnitude
     * @param phase
     * @param frequency
     * @param time
     * @return
     */
    protected double computeWindVelocity(Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance, Magnitude magnitude, Phase phase,
            Frequency frequency, Time time, double altitude, TupleCacheMap<Point.Double, Point.Double, Complex> cache)
    {
        startIntrospection();

        //  Get the method of averaging wind
        WindModel windModel = null;
        WindMode windMode = WindMode.NONE;
        if ( paths instanceof gov.sandia.gnem.netmod.infra.path.Paths )
        {
            windModel = ((gov.sandia.gnem.netmod.infra.path.Paths) paths).getWindModel();
        	windMode = ((gov.sandia.gnem.netmod.infra.path.Paths) paths).getWindMode(); 
        }
        
        if ( windModel == null || windMode == WindMode.NONE )    
        {
        	this.statusIntrospection(StatusType.ERROR);
            recordIntrospection("Wind Velocity Correction Disabled");
            stopIntrospection();
            
            return 0;            
        }
        
        //  Get the azimuthal distance
        double az = distance.getAzimuth();
        double angle = Math.toRadians(90 - az);
        double dist_deg = distance.getDistance();

        Complex windVector = cache.get(epicenter, station.getLocation());

        if (windVector == null)
        {
            //  Compute the points over which to estimate velocity
            List<Point.Double> locations = new ArrayList<Point.Double>();
            
            if ( windMode == WindMode.SOURCE )
            {
                locations.add(epicenter);
            }
            else if ( windMode == WindMode.STA )
            {
                locations.add(station.getLocation());
            }
            else if ( windMode == WindMode.SOURCE_STA )
            {
                locations.add(epicenter);
                locations.add(station.getLocation());
            }
            else if ( windMode == WindMode.PATH )
            {
                locations.add(epicenter);
                for (double dist = WindModel.SAMPLE_INCREMENT_DEG; dist < dist_deg; dist += WindModel.SAMPLE_INCREMENT_DEG)
                    locations.add(distance.computePoint(dist));
                locations.add(station.getLocation());
            }
            
            //  Compute the velocity vectors at each point

            //  Average across each point
            double North_avg = 0;
            double East_avg = 0;
            int N = locations.size();
            for (int i = 0; i < N; i++)
            {
                startIntrospection();

                Point.Double p = locations.get(i);
                Complex v = windModel.getWindVelocity(time, altitude, p);
                
                North_avg += v.getImaginary();
                East_avg += v.getReal();

                recordIntrospection("Velocity at: ", p);
                recordIntrospection("Wind Velocity (E, N m/s): ", v);
                stopIntrospection();
            }
            
            //  Compute the average wind vector
            if ( N == 0 )
                windVector = new Complex(0, 0);
            else
                windVector = new Complex(East_avg/N, North_avg/N);
            
            cache.put(epicenter, station.getLocation(), windVector);
        }
        
        //  Compute the wind speed along the bearing
        double velocity = windVector.getMagnitude(angle);

        recordIntrospection("Wind Velocity along path (m/s): ", velocity);
        recordIntrospection("Wind Velocity (E, N m/s): ", windVector);
        recordIntrospection("Altitude (km): ", altitude);
        recordIntrospection("Path Sampling (degrees): ", WindModel.SAMPLE_INCREMENT_DEG);
        recordIntrospection("Distance (degrees): ", dist_deg);
        recordIntrospection("Azimuth (degrees): ", az);
        stopIntrospection();
        
        return velocity;
    }
}
