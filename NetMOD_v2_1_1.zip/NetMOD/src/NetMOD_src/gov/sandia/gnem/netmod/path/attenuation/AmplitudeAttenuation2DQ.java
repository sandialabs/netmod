package gov.sandia.gnem.netmod.path.attenuation;

import com.carrotsearch.hppc.ObjectDoubleMap;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.io.AbstractNetModFile;
import gov.sandia.gnem.netmod.io.CacheMap;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.TripleCacheMap;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Frequency;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import gov.sandia.gnem.netmod.numeric.SpectraDouble;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

import static gov.sandia.gnem.netmod.numeric.Distance.computeDistance;

public class AmplitudeAttenuation2DQ extends AbstractNetModFile implements AmplitudeAttenuation
{
	public static final Double NO_RESULT = -99999.0;
	public static final SpectraDouble NO_RESULT_SPECTRA = new SpectraDouble(NO_RESULT);
	private static final String _type = "Amplitude Attenuation 2D Q file";

	// Register Plugin
	static
	{
		AmplitudeAttenuationPlugin.getPlugin().registerComponent(_type, AmplitudeAttenuation2DQ.class);
	}

//    private static String _filename;
	private String _name;
	private double _gamma;
	private double _velocity;
	private int _n_lat;
	private int _n_lon;
	private double _start_lat;
	private double _start_lon;
	private double _delta_lat;
	private double _delta_lon;
	private double[] _latitudes = null;
	private double[] _longitudes = null;
	private int _n_freq;
	private double[] _frequencies = null;
	private double[][][] _q = null; // NLongitude x NLatitude x NFrequencies

	// Cache frequently requested frequencies
	private transient TripleCacheMap<Frequency, Distance, Distance, SpectraDouble> _cache = new TripleCacheMap<Frequency, Distance, Distance, SpectraDouble>(
			null, CacheMap.CACHE_FREQUENCY, CacheMap.CACHE_DISTANCE, CacheMap.CACHE_DISTANCE);
	private transient CacheMap<Distance, ObjectDoubleMap<Point.Double>> _points_cache = new CacheMap<Distance, ObjectDoubleMap<Point.Double>>(
			CacheMap.CACHE_DISTANCE);

	public AmplitudeAttenuation2DQ(NetModComponent parent)
	{
		super(parent, _type);
	}

	@Override
	public void clearCache()
	{
		super.clearCache();
		_latitudes = null;
		_longitudes = null;
		_frequencies = null;
		_q = null;
		_cache.clear();
		_points_cache.clear();
	}

	@Override
	public SpectraDouble getAttenuation(Point.Double start, Point.Double end, Distance distance, Frequency frequency)
	{
		startIntrospection();
		recordIntrospection("Amplitude Attenuation from file: '", getFilename(), "'");
		recordIntrospection("at frequency: ", frequency);
		recordIntrospection("at Start Location: ", start, " , End Location: ", end);

		// calc distance
		Distance distance_start_end = computeDistance(start, end);
		recordIntrospection("segment distance (deg): ", distance_start_end);
		recordIntrospection("total distance (deg): ", distance);

		SpectraDouble a = _cache.get(frequency, distance, distance_start_end);
		if (a != null)
		{
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			stopIntrospection();
			return a;
		}

		/*
		 * Check for no attenuation defined
		 */
		double[] frequencies = getFrequencies();

		if (distance_start_end.getDistance() == 0)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Start and End equal, no amplitude attenuation defined");
			stopIntrospection();

			return a;
		}

		if (getLon() == null || getLat() == null)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Start and End outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return a;
		}

		ObjectDoubleMap<Point.Double> point_distances = _points_cache.get(distance_start_end);
		if (point_distances == null)
		{
			point_distances = distance_start_end.computePoints(getLon(), getLat(), true);
			_points_cache.put(distance_start_end, point_distances);
		}

		/*
		 * Check for no attenuation defined
		 */
		if (frequencies == null || frequencies.length == 0 || start == null || end == null)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("No attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.ERROR);
			stopIntrospection();

			return a;
		}

		// Check point bounds
		if (start.getLatitude() < getLatStart() || start.getLongitude() < getLonStart()
				|| end.getLatitude() > getLatStart() + ((getNLat() - 1) * getDeltaLat())
				|| end.getLongitude() > getLonStart() + (getNLon() * getDeltaLon()))
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Segment outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			stopIntrospection();

			return a;
		}

		// Identify the evaluation frequencies
		double[] f_eval = getEvaluationFrequencies(frequency, _frequencies);
		int N = f_eval.length;

		// Check that the range overlaps the available frequencies
		if (N == 0)
		{
			a = NO_RESULT_SPECTRA;
			recordIntrospection("Frequency outside bounds, no amplitude attenuation defined");
			recordIntrospection("Amplitude Attenuation (log10): ", a);
			statusIntrospection(StatusType.WARNING);
			stopIntrospection();

			return a;
		}

		a = new SpectraDouble(N);
		for (int i = 0; i < N; i++)
		{
			a.setValue(i, f_eval[i], computeAttenuation(point_distances, distance_start_end.getDistance(),
					distance.getDistance(), f_eval[i]));
		}

		// Cache the results for the next call
		_cache.put(frequency, distance, distance_start_end, a);

		recordIntrospection("Amplitude Attenuation (log10): ", a);
		stopIntrospection();

		return a;

	}

	private double computeAttenuation(ObjectDoubleMap<Point.Double> distances, double segment_distance,
			double total_distance, double frequency)
	{

		startIntrospection();

		double gamma = getGamma();
		double total_distance_km = Distance.KM_PER_DEGREE * total_distance;
		double total_distance_m = total_distance_km * 1000;
		double geo_spreading = Math.log10(Math.pow(total_distance_m, -(gamma)));

		recordIntrospection("Geometric Spreading (log10): ", geo_spreading);
		recordIntrospection("gamma: ", gamma);
		recordIntrospection("Total Distance (m): ", total_distance_m);
		stopIntrospection();

		startIntrospection();

		double Qij = qualityFactor(distances, frequency, segment_distance);
		double vK = getVelocity();
		double attn = Math.log10(Math.exp(-(Math.PI * frequency * total_distance_km) / (Qij * vK)));
		double total_attn = geo_spreading + attn;

		recordIntrospection("Q attenuation (log10): ", attn);
		recordIntrospection("Quality Factor: ", Qij);
		recordIntrospection("Velocity (km/s): ", vK);
		recordIntrospection("Total Distance (km): ", total_distance_km);
		stopIntrospection();

		return total_attn;
	}

	private double qualityFactor(ObjectDoubleMap<Point.Double> distances, double frequency, double distance)
	{
		startIntrospection();

		double[][][] q = getQ();
		double[] frequencies = getFrequencies();

		double d_total = 0;
		double Qij_inv = 0;

		Point.Double[] points = Distance.sortPoints(distances);

		// loops through q to get [] at index, then loops through [], if all values are
		// NaN, value is skipped
		// and the distance removed
		for (int i = 1; i < points.length; i++)
		{
			Point.Double p1 = points[i - 1];
			Point.Double p2 = points[i];

			double segment_distance = distances.get(p2) - distances.get(p1);

			Point.Integer p1_index = getPointIndex(p1);
			Point.Integer p2_index = getPointIndex(p2);

			int lon_index = Math.min(p1_index.getLongitudeInt(), p2_index.getLongitudeInt());
			int lat_index = Math.min(p1_index.getLatitudeInt(), p2_index.getLatitudeInt());

			double[] attn = q[lon_index][lat_index];

			// Skip any entries that have NaN values
			for (int j = 0; j < attn.length; j++)
				if (Double.isNaN(attn[j]))
					continue;

			startIntrospection();

			double q_value = Interpolation.interpolateQuadratic(frequencies, attn, frequency);

			recordIntrospection("Q value: " + q_value);
			recordIntrospection("Segment Start Location: ", p1);
			recordIntrospection("Segment End Location: ", p2);
			recordIntrospection("Segment Distance (deg): ", segment_distance);
			recordIntrospection("Frequency: ", frequency);
			recordIntrospection("Interpolating Frequencies: ", frequencies);
			recordIntrospection("Interpolating Q values: ", attn);

			Qij_inv += segment_distance / q_value;
			d_total += segment_distance;

			stopIntrospection();
		}

		double Qij = d_total / Qij_inv;
		recordIntrospection("Quality Factor: ", Qij);
		recordIntrospection("Segment Start: ", points[0]);
		recordIntrospection("Segment End: ", points[points.length - 1]);
		recordIntrospection("Segment distance (deg): ", d_total);
		stopIntrospection();

		return Qij;
	}

	private Point.Integer getPointIndex(Point.Double point)
	{
		double lon = point.getLongitude();
		double lat = point.getLatitude();

		int lon_index = (int) ((lon - getLonStart()) / getDeltaLon());
		int lat_index = (int) ((lat - getLatStart()) / getDeltaLat());

		return new Point.Integer(lat_index, lon_index);
	}

	@Override
	public boolean isAvailable()
	{
		return getFrequencies().length > 0;
	}

	@Override
	public boolean isFor(Object o)
	{
		// Extract a file from the object
		File file = null;
		if (o instanceof File)
			file = (File) o;
		else if (o instanceof String)
			file = IOUtility.openFile((String) o);

		// Check if the file exists
		if (file == null || !file.exists())
			return false;

		// Amplitude Attenuation Text Files end with ".2dq_atn"
		return IOUtility.endsWith(file, ".2dq_atn");
	}

	@Override
	public boolean read()
	{

		boolean value = false;
		synchronized (_type)
		{
			FileInputStream fis = null;
			Scanner fin = null;

			try
			{
				File file = IOUtility.openFile(getFilename());

				fis = new FileInputStream(file);
				fin = new Scanner(fis);

				// in case there is not title
				if (fin.hasNext("#"))
				{
					skipComments(fin);
				}
				else
				{
					setName(fin.nextLine());
				}

				setGamma(Double.parseDouble(fin.nextLine()));

				setVelocity(Double.parseDouble(fin.nextLine()));

				String[] n_coords = skipBlanks(fin).split(" ");
				setNLat(Integer.parseInt(n_coords[0]));
				setNLon(Integer.parseInt(n_coords[1]));

				setLatStart(Double.parseDouble(fin.next()));
				setLonStart(Double.parseDouble(fin.next()));

				setDeltaLat(Double.parseDouble(fin.next()));
				setDeltaLon(Double.parseDouble(fin.next()));

				setNFreq(Integer.parseInt(skipBlanks(fin)));

				double[] frequencies = new double[getNFreq()];
				for (int i = 0; i < getNFreq(); i++)
				{
					frequencies[i] = Double.parseDouble(fin.next());
				}
				setFrequencies(frequencies);

				double[][] grid = new double[getNLon() * getNLat()][getNFreq() + 2];
				String[] first_line = skipBlanks(fin).split(" ");

				grid[0] = Arrays.stream(first_line).mapToDouble(Double::parseDouble).toArray();
				int index = 1;
				while (index < getNLon() * getNLat())
				{
					grid[index] = Arrays.stream(fin.nextLine().split(" ")).mapToDouble(Double::parseDouble).toArray();
					index++;
				}

				double[][][] q = new double[getNLon()][getNLat()][getNFreq()];

				for (int i = 0; i < grid.length; i++)
				{
					double[] grid_i = grid[i];
					Point.Double p = new Point.Double(grid_i[0], grid_i[1]);
					Point.Integer p_index = getPointIndex(p);
					try
					{
						double[] q_f = q[p_index.getLongitudeInt()][p_index.getLatitudeInt()];

						for (int j = 0; j < getNFreq(); j++)
							q_f[j] = grid_i[j + 2];
					}
					catch (Exception e)
					{
						System.out.println("Error on finding point index:");
						System.out.println("Point: " + p);
						System.out.println("Point Index: " + p_index);

					}
				}

				setQ(q);

				value = true;

			}
			catch (Exception e)
			{
				if (!getFilename().isEmpty())
				{
					System.out.println("Unable to read amplitude attenuation file: '" + getFilename() + "'");
					e.printStackTrace();
				}

			}
			finally
			{
				if ( fin != null )
					IOUtility.safeClose(fin);
				if ( fis != null )
					IOUtility.safeClose(fis);
			}

		}

		return value;
	}

	@Override
	public void setFilename(String name)
	{
		super.setFilename(name);

	}

	@Override
	public void setName(String name)
	{
		_name = name;
	}

	public void setGamma(double gamma)
	{
		_gamma = gamma;
	}

	public void setVelocity(double velocity)
	{
		_velocity = velocity;
	}

	public double getVelocity()
	{
		return _velocity;
	}

	public void setNLat(int n_lat)
	{
		_n_lat = n_lat;
	}

	public void setNLon(int n_lon)
	{
		_n_lon = n_lon;
	}

	public double[] getLat()
	{
		if (_latitudes == null)
		{
			int N = getNLat();
			double start = getLatStart();
			double delta = getDeltaLat();

			_latitudes = new double[N];
			for (int i = 0; i < N; i++)
				_latitudes[i] = start + delta * i;
		}

		return _latitudes;
	}

	public double[] getLon()
	{
		if (_longitudes == null)
		{
			int N = getNLon();
			double start = getLonStart();
			double delta = getDeltaLon();

			_longitudes = new double[N];
			for (int i = 0; i < N; i++)
				_longitudes[i] = start + delta * i;
		}

		return _longitudes;
	}

	public void setLatStart(double start_lat)
	{
		_start_lat = start_lat;
	}

	public double getLatStart()
	{
		return _start_lat;
	}

	public double getGamma()
	{
		return _gamma;
	}

	public void setLonStart(double start_lon)
	{
		_start_lon = start_lon;
	}

	public double getLonStart()
	{
		return _start_lon;
	}

	public void setDeltaLat(double delta_lat)
	{
		_delta_lat = delta_lat;
	}

	public double getDeltaLat()
	{
		return _delta_lat;
	}

	public void setDeltaLon(double delta_lon)
	{
		_delta_lon = delta_lon;
	}

	public double getDeltaLon()
	{
		return _delta_lon;
	}

	public void setNFreq(int n_freq)
	{
		_n_freq = n_freq;
	}

	public int getNFreq()
	{
		return _n_freq;
	}

	public int getNLon()
	{
		return _n_lon;
	}

	public int getNLat()
	{
		return _n_lat;
	}

	public void setFrequencies(double[] frequencies)
	{
		_frequencies = frequencies;
	}

	@Override
	public double[] getFrequencies()
	{
		if (_frequencies == null)
		{
			read();
		}
		return _frequencies;
	}

	public double[][][] getQ()
	{
		return _q;
	}

	public void setQ(double[][][] q)
	{
		_q = q;
	}

	@Override
	public AmplitudeAttenuation2DQViewer getViewer()
	{
		return new AmplitudeAttenuation2DQViewer(this);
	}

	public int findClosestIndex(Point.Double point, Point.Double[] LatLon)
	{

		double distanceLat = Math.abs(point.getLatitude() - LatLon[0].getLatitude());
		double distanceLon = Math.abs(point.getLongitude() - LatLon[0].getLongitude());

		int idx = 0;
		for (int c = 1; c < LatLon.length; c++)
		{
			double cdistanceLat = Math.abs(point.getLatitude() - LatLon[c].getLatitude());
			double cdistanceLon = Math.abs(point.getLongitude() - LatLon[c].getLongitude());

			if (cdistanceLat <= distanceLat && cdistanceLon <= distanceLon)
			{
				idx = c;
				distanceLat = cdistanceLat;
				distanceLon = cdistanceLon;
			}
		}
		return idx;
	}

	/**
	 * Remove all attenuations for the provided frequency
	 *
	 * @param frequency
	 */
	public void removeAttenuationFrequency(double frequency)
	{
		// Find the index of the existing frequency
		int index = Arrays.binarySearch(getFrequencies(), frequency);
		if (index < 0)
			return;

		// Create copies of the arrays, excluding the index
		_frequencies = removeIndex(_frequencies, index);
		for (int i = 0; i < _q.length; i++)
			_q[i] = removeIndex(_q[i], index);

		_cache.clear();

		setDirty(true);
	}

	@Override
	public boolean write()
	{
		// Get the File to write to
		File file = IOUtility.openFile(getFilename());

		// Don't write if not needed
		if (!getDirty() && file.exists())
			return true;

		// Test whether there is no file to write to
		if (isEmpty(file.getPath()))
			return true;

		PrintWriter fout = null;
		try
		{
			double[] frequencies = getFrequencies();

			// Ensure the path to the file exists
			file.getParentFile().mkdirs();

			// Open the file and write the title
			fout = new PrintWriter(new FileWriter(file));
			fout.println(getName());

			// Gamma
			fout.println(getGamma());

			// Velocity (km/s)
			fout.println(getVelocity());
			fout.println();

			// NLat and NLon
			fout.print(getNLat());
			fout.print(" ");
			fout.println(getNLon());

			// Lat/Lon Start
			fout.print(getLatStart());
			fout.print(" ");
			fout.println(getLonStart());

			// Lat/Lon Delta
			fout.print(getDeltaLat());
			fout.print(" ");
			fout.println(getDeltaLon());
			fout.println();

			// NFreq
			int nfreq = getNFreq();
			fout.println(nfreq);

			// Frequencies
			GUIUtility.printArray(getFrequencies(), fout, "\t%10.3f");
			fout.println();
			fout.println();

			// Coordinates
			double[] lats = getLat();
			double[] lons = getLon();
			for (int i = 0; i < lats.length; i++)
				for (int j = 0; j < lons.length; j++)
				{
					fout.print(lats[i]);
					fout.print(" ");
					fout.print(lons[j]);

					double[] values = _q[i][j];
					GUIUtility.printArray(values, fout, "\t%10.3f", nfreq);
					fout.println();
				}

			setDirty(false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		finally
		{
			if ( fout != null )
				IOUtility.safeClose(fout);
		}

		return true;
	}

}
