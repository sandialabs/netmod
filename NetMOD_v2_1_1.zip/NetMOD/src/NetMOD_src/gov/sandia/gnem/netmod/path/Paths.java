/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.ParTable;
import gov.sandia.gnem.netmod.path.media.PathMedia;
import gov.sandia.gnem.netmod.path.media.PathMediaPhaseParameter;
import gov.sandia.gnem.netmod.path.media.PathMediaPlugin;
import gov.sandia.gnem.netmod.path.media.PathMediaType;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.simulation.DetectionPhase;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Hierarchical container for organizing the path components
 * within a simulation.
 * 
 * @author bjmerch
 *
 */
public class Paths extends AbstractNetModComponent
{
    private PhaseParameters<PathPhaseParameter> _phaseParameters;
    private PathMedia _pathMedia;

    private String _pathGridFile = "";
    private String _pathMediaFile = "";

    public Paths(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent);
        
        setName("Paths");
        
        //  Initialize the set of phases
        _phaseParameters = new PhaseParameters<PathPhaseParameter>(this);
        for (Phase phase : phases)
            _phaseParameters.addParameter(new PathPhaseParameter(_phaseParameters, phases, phase));
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof PathPhaseParameter) || (component instanceof PathMedia);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getPhaseParameters());
        children.add(getPathMedia());

        return children;
    }

    /**
     * @return the pathGridFile
     */
    public String getPathGridFile()
    {
        return _pathGridFile;
    }

    /**
     * Get the Path Media
     * 
     * @return
     */
    public PathMedia getPathMedia()
    {
        if (_pathMedia == null)
        {
            _pathMedia = PathMediaPlugin.getPlugin().getComponentFor(this, getPathMediaFile());
            
			if (_pathMedia != null)
			{
				_pathMedia.setPhases(getPhaseParameters().getPhases());
				_pathMedia.setPathMediaFile(getPathMediaFile());
				_pathMedia.setPathGridFile(getPathGridFile());
			}
        }

        return _pathMedia;
    }

    /**
     * @return the pathMediaFile
     */
    public String getPathMediaFile()
    {
        return _pathMediaFile;
    }

    /**
     * @return
     */
    public PhaseParameters<PathPhaseParameter> getPhaseParameters()
    {
        return _phaseParameters;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return new PathsViewer(this);
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
        super.load(parameters);
        
        //  Load the phase parameters
        PhaseParameters<PathPhaseParameter> pp = getPhaseParameters();

        ParTable phaseSpecTable = parameters.get(NetSimParameters.phaseSpec);
        for (String row : phaseSpecTable.getRowNames())
        {
            PathPhaseParameter p = pp.getPhaseParameter(DetectionPhase.valueOfIgnoreCase(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_PHASE)));

            if (p != null)
            {
                p.setTimeWindowLength(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_TIME_W, 0));
                p.setLowGroupVelocity(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_GVEL1, 0));
                p.setHighGroupVelocity(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_GVEL2, 0));

                //  Set the previous phase, if specified
                String prevPhase = phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_PREV_PHASE);
                if (prevPhase != null)
                    p.setPriorPhase(DetectionPhase.valueOfIgnoreCase(prevPhase));

                //  Set the coda decay noise file, if specified
                File file = IOUtility.openFile(IOUtility.fixPathSeparator(phaseSpecTable.getTableValue(row, NetSimParameters.PHASESPEC_NF_FILE)));
                p.setCodaDecayFile(file.getCanonicalPath());
            }
        }

        //  Construct the path media, media file followed by grid file
        setPathMediaFile(IOUtility.openFile(IOUtility.fixPathSeparator(parameters.get(NetSimParameters.pathMediaDescFile))).getCanonicalPath());
        setPathGridFile(IOUtility.openFile(IOUtility.fixPathSeparator(parameters.get(NetSimParameters.pathGridFile))).getCanonicalPath());
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        //  Load the phase parameters
        PhaseParameters<PathPhaseParameter> pp = getPhaseParameters();

        ParTable phaseSpecTable = parameters.get(NetSimParameters.phaseSpec);
        for (Phase phase : pp.getPhases())
        {
            PathPhaseParameter p = pp.getPhaseParameter(phase);
            String row = phase.toString();

            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_PHASE, row);
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_TIME_W, Double.toString(p.getTimeWindowLength()));
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_GVEL1, Double.toString(p.getLowGroupVelocity()));
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_GVEL2, Double.toString(p.getHighGroupVelocity()));
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_PREV_PHASE, (p.getPriorPhase() == null ? "-" : p.getPriorPhase().toString()));

            String filename = p.getCodaDecayFile();
            if (files)
            {
                if (reset && filename != null && filename.trim().length() != 0)
                {
                    //  Ensure the existing file is read in
                    p.getCodaDecay().read();

                    File codaParent = IOUtility.openFile(parameters.getNS_CONFIG(), "codadecay");
                    filename = IOUtility.openFile(codaParent, IOUtility.openFile(p.getCodaDecayFile()).getName()).getPath();
                    p.setCodaDecayFile(IOUtility.fixPathSeparator(filename));
                }

                p.getCodaDecay().write();
            }
            phaseSpecTable.setTableValue(row, NetSimParameters.PHASESPEC_NF_FILE, IOUtility.fixPathSeparator(filename));
        }

        if (files)
        {
            if (reset)
            {
                File pathParent = IOUtility.openFile(parameters.getNS_CONFIG(), NetSimParameters.ParameterFolder.PATH.getFolder());

                for (PathMediaType pmt : getPathMedia().getMediaTypes())
                {
                    for (PathMediaPhaseParameter p : pmt.getPhaseParameters().getParameters())
                    {
                        //  Ensure the existing file is read in
                        p.getAmplitudeAttenuation().getFrequencies();

                        String filename = IOUtility.openFile(p.getAmplitudeAttenuationFile()).getName();

                        if (filename == null || !IOUtility.openFile(p.getAmplitudeAttenuationFile()).exists())
                            p.setAmplitudeAttenuationFile("");
                        else
                            p.setAmplitudeAttenuationFile(IOUtility.fixPathSeparator(IOUtility.openFile(pathParent, filename).getPath()));
                    }
                }

                //  Define destination path grid and media files
                String pathGridFilename = IOUtility.openFile(getPathGridFile()).getName();
                if ( pathGridFilename == null || pathGridFilename.isEmpty())
                    pathGridFilename = "path_grid.pgr";
                File pathGridFile = IOUtility.openFile(pathParent, pathGridFilename);
                
                String pathMediaFilename = IOUtility.openFile(getPathMediaFile()).getName();
                if ( pathMediaFilename == null || pathMediaFilename.isEmpty())
                    pathMediaFilename = "path_media.pmd";
                File pathMediaFile = IOUtility.openFile(pathParent, pathMediaFilename);

                //  Delete any existing to force write
                pathGridFile.delete();
                pathMediaFile.delete();

                setPathGridFile(IOUtility.fixPathSeparator(pathGridFile.getPath()));
                setPathMediaFile(IOUtility.fixPathSeparator(pathMediaFile.getPath()));
            }

            getPathMedia().write();
        }

        //  Store the path media and grid files
        parameters.set(NetSimParameters.pathMediaDescFile, IOUtility.fixPathSeparator(getPathMediaFile()));
        parameters.set(NetSimParameters.pathGridFile, IOUtility.fixPathSeparator(getPathGridFile()));
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof PhaseParameters)
                _phaseParameters = (PhaseParameters<PathPhaseParameter>) child;
            else if (child instanceof PathMedia)
                _pathMedia = (PathMedia) child;
        }

        clearCache();
    }

    /**
     * @param pathGridFile the pathGridFile to set
     */
    public void setPathGridFile(String pathGridFile)
    {
        if (_pathGridFile.equals(pathGridFile))
            return;

        //  If file exists, load it
        if (IOUtility.openFile(pathGridFile).exists())
        {
            _pathGridFile = pathGridFile;
            setPathMedia(null);
        }
        //  Otherwise, save to it
        else
        {
            PathMedia pathMedia = getPathMedia();
            pathMedia.setPathGridFile(pathGridFile);
            _pathGridFile = pathMedia.getPathGridFile();
        }
    }

    public void setPathMedia(PathMedia pathMedia)
    {
        if (pathMedia != null)
        {
            _pathGridFile = pathMedia.getPathGridFile();
            _pathMediaFile = pathMedia.getPathMediaFile();
        }

        _pathMedia = pathMedia;

        clearCache();
    }

    /**
     * @param pathMediaFile the pathMediaFile to set
     */
    public void setPathMediaFile(String pathMediaFile)
    {
        if (_pathMediaFile.equals(pathMediaFile))
            return;

        //  If file exists, load it
        if (IOUtility.openFile(pathMediaFile).exists())
        {
            _pathMediaFile = pathMediaFile;
            setPathMedia(null);
        }
        //  Otherwise, save to it
        else
        {
            PathMedia pathMedia = getPathMedia();
            pathMedia.setPathMediaFile(pathMediaFile);
            _pathMediaFile = pathMedia.getPathMediaFile();
        }
    }
}
