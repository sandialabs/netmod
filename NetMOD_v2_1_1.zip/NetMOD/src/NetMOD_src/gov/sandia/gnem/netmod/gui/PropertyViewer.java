/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.map.MapPlugin;
import gov.sandia.gnem.netmod.map.ShadingType;
import gov.sandia.gnem.netmod.simulation.SimulationOutputPlugin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * A viewer for editing GUI-related properties.
 * @author avencar
 *
 */
@SuppressWarnings("serial")
public class PropertyViewer extends JFrame
{
    private JTabbedPane _tabbedPane = new JTabbedPane();

    private JPanel _mainPropertiesPanel = new JPanel();
    private JPanel _chartViewerPropertiesPanel = new JPanel();
    private JPanel _mediaGridPropertiesPanel = new JPanel();
    private JPanel _mapPropertiesPanel = new JPanel();
    private JPanel _algorithmsPropertiesPanel = new JPanel();
    
    private ColorPaletteListener _colorPaletteListener = new ColorPaletteListener();

    private JTextField _outputName = new JTextField("");
    private JComboBox _outputFormat = new JComboBox(SimulationOutputPlugin.getPlugin().getTypesArray());
    private FileField _defaultDirectory = new FileField("Select default directory", JFileChooser.DIRECTORIES_ONLY);
    private JFormattedTextField _fontSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JComboBox _iconSize = new JComboBox(new String[]{ "small", "medium", "large"});
    private JColorButton _backgroundColor = new JColorButton(35,20);
    private JFormattedTextField _dividerLocation = new JFormattedTextField(new DoubleRangeFormatter(0, 1));
    private JFormattedTextField _numberThreads = new JFormattedTextField(new IntegerRangeFormatter(0, Integer.MAX_VALUE));

    private JFormattedTextField _chartViewerHeight = new JFormattedTextField(new IntegerRangeFormatter(1, Integer.MAX_VALUE));
    private JFormattedTextField _chartViewerWidth = new JFormattedTextField(new IntegerRangeFormatter(1, Integer.MAX_VALUE));
    private JFormattedTextField _chartViewerLineWidth = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _chartViewerGridlineWidth = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JFormattedTextField _chartViewerLabelFontSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    private JComboBox _chartViewerAntiAlias = new JComboBox(new Boolean[] { true, false });
    private JColorButton _chartViewerBackgroundColor = new JColorButton(35,20);
    private JColorButton _chartViewerGridlineColor = new JColorButton(35,20);
    private JFormattedTextField _chartViewerLineColorPaletteCount = new JFormattedTextField(new IntegerRangeFormatter(0, Integer.MAX_VALUE));
    private List<JColorButton> _chartViewerLineColorPalette = new ArrayList<JColorButton>();
    
    JFormattedTextField _mediaGridColorPaletteCount = new JFormattedTextField(new IntegerRangeFormatter(0, Integer.MAX_VALUE));
    List<JColorButton> _mediaGridColorPalette = new ArrayList<JColorButton>();

    private JComboBox _mapType = new JComboBox(MapPlugin.getPlugin().getTypes().toArray());
    private JComboBox _mapWeight = new JComboBox(new String[]{ "light", "heavy" });
    private JColorButton _mapBackgroundColor = new JColorButton(35,20);
    private FileField _mapTopo = new FileField("Select map topography", JFileChooser.FILES_ONLY);
    private FileField _mapBoundaries = new FileField("Select map political boundaries", JFileChooser.FILES_ONLY);
    private JComboBox _mapBoundariesLine = new JComboBox(new Boolean[] { true, false });
    private JFormattedTextField _mapBoundariesLineWidth = new JFormattedTextField(new DoubleRangeFormatter(1, Double.MAX_VALUE));
    private JColorButton _mapBoundariesLineColor = new JColorButton(35,20);
    private JComboBox _mapBoundariesFill = new JComboBox(new Boolean[] { true, false });
    private JColorButton _mapBoundariesFillLandColor = new JColorButton(35,20);
    private JColorButton _mapBoundariesFillWaterColor = new JColorButton(35,20);
    
    private JComboBox _outputShadingType = new JComboBox(ShadingType.values());
    private JColorButton _outputContourColor = new JColorButton(35,20);
    private JFormattedTextField _outputContourWidth = new JFormattedTextField(new DoubleRangeFormatter(1, Double.MAX_VALUE));
    
    private JColorButton _mapSourceColor = new JColorButton(35,20);
    private JFormattedTextField _mapSourcePointSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    
    private JColorButton _mapStationEnabledColor = new JColorButton(35,20);
    private JFormattedTextField _mapStationEnabledPointSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));    
    private JColorButton _mapStationEnabledLabelColor = new JColorButton(35,20);
    private JFormattedTextField _mapStationEnabledFontSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    
    private JColorButton _mapStationDisabledColor = new JColorButton(35,20);
    private JFormattedTextField _mapStationDisabledPointSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));    
    private JColorButton _mapStationDisabledLabelColor = new JColorButton(35,20);
    private JFormattedTextField _mapStationDisabledFontSize = new JFormattedTextField(new DoubleRangeFormatter(0, Double.MAX_VALUE));
    
    private JComboBox _netsim_path_sd = new JComboBox(new Boolean[] { true, false });
    private JComboBox _netsim_c_interp = new JComboBox(new Boolean[] { true, false });
    private JComboBox _netsim_noise_sd_db = new JComboBox(new Boolean[] { true, false });

    public PropertyViewer()
    {
        setTitle("Properties Editor");

        _mainPropertiesPanel.setLayout(new GridBagLayout());
        _mainPropertiesPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
        _chartViewerPropertiesPanel.setLayout(new GridBagLayout());
        _chartViewerPropertiesPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
        _mediaGridPropertiesPanel.setLayout(new GridBagLayout());
        _mediaGridPropertiesPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
        _mapPropertiesPanel.setLayout(new BoxLayout(_mapPropertiesPanel,BoxLayout.Y_AXIS));
        _mapPropertiesPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
        _algorithmsPropertiesPanel.setLayout(new GridBagLayout());
        _algorithmsPropertiesPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));

        setupPanels(true);

        _chartViewerLineColorPaletteCount.addActionListener(_colorPaletteListener);
        _mediaGridColorPaletteCount.addActionListener(_colorPaletteListener);

        _tabbedPane.add(new JScrollPane(_mainPropertiesPanel), "General");
        _tabbedPane.add(new JScrollPane(_chartViewerPropertiesPanel), "Chart Viewer");
        _tabbedPane.add(new JScrollPane(_mediaGridPropertiesPanel), "Media Grid");
        _tabbedPane.add(new JScrollPane(_mapPropertiesPanel), "Map");
        _tabbedPane.add(new JScrollPane(_algorithmsPropertiesPanel), "Algorithms");

        // Add the Close button to the bottom
        JPanel buttonPanel = GUIUtility.createButtonPanel(new AbstractAction("Apply")
        {
            {
                putValue(SHORT_DESCRIPTION, "Apply Configuration Settings");
            };
            
            public void actionPerformed(ActionEvent arg0)
            {
                apply();
            }
        }, new AbstractAction("Save As")
        {
            {
                putValue(SHORT_DESCRIPTION, "Save Configuration Settings to an external file");
            };
            
            public void actionPerformed(ActionEvent arg0)
            {
                //  Locate a file to save as
                File file = GUIUtility.showSaveDialog(null, "", "Save Configuration File", JFileChooser.FILES_ONLY, null, null);
                if ( file == null )
                    return;
                
                //  Commit any changes in the viewer
                apply();

                //  Save the properties to the file
                Property.saveProperties(file);
            }
        }, new AbstractAction("Load")
        {
            {
                putValue(SHORT_DESCRIPTION, "Load Configuration Settings from an external file");
            };
            
            public void actionPerformed(ActionEvent arg0)
            {
                //  Locate the file to open
                File[] files = GUIUtility.showOpenDialog(null,  "",  "Load Configuration File",  JFileChooser.FILES_ONLY, false, null, null);
                if ( files == null || files.length == 0 )
                    return;
                File file = files[0];
                
                //  Load the file
                Property.loadProperties(file);
                
                //  Update the viewer
                PropertyViewer.this.dispose();
                new PropertyViewer();
            }
        }, new AbstractAction("Close")
        {
            {
                putValue(SHORT_DESCRIPTION, "Close the dialog");
            };
            
            public void actionPerformed(ActionEvent arg0)
            {
                PropertyViewer.this.dispose();
            }
        });

        Container contentPane = this.getContentPane();
        contentPane.add(_tabbedPane, BorderLayout.CENTER);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Class to refresh all panels in the viewer, after an update.
     * @author avencar
     */
    private class ColorPaletteListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0)
        {
            setupPanels(false);
            SwingUtilities.updateComponentTreeUI(_mainPropertiesPanel);
            SwingUtilities.updateComponentTreeUI(_chartViewerPropertiesPanel);
            SwingUtilities.updateComponentTreeUI(_mediaGridPropertiesPanel);
        }
    }

    /**
     * Layout the components on the panels.
     * @param load - whether or not to load the initial parameter values
     */
    private void setupPanels(boolean load)
    {
    	_outputName.setToolTipText("<html>Default output filename.<br>Output names may contain multiple parameter fields expressed as ${PAR_FIELD}</html>");
    	_outputFormat.setToolTipText("<html>Commandline output format</html>");
        _dividerLocation.setToolTipText("Divider location as a fraction of window width");
        _numberThreads.setToolTipText("<html>Number of threads to use in simulations.<br>Values less than 1 will use all available processors</html>");
        _chartViewerHeight.setToolTipText("Height of chart in pixels");
        _chartViewerWidth.setToolTipText("Width of chart in pixels");
        _chartViewerLineWidth.setToolTipText("Width of lines in points");
        _chartViewerGridlineWidth.setToolTipText("Width of gridlines in points");
        _chartViewerLabelFontSize.setToolTipText("Label font size");
        _chartViewerAntiAlias.setToolTipText("Enable anti-alias line smoothing");
        _chartViewerBackgroundColor.setToolTipText("Set color of chart background");
        _chartViewerGridlineColor.setToolTipText("Set color of chart grid lines");
        _chartViewerLineColorPaletteCount.setToolTipText("Set the number of line colors in the palette");
        _mediaGridColorPaletteCount.setToolTipText("Set the number of media colors in the palette");
        
        _mapType.setToolTipText("Set the map component");
        _mapBackgroundColor.setToolTipText("Set color of map background");
        _mapWeight.setToolTipText("Set the panel to light (Java compatible) or heavy (System native)");
        _mapTopo.setToolTipText("Location of topography image file");
        _mapBoundaries.setToolTipText("Location of political boundaries shapefile");
        _mapBoundariesLine.setToolTipText("Set whether to display boundary lines");
        _mapBoundariesLineWidth.setToolTipText("Width of boundary lines in pixels");
        _mapBoundariesLineColor.setToolTipText("Set color of boundary lines");
        _mapBoundariesFill.setToolTipText("Set whether to fill the boundaries");
        _mapBoundariesFillLandColor.setToolTipText("Set color of land fill");
        _mapBoundariesFillWaterColor.setToolTipText("Set color of water fill");
        _mapSourceColor.setToolTipText("Set color of sources");
        _mapSourcePointSize.setToolTipText("Set the size of sources in points");
        _mapStationEnabledColor.setToolTipText("Set color of enabled stations");
        _mapStationEnabledPointSize.setToolTipText("Set the size of enabled stations in points");
        _mapStationEnabledLabelColor.setToolTipText("Set color of the enabled station labels");
        _mapStationEnabledFontSize.setToolTipText("Set font size of the enabled station labels");
        _mapStationDisabledColor.setToolTipText("Set color of disabled stations");
        _mapStationDisabledPointSize.setToolTipText("Set the size of disabled stations in points");
        _mapStationDisabledLabelColor.setToolTipText("Set color of the disabled station labels");
        _mapStationDisabledFontSize.setToolTipText("Set font size of the disabled station labels");
        
        _outputShadingType.setToolTipText("<html>Set the interpolation method of the output surface to<br>flat (nearest neighbor) or bilinear</html>");

        _netsim_path_sd.setToolTipText("<html>Enable NetSim method of obtaining teleseismic path attenuation<br>standard deviation from the station location.</html>");
        _netsim_c_interp.setToolTipText("<html>Enable NetSim v2.4.1 method, implemented in C, of interpolating<br>the site noise, response, and coda decay curves.</html>");
        _netsim_noise_sd_db.setToolTipText("<html>Enable NetSim bug of handling the standard deviation in the site noise file as dB instead of log10");

        // *** Setup main properties panel ***
        _mainPropertiesPanel.removeAll();

        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Output Name: "), _outputName);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Output Format: "), _outputFormat);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Default Directory: "), _defaultDirectory);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Font Size *: "), _fontSize);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Icon Size *: "), _iconSize);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Background Color *: "), _backgroundColor);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Divider Location: "), _dividerLocation);
        GUIUtility.addRow(_mainPropertiesPanel, new JLabel("Number of Threads: "), _numberThreads);
        GUIUtility.addRow(_mainPropertiesPanel, GridBagConstraints.REMAINDER, new JLabel("* Application must be restarted for changes to take effect"));

        // *** Setup Chart viewer properties panel ***
        _chartViewerPropertiesPanel.removeAll();
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Chart Height: "), _chartViewerHeight);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Chart Width: "), _chartViewerWidth);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Line Width: "), _chartViewerLineWidth);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Gridline Width: "), _chartViewerGridlineWidth);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Label Font Size: "), _chartViewerLabelFontSize);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Line Smoothing: "), _chartViewerAntiAlias);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Background Color: "), _chartViewerBackgroundColor);
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Gridline Color: "), _chartViewerGridlineColor);

        // Add line color palette components
        GUIUtility.addRow(_chartViewerPropertiesPanel, new JLabel("Line Colors: "), _chartViewerLineColorPaletteCount);
        addPalette(_chartViewerPropertiesPanel, _chartViewerLineColorPaletteCount, _chartViewerLineColorPalette,
                Property.CHART_VIEWER_LINE_COLOR_PALETTE);
        GUIUtility.addRow(_chartViewerPropertiesPanel, GridBagConstraints.REMAINDER, new JLabel(" "));
        
        //  Setup Media Grid properties panel
        _mediaGridPropertiesPanel.removeAll();
        GUIUtility.addRow(_mediaGridPropertiesPanel, new JLabel("Media Colors: "), _mediaGridColorPaletteCount);
        addPalette(_mediaGridPropertiesPanel, _mediaGridColorPaletteCount, _mediaGridColorPalette,
                Property.MEDIA_GRID_COLOR_PALETTE);
        GUIUtility.addRow(_mediaGridPropertiesPanel, GridBagConstraints.REMAINDER, new JLabel(" "));
        
        //  Setup Map properties panel
        JPanel mapPanel = new JPanel(new GridBagLayout());
        GUIUtility.addRow(mapPanel, new JLabel("Map Component: "), _mapType);
        GUIUtility.addRow(mapPanel, new JLabel("Background Color: "), _mapBackgroundColor);
        GUIUtility.addRow(mapPanel, new JLabel("Panel Type: "), _mapWeight);
        GUIUtility.addRow(mapPanel, new JLabel("Topography: "), _mapTopo);

        JPanel mapBoundariesPanel = new JPanel(new GridBagLayout());
        mapBoundariesPanel.setBorder(BorderFactory.createTitledBorder("Boundaries"));
        
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Shapefile: "), _mapBoundaries);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Line Enabled: "), _mapBoundariesLine);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Line Width: "), _mapBoundariesLineWidth);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Line Color: "), _mapBoundariesLineColor);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Fill Enabled: "), _mapBoundariesFill);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Land Color: "), _mapBoundariesFillLandColor);
        GUIUtility.addRow(mapBoundariesPanel, new JLabel("Water Color: "), _mapBoundariesFillWaterColor);

        JPanel mapSourcePanel = new JPanel(new GridBagLayout());
        mapSourcePanel.setBorder(BorderFactory.createTitledBorder("Sources"));
        GUIUtility.addRow(mapSourcePanel, new JLabel("Color: "), _mapSourceColor);
        GUIUtility.addRow(mapSourcePanel, new JLabel("Point Size: "), _mapSourcePointSize);
        
        JPanel mapStationPanel = new JPanel(new GridBagLayout());
        mapStationPanel.setBorder(BorderFactory.createTitledBorder("Stations"));
        
        GUIUtility.addRow(mapStationPanel, new JLabel(" "), new JLabel("Enabled"), new JLabel("Disabled"));
        GUIUtility.addRow(mapStationPanel, new JLabel("Color: "), _mapStationEnabledColor, _mapStationDisabledColor);
        GUIUtility.addRow(mapStationPanel, new JLabel("Point Size: "), _mapStationEnabledPointSize, _mapStationDisabledPointSize);
        GUIUtility.addRow(mapStationPanel, new JLabel("Label Color: "), _mapStationEnabledLabelColor, _mapStationDisabledLabelColor);
        GUIUtility.addRow(mapStationPanel, new JLabel("Font Size: "), _mapStationEnabledFontSize, _mapStationDisabledFontSize);

        JPanel mapOutputPanel = new JPanel(new GridBagLayout());
        mapOutputPanel.setBorder(BorderFactory.createTitledBorder("Outputs"));
        
        GUIUtility.addRow(mapOutputPanel, new JLabel("Shading: "), _outputShadingType);
        GUIUtility.addRow(mapOutputPanel, new JLabel("Contour Color: "), _outputContourColor);
        GUIUtility.addRow(mapOutputPanel, new JLabel("Contour Width: "), _outputContourWidth);

        _mapPropertiesPanel.removeAll();
        
        _mapPropertiesPanel.add(mapPanel);
        _mapPropertiesPanel.add(mapBoundariesPanel);
        _mapPropertiesPanel.add(mapSourcePanel);
        _mapPropertiesPanel.add(mapStationPanel);
        _mapPropertiesPanel.add(mapOutputPanel);
        
        //  Setup the algorithms properties panel
        _algorithmsPropertiesPanel.removeAll();
        GUIUtility.addRow(_algorithmsPropertiesPanel, new JLabel("NetSim Path SD: "), _netsim_path_sd);
        GUIUtility.addRow(_algorithmsPropertiesPanel, new JLabel("NetSim C Interpolate: "), _netsim_c_interp);
        GUIUtility.addRow(_algorithmsPropertiesPanel, new JLabel("NetSim Noise SD: "), _netsim_noise_sd_db);
        GUIUtility.addRow(_algorithmsPropertiesPanel, GridBagConstraints.REMAINDER, new JLabel(" "));

        // *** Load values from properties, if requested ***
        if (load)
        {
        	_outputName.setText(Property.OUTPUT_NAME.getValue());
        	_outputFormat.setSelectedItem(Property.OUTPUT_FORMAT.getValue());
            _defaultDirectory.setText(Property.FILE_CHOOSER_DIRECTORY.getValue());
            _fontSize.setText(Property.FONT_SIZE.getValue());
            _iconSize.setSelectedItem(Property.ICON_SIZE.getValue());
            _backgroundColor.setColor(Property.BACKGROUND_COLOR.getColorValue());
            _dividerLocation.setText(Property.DIVIDER_LOCATION.getValue());
            _numberThreads.setText(Property.NUMBER_THREADS.getValue());

            _chartViewerHeight.setText(Property.CHART_VIEWER_HEIGHT.getValue());
            _chartViewerWidth.setText(Property.CHART_VIEWER_WIDTH.getValue());
            _chartViewerLineWidth.setText(Property.CHART_VIEWER_LINE_WIDTH.getValue());
            _chartViewerGridlineWidth.setText(Property.CHART_VIEWER_GRIDLINE_WIDTH.getValue());
            _chartViewerLabelFontSize.setText(Property.CHART_VIEWER_LABEL_FONT_SIZE.getValue());
            _chartViewerAntiAlias.setSelectedItem(Property.CHART_VIEWER_ANTI_ALIASING.getBooleanValue());
            _chartViewerBackgroundColor.setColor(Property.CHART_VIEWER_BACKGROUND_COLOR.getColorValue());
            _chartViewerGridlineColor.setColor(Property.CHART_VIEWER_GRIDLINE_COLOR.getColorValue());

            _chartViewerLineColorPaletteCount.setText(Integer.toString(Property.CHART_VIEWER_LINE_COLOR_PALETTE.getNumberOfColors()));
            int i = 0;
            for (Color c : Property.CHART_VIEWER_LINE_COLOR_PALETTE.getColorPaletteValue())
            {
                _chartViewerLineColorPalette.get(i).setColor(c);
                i++;
            }

            _mediaGridColorPaletteCount.setText(Integer.toString(Property.MEDIA_GRID_COLOR_PALETTE.getNumberOfColors()));
            i = 0;
            for (Color c : Property.MEDIA_GRID_COLOR_PALETTE.getColorPaletteValue())
            {
                _mediaGridColorPalette.get(i).setColor(c);
                i++;
            }
            
            _mapType.setSelectedItem(Property.MAP.getValue());
            if ( _mapType.getSelectedItem() == null && _mapType.getItemCount() > 0 )
                _mapType.setSelectedIndex(0);
            _mapBackgroundColor.setColor(Property.MAP_BACKGROUND_COLOR.getColorValue());
            
            _mapWeight.setSelectedItem(Property.MAP_WEIGHT.getValue());
            if ( _mapWeight.getSelectedItem() == null )
                _mapWeight.setSelectedIndex(0);
            
            _mapTopo.setText(Property.MAP_TOPOGRAPHY.getValue());
            _mapBoundaries.setText(Property.MAP_BOUNDARIES.getValue());
            _mapBoundariesLine.setSelectedItem(Property.MAP_BOUNDARIES_LINE.getBooleanValue());
            _mapBoundariesLineWidth.setValue(Property.MAP_BOUNDARIES_LINE_WIDTH.getFloatValue());
            _mapBoundariesLineColor.setColor(Property.MAP_BOUNDARIES_LINE_COLOR.getColorValue());
            _mapBoundariesFill.setSelectedItem(Property.MAP_BOUNDARIES_FILL.getBooleanValue());
            _mapBoundariesFillLandColor.setColor(Property.MAP_BOUNDARIES_FILL_LAND_COLOR.getColorValue());
            _mapBoundariesFillWaterColor.setColor(Property.MAP_BOUNDARIES_FILL_WATER_COLOR.getColorValue());
            
            _mapSourceColor.setColor(Property.MAP_SOURCE_COLOR.getColorValue());
            _mapSourcePointSize.setText(Property.MAP_SOURCE_POINTSIZE.getValue());
            _mapStationEnabledColor.setColor(Property.MAP_STATION_ENABLED_COLOR.getColorValue());
            _mapStationEnabledPointSize.setText(Property.MAP_STATION_ENABLED_POINTSIZE.getValue());
            _mapStationEnabledLabelColor.setColor(Property.MAP_STATION_ENABLED_LABEL_COLOR.getColorValue());
            _mapStationEnabledFontSize.setText(Property.MAP_STATION_ENABLED_FONTSIZE.getValue());
            
            _mapStationDisabledColor.setColor(Property.MAP_STATION_DISABLED_COLOR.getColorValue());
            _mapStationDisabledPointSize.setText(Property.MAP_STATION_DISABLED_POINTSIZE.getValue());
            _mapStationDisabledLabelColor.setColor(Property.MAP_STATION_DISABLED_LABEL_COLOR.getColorValue());
            _mapStationDisabledFontSize.setText(Property.MAP_STATION_DISABLED_FONTSIZE.getValue());
            
            try
            {
                _outputShadingType.setSelectedItem(ShadingType.valueOf(Property.MAP_OUTPUT_SHADING.getValue()));
            }
            catch (Exception e)
            {}
            
            if ( _outputShadingType.getSelectedItem() == null )
                _outputShadingType.setSelectedIndex(0);
            _outputContourColor.setColor(Property.MAP_OUTPUT_CONTOUR_COLOR.getColorValue());
            _outputContourWidth.setText(Property.MAP_OUTPUT_CONTOUR_WIDTH.getValue());
            
            _netsim_path_sd.setSelectedItem(Property.NETSIM_PATH_SD.getBooleanValue());
            _netsim_c_interp.setSelectedItem(Property.NETSIM_C_INTERP.getBooleanValue());
            _netsim_noise_sd_db.setSelectedItem(Property.NETSIM_NOISE_SD_DB.getBooleanValue());
        }
    }

    /**
     * Add a color palette component to the given panel
     * @param panel
     * @param colorPaletteCountTextField
     * @param colorPalette
     * @param colorPaletteProperty
     */
    private void addPalette(JPanel panel, JTextField colorPaletteCountTextField, List<JColorButton> colorPalette, Property colorPaletteProperty)
    {
        // Find diff from current count to new count (entered in text box)
        int currentCount = colorPalette.size();
        int newCount = 0;
        if (colorPaletteCountTextField.getText().equals(""))
        {
            newCount = colorPaletteProperty.getNumberOfColors();
        }
        else
        {
            try
            {
                newCount = Integer.valueOf(colorPaletteCountTextField.getText());
            }
            catch (NumberFormatException e)
            {
                newCount = currentCount;
                colorPaletteCountTextField.setText(String.valueOf(newCount));
            }
        }
        if (newCount <= 0)
        {
            newCount = currentCount;
            colorPaletteCountTextField.setText(String.valueOf(newCount));
        }

        // Add OR delete colors from the palette based on difference in counts
        int diff = newCount - currentCount;
        if (diff > 0)
        {
            for (int i = 0; i < diff; i++)
            {
                JColorButton button = new JColorButton();
                List<Color> oldPalette = colorPaletteProperty.getColorPaletteValue();
                if (colorPalette.size() < oldPalette.size())
                {
                    button.setColor(oldPalette.get(colorPalette.size()));
                }
                colorPalette.add(button);
            }
        }
        else if (diff < 0)
        {
            for (int i = colorPalette.size() - 1; i >= 0; i--)
            {
                if (diff >= 0)
                    break;
                colorPalette.remove(i);
                diff++;
            }
        }

        // Add row list
        addRowList(panel, new JLabel(""), colorPalette);
    }

    /**
     * Save an integer property and update the corresponding JTextField
     * @param property
     * @param field
     */
    private void applyIntegerProperty(Property property, JTextField field)
    {
        String text = field.getText();
        Integer i = null;
        try
        {
            i = Integer.valueOf(text);
        }
        catch (NumberFormatException e)
        {
            try
            {
                float f = Float.valueOf(text);
                i = Math.round(f);
            }
            catch (NumberFormatException e2)
            {
            }
        }

        // If we did not get an exception AND integer >= 0, then set property value
        if (i != null && i >= 0)
        { // all integers must be >= 0
            property.setIntegerValue(i);
        }
        field.setText(String.valueOf(property.getIntegerValue())); // update text field
    }

    /**
     * Save a float property and update the corresponding JTextField
     * @param property
     * @param field
     */
    private void applyFloatProperty(Property property, JTextField field)
    {
        String text = field.getText();
        Float f = null;
        try
        {
            f = Float.valueOf(text);
        }
        catch (NumberFormatException e)
        {
        }

        // If we did not get an exception AND float >= 0.0, then set property value
        if (f != null && f >= 0.0)
        { // all floats must be >= 0.0
            property.setFloatValue(f);
        }
        field.setText(String.valueOf(property.getFloatValue())); // update text field
    }

    /**
     * Save all property values in all the panels.
     * @param property
     * @param field
     */
    private void apply()
    {
    	Property.OUTPUT_NAME.setValue(_outputName.getText());
    	Property.OUTPUT_FORMAT.setValue(_outputFormat.getSelectedItem().toString());
        Property.FILE_CHOOSER_DIRECTORY.setValue(_defaultDirectory.getText());
        applyIntegerProperty(Property.FONT_SIZE, _fontSize);
        Property.ICON_SIZE.setValue(_iconSize.getSelectedItem().toString());
        Property.BACKGROUND_COLOR.setColorValue(_backgroundColor.getColor());
        Property.DIVIDER_LOCATION.setValue(_dividerLocation.getText());
        Property.NUMBER_THREADS.setValue(_numberThreads.getText());

        applyIntegerProperty(Property.CHART_VIEWER_HEIGHT, _chartViewerHeight);
        applyIntegerProperty(Property.CHART_VIEWER_WIDTH, _chartViewerWidth);
        applyFloatProperty(Property.CHART_VIEWER_LINE_WIDTH, _chartViewerLineWidth);
        applyFloatProperty(Property.CHART_VIEWER_GRIDLINE_WIDTH, _chartViewerGridlineWidth);
        applyFloatProperty(Property.CHART_VIEWER_LABEL_FONT_SIZE, _chartViewerLabelFontSize);
        Property.CHART_VIEWER_ANTI_ALIASING.setBooleanValue((Boolean) _chartViewerAntiAlias.getSelectedItem());
        Property.CHART_VIEWER_BACKGROUND_COLOR.setColorValue(_chartViewerBackgroundColor.getColor());
        Property.CHART_VIEWER_GRIDLINE_COLOR.setColorValue(_chartViewerGridlineColor.getColor());

        ArrayList<Color> colors = new ArrayList<Color>();
        for (int i = 0; i < _chartViewerLineColorPalette.size(); i++)
            colors.add(_chartViewerLineColorPalette.get(i).getColor());
        Property.CHART_VIEWER_LINE_COLOR_PALETTE.setColorPaletteValue(colors);
        
        colors = new ArrayList<Color>();
        for (int i = 0; i < _mediaGridColorPalette.size(); i++)
            colors.add(_mediaGridColorPalette.get(i).getColor());
        Property.MEDIA_GRID_COLOR_PALETTE.setColorPaletteValue(colors);
        
        Property.MAP.setValue(_mapType.getSelectedItem().toString());
        Property.MAP_BACKGROUND_COLOR.setColorValue(_mapBackgroundColor.getColor());
        Property.MAP_WEIGHT.setValue(_mapWeight.getSelectedItem().toString());
        Property.MAP_TOPOGRAPHY.setValue(_mapTopo.getText());
        Property.MAP_BOUNDARIES.setValue(_mapBoundaries.getText());
        Property.MAP_BOUNDARIES_LINE.setBooleanValue((Boolean) _mapBoundariesLine.getSelectedItem());
        Property.MAP_BOUNDARIES_LINE_WIDTH.setValue(_mapBoundariesLineWidth.getText());
        Property.MAP_BOUNDARIES_LINE_COLOR.setColorValue(_mapBoundariesLineColor.getColor());
        Property.MAP_BOUNDARIES_FILL.setBooleanValue((Boolean) _mapBoundariesFill.getSelectedItem());
        Property.MAP_BOUNDARIES_FILL_LAND_COLOR.setColorValue(_mapBoundariesFillLandColor.getColor());
        Property.MAP_BOUNDARIES_FILL_WATER_COLOR.setColorValue(_mapBoundariesFillWaterColor.getColor());
        Property.MAP_OUTPUT_SHADING.setValue(_outputShadingType.getSelectedItem().toString());
        Property.MAP_OUTPUT_CONTOUR_COLOR.setColorValue(_outputContourColor.getColor());
        Property.MAP_OUTPUT_CONTOUR_WIDTH.setValue(_outputContourWidth.getText());
        Property.MAP_SOURCE_COLOR.setColorValue(_mapSourceColor.getColor());
        applyFloatProperty(Property.MAP_SOURCE_POINTSIZE, _mapSourcePointSize);
        

        Property.MAP_STATION_ENABLED_COLOR.setColorValue(_mapStationEnabledColor.getColor());
        applyFloatProperty(Property.MAP_STATION_ENABLED_POINTSIZE, _mapStationEnabledPointSize);
        Property.MAP_STATION_ENABLED_LABEL_COLOR.setColorValue(_mapStationEnabledLabelColor.getColor());
        applyFloatProperty(Property.MAP_STATION_ENABLED_FONTSIZE, _mapStationEnabledFontSize);

        Property.MAP_STATION_DISABLED_COLOR.setColorValue(_mapStationDisabledColor.getColor());
        applyFloatProperty(Property.MAP_STATION_DISABLED_POINTSIZE, _mapStationDisabledPointSize);
        Property.MAP_STATION_DISABLED_LABEL_COLOR.setColorValue(_mapStationDisabledLabelColor.getColor());
        applyFloatProperty(Property.MAP_STATION_DISABLED_FONTSIZE, _mapStationDisabledFontSize);
        
        Property.NETSIM_PATH_SD.setBooleanValue((Boolean) _netsim_path_sd.getSelectedItem());
        Property.NETSIM_C_INTERP.setBooleanValue((Boolean) _netsim_c_interp.getSelectedItem());
        Property.NETSIM_NOISE_SD_DB.setBooleanValue((Boolean) _netsim_noise_sd_db.getSelectedItem());

        //  Save all of the properties
        Property.saveProperties();
        
        NetMOD.getFrame().resetMap();
    }

    /**
     * Add vertical filler to a given panel
     * @param panel
     * @param height
     */
    public static void addFiller(JPanel panel, int height)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.NORTH;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weightx = 1;
        c.insets = new Insets(height, 0, 0, 0);
        panel.add(Box.createHorizontalGlue(), c);
    }

    /**
     * Add vertical glue to a given panel
     * 
     * @param panel
     */
    public static void addVerticalGlue(JPanel panel)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.VERTICAL;
        c.gridheight = GridBagConstraints.REMAINDER;
        c.weighty = 1;
        panel.add(Box.createVerticalGlue(), c);
    }

    /**
     * Add rows to a given panel for a JLabel and color palette (list of JColorButtons)
     * @param panel
     * @param label
     * @param fields
     */
    public static void addRow(JPanel panel, JComponent label, List<JColorButton> fields)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.NORTH;
        c.fill = GridBagConstraints.BOTH;
        c.insets = new Insets(2, 2, 2, 2);

        if (label != null)
        {
            c.weightx = 0.0;
            if (label instanceof JLabel)
                ((JLabel) label).setHorizontalAlignment(SwingConstants.RIGHT);
            panel.add(label, c);
        }

        c.weightx = 1.0;
        int count = 0;
        for (JComponent field : fields)
        {
            if (field instanceof JButton)
            {
                c.anchor = GridBagConstraints.LINE_START;
                c.fill = GridBagConstraints.NONE;
            }
            count++;
            if (count == fields.size())
            {
                c.gridwidth = GridBagConstraints.REMAINDER;
            }

            panel.add(field, c);
        }
    }

    public static void addRowList(JPanel panel, JLabel label, List<JColorButton> fields)
    {
        JLabel actualLabel;
        int increment = 6;
        for (int start = 0; start < fields.size(); start += increment)
        {
            if (start == 0)
            {
                actualLabel = (JLabel) label;
            }
            else
            {
                actualLabel = new JLabel("");
            }

            int end = start + increment;
            if (end > fields.size())
            {
                end = fields.size();
            }
            addRow(panel, actualLabel, fields.subList(start, end));
        }
    }

}
