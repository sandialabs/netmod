/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.*;

/**
 * SubCriteria composed of twp sub-criteria joined by an AND operator:
 * 
 *   SubCriteria * SubCriteria
 * 
 * @author bjmerch
 *
 */
public class AndSubCriteria extends SubCriteria
{
    public static final String AND = "*";
    private SubCriteria _criteria1;
    private SubCriteria _criteria2;
    
    public AndSubCriteria(SubCriteria criteria1, SubCriteria criteria2)
    {
        _criteria1 = criteria1;
        _criteria2 = criteria2;
        
        criteria1.setParent(this);
        criteria2.setParent(this);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getCriteria1());
        children.add(getCriteria2());

        return children;
    }

    @Override
    public Set<Phase> getPhases()
    {
        Set<Phase> phases = getCriteria1().getPhases();
        phases.addAll(getCriteria2().getPhases());
        
        return phases;
    }

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    public ObjectDoubleMap<String> getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        startIntrospection();
        recordIntrospection(this);
        
        //  Get the probabilities for each of the subcriteria
        ObjectDoubleMap<String> c1_probabilities = getCriteria1().getProbability(probabilities);
        ObjectDoubleMap<String> c2_probabilities = getCriteria2().getProbability(probabilities);
        
        //  Create a container for the resulting probabilities
        ObjectDoubleMap<String> result = new ObjectDoubleOpenHashMap<String>();

        //  Get the station set from the first map
        List<String> stations = Arrays.asList(c1_probabilities.keys().toArray(String.class));
        
        if ( isIntrospection() )
            Collections.sort(stations);
        
        //  Iterate over each station
        for (String station : stations)
        {            
            double p1 = c1_probabilities.get(station);
            double p2 = c2_probabilities.get(station);
            
            double p = p1 * p2;

            if ( p > 0 )
                recordIntrospection(station, ": ", p);
            
            result.put(station, p);
        }
        
        stopIntrospection();
        
        return result;
    }
    

    
    /**
     * @return the criteria1
     */
    public SubCriteria getCriteria1()
    {
        return _criteria1;
    }

    /**
     * @return the criteria2
     */
    public SubCriteria getCriteria2()
    {
        return _criteria2;
    }

    @Override
    public String toString()
    {
        return PAREN_OPEN + _criteria1 + AND + _criteria2 + PAREN_CLOSE;
    }
}
