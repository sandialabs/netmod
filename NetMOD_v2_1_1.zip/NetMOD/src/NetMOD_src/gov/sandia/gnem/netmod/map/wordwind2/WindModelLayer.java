/**
 * 
 */
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.View;
import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.event.SelectEvent;
import gov.nasa.worldwind.event.SelectListener;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Vec4;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.pick.PickedObject;
import gov.nasa.worldwind.render.*;
import gov.nasa.worldwindx.examples.util.DirectedPath;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.path.wind.WindModel;

import javax.swing.*;
import java.awt.*;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class WindModelLayer extends RenderableLayer implements Layer<WindModel>, SelectListener
{
    private WindModel _windModel;
    private GlobeAnnotation _tooltip;

    protected WindModelLayer(WindModel data)
    {
        //  Initialize the tooltip
        _tooltip = new GlobeAnnotation("", Position.fromDegrees(0, 0, 0));
        _tooltip.getAttributes().setFont(new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue()));
        _tooltip.getAttributes().setDistanceMinOpacity(1);
        _tooltip.getAttributes().setDistanceMaxScale(1);
        _tooltip.getAttributes().setVisible(false);
        _tooltip.getAttributes().setAdjustWidthToText(AVKey.SIZE_FIT_TEXT);
        _tooltip.getAttributes().setLeaderGapWidth(20);
        _tooltip.setAlwaysOnTop(true);

        //  Set the data
        setNMC(data);
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }

    @Override
    public JPanel getLegendPanel()
    {
        return null;
    }

    @Override
    public String getName()
    {
        return _windModel.getName();
    }

    @Override
    public WindModel getNMC()
    {
        return _windModel;
    }

    @Override
    public void selected(SelectEvent event)
    {
        if (event.isConsumed())
            return;

        if (event.getEventAction().equals(SelectEvent.ROLLOVER))
        {
            PickedObject object = event.getTopPickedObject();
            if (object != null && object.getParentLayer() == this)
            {
                if (object.getObject() instanceof DirectedPath)
                {
                    for (Position p : ((DirectedPath) object.getObject()).getPositions())
                    {
                        Complex v = _windModel.getWindVelocity(WindModel.ALTITUDE_KM, 
                                new Point.Double(p.getLatitude().getDegrees(), p.getLongitude().getDegrees()));

						_tooltip.setPosition(p);
						_tooltip.setText("N: " + Float.toString((float) v.getImaginary()) + " m/s\nE: " + Float.toString((float) v.getReal()) + " m/s");
						_tooltip.getAttributes().setVisible(true);

						event.consume();
						return;
                    }
                }
            }
            else
                _tooltip.getAttributes().setVisible(false);
        }

    }

    @Override
    public void setDisplay(DISPLAY display)
    {
    }

    @Override
    public void setNMC(WindModel data)
    {
        _windModel = data;

        setPickEnabled(true);

        //  Remove all renderables
        removeAllRenderables();

        //  Add contour lines
        addRenderables(generateWindVectors(data));

        //  Add the tooltip
        addRenderable(_tooltip);
    }

    @Override
    public void setVisible(boolean value)
    {
        setEnabled(value);
    }

    private List<Renderable> generateWindVectors(WindModel windModel)
    {
        ArrayList<Renderable> lines = new ArrayList<Renderable>();
        
        //  Generate a set of locations across the globe
        List<Complex> vectors = new ArrayList<Complex>(); 
        List<Point.Double> locations = new ArrayList<Point.Double>();
        for (double lon = -180; lon <= 180; lon += 10)
            for (double lat = -80; lat <= 80; lat += 10)
            {
            	Point.Double p = new Point.Double(lat, lon);
            	locations.add(p);
            	vectors.add(windModel.getWindVelocity(WindModel.ALTITUDE_KM, p));
            }

        //  Define the line appearance
        BasicShapeAttributes lineAttributes = new BasicShapeAttributes();
        lineAttributes.setEnableAntialiasing(true);
        lineAttributes.setOutlineMaterial(new Material(Property.MAP_BOUNDARIES_LINE_COLOR.getColorValue()));
        lineAttributes.setOutlineWidth(2);
        lineAttributes.setDrawInterior(true);
        lineAttributes.setDrawOutline(true);
        
        //  Render each vector
        int N = locations.size();
        for (int i=0; i<N; i++)
        {
            Point.Double p1 = locations.get(i);
            Complex v = vectors.get(i);
            double scale = v.getMagnitude();
            scale = 2 * Math.log(scale+1) / scale;
            
            Point.Double p2 = new Point.Double(
                    Math.min(90, Math.max(-90, p1.getLatitude() + scale * v.getImaginary())),
                    Math.min(180, Math.max(-180, p1.getLongitude() + scale * v.getReal())));
            
            //  Convert the points to a path
            DirectedPath line = new DirectedPath(
                    Position.fromDegrees(p1.getLatitude(), p1.getLongitude(), 100000),
                    Position.fromDegrees(p2.getLatitude(), p2.getLongitude(), 100000))
            {
                protected void computeArrowheadGeometry(DrawContext dc, Vec4 polePtA, Vec4 polePtB, Vec4 ptA, Vec4 ptB, double arrowLength, double arrowBase,
                        FloatBuffer buffer, PathData pathData)
                {
                    // Build a triangle to represent the arrowhead. The triangle is built from two vectors, one parallel to the
                    // segment, and one perpendicular to it. The plane of the arrowhead will be parallel to the surface.
                    double poleDistance = polePtA.distanceTo3(polePtB);

                    // Compute parallel component
                    Vec4 parallel = ptA.subtract3(ptB);

                    Vec4 surfaceNormal = dc.getGlobe().computeSurfaceNormalAtPoint(ptA);

                    // Compute perpendicular component
                    Vec4 perpendicular = surfaceNormal.cross3(parallel);

                    // Compute midpoint of segment
                    Vec4 arrowHead = polePtB;

                    if (!this.isArrowheadSmall(dc, arrowHead, 1))
                    {
                        // Compute the size of the arrowhead in pixels to make ensure that the arrow does not exceed the maximum
                        // screen size.
                        View view = dc.getView();
                        double arrowHeadDistance = view.getEyePoint().distanceTo3(arrowHead);
                        double pixelSize = view.computePixelSizeAtDistance(arrowHeadDistance);

                        if (arrowLength / pixelSize > this.maxScreenSize)
                        {
                            arrowLength = this.maxScreenSize * pixelSize;
                            arrowBase = arrowLength * this.getArrowAngle().tanHalfAngle();
                        }

                        perpendicular = perpendicular.normalize3().multiply3(arrowBase);
                        parallel = parallel.normalize3().multiply3(arrowLength);

                        // Compute geometry of direction arrow
                        Vec4 vertex1 = arrowHead.add3(parallel).add3(perpendicular);
                        Vec4 vertex2 = arrowHead.add3(parallel).add3(perpendicular.multiply3(-1.0));

                        // Add geometry to the buffer
                        Vec4 referencePoint = pathData.getReferencePoint();
                        buffer.put((float) (vertex1.x - referencePoint.x));
                        buffer.put((float) (vertex1.y - referencePoint.y));
                        buffer.put((float) (vertex1.z - referencePoint.z));

                        buffer.put((float) (vertex2.x - referencePoint.x));
                        buffer.put((float) (vertex2.y - referencePoint.y));
                        buffer.put((float) (vertex2.z - referencePoint.z));

                        buffer.put((float) (arrowHead.x - referencePoint.x));
                        buffer.put((float) (arrowHead.y - referencePoint.y));
                        buffer.put((float) (arrowHead.z - referencePoint.z));
                    }
                }

            };
            line.setArrowLength(300000);
            line.setAttributes(lineAttributes);
            line.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
            line.setFollowTerrain(true);
            line.setPathType(AVKey.GREAT_CIRCLE);
            
            //  Add the polyline
            lines.add(line);
        }

        return lines;
    }
}

