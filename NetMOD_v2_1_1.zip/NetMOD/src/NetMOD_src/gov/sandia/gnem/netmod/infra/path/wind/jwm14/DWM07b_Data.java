/**
 * Notice: This computer software was prepared by Sandia Corporation, hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the Department of Energy (DOE). All rights in the computer software are reserved by DOE on behalf of the United States Government and the Contractor as provided in the Contract. You are authorized to use this computer software for Governmental purposes but it is not to be released or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence must appear on any copies of this computer software.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jwm14;

import java.io.DataInputStream;
import java.io.InputStream;

import gov.sandia.gnem.netmod.io.IOUtility;

/**
 * Container used for DWM07b information that is static between HWM14 calls
 * 
 * @author bjmerch
 *
 */
public class DWM07b_Data
{
    public int nterm; // Number of terms in the model

    public int nmax; // Max latitudinal degree
    public int mmax; // Max order of MLT variation
    public int nvshterm; // Number of VSH basis functions

    //public int[][] termarr; // 3 x nterm index of coupled terms
    public int[] termarr0; // 3 x nterm index of coupled terms
    public int[] termarr1;
    public int[] termarr2;

    public double[] coeff; // Model coefficients

    public double twidth; // Transition width of high-lat mask
    public String dwmdefault = "/gov/sandia/gnem/netmod/infra/path/wind/hwm14/dwm07b104i.dat";

    private static DWM07b_Data _instance = null;

    final public static DWM07b_Data getInstance()
    {
        if (_instance == null)
            _instance = new DWM07b_Data();

        return _instance;
    }

    private DWM07b_Data()
    {
    	initdwm();
    }
    
    public void initdwm()
    {
        InputStream in = null;
        DataInputStream data = null;
        
        try
        {
            int numBytes = 0;

            // Default file name of data file
            in = DWM07b_Data.class.getResourceAsStream(dwmdefault);
            data = new DataInputStream(in);

            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 12)
                throw new Exception("Unexpected number of bytes: " + numBytes);
            nterm = FortranDataReader.readInt(data);
            mmax = FortranDataReader.readInt(data);
            nmax = FortranDataReader.readInt(data);
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 12)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            termarr0 = new int[nterm];
            termarr1 = new int[nterm];
            termarr2 = new int[nterm];
            coeff = new double[nterm];

            //  Read termarr
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 3 * 4 * nterm)
                throw new Exception("Unexpected number of bytes: " + numBytes);
            for (int i = 0; i < nterm; i++)
            {
                termarr0[i] = FortranDataReader.readInt(data);
                termarr1[i] = FortranDataReader.readInt(data);
                termarr2[i] = FortranDataReader.readInt(data);
            }
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 3 * 4 * nterm)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            //  Read coeff
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 4 * coeff.length)
                throw new Exception("Unexpected number of bytes: " + numBytes);
            FortranDataReader.readFloatArray(data, coeff, 0,  coeff.length);
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 4 * coeff.length)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            //  Read twidth
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 4)
                throw new Exception("Unexpected number of bytes: " + numBytes);
            twidth = FortranDataReader.readFloat(data);
            numBytes = FortranDataReader.readInt(data);
            if (numBytes != 4)
                throw new Exception("Unexpected number of bytes: " + numBytes);

            nvshterm = (((nmax + 1) * (nmax + 2) - (nmax - mmax) * (nmax - mmax + 1)) / 2 - 1) * 4 - 2 * nmax;
            
            /*
             * Debugging statements
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("initdwm");
            System.out.println("nterm = " + nterm);
            System.out.println("mmax = " + mmax);
            System.out.println("nmax = " + nmax);
            System.out.println("termarr = ");
            System.out.println(Arrays.toString(termarr0));
            System.out.println(Arrays.toString(termarr1));
            System.out.println(Arrays.toString(termarr2));
            System.out.println("coeff = ");
            System.out.println(Arrays.toString(coeff));
            System.out.println("twidth = " + twidth);
            System.out.println("nvshterm = " + nvshterm);
             */
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
        	if ( data != null )
        		IOUtility.safeClose(data);
        	if ( in != null )
        		IOUtility.safeClose(in);
        }

    }

}
