/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.noise;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.numeric.*;
import gov.sandia.gnem.netmod.path.PathPhaseParameter;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.receiver.Station;
import gov.sandia.gnem.netmod.seismic.io.SeismicDetectionParameters;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.simulation.Magnitude;
import gov.sandia.gnem.netmod.simulation.Phase;
import gov.sandia.gnem.netmod.source.Sources;

/**
 * @author bjmerch
 *
 */
public class NetSimBodywave extends AbstractNetModComponent implements NoiseAmplitude
{
    public static final String TYPE = "NetSim";
    static
    {
        NoiseAmplitudePlugin.getPlugin().registerComponent(TYPE, NetSimBodywave.class);
    }

    public NetSimBodywave(NetModComponent parent)
    {
        super(parent, TYPE, "NetSim Noise Amplitude");
    }

    /**
     * Constructor for classes that extend this class
     * 
     * @param type
     */
    protected NetSimBodywave(NetModComponent parent, String type, String name)
    {
        super(parent, type, name);
    }

    @Override
    public Spectra generateAmplitude(SignalAmplitude signal, Sources sources, Paths paths, Receivers receivers, Point.Double epicenter, Station station, Distance distance,
            Magnitude magnitude, Phase phase, Frequency frequency, Time time, int N, PRNG prng)
    {
        startIntrospection();

        /*
         * 
         * Get the estimate of the site noise
         * 
         */
        startIntrospection();
        Spectra siteLogPSD = station.getNoiseSpectra().getNoise(frequency, time);
        int Nfreq = siteLogPSD.getLength();
        
        SpectraDouble siteLogPSD_mean = siteLogPSD.getMeanSpectra();
        SpectraDouble siteLogPSD_sd = siteLogPSD.getStandardDeviationSpectra();

        //  Check if no ambient standard deviation, use station default
        boolean found = false;
        if (station.getNoiseSpectraSD() > 0)
            for (int i = 0; i < Nfreq; i++)
                if (siteLogPSD_sd.getValue(i) <= 0)
                    found = true;
        if (found)
        {
            double new_sd = 2 * station.getNoiseSpectraSD();
            for (int i = 0; i < Nfreq; i++)
                siteLogPSD_sd.setValue(i, new_sd);
            
            recordIntrospection("Ambient Site Noise Mean (log10 PSD): ", siteLogPSD_mean);
            recordIntrospection("Standard Deviation from station parameter (log10 PSD): ", siteLogPSD_sd);
        }
        else
            recordIntrospection("Ambient Site Noise (log10 PSD): ", siteLogPSD);

        stopIntrospection();

        //  Combine the two noise estimates means and standard deviations
        SpectraDouble totalNoisePSD_mean = new SpectraDouble(siteLogPSD_mean);
        SpectraDouble totalNoiseLogSA_sd = new SpectraDouble(siteLogPSD_sd);
        
        //  Convert from log10 PSD to log10 SA
        totalNoiseLogSA_sd.scale(0.5);

        /*
         * 
         * Get the estimate of the prior phase noise
         * 
         */

        //  Get the path phase parameters
        PathPhaseParameter pathPP = paths.getPhaseParameters().getPhaseParameter(phase);

        //  Identify the prior phase
        Phase priorPhase = pathPP.getPriorPhase();

        startIntrospection();

        if (priorPhase != null)
        {
            //  Convert from log10 PSD to PSD
            totalNoisePSD_mean.pow10();
            
            //  Get the spectral amplitude of the prior phase
            Spectra logSijk_ = signal.generateAmplitude(sources, paths, receivers, epicenter, station, distance, magnitude, priorPhase, frequency, time, N, prng);
            
            //  Get the coda decay scale factor, copied so we don't modify the cached copy
            SpectraDouble codaDecayRate = new SpectraDouble(pathPP.getCodaDecay().getCodaDecay(distance, frequency));
            codaDecayRate.log10().scale(2.0);
            
            //  Get the time window
            double Tk_ = paths.getPhaseParameters().getPhaseParameter(priorPhase).getTimeWindow(epicenter, station.getLocation());

            //  Convert the spectral amplitude of the prior phase to log PSD
            SpectraPDF logPrior_PSD = new SpectraPDF(logSijk_, 0);
            logPrior_PSD.scale(2.0);
            logPrior_PSD.add(- Math.log10(Tk_));
            logPrior_PSD.add(codaDecayRate);
            
            //  Add the Site Noise and Prior Phase noise
            for (int i=0; i<Nfreq; i++)
            {
                //  Get the mean and standard deviation
                double f = siteLogPSD.getFrequency(i);
                
                PDF priorLogPSD_pdf = logPrior_PSD.getFrequencyValue(f);
                double priorLogPSD_mean = priorLogPSD_pdf.getMean();
                double priorLogPSD_sd = priorLogPSD_pdf.getStandardDeviation();
                
                //  Compute the mean value of the prior PSD
                double priorPSD_mean = Math.pow(10, priorLogPSD_mean);

                //  Compute standard deviation of the prior SA
                double priorLogSA_sd = priorLogPSD_sd * 0.5;
                double tmpPrior = priorPSD_mean * priorLogSA_sd;
                
                double sitePSD_mean = totalNoisePSD_mean.getValue(i);
                double siteLogSA_sd = totalNoiseLogSA_sd.getValue(i);
                double tmpSite = sitePSD_mean * siteLogSA_sd;
                
                //  Set the total mean and standard deviation
                totalNoisePSD_mean.add(i, priorPSD_mean);
                totalNoiseLogSA_sd.setValue(i, Math.sqrt(tmpPrior * tmpPrior + tmpSite * tmpSite) / totalNoisePSD_mean.getValue(i));
            }

            recordIntrospection("Prior Phase noise (log10 PSD): ", logPrior_PSD);
            recordIntrospection("Prior Phase: ", priorPhase);
            recordIntrospection("Coda Decay Rate Correction (2 * log10): ", codaDecayRate);
            recordIntrospection("Time Window length of prior phase (sec): ", Tk_);
            
            //  Convert from PSD to log10 PSD
            totalNoisePSD_mean.log10();
        }
        else
        {
            recordIntrospection("No Prior Phase");
        }

        stopIntrospection();

        //  Convert the mean from PSD to SA
        double Tk = pathPP.getTimeWindow(epicenter, station.getLocation());

        totalNoisePSD_mean.scale(0.5);
        totalNoisePSD_mean.add(0.5*Math.log10(Tk));
        
        SpectraPDF logTotalNoise = new SpectraPDF(totalNoisePSD_mean, totalNoiseLogSA_sd);
        
        //  Convert to MonteCarlo iterations, if necessary
        logTotalNoise = logTotalNoise.toMonteCarlo(prng, N);

        recordIntrospection("NetSim Noise Amplitude (log10 Amplitude): ", logTotalNoise);
        recordIntrospection("Time Window length (sec): ", Tk);

        stopIntrospection();

        return logTotalNoise;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        return null;
    }

    @Override
    public boolean isLeaf()
    {
        return true;
    }

    @Override
    public void load(NetSimParameters parameters) throws Exception
    {
    	super.load(parameters);
    }

    @Override
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception
    {
        super.save(parameters, files, reset);
        
        parameters.set(SeismicDetectionParameters.noiseAmplitude, getType());
    }
}
