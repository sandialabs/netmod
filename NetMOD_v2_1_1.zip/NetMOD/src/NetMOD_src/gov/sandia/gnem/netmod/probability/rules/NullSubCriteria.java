/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import com.carrotsearch.hppc.ObjectDoubleOpenHashMap;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * SubCriteria that is empty
 * 
 * @author bjmerch
 *
 */
public class NullSubCriteria extends SubCriteria
{
    public NullSubCriteria()
    {
    }

    @Override
    public Set<Phase> getPhases()
    {
        return new TreeSet<Phase>();
    }

    /**
     * Get the probabilities of the SubCriteria from the individual probabilities
     * 
     * @param probabilities
     */
    public ObjectDoubleMap<String> getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        return new ObjectDoubleOpenHashMap<String>();
    }

    @Override
    public String toString()
    {
        return "";
    }
}
