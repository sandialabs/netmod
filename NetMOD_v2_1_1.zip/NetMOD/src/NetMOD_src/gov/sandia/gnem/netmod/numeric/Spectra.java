package gov.sandia.gnem.netmod.numeric;

import java.util.Arrays;

import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;

/**
 * Representation of some quantity as a function of frequency
 * 
 * @author bjmerch
 *
 */
public abstract class Spectra
{
	/**
	 * Get the set of frequencies to iterate over from the provided set of spectra
	 * 
	 * @param spectras
	 * @param N
	 * @return
	 */
	private static double[] getFrequencies(Spectra[] spectras, int N)
	{
		double[] freqs = new double[0];
		for (int i=0; i<N; i++)
		{
			Spectra spectra = spectras[i];
			if ( spectra == null )
				continue;
			
			double[] f2 = spectra.getFrequencies();
			if ( freqs == null || f2.length > freqs.length )
				freqs = f2;
		}
		
		return freqs;
	}
	
	/**
	 * Sum the provided spectra, the optional standard deviation, and the offset value
	 * 
	 * @param value  Offset value
	 * @param std  Standard deviation, if not defined within spectra
	 * @param spectra spectra value
	 * @return
	 */
	public static Spectra sum(double value, double std, Spectra spectra)
	{
		if ( value == 0 && std == 0 )
			return spectra;
		
		int N = spectra.getLength();
		SpectraPDF sum = new SpectraPDF(spectra.getFrequencies());
		
		//  Only add the standard deviation to a SpectraPDF if it has no standard deviation
    	if ( spectra instanceof SpectraPDF )
    	{
    		for (int i=0; i<N; i++)
    		{
    			double f = spectra.getFrequency(i);
    			PDF pdf = ((SpectraPDF) spectra).getValue(i);
    			
    			if ( pdf.getStandardDeviation() > 0 )
    				sum.setValue(i, f, pdf.add(value));
    			else
    				sum.setValue(i, f, new NormalPDF(pdf.getMean()+value, std));
    		}
    	}
		//  Always add the standard deviation to a SpectraDouble
    	else if ( spectra instanceof SpectraDouble )
    	{
    		for (int i=0; i<N; i++)
    		{
    			double f = spectra.getFrequency(i);
    			double mean = ((SpectraDouble) spectra).getValue(i);

				sum.setValue(i, f, new NormalPDF(mean+value, std));
    		}
    	}
    	
    	return sum;
	}
	
	/**
	 * Sum all of the provided Spectras into a unified spectra
	 * 
	 * @param value Scalar value to add
	 * @param pdf  Scaled PDF to add
	 * @param spectras A set of spectra to add
	 * @return
	 */
	public static Spectra sum(double value, PDF pdf, Spectra... spectras)
	{
		if ( pdf == null )
			pdf = NormalPDF.ZERO;
		
		//  Identify all of the frequencies to use, pick the spectra with the most frequencies
		double[] freqs = getFrequencies(spectras, spectras.length);
		
		//  Could the number of SpectraPDF
		int NSpectraPDF = 0;
		for (Spectra spectra : spectras)
		{
			if ( spectra == null )
				continue;
			
			//  Count the number of spectra pdf components
			if ( spectra instanceof SpectraPDF )
				NSpectraPDF++;
		}
		
		//  Construct a new SpectraPDF as the sum
		int Nfreq = freqs.length;
		SpectraPDF sum = new SpectraPDF(freqs);

		//  Add the spectra component at each frequency
		PDF[] pdfs = new PDF[NSpectraPDF];
		for (int i=0; i<Nfreq; i++)
		{
			double f = freqs[i];			
			double sumValue = value;
			int j=0;
			
			//  Sum all of the frequencies, differentiating between SpectraDouble and SpectraPDF
			for (Spectra spectra : spectras)
			{
				if ( spectra == null )
					continue;
				
				if ( spectra instanceof SpectraDouble )
					sumValue += ((SpectraDouble) spectra).getFrequencyValue(f);
				else if ( spectra instanceof SpectraPDF )
					pdfs[j++] = ((SpectraPDF) spectra).getFrequencyValue(f);
			}
			
			sum.setValue(i, pdf.add(sumValue, pdfs));
		}

		return sum;
	}
	
	/**
	 * Sum the weighted spectra.  Assume the incoming spectra as being defined by a mean and standard deviation
	 * 
	 * @param spectra  Spectra to sum
	 * @param weights  Weight applied to each spectra
	 * @param std  Standard deviation value to use for spectra that don't include it
	 * @param N  Number of spectra to include in the sum
	 * @return
	 */
	public static Spectra sum(Spectra[] spectras, double[] weights, double[] std, int N)
	{
		//  Identify all of the frequencies to use, pick the spectra with the most frequencies
		double[] freqs = getFrequencies(spectras, N);
		
		//  Construct a new SpectraPDF as the sum
		int Nfreq = freqs.length;
		SpectraPDF sum = new SpectraPDF(freqs);

		//  Add the spectra component at each frequency
		for (int i=0; i<Nfreq; i++)
		{
			double f = freqs[i];
			double mean = 0;
			double var = 0;
			
			//  Sum all of the frequencies, differentiating between SpectraDouble and SpectraPDF
			for (int j=0; j<N; j++)
			{
				Spectra spectra = spectras[j];
				if ( spectra == null )
					continue;
				
				if ( spectra instanceof SpectraDouble )
				{
					mean += weights[j] * ((SpectraDouble) spectra).getFrequencyValue(f);
					var += weights[j] * std[j] * std[j];
				}
				else if ( spectra instanceof SpectraPDF )
				{
					PDF pdf = ((SpectraPDF) spectra).getFrequencyValue(f);
					
					mean += weights[j] * pdf.getMean();
					if ( pdf.getStandardDeviation() > 0 )
						var += weights[j] * pdf.getVariance();
					else
						var += weights[j] * std[j] * std[j];
				}
			}
			
			sum.setValue(i, new NormalPDF(mean, Math.sqrt(var)));
		}

		return sum;
	}
	
	protected double[] _frequencies;

    public Spectra(double f)
	{
		this(f, 1);
	}

	public Spectra(double f, int N)
	{
		this(N);
		
		if ( f != 0.0 )
			Arrays.fill(_frequencies, f);
	}
    
    public Spectra(double[] f)
	{
        int N = f.length;
        
        _frequencies = Arrays.copyOf(f, N);
	}
    
    public Spectra(int N)
	{
		_frequencies = new double[N];
	}
    
    /**
     * Add the provided constant value to all frequencies equally
     * 
     * @param value
     * @return this
     */
    abstract public Spectra add(double value);
    
    /**
     * Add the provided quantities to this spectra and return the result
     * 
     * @param value
     * @param pdf
     * @return a new spectraPDF
     */
    abstract public Spectra add(double value, PDF pdf);

    /**
     * Add the provided quantities to this spectra and return the result
     * 
     * @param value
     * @param pdf
     * @param spectra
     * @return
     */
    abstract public Spectra add(double value, PDF pdf, SpectraDouble spectra);
    
    /**
     * @param index
     * @param value
     * @return 
     */
    abstract public Spectra add(int index, double value);
    
    /**
     * Add the provided quantities to this spectra and return the result
     * 
     * @param value
     * @param pdf
     * @return a new spectraPDF
     */
    abstract public Spectra add(PDF pdf);

    /**
     * Add the provided quantities to this spectra and return the result
     * 
	 * @param pdf
	 * @param spectra
	 * @return
	 */
	abstract public Spectra add(PDF pdf, SpectraPDF spectra);
    
    /**
     * Add the provided spectra to this spectra
     * 
     * @param spectra
     */
    public abstract Spectra add(Spectra spectra);
    
	/**
     * Add the provided spectra to this spectra, scaled by
     * the provided value.
     * 
     * @param spectra
     * @param scale
     * @return 
     */
    abstract public Spectra addScaled(double scale, Spectra spectra);
	
    @Override
    public boolean equals(Object o)
    {
        if ( !(o instanceof Spectra) )
            return false;
        
        Spectra s = (Spectra) o;
        
        return Arrays.equals(s._frequencies, _frequencies) && 
        		Arrays.deepEquals(s.getValues(), getValues());
    }
    
    /**
     * Get the frequencies
     * 
     * @return
     */
    public double[] getFrequencies()
    {
    	return _frequencies;
    }
    
    /**
     * Get the frequency for the provided index
     * 
     * @param index
     * @return
     */
    public double getFrequency(int index)
    {
        return _frequencies[index];
    }
    
    public int getLength()
	{
		return _frequencies.length;
	}

    /**
     * Get the mean value, accounting for the frequency spacing.
     * 
     * @return
     */
    abstract public double getMean();   
    
    /**
	 * Get the mean value at the provided frequency index.
	 * 
	 * @param i Frequency index
	 * @return
	 */
	public abstract double getMean(int i);    
    
    /**
     * Get the mean value, accounting for the frequency spacing.
     * Assume that the values are log10.
     * 
     * @return
     */
    abstract public double getMeanLog();   

	/**
	 * Get the mean PDF, accounting for frequency spacing.
	 * Assume that the values are log10.
	 * 
	 * @return
	 */
	public abstract PDF getMeanLogPDF();

	/**
     * Get the spectra of the mean as a function of frequency
     * 
     * @return
     */
    abstract public SpectraDouble getMeanSpectra(); 
    
    /**
	 * Get the standard deviation at the provided frequency index
	 * 
	 * @return
	 */
	public abstract double getStandardDeviation(int i);
    
    /**
	 * Get the spectra of the standard deviation as a function of frequency
	 * 
	 * @return
	 */
	public abstract SpectraDouble getStandardDeviationSpectra();    
    
    /**
     * Get the value for the provided index
     * 
     * @param index
     * @return
     */
    public abstract Object getValue(int index);
    
    /**
     * Get the values
     * 
     * @return
     */
    abstract public Object[] getValues();
    
    @Override
    public int hashCode()
    {
		return Arrays.hashCode(_frequencies) + Arrays.hashCode(getValues());
    }
    
    /**
     * Get the log10 of this spectra
     * 
     * @return 
     * 
     */
    abstract public Spectra log10();
    
    /**
     * Get the pow10 of this spectra
     * 
     * @return 
     * 
     */
    abstract public Spectra pow10();

	/**
     * Scale this spectra by the provided value
     * 
     * @param value
     * @return 
     */
    public Spectra scale(double value)
    {
    	return scale(value, 0.0);
    }

	/**
     * Scale the PDF by the provided slope and offset
     * new_value = a * value + b;
     * Return this object.
     * 
     * @param a
     * @param b
     * @return
     */
    abstract public Spectra scale(double a, double b);

	/**
     * Scale this spectra by the provided values
     * Returns a reference to this object.
     * 
     * @param value
     * @param scale
     * @return
     */
    abstract public Spectra scale(double value, Spectra... scale);

	/**
     * Set this spectra to be equal to the provided spectra
     * 
     * @param spectra
     * @return 
     */
    abstract public Spectra set(Spectra spectra);

	abstract public Spectra toMonteCarlo(PRNG prng, int n);

	@Override
	public String toString()
    {
        int N = getLength();
        
        if ( N == 0 )
            return "";
        else if ( N == 1 )
            return GUIUtility.format(getValue(0));
        else
        {
            StringBuffer sb = new StringBuffer();

            sb.append("\n\tFrequencies\tValues\n");
            for (int i=0; i<N; i++)
                sb.append("\t").append(GUIUtility.format(_frequencies[i])).append("\t").append(GUIUtility.format(getValue(i))).append("\n");
            
            return sb.toString();
        }
    }
}
