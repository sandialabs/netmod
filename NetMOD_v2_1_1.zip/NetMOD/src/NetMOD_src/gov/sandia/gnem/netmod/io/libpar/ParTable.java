/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io.libpar;

import java.util.*;

/**
 * Table contained within a PAR file
 * 
 * @author bjmerch
 *
 */
public class ParTable
{

    /**
     * Delimiter for the list of labels.
     */
    public static final String DELIM = ",";

    /**
     * The format for the keys of table values is as follows:<br />
     * {@literal <table-name>[<row>].<column>}<br />
     * This is the open bracket.
     */
    private static final String OPEN_B = "[";
    /**
     * The format for the keys of table values is as follows:<br />
     * {@literal <table-name>[<row>].<column>}<br />
     * This is the close bracket.
     */
    private static final String CLOSE_B = "]";
    /**
     * The format for the keys of table values is as follows:<br />
     * {@literal <table-name>[<row>].<column>}<br />
     * This is the dot.
     */
    private static final String DOT = ".";

    /*
     * Internal table attributes
     */
    private String _name;
    private Set<String> _columnNames = new LinkedHashSet<String>();
    private Set<String> _rowNames = new LinkedHashSet<String>();
    private LibParParameters _parameters = null;
    
    //  Cache of keys
    private Map<String,Map<String,String>> _tableKeyCache = new HashMap<String,Map<String,String>>();
    

    public ParTable(String name, Collection<String> columns)
    {
        this(name, (LibParParameters) null);

        addColumns(columns);
    }

    public ParTable(String name, LibParParameters parameters)
    {
        _name = name;
        _parameters = parameters;
    }

    public ParTable(String name, LibParParameters parameters, Collection<String> columns)
    {
        this(name, parameters);

        addColumns(columns);
    }

    /**
     * @param name
     */
    public void addColumn(String name)
    {
        _columnNames.add(name);
    }

    /**
     * @param names
     */
    public void addColumns(Collection<String> names)
    {
        if (names.size() == 0)
            throw new IllegalArgumentException("Can't append 0 columns.");
        if (!verifyUnique(names))
        {
            throw new IllegalArgumentException("Non-unique column names found in a single column def: " + getName());
        }

        _columnNames.addAll(names);
    }

    /**
     * @param columns
     * @param values
     * @param rowName
     */
    public void addRow(List<String> columns, List<String> values, String rowName)
    {
        if ( rowName == null )
            rowName = Integer.toString(_rowNames.size() + 1);
        
        _rowNames.add(rowName);
        _columnNames.addAll(columns);

        int N = Math.min(columns.size(), values.size());

        for (int i = 0; i < N; i++)
            setTableValue(rowName, columns.get(i), values.get(i));
    }

    public int getColumnCount()
    {
        return _columnNames.size();
    }

    public Set<String> getColumnNames()
    {
        return _columnNames;
    }

    public String getName()
    {
        return _name;
    }

    /**
     * Get all of the parameter names referenced by this table
     * 
     * @return
     */
    public Set<String> getParameterNames()
    {
        Set<String> names = new HashSet<String>();
        
        for (String row : getRowNames())
            for (String column : getColumnNames())
            {
                String name = buildTableKey(row, column);
                names.add(name);
            }
        
        return names;
    }

    public int getRowCount()
    {
        return _rowNames.size();
    }

    public Set<String> getRowNames()
    {
        return _rowNames;
    }
    
    /**
     * Get the table value for the provided row and column
     * 
     * @param column
     * @param row
     * @return
     */
    public String getTableValue(String row, String column)
    {
        if ( _parameters == null )
            return "";
        
        String key = buildTableKey(row,column);
        String value = _parameters.get(key);
        
        if ( value == null )
            value = "";
        
        return value;
    }
    
    /**
     * Get the table value for the provided row and column
     * 
     * @param row
     * @param column
     * @param defaultValue
     * @return
     */
    public double getTableValue(String row, String column, double defaultValue)
    {
        String value = getTableValue(row, column);

        try
        {
            return Double.parseDouble(value);
        }
        catch (Exception e)
        {

        }

        return defaultValue;
    }

    /**
     * Set the table value for the provided row and column
     * 
     * @param row
     * @param column
     * @param value
     */
    public void setTableValue(String row, String column, String value)
    {
        if ( _parameters == null )
            return;

        String key = buildTableKey(row,column);
        _rowNames.add(row);
        _parameters.set(key, value);
    }

    private String buildTableKey(String row, String column)
    {
        //  Check the column cache
        Map<String, String> cache2 = _tableKeyCache.get(column);
        if ( cache2 == null )
        {
            cache2 = new HashMap<String,String>();
            _tableKeyCache.put(column, cache2);
        }
        
        //  Check the row cache
        String key = cache2.get(row);
        if ( key == null )
        {
            key = getName() + OPEN_B + row + CLOSE_B + DOT + column;
            cache2.put(row, key);
        }
        
        return key;
    }

    /**
     * Iterates through the list of strings and makes sure each string is only found once per list.
     * {@code null} elements are ignored.
     * @param names - The list of strings to check.
     * @return {@code true} if each element is unique.
     */
    private boolean verifyUnique(Collection<String> names)
    {
        return names.size() == new HashSet<String>(names).size();
    }
}
