/**
 * 
 */
package gov.sandia.gnem.netmod.path.wind;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.numeric.Complex;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

/**
 * Interface for modeling wind vectors
 * 
 * @author bjmerch
 *
 */
public interface WindModel extends NetModComponent
{
    public static final double ALTITUDE_KM = 50.0;
    public static final double SAMPLE_INCREMENT_DEG = 50 / 111.1949266;

    /**
     * Get wind vectors for the requested time, altitude, and locations.
     * Returned values are complex with the real component representing the east wind vector in m/s
     * and the imaginary component representing the north wind vector in m/s.
     * 
     * @param time Time in epoch seconds
     * @param altitude Altitude in kilometers
     * @param location location in degrees latitude and longitude
     * @return
     */
    public Complex getWindVelocity(Time time, double altitude, Point.Double location);
    
    /**
     * Get wind vectors for the requested time, altitude, and locations.
     * Returned values are complex with the real component representing the east wind vector in m/s
     * and the imaginary component representing the north wind vector in m/s.
     * 
     * @param altitude Altitude in kilometers
     * @param location location in degrees latitude and longitude
     * @return
     */
    public Complex getWindVelocity(double altitude, Point.Double location);
}
