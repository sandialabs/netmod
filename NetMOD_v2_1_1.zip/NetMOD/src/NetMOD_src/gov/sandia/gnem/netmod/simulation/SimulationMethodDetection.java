/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.simulation;

import gov.sandia.gnem.netmod.detection.NetworkDetection;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.ProgressDialog;
import gov.sandia.gnem.netmod.introspection.IntrospectionNode.StatusType;
import gov.sandia.gnem.netmod.noise.NoiseAmplitude;
import gov.sandia.gnem.netmod.numeric.Time;
import gov.sandia.gnem.netmod.output.Output;
import gov.sandia.gnem.netmod.path.Paths;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.receiver.Receivers;
import gov.sandia.gnem.netmod.signal.SignalAmplitude;
import gov.sandia.gnem.netmod.source.Sources;
import gov.sandia.gnem.netmod.source.epicenter.EpicenterGrid;
import gov.sandia.gnem.netmod.source.media.SourceMediaType;

/**
 *  Simulation method that supports detection 
 * 
 * @author bjmerch
 *
 */
public class SimulationMethodDetection extends SimulationMethod
{
	private static String _type = "Detection";
    static
    {
        SimulationMethodPlugin.getPlugin().registerComponent(_type, SimulationMethodDetection.class, true);
    }
    
    public SimulationMethodDetection(NetModComponent parent)
    {
	    super(parent, _type);
    }

	@Override
    public void run(Simulation simulation, Output output, int index)
    {
        long t1 = System.currentTimeMillis();

        startIntrospection();
        
        //  Get the type of simulation
        SimulationType simulationType = simulation.getSimulationType();

        //  Get the sources
        Sources sources = simulation.getSources();

        //  Get the time
        Time time = simulation.getSimulationTime();

        //  Get the paths
        Paths paths = simulation.getPaths();

        //  Get the receivers
        Receivers receivers = simulation.getReceivers();

        //  Get the signal and noise amplitude computation routines
        SignalAmplitude signalAmplitude = simulation.getSignalAmplitude();
        NoiseAmplitude noiseAmplitude = simulation.getNoiseAmplitude();

        //  Get the Network Detection routine
        NetworkDetection networkDetection = simulation.getNetworkDetection();

        //  Get the set of epicenters
        EpicenterGrid epicenters = sources.getEpicenterGrid();

        //  Determine the magnitude(s) to simulate
        double probability = Double.NaN;
        double magnitude = Double.NaN;

        //  Start with an initial guess of magnitude as the previous magnitude
        Point.Double epicenter = epicenters.get(index);
        SourceMediaType sourceMediaType = sources.getSourceMedia().getMediaType(epicenters.get(index));
        double dist = java.lang.Double.POSITIVE_INFINITY;
        for (int j = index; --j >= 0 && ((index - j) > 1000 || Double.isNaN(magnitude));)
        {
            //  Verify that a value is defined
            if (output.getEpicenterValue(j, Output.SIMULGRID_SIZE) > 0)
            {
                //  Verify that the source media type is the same
                if (sourceMediaType == sources.getSourceMedia().getMediaType(epicenters.get(j)))
                {
                    //  Find the closest
                    double tmp_dist = epicenters.get(j).distance(epicenter);
                    if (tmp_dist < dist)
                    {
                        magnitude = output.getEpicenterValue(j, Output.SIMULGRID_SIZE);
                        dist = tmp_dist;
                    }
                }
            }
        }

        //  Keep track of the magnitude history
        double[][] history = simulation.getSimulationType().getMagnitudeHistory();
        
        //  Iterate over magnitudes
        int iter = 0;
        while (true)
        {
            //   Determine the next magnitude to simulate
            double nextMagnitude = simulationType.getNextMagnitude(magnitude, probability, history, iter);
            if (nextMagnitude == magnitude && !Double.isNaN(probability))
                break;

            magnitude = nextMagnitude;

            startIntrospection();
            recordIntrospection("Magnitude: ", magnitude);

            //  Convert the magnitude to a log moment
            if (sourceMediaType == null || sourceMediaType.getEventSizeConversion() == null)
            {
                recordIntrospection("No moment conversion");
                statusIntrospection(StatusType.ERROR);
                stopIntrospection();
                break;
            }

            //  Convert the magnitude to a moment
            Magnitude moment = sourceMediaType.getEventSizeConversion().convertToMoment(magnitude, simulationType.getMagnitudeType());

            //  Compute the probability of a network detection
            probability = networkDetection.computeDetectionProbability(sources, paths, receivers, epicenter, time, moment, signalAmplitude,
                    noiseAmplitude);
            recordIntrospection("Probability: ", probability);

            stopIntrospection();

            if (ProgressDialog.getProgressDialog().isCanceled())
                break;
            
            if (Double.isNaN(probability))
            	break;

            iter++;
        }
        long t2 = System.currentTimeMillis();

        //  Store the result
        double result = simulationType.getResult(magnitude, probability);

        output.setEpicenterValue(index, Output.SIMULGRID_LAT, epicenter.getLatitude());
        output.setEpicenterValue(index, Output.SIMULGRID_LON, epicenter.getLongitude());
        output.setEpicenterValue(index, Output.SIMULGRID_SIZE, magnitude);
        output.setEpicenterValue(index, Output.SIMULGRID_NETPROB, probability);
        output.setTime(index, (int) (t2 - t1));
        output.setIterations(index, iter);

        //  Stamp output at recorded
        output.setOutputSet(index, true);

        recordIntrospection("Detection Simulation ", epicenter, ": ", result);
        stopIntrospection();
    }
}
