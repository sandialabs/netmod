/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.gui.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author bjmerch
 *
 */
public class StationsViewer extends NetModComponentViewer<Stations>
{
    private NetModList _list = new NetModList(null, createAddStationButton(), createCopyStationButton(), createRemoveStationButton());

    public StationsViewer(Stations nmc)
    {
        super(nmc, true, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);
    }

    @Override
    public void apply(Stations nmc)
    {
    }

    private JButton createAddStationButton()
    {
        JButton button = GUIUtility.createButton(Icons.ADD.getIcon());
        button.setToolTipText("Create new station");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Get the name of the new station
                String name = JOptionPane.showInputDialog(NetMOD.getFrame(), "Name: ", "Add a new station", JOptionPane.INFORMATION_MESSAGE);
                if (name == null)
                    return;

                //  Don't allow empty names
                name = name.trim();
                if (name.isEmpty())
                    return;
                
                //  Create the station
                Station station = new Station(_nmc, _nmc.getPhases());
                station.setName(name);
                station.setGroup(name);

                //  Add the station
                _nmc.add(station);

                //  Update the display
                refresh();
            }
        });

        return button;
    }
    


    private JButton createCopyStationButton()
    {
        JButton button = GUIUtility.createButton(Icons.COPY.getIcon());
        button.setToolTipText("Copy existing station");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
            	//  Get the existing station
            	Station station = (Station) _list.getSelectedItem();
            	if (station == null)
                    return;

                //  Get the name of the new epicenter grid
                String name = JOptionPane.showInputDialog(NetMOD.getFrame(), "Name: ", "Copy existing station", JOptionPane.INFORMATION_MESSAGE);
                if (name == null)
                    return;
                
                //  Don't allow empty names
                name = name.trim();
                if (name.isEmpty())
                    return;
                
                if ( name.equalsIgnoreCase(station.getName()) )
                {
                	JOptionPane.showMessageDialog(NetMOD.getFrame(), "New station name must be unique", "Network copy error", JOptionPane.WARNING_MESSAGE);
                	return;
                }
                
                //  Create the station
                Station newStation = new Station(_nmc, _nmc.getPhases());
                newStation.setName(name);;
                newStation.setGroup(name);
                
                newStation.setElevation(station.getElevation());
                newStation.setLatitude(station.getLatitude());
                newStation.setLongitude(station.getLongitude());
                newStation.setMediaDensity(station.getMediaDensity());
                newStation.setNoiseSpectraFile(station.getNoiseSpectraFile());
                newStation.setNoiseSpectraSD(station.getNoiseSpectraSD());
                newStation.setNumberChannels(station.getNumberChannels());
                newStation.setReliability(station.getReliability());
                newStation.setStationType(station.getStationType());
                newStation.setTechnology(station.getTechnology());

                for ( StationPhaseParameter spp : station.getPhaseParameters().getParameters())
                {
                	StationPhaseParameter newSPP = newStation.getPhaseParameters().getPhaseParameter(spp.getPhase());
                	                	
                	newSPP.setLogAmplitudeCorrection(spp.getLogAmplitudeCorrection());
                	newSPP.setReceiverMediaVelocity(spp.getReceiverMediaVelocity());
                	newSPP.setSiteResponseFile(spp.getSiteResponseFile());
                	newSPP.setSnrThreshold(spp.getSnrThreshold());
                }
                
                //  Add the station
                _nmc.add(newStation);

                //  Update the display
                refresh();
                
                _list.setSelectedItem(newStation);
            }
        });

        return button;
    }    

    private JButton createRemoveStationButton()
    {
        JButton button = GUIUtility.createButton(Icons.DELETE.getIcon());
        button.setToolTipText("Remove selected stations");

        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                //  Remove the selected stations
                for (Object o : _list.getSelectedItems())
                    if ( o instanceof Station )
                        _nmc.remove((Station) o);

                //  Update the display
                refresh();
            }
        });

        return button;
    }

    @Override
    public JPanel getExpandedPanel()
    {
        return _list;
    }
    
    @Override
    public void refresh()
    {
    	super.refresh();
    	
    	//  Refresh the network viewer so that the network viewer gets refreshed
        _updating = true;
    	refreshParent();
        _updating = false;
    }

    @Override
    public void reset(Stations nmc)
    {
        _list.setItems(nmc.getStations());
    }
}
