/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.plugin;

import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.introspection.Introspection;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.map.Layer;

import javax.swing.*;
import java.util.List;

/**
 * NetModComponent
 * 
 * A high level interface that all components within NetMod must implement:
 *      Projects
 *      Simulations (SeismicDetection, SeismicLocation, InfrasoundDetection, HydroacousticDetection, etc)
 *      Sources
 *      Paths
 *      Receivers
 *      SignalModel
 *      NoiseModel
 *      StationDetectionAlgorithm
 *      NetworkDetectionAlgorithm
 *      etc.
 * 
 * @author bjmerch
 *
 */
public interface NetModComponent extends Cloneable
{
    /**
     * Test whether this NetModComponent can contain the supplied NetModComponent as a child
     * 
     * @param component
     * @return true if this component can contain the provided component, otherwise false.
     */
    public boolean canContain(NetModComponent component);

    /**
     * Clear any cached data
     */
    public void clearCache();

    /**
     * Get the children of this Node. If this Node is a leaf, this method
     * will return an empty list and not null.
     * <p>
     * The list will be sorted in the order in which the Nodes are to be
     * displayed.
     * 
     * @return List of children.
     */
    public List<NetModComponent> getChildren();

    /**
     * Retrieve the icon that will be used for displaying this NetModComponent.
     * Returns null if there is no icon associated.
     * 
     * @return icon
     */
    public Icon getIcon();

    /**
     * Get the introspection object.  Returns null if no object specified.
     * 
     * @return introspection object
     */
    public Introspection getIntrospection();

    /**
     * Get the Map Layer that should be displayed for this component
     * 
     * @return map layer
     */
    public Layer<?> getMapLayer();

    /**
     * Get the name of the NetModComponent
     * 
     * @return name
     */
    public String getName();

    /**
     * Get the component type
     * 
     * @return component type
     */
    public String getType();
    
    /**
     * Get the parent of this NetModComponent.
     * Returns null if the component has no parent.
     * 
     * @return parent component
     */
    public NetModComponent getParent();

    /**
     * Get the general viewer for this component
     * 
     * @return viewer
     */
    public NetModComponentViewer<? extends NetModComponent> getViewer();

    /**
     * Check whether this netmod component is the appropriate component for the provided object.
     * For example, the object may be a string of a file that references a resource on disk.
     * If this NetModComponent has the ability to load data from a file, this method
     * will check whether the file is of a valid format and type.
     * 
     * @param o
     * @return true if appropriate component, otherwise false.
     */
    public boolean isFor(Object o);

    /**
     * Check if the Node is a leaf node.
     * Only nodes whose associated object is a Test are leaf nodes.
     * 
     * @return true if the TocNode is a leaf, otherwise false.
     */
    public boolean isLeaf();

    /**
     * Load the component state from the provided parameters
     * 
     * @param parameters
     */
    public void load(NetSimParameters parameters) throws Exception;

    /**
     * Save the component state to the provided parameters
     * 
     * @param parameters Parameters to save to
     * @param files if true, export referenced files.  If false, save just the parameters without the referenced files being exported.
     * @param reset if true, export any referenced files to a new location relative the parameter set location
     *              if false, export referenced files to their existing locations if needed.
     */
    public void save(NetSimParameters parameters, boolean files, boolean reset) throws Exception;

    /**
     * Set the children of this NetModComponent
     * 
     * @param children
     */
    public void setChildren(List<NetModComponent> children);
    
    /**
     * Set the parent of this NetModComponent
     * 
     * @param parent
     */
    public void setParent(NetModComponent parent);

    /**
     * @param introspection
     */
    public void setIntrospection(Introspection introspection);

    /**
     * Set the name of the NetModComponent
     * 
     * @param name
     */
    public void setName(String name);
}
