/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io.libpar;

import java.io.IOException;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;

/**
 * A Reader that seamlessly reads characters from the given
 * list of Strings.  The characters are read from the start of the first
 * String in the list to the last character in that String.  An option is given to
 * introduce a newline character after each element in the List except the last.  This makes
 * it easy to turn a list of Strings into a stream of Strings each element on its own line.
 * {@code EOF} will be reached when the last String in the List is exhausted.  This Reader does
 * not support Mark.<br /><br />
 */
public class ListReader extends Reader
{

    private final List<String> ls;
    private boolean isClosed;
    private boolean eofReached;
    private final boolean newlines;
    private int index;

    /**
     * Creates a Reader that seamlessly reads characters from the given
     * list of Strings.  The characters are read from the start of the first
     * String in the list to the last character in that String.  Once the end
     * of a single String element in the list is exhausted, one of two things
     * will happen.  Depending on {@code newlines}, only if it is {@code true} then
     * a newline character {@literal '\n'} will be inserted.  In either case, the
     * following character will be the start of the next String in the List.  {@code EOF}
     * will be reached when the last String in the List is exhausted.  This Reader does
     * not support Mark.<br /><br />
     * This ListReader makes a defensive copy of the given list, so future modifications
     * will not affect it.
     * @param ls - The list to read from.
     * @param newlines - If '\n' characters should be inserted after each String element
     * in the List except the last one.
     */
    public ListReader(List<String> ls, boolean newlines)
    {
        this.ls = new LinkedList<String>(ls);
        isClosed = false;
        eofReached = false;
        this.newlines = newlines;
        index = 0;
    }

    @Override
    public boolean markSupported()
    {
        return false;
    }

    @Override
    public int read(char[] cbuf, int off, int len) throws IOException
    {
        if (isClosed)
            throw new IOException("This List Reader has been closed");
        if (eofReached)
            return -1;
        int pos = 0;
        if (ls.size() == 0)
        {
            eofReached = true;
            return -1;
        }
        String curr = ls.get(0);
        while (len > 0)
        {
            if (index >= curr.length())
            {
                ls.remove(0);
                if (ls.size() == 0)
                {
                    eofReached = true;
                    if (pos == 0)
                        return -1;
                    break;
                }
                curr = ls.get(0);
                index = 0;
                if (newlines)
                {
                    cbuf[off + pos] = '\n';
                    pos++;
                    len--;
                }
                continue;
            }
            cbuf[off + pos] = curr.charAt(index);
            len--;
            pos++;
            index++;
        }
        return pos;
    }

    @Override
    public void close() throws IOException
    {
        isClosed = true;
    }

}
