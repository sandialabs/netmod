package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import gov.sandia.gnem.netmod.infra.path.wind.jg2s.G2SDB.GSINFO;
import gov.sandia.gnem.netmod.infra.path.wind.jhwm08.HWM08;
import gov.sandia.gnem.netmod.io.IOUtility;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;

class LoadFile
{

	private static String getString(ByteBuffer buffer, int len)
	{
		byte[] charBuffer = new byte[len];
		buffer.get(charBuffer);

		return new String(charBuffer);
	}

	static G2SDB loadfile(String filename)
	{
		G2SDB g2sdb = new G2SDB();

		// Reset global state variables
		g2sdb.SIGMA = false;
		g2sdb.DENSITY = false;
		g2sdb.V4 = false;
		g2sdb.lastlat = -999.0;
		g2sdb.lastlon = -999.0;
		g2sdb.lastnalt = 1002;

		// Map the file
		ByteBuffer buffer = LoadFile.map(filename);

		// Read in the header information
		int startPosition = buffer.position();
		buffer.order(ByteOrder.LITTLE_ENDIAN);
		g2sdb.info = read_header(buffer);

		// Check if the byte order needs to be swapped
		if (g2sdb.info.year < 1900 || g2sdb.info.year > 2100)
		{
			buffer.order(ByteOrder.BIG_ENDIAN);
			buffer.position(startPosition);

			g2sdb.info = read_header(buffer);
		}

		// Parse some of the header information
		if (g2sdb.info.desc.contains("WF"))
		{
			g2sdb.SIGMA = true;
		}
		if (g2sdb.info.desc.contains("d"))
		{
			g2sdb.DENSITY = true;
		}
		if (g2sdb.info.desc.contains("4.0"))
		{
			g2sdb.V4 = true;
		}

		g2sdb.ntrunc = g2sdb.info.maxtrunc;
		g2sdb.nzs = g2sdb.info.nlevels;
		g2sdb.g2sfile = filename;

		// Allocate the common field variables
		g2sdb.trunc = new int[g2sdb.nzs];
		g2sdb.zgrid = new float[g2sdb.nzs];
		g2sdb.zs = new float[g2sdb.nzs];

		g2sdb.zag = new double[g2sdb.ntrunc][g2sdb.ntrunc][1];
		g2sdb.zbg = new double[g2sdb.ntrunc][g2sdb.ntrunc][1];

		g2sdb.zas = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.zbs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.tas = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.tbs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.brs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.bis = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.crs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		g2sdb.cis = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];

		// A pressure field if sigma coordinates are used
		if (g2sdb.SIGMA)
		{
			g2sdb.pas = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
			g2sdb.pbs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		}

		// A density field if needed
		if (g2sdb.DENSITY)
		{
			g2sdb.das = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
			g2sdb.dbs = new double[g2sdb.ntrunc][g2sdb.ntrunc][g2sdb.nzs];
		}

		g2sdb.pbar = new double[g2sdb.ntrunc + 1][g2sdb.ntrunc + 1];
		g2sdb.vbar = new double[g2sdb.ntrunc + 1][g2sdb.ntrunc + 1];
		g2sdb.wbar = new double[g2sdb.ntrunc + 1][g2sdb.ntrunc + 1];

		g2sdb.cosl = new double[g2sdb.ntrunc + 1];
		g2sdb.sinl = new double[g2sdb.ntrunc + 1];

		// Read in the data accounting for the various file/data formats
		readIntArray(buffer, g2sdb.trunc);
		readFloatArray(buffer, g2sdb.zgrid);

		if (!g2sdb.SIGMA && !g2sdb.V4)
		{
			read_vsh(buffer, g2sdb, 1, g2sdb.zag);
		}

		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.zas);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.zbs);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.brs);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.bis);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.crs);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.cis);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.tas);
		read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.tbs);

		if (g2sdb.SIGMA)
		{
			g2sdb.nzsp = buffer.getInt();
			read_vsh(buffer, g2sdb, g2sdb.nzsp, g2sdb.pas);
			read_vsh(buffer, g2sdb, g2sdb.nzsp, g2sdb.pbs);

			for (int m = 0; m < g2sdb.nzs - g2sdb.nzsp; m++)
			{
				g2sdb.zgrid[m + g2sdb.nzsp] = g2sdb.zgrid[m];
			}

			g2sdb.beta = 80.0f;
		}

		if (g2sdb.DENSITY)
		{
			read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.das);
			read_vsh(buffer, g2sdb, g2sdb.nzs, g2sdb.dbs);
		}

		unmap(buffer);
//    System.out.println(Arrays.toString(g2sdb.pbar));

		// Load HMW08
		g2sdb.hwm08 = new HWM08();

		return g2sdb;
	}

	/**
	 * Return a memory mapped byte buffer for the provided file.
	 */
	private static ByteBuffer map(String path)
	{
		FileInputStream fis = null;
		
		try
		{
			File file = IOUtility.openFile(path);
			fis = new FileInputStream(file);
			ByteBuffer byteBuffer = ByteBuffer.allocate(fis.available());
			FileChannel channel = fis.getChannel();
			while (channel.read(byteBuffer) != 0)
			{}

			byteBuffer.position(0);
			return byteBuffer;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fis != null )
				IOUtility.safeClose(fis);
		}

		return null;
	}

	private static GSINFO read_header(ByteBuffer buffer)
	{
		GSINFO info = new G2SDB.GSINFO();

		info.version = getString(buffer, 32);
		info.year = buffer.getInt();
		info.month = buffer.getInt();
		info.day = buffer.getInt();
		info.daynumber = buffer.getInt();
		info.utc = buffer.getFloat();
		info.desc = getString(buffer, 32);
		info.f107a = buffer.getFloat();
		info.f107 = buffer.getFloat();
		info.apd = buffer.getInt();
		info.nlevels = buffer.getInt();
		info.maxtrunc = buffer.getInt();

		return info;
	}

	private static void read_vsh(ByteBuffer buffer, G2SDB g2sdb, int nc, double[][][] coeff)
	{
//		System.out.println("");
//		System.out.println("read_vsh");
//		System.out.println("nc: " + nc);
//		System.out.println("ntrunc: " + g2sdb.ntrunc);

		float[] array = new float[g2sdb.ntrunc * (g2sdb.ntrunc + 1) / 2 + 1];

		for (int k = 0; k < nc; k++)
		{
			int trunc_k = g2sdb.trunc[k];
			int size = trunc_k * (trunc_k + 1) / 2;

			readFloatArray(buffer, array, 0, size);

			// System.out.println("k: " + k);
			// System.out.println(Arrays.toString(Arrays.copyOfRange(array,0,10)));
			int c = 0;
			for (int n = 0; n < trunc_k; n++)
			{
				for (int m = 0; m <= n; m++)
				{
					coeff[m][n][k] = array[c];
					c++;
				}
			}
		}
	}

	private static void readFloatArray(ByteBuffer buffer, float[] array)
	{
		readFloatArray(buffer, array, 0, array.length);
	}

	private static void readFloatArray(ByteBuffer buffer, float[] array, int start, int end)
	{
		for (int i = start; i < end; i++)
		{
			array[i] = buffer.getFloat();
		}
	}

	private static void readIntArray(ByteBuffer buffer, int[] array)
	{
		for (int i = 0; i < array.length; i++)
		{
			array[i] = buffer.getInt();
		}
	}

	private static void unmap(ByteBuffer buffer)
	{

	}
}
