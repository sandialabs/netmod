/**
 * Copyright (C) 2012,	Aaron Easter
 * Sandia Corporation (Sandia National	Laboratories)
 * Albuquerque, NM, 87185-1004
 * All rights reserved.
 *
 * This software was developed	at Sandia National Laboratories, which is
 * operated by	the	Sandia Corporation under contract for the United States
 * Department of Energy.  This	software is	is protected by	copyright under
 * the	laws of	the	United States.	This software is not to	be disclosed or
 * duplicated without express written authorization from Sandia
 * Corporation.
 *
 * Notice: This computer software was prepared by Sandia Corporation,
 * hereinafter the Contractor, under Contract DE-AC04-94AL85000 with the
 * Department of Energy (DOE). All rights in the computer software are
 * reserved by DOE on behalf of the United States Government and the
 * Contractor as provided in the Contract. You are authorized to use this
 * computer software for Governmental purposes but it is not to be released
 * or distributed to the public. NEITHER THE U.S. GOVERNMENT NOR THE
 * CONTRACTOR MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY
 * LIABILITY FOR THE USE OF THIS SOFTWARE. This notice including this sentence
 * must appear on any copies of this computer software.
 *
 * Ported From:
 * Horizontal Wind Model 08 (HWM08)
 * Version HWM071308E_DWM07B104i.01
 * See readme.txt file for detailed release notes.
 *
 * AUTHORS
 * Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 * DATE
 * 6 April 2009
 *
 * REFERENCES
 * Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner,
 * Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez,
 * M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu,
 * Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model
 * of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 * Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W.
 * Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 * DWM07 global empirical model of upper thermospheric storm-induced
 * disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */

/**
 * Ported From:
 *  Horizontal Wind Model 08 (HWM08)
 *  Version HWM071308E_DWM07B104i.01
 *  See readme.txt file for detailed release notes.
 *
 *  AUTHORS
 *    Douglas P. Drob, John T. Emmert, msishwmhelp@nrl.navy.mil
 *
 *  DATE
 *    6 April 2009
 *
 *  REFERENCES
 *    Drob, D. P, J. T. Emmert, G. Crowley, J. M. Picone, G. G. Shepherd, W. Skinner, 
 *      Paul Hayes, R. J. Niciejewski, M. Larsen, C.Y. She, J. W. Meriwether, G. Hernandez, 
 *      M. J. Jarvis, D. P. Sipler, C. A. Tepley, M. S. O'Brien, J. R. Bowman, Q. Wu, 
 *      Y. Murayama, S. Kawamura, I.M. Reid, and R.A. Vincent (2008), An Empirical Model 
 *      of the Earth's Horizontal Wind Fields: HWM07, J. Geophy. Res., doi:10.1029/2008JA013668.
 *    Emmert, J. T., D. P. Drob, G. G. Shepherd, G. Hernandez, M. J. Jarvis, J. W. 
 *      Meriwether, R. J. Niciejewski, D. P. Sipler, and C. A. Tepley (2008),
 *      DWM07 global empirical model of upper thermospheric storm-induced 
 *      disturbance winds, J. Geophys Res., 113, doi:10.1029/2008JA013541.
 */
package gov.sandia.gnem.netmod.infra.path.wind.jhwm08;

/**
 * @author aceaste
 *
 */
public class DWM07b {

  private double[] vshTerms0; // VSH basis values
  private double[] vshTerms1; // VSH basis values
  private double[] termval0; // Term values to which coefficients are applied
  private double[] termval1; // Term values to which coefficients are applied

  private double[][] dpbar; // Associated legendre fns
  private double[][] dvbar;
  private double[][] dwbar;
  private double[] mltTerms0; // MLT Fourier terms
  private double[] mltTerms1; // MLT Fourier terms

  // Storage for previous values in order to limit recalculations when values don't change
  private double mltLast;
  private double mlatLast;
  private double kpLast;
  private double glatLast;
  private double glonLast;
  private double dayLast;
  private double utLast;
  private double apLast;

  private double mmpwind; // Meridional disturbance wind (+north, QD coordinates)

  private double mzpwind; // Zonal disturbance wind (+east, QD coordinates)
  private double mlt; // Magnetic local time
  public double[][] f; // Coefficients
  private double[] kpTerms; //
  private double[] mCoord; //
  private double kp; // 3-hour Kp

  public GD2QD gdqd;

  public final double sineps = 0.39781868;

  //  used in dwm_latwgt2
  final double[] coeff = new double[]{65.7633, -4.60256, -3.53915, -1.99971, -0.752193, 0.972388};

  public DWM07b() {
    DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();

    mltLast = (Double.MAX_VALUE);
    mlatLast = (Double.MAX_VALUE);
    kpLast = (Double.MAX_VALUE);
    glatLast = (Double.MAX_VALUE);
    glonLast = (Double.MAX_VALUE);
    dayLast = (Double.MAX_VALUE);
    utLast = (Double.MAX_VALUE);
    apLast = (Double.MAX_VALUE);
    mmpwind = (0);
    mzpwind = (0);
    mlt = 0;
    kp = 0;

    termval0 = new double[dwm07b_data.nterm];
    termval1 = new double[dwm07b_data.nterm];
    dpbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
    dvbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
    dwbar = new double[dwm07b_data.nmax + 1][dwm07b_data.mmax + 1];
    mltTerms0 = new double[dwm07b_data.mmax + 1];
    mltTerms1 = new double[dwm07b_data.mmax + 1];
    vshTerms0 = new double[dwm07b_data.nvshterm];
    vshTerms1 = new double[dwm07b_data.nvshterm];

    f = new double[][]{{0, 0}, {0, 0}};
    kpTerms = new double[3];
    mCoord = (new double[]{0, 0});

    gdqd = new GD2QD();

  }

  /**
   * Computes a latitude dependent weighting function that goes to Zero at low latitudes and
   * one at high latitudes. The transition Is an exponential s-curve, with the transition
   * latitude determined by a MLT/Kp model.
   */
  public double dwm_latwgt2(double mlat, double kp0) {
    DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();

    double kp, mltrad, sinmlt, cosmlt, tlat;

    mltrad = Math.toRadians(mlt * 15.0);
    sinmlt = Math.sin(mltrad);
    cosmlt = Math.cos(mltrad);
    kp = Math.min(Math.max(kp0, 0.0), 8.0);
    tlat = coeff[0] + coeff[1] * cosmlt + coeff[2] * sinmlt + kp * (coeff[3] + coeff[4] * cosmlt
        + coeff[5] * sinmlt);

    return (1.0 / (1 + Math.exp(-(Math.abs(mlat) - tlat) / dwm07b_data.twidth)));
  }

  /**
   * Evaluates the disturbance wind model.
   */
  public void dwm07b(double mlat, double kp, ALF alf) throws Exception {
    DWM07b_Data dwm07b_data = DWM07b_Data.getInstance();

    double latwgtTerm;
    double theta, phi, mphi;
    int ivshterm;

    // Compute Latitude part of VSH terms
    if (mlat != mlatLast) {
      theta = Math.toRadians(90.0 - mlat);
      alf.ALFBasis(theta, dpbar, dvbar, dwbar);
    }

    // Compute MLT part of VSH terms
    if (mlt != mltLast) {
      phi = Math.toRadians(mlt) * 15.0;
      for (int m = 0; m <= dwm07b_data.mmax; m++) {
        mphi = m * phi;
        mltTerms0[m] = Math.cos(mphi);
        mltTerms1[m] = Math.sin(mphi);
      }
    }

    // Compute VSH terms
    if ((mlat != mlatLast) || (mlt != mltLast)) {
      ivshterm = 0;

      for (int n = 1; n <= dwm07b_data.nmax; n++) {
        double[] dvbar_n = dvbar[n];
        double[] dwbar_n = dwbar[n];

        vshTerms0[ivshterm] = (double) (-dvbar_n[0] * mltTerms0[0]);
        vshTerms0[ivshterm + 1] = (double) (dwbar_n[0] * mltTerms0[0]);
        vshTerms1[ivshterm] = -vshTerms0[ivshterm + 1];
        vshTerms1[ivshterm + 1] = vshTerms0[ivshterm];
        ivshterm += 2;

        for (int m = 1; m <= dwm07b_data.mmax; m++) {
          if (m > n) {
            continue;
          }

          vshTerms0[ivshterm] = (double) (-dvbar_n[m] * mltTerms0[m]);
          vshTerms0[ivshterm + 1] = (double) (dvbar_n[m] * mltTerms1[m]);
          vshTerms0[ivshterm + 2] = (double) (dwbar_n[m] * mltTerms1[m]);
          vshTerms0[ivshterm + 3] = (double) (dwbar_n[m] * mltTerms0[m]);
          vshTerms1[ivshterm] = -vshTerms0[ivshterm + 2];
          vshTerms1[ivshterm + 1] = -vshTerms0[ivshterm + 3];
          vshTerms1[ivshterm + 2] = vshTerms0[ivshterm];
          vshTerms1[ivshterm + 3] = vshTerms0[ivshterm + 1];
          ivshterm += 4;
        }
      }
    }

    // Compute KP terms
    if (kp != kpLast) {
      dwm_kpsp13(kp, kpTerms);
    }

    //Compute Latitudinal Weighting Terms
    latwgtTerm = dwm_latwgt2(mlat, kp);

    // Generate Coupled terms
    for (int i = 0; i < dwm07b_data.nterm; i++) {
      int t0 = dwm07b_data.termarr0[i];
      int t1 = dwm07b_data.termarr1[i];
      int t2 = dwm07b_data.termarr2[i];

      double termval_temp0 = 1;
      double termval_temp1 = 1;

      if (t0 != 999) {
        termval_temp0 *= vshTerms0[t0];
        termval_temp1 *= vshTerms1[t0];
      }
      if (t1 != 999) {
        termval_temp0 *= kpTerms[t1];
        termval_temp1 *= kpTerms[t1];
      }
      if (t2 != 999) {
        termval_temp0 *= latwgtTerm;
        termval_temp1 *= latwgtTerm;
      }
      termval0[i] = termval_temp0;
      termval1[i] = termval_temp1;
    }

    // Apply coefficients
    mmpwind = (mathutil.dot_product(dwm07b_data.coeff, termval0, dwm07b_data.nterm));
    mzpwind = (mathutil.dot_product(dwm07b_data.coeff, termval1, dwm07b_data.nterm));

    mlatLast = (mlat);
    mltLast = (mlt);
    kpLast = (kp);
  }

  /**
   * Using HWM inputs, computes Quasi-dipole latitude and local time, and Kp. Retrieves DWM
   * results for these conditions, converts to geographic directions, and applies artificial
   * height profile.
   */
  public void DWM07b_HWM_interface(int iyd, double sec, double alt, double glat, double glon,
      double[] ap, double[] dw, ALF alf) throws Exception {
    double day, ut;
    final double talt = 125.0, twidth = 5.0;

    // Convert AP to KP
    if (ap[1] != apLast) {
      kp = ap2kp(ap[1]);
    }

    // Convert Geo Lat/Lon to QD Lat/Lon
    if ((glat != glatLast) || (glon != glonLast)) {
      try {
        gdqd.gd2qd(glat, glon, mCoord, f, alf);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    //Compute QD magnetic local time (low precision)
    day = iyd % 1000;
    ut = sec / 3600.0;

    if (day != dayLast || ut != utLast || glat != glatLast || glon != glonLast) {
      mlt = mltCalc(mCoord, day, ut, alf);
    }

    //Retrieve DWM winds
    if (mCoord[0] != mlatLast || mlt != mltLast || kp != kpLast) {
      dwm07b(mCoord[0], kp, alf);
    }

    // Convert to geographic coordinates
    dw[0] = (double) (f[1][1] * mmpwind + f[0][1] * mzpwind);
    dw[1] = (double) (f[1][0] * mmpwind + f[0][0] * mzpwind);

    // Apply height profile
    dw[0] /= (double) (1 + Math.exp(-(alt - talt) / twidth));
    dw[1] /= (double) (1 + Math.exp(-(alt - talt) / twidth));

    glatLast = (glat);
    glonLast = (glon);
    dayLast = (day);
    utLast = (ut);
    apLast = (ap[1]);

  }

  /**
   * @return the apLast
   */
  public double getApLast() {
    return apLast;
  }

  /**
   * @return the dayLast
   */
  public double getDayLast() {
    return dayLast;
  }

  /**
   * @return the glatLast
   */
  public double getGlatLast() {
    return glatLast;
  }

  /**
   * @return the glonLast
   */
  public double getGlonLast() {
    return glonLast;
  }

  /**
   * @return the kpLast
   */
  public double getKpLast() {
    return kpLast;
  }

  /**
   * @return the mCoord
   */
  public double[] getmCoord() {
    return mCoord;
  }

  /**
   * @return the mlatLast
   */
  public double getMlatLast() {
    return mlatLast;
  }

  /**
   * @return the mlt
   */
  public double getMlt() {
    return mlt;
  }

  /**
   * @return the mltLast
   */
  public double getMltLast() {
    return mltLast;
  }

  /**
   * @return the mmpwind
   */
  public double getMmpwind() {
    return mmpwind;
  }

  /**
   * @return the mzpwind
   */
  public double getMzpwind() {
    return mzpwind;
  }

  /**
   * @return the utLast
   */
  public double getUtLast() {
    return utLast;
  }

  /**
   * Low-precision calculation of magnetic local time.
   */
  public double mltCalc(double[] qCoord, double day, double ut, ALF alf) throws Exception {
    double asunglat, asunglon, asunqlon, theta, phi;
    double mphi, cosmphi, sinmphi, x, y;
    int i;

    // Compute Geographic coordinates of anti-sunward direction (low precision)
    asunglat = -Math
        .toDegrees(Math.asin(Math.sin(Math.toRadians(day + ut / 24.0 - 80.0)) * sineps));
    asunglon = -ut * 15.0;

    // Compute Magnetic coordinates of anti-sunward direction
    theta = Math.toRadians(90.0 - asunglat);
    alf.ALFBasisSBar(theta);
    phi = Math.toRadians(asunglon);

    GD2QD_Data gd2qd_data = GD2QD_Data.getInstance();

    i = 0;
    for (int n = 0; n <= gd2qd_data.nmax; n++) {
      gdqd.sh[i] = alf.getSpbar(n, 0);
      i++;
    }
    for (int m = 1; m <= gd2qd_data.mmax; m++) {
      mphi = m * phi;
      cosmphi = Math.cos(mphi);
      sinmphi = Math.sin(mphi);

      for (int n = m; n <= gd2qd_data.nmax; n++) {
        gdqd.sh[i] = alf.getSpbar(n, m) * cosmphi;
        gdqd.sh[i + 1] = alf.getSpbar(n, m) * sinmphi;
        i += 2;
      }
    }

    x = mathutil.dotProduct(gdqd.sh, gd2qd_data.xcoeff);
    y = mathutil.dotProduct(gdqd.sh, gd2qd_data.ycoeff);
    asunqlon = Math.toDegrees(Math.atan2(y, x));

    // Compute mlt
    return ((qCoord[1] - asunqlon) / 15.0);
  }

  /**
   * @param apLast the apLast to set
   */
  public void setApLast(double apLast) {
    this.apLast = apLast;
  }

  /**
   * @param dayLast the dayLast to set
   */
  public void setDayLast(double dayLast) {
    this.dayLast = dayLast;
  }

  /**
   * @param glatLast the glatLast to set
   */
  public void setGlatLast(double glatLast) {
    this.glatLast = glatLast;
  }

  /**
   * @param glonLast the glonLast to set
   */
  public void setGlonLast(double glonLast) {
    this.glonLast = glonLast;
  }

  /**
   * @param kpLast the kpLast to set
   */
  public void setKpLast(double kpLast) {
    this.kpLast = kpLast;
  }

  /**
   * @param mCoord the mCoord to set
   */
  public void setmCoord(double[] mCoord) {
    this.mCoord = mCoord;
  }

  /**
   * @param mlatLast the mlatLast to set
   */
  public void setMlatLast(double mlatLast) {
    this.mlatLast = mlatLast;
  }

  /**
   * @param mlt the mlt to set
   */
  public void setMlt(double mlt) {
    this.mlt = mlt;
  }

  /**
   * @param mltLast the mltLast to set
   */
  public void setMltLast(double mltLast) {
    this.mltLast = mltLast;
  }

  /**
   * @param mmpwind the mmpwind to set
   */
  public void setMmpwind(double mmpwind) {
    this.mmpwind = mmpwind;
  }

  /**
   * @param mzpwind the mzpwind to set
   */
  public void setMzpwind(double mzpwind) {
    this.mzpwind = mzpwind;
  }

  /**
   * @param utLast the utLast to set
   */
  public void setUtLast(double utLast) {
    this.utLast = utLast;
  }

  //  Arrays used in ap2kp
  private final double[] apgrid = new double[]{0.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 9.0, 12.0, 15.0,
      18.0, 22.0, 27.0, 32.0, 39.0, 48.0, 56.0, 67.0, 80.0, 94.0,
      111.0, 132.0, 154.0, 179.0, 207.0, 236.0, 300.0, 400.0};
  private final double[] kpgrid = new double[]{0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,
      10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0,
      21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 27.0};

  {
    for (int j = 0; j < kpgrid.length; j++) {
      kpgrid[j] /= 3.0;
    }
  }

  /**
   * Converts ap values to Kp values, via linear interpolation on the lookup table.
   */
  private double ap2kp(double ap0) {
    double ap;
    int i;

    ap = ap0;
    if (ap < 0) {
      ap = 0;
    }
    if (ap > 400) {
      ap = 400;
    }

    for (i = 0; ap > apgrid[i]; i++) {
      ;
    }

    if (ap == apgrid[i]) {
      return kpgrid[i];
    }

    return (kpgrid[i - 1] + (ap - apgrid[i - 1]) / (3.0 * (apgrid[i] - apgrid[i - 1])));
  }

  //  Arrays used in dwm_kpsp13
  private double[] kpspl = new double[7];
  private final double[] node = new double[]{-10.0, -8.0, 0.0, 2.0, 5.0, 8.0, 18.0, 20.0};

  /**
   * Computes a quadratic spline basis for the Kp dependence. Covers the interval [0,8],
   * with 2 interior nodes at Kp = 2 and 5. The basis is constrained to have zero slope at
   * the bounds.
   */
  private void dwm_kpsp13(double kp, double[] kpTerms) {
    double x;
    double[] kpspl = new double[7];
    final double[] node = new double[]{-10.0, -8.0, 0.0, 2.0, 5.0, 8.0, 18.0, 20.0};

    x = Math.min(Math.max(kp, 0.0), 8.0);

    kpTerms[0] = 0.0;
    kpTerms[1] = 0.0;
    kpTerms[2] = 0.0;

    for (int i = 0; i < 7; i++) {
      kpspl[i] = 0;
      if ((x >= node[i]) && (x < node[i + 1])) {
        kpspl[i] = 1.0;
      }
    }
    for (int j = 2; j <= 3; j++) {
      for (int i = 0; i < 8 - j; i++) {
        kpspl[i] = kpspl[i] * (x - node[i]) / (node[i + j - 1] - node[i])
            + kpspl[i + 1] * (node[i + j] - x) / (node[i + j] - node[i + 1]);
      }
    }

    kpTerms[0] = kpspl[0] + kpspl[1];
    kpTerms[1] = kpspl[2];
    kpTerms[2] = kpspl[3] + kpspl[4];

  }

}
