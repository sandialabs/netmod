/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.event.SelectEvent;
import gov.nasa.worldwind.event.SelectListener;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.pick.PickedObject;
import gov.nasa.worldwind.render.*;
import gov.nasa.worldwind.util.VecBufferBlocks;
import gov.sandia.gnem.netmod.geometry.MediaGrid;
import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.geometry.Region;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.Property;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author bjmerch
 *
 */
class MediaGridLayer extends RenderableLayer implements Layer<MediaGrid<NetModComponent>>, SelectListener
{
    private MediaGrid _mediaGrid;
    private GlobeAnnotation _tooltip;
    private WorldWindow _wwd;
    
    protected MediaGridLayer(WorldWindow wwd, MediaGrid grid)
    {
        _wwd = wwd;
        
        //  Initialize the tooltip
        _tooltip = new GlobeAnnotation("", Position.fromDegrees(0,  0, 0));
        _tooltip.getAttributes().setFont(new Font("Dialog", Font.PLAIN, Property.FONT_SIZE.getIntegerValue()));
        _tooltip.getAttributes().setDistanceMinOpacity(1);
        _tooltip.getAttributes().setDistanceMaxScale(1);
        _tooltip.getAttributes().setVisible(false);
        _tooltip.getAttributes().setAdjustWidthToText(AVKey.SIZE_FIT_TEXT);
        _tooltip.getAttributes().setLeaderGapWidth(20);
        _tooltip.setAlwaysOnTop(true);
    }
    
    @Override
    public void dispose()
    {
        
    }

    @Override
    public DISPLAY getDisplay()
    {
        return DISPLAY.ALL;
    }
    
    @Override
    public JPanel getLegendPanel()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        int count = 0;
        for (NetModComponent type : getNMC().getMediaTypes())
        {
            Color c = getColor(count++);
            
            GUIUtility.addRow(panel, new JLabel(""), generatePolygon(new Color(c.getRed(), c.getGreen(), c.getBlue(), 128), Color.BLACK, 1.0, type.toString()));
        }
        
        return panel;
    }

    @Override
    public String getName()
    {
        return _mediaGrid.getName();
    }
    
    @Override
    public MediaGrid<NetModComponent> getNMC()
    {
        return _mediaGrid;
    }

    @Override
    public void selected(SelectEvent event)
    {
        if ( event.isConsumed() )
            return;
        
        if ( event.getEventAction().equals(SelectEvent.ROLLOVER) )
        {
            PickedObject object = event.getTopPickedObject();
            if (object != null && object.getParentLayer() == this)
            {
                Position position = object.getPosition();
                if ( position != null )
                {
                    NetModComponent type = _mediaGrid.getMediaType(
                            position.getLongitude().getDegrees(), 
                            position.getLatitude().getDegrees());
                    
                    _tooltip.setPosition(position);
                    _tooltip.setText((type == null ? "" : type.toString()));
                    _tooltip.getAttributes().setVisible(true);
                    
                    event.consume();
                }                
            }
        }
        else
            _tooltip.getAttributes().setVisible(false);
        
    }

    @Override
    public void setDisplay(DISPLAY display)
    {
        
    }

    @Override
    public void setNMC(MediaGrid<NetModComponent> data)
    {
        _mediaGrid = data;
        
        setPickEnabled(true);
        
        //  Determine the total size of the regions
        List<Region> regions = data.getRegions();
        int Npoints = 0;
        for (Region region : regions)
            Npoints += region.getVertices().size() + 1;
        
        //  Allocate memory
        int scale = java.lang.Double.SIZE / 8 * 2;
        byte[] bytes = new byte[scale * Npoints];
        
        //  Create a compound vector buffers to hold them
        Map<NetModComponent,  VecBufferBlocks> vectorMap = new HashMap<NetModComponent,  VecBufferBlocks>();
        for (NetModComponent type : data.getMediaTypes())
            vectorMap.put(type, new VecBufferBlocks(2, AVKey.FLOAT64, ByteBuffer.wrap(bytes)));

        //  Load the region coordinates into a byte buffer
        Npoints = 0;
        DoubleBuffer doubleBuffer = ByteBuffer.wrap(bytes).asDoubleBuffer();
        for (Region region : regions)
        {
            Point.Double p1 = null;
            
            //  Load all of the verticies
            for (Point.Double p : region.getVertices())
            {
                if ( p1 == null )
                    p1 = p;
                
                doubleBuffer.put(p.getLongitude());
                doubleBuffer.put(p.getLatitude());
            }

			if (p1 != null)
			{
				// Close the region
				doubleBuffer.put(p1.getLongitude());
				doubleBuffer.put(p1.getLatitude());

				// Add an index block for the media type at this point
				NetModComponent type = data.getMediaType(p1);

				int regionPoints = region.getVertices().size() + 1;
				vectorMap.get(type).addBlock(scale * Npoints, scale * (Npoints + regionPoints) - 1);
				Npoints += regionPoints;
			}
        }
        
        //  Plot each media type
        int count = 0;
        clearRenderables();
        for (NetModComponent type : data.getMediaTypes())
        {
            //  Define the attributes
            ShapeAttributes attrs = new BasicShapeAttributes();
            attrs.setInteriorOpacity(0.5);
            attrs.setInteriorMaterial(new Material(getColor(count++)));
            attrs.setOutlineOpacity(0.8);
            attrs.setOutlineWidth(1);
            attrs.setOutlineMaterial(Material.BLACK);
            attrs.setDrawOutline(false);
            attrs.setDrawInterior(true);

            //  Construct the polygons
            SurfacePolygons polygons = new SurfacePolygons(Sector.fromDegrees(-90, 90, -180, 180), vectorMap.get(type));
            polygons.setAttributes(attrs);

            //  Add the polygons
            addRenderable(polygons);
        }
        
        //  Add the tooltip
        addRenderable(_tooltip);
    }
    @Override
    public void setVisible(boolean value)
    {
        setEnabled(value);
    }

    /**
     * Generate a label that uses the provided image as an icon
     * and uses the provided range as a label.
     * 
     * @param image
     * @param range
     * @return
     */

    private JLabel generateLabel(BufferedImage image, String text)
    {
        JLabel label = new JLabel();

        if (image != null)
            label.setIcon(new ImageIcon(image));

        label.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        label.setText((text == null ? "" : text));

        return label;
    }

    /**
     * Generate a label the represents a polygon symbology
     * 
     * @param fillType
     * @param fillPaint
     * @param range
     * @return
     */
    private JLabel generatePolygon(Paint fillPaint, Color lineColor, double width, String overridelabel)
    {
        BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g = image.createGraphics();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(fillPaint);
        g.fillRect(0, 0, 16, 16);

        g.setColor(lineColor);
        g.setStroke(new BasicStroke((float) width, BasicStroke.CAP_SQUARE, 1, BasicStroke.JOIN_MITER, null, 0));
        g.drawRect(0, 0, 15, 15);
        g.dispose();

        return generateLabel(image, overridelabel);
    }

    /**
     * Get the i'th color
     * 
     * @param i
     * @return
     */
    private Color getColor(int i)
    {
        List<Color> colors = Property.MEDIA_GRID_COLOR_PALETTE.getColorPaletteValue();
        
        return colors.get(i % colors.size());
    }
}
