/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.io;

import gov.sandia.gnem.netmod.gui.GUIUtility;

import java.io.*;
import java.net.URL;
import java.util.Locale;

/**
 * @author bjmerch
 *
 */
public class IOUtility
{
	/**
	 * Fix the path separators in the provided file path to conform to the platform
	 * specific path separator.
	 * 
	 * @param path
	 * @return
	 */
	public static String fixPathSeparator(String path)
	{
		if (path == null)
			return "";

		String new_path = path.replace('\\', '/');

		return new_path;
	}

	/**
	 * Find the file referred to by the provided file reference
	 * 
	 * @param file
	 * @return
	 */
	public static final File findFile(File file)
	{
		if (file.exists())
			return file;

		// Look for a file relative to the code location
		String location = IOUtility.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		File locationFile = openFile(location.substring(0, location.lastIndexOf("/")));
		File newFile = IOUtility.openFile(locationFile, file.getPath());
		if (newFile.exists())
			return newFile;

		// Look for a file up on level from the code location
		newFile = openFile(locationFile.getParent(), file.getPath());
		if (newFile.exists())
			return newFile;

		// Check the parent folder
		newFile = openFile(openFile(location).getParent(), file.getPath());
		if (newFile.exists())
			return newFile;

		// Check for a path relative to the starting location
		newFile = openFile(System.getProperty("user.dir"), file.getPath());
		if (newFile.exists())
			return newFile;

		return file;
	}

	/**
	 * Copy the contents of the provided URL to a local file and return the
	 * reference to the file
	 * 
	 * @param url
	 * @return
	 */
	public static final File writeFile(URL url, String filename)
	{
		File file = IOUtility.openFile(System.getProperty("user.dir"), filename);
		InputStream is = null;
		OutputStream os = null;

		try
		{
			is = new BufferedInputStream(url.openStream());

			if (file.exists())
				file.delete();

			if (!file.exists())
			{
				file.createNewFile();

				os = new FileOutputStream(file);

				byte buf[] = new byte[8096];
				int len;
				while ((len = is.read(buf)) > 0)
					os.write(buf, 0, len);
			}

			return file;

		}
		catch (Exception ex)
		{
			GUIUtility.showExceptionDialog(null, "Error opening URL", "Unable to locate URL: " + url, ex);
		}
		finally
		{
			if ( is != null )
				safeClose(is);
			if ( os != null )
				safeClose(os);
		}

		return file;
	}

	/**
	 * Write the content of the URL into a tempfile with the given filename
	 *
	 * @param url
	 * @param filename
	 * @return
	 */
	public static final File writeTmpFile(URL url, String filename)
	{
		try
		{
			return writeTmpFile(url.openStream(), filename);
		}
		catch (Exception e)
		{
		}

		return null;
	}

	/**
	 * Write the content of the inputstream into a tempfile with the given filename
	 *
	 * @param is
	 * @param filename
	 * @throws IOException
	 */
	public static final File writeTmpFile(InputStream is, String filename)
	{
		// Create a temporary file
		File tmpFile = IOUtility.openFile(System.getProperty("java.io.tmpdir"), filename);

		// Create any directories that are needed
		tmpFile.getParentFile().mkdirs();

		// Check if it's a directory
		if (tmpFile.isDirectory())
			tmpFile.delete();

		// Delete if file already exists
		if (tmpFile.exists())
			tmpFile.delete();

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tmpFile);
			byte[] buffer = new byte[8096];
			int len;
			while ((len = is.read(buffer)) != -1)
			{
				fos.write(buffer, 0, len);
			}
		}
		catch (Exception e)
		{
		}
		finally
		{
			if (fos != null)
				IOUtility.safeClose(fos);;
		}

		return tmpFile;
	}

	/**
	 * Copy the source file to the destination files
	 * 
	 * @param src_file
	 * @param dst_file
	 */
	public static void copy(String src_file, String dst_file)
	{
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try
		{
			fis = new FileInputStream(openFile(src_file));
			fos = new FileOutputStream(openFile(dst_file));
			byte[] buffer = new byte[8096];
			int len;
			while ((len = fis.read(buffer)) != -1)
				fos.write(buffer, 0, len);
		}
		catch (Exception e)
		{
		}
		finally
		{
			if (fos != null)
				IOUtility.safeClose(fos);
			if (fis != null)
				IOUtility.safeClose(fis);
		}
	}

	/**
	 * Remove any undesired content from the provided string
	 * 
	 * @param str
	 * @return
	 */
	public static String cleanString(String str)
	{
		if (str == null)
			return null;

		int N = str.length();
		StringBuffer cleanString = new StringBuffer();

		for (int i = 0; i < N; i++)
			cleanString.append(cleanChar(str.charAt(i)));

		return cleanString.toString();
	}

	/**
	 * Clear the provided character
	 * 
	 * @param aChar
	 * @return
	 */
	private static char cleanChar(char aChar)
	{
		// 0 - 9
		for (int i = 48; i < 58; ++i)
		{
			if (aChar == i)
				return (char) i;
		}

		// 'A' - 'Z'
		for (int i = 65; i < 91; ++i)
		{
			if (aChar == i)
				return (char) i;
		}

		// 'a' - 'z'
		for (int i = 97; i < 123; ++i)
		{
			if (aChar == i)
				return (char) i;
		}

		// other valid characters
		switch (aChar)
		{
		case '/':
			return '/';
		case '\\':
			return '\\';
		case ':':
			return ':';
		case '.':
			return '.';
		case '-':
			return '-';
		case '_':
			return '_';
		case ' ':
			return ' ';
		}

		return '%';
	}

	/**
	 * Helper method to open files while ensuring proper screening of the input
	 * 
	 * @param file
	 * @return
	 */
	public static File openFile(String file)
	{
		return new File(cleanString(file));
	}

	/**
	 * Helper method to open files while ensuring proper screening of the input
	 * 
	 * @param file
	 * @return
	 */
	public static File openFile(File path, String file)
	{
		return new File(path, cleanString(file));
	}

	/**
	 * Helper method to open files while ensuring proper screening of the input
	 * 
	 * @param file
	 * @return
	 */
	public static File openFile(String path, String file)
	{
		return new File(cleanString(path), cleanString(file));
	}

	/**
	 * Safely close the provided closeable object.
	 * 
	 * @param c
	 */
	public static void safeClose(Closeable c)
	{
		try
		{
			if (c != null)
				c.close();
		}
		catch (Exception e)
		{
			GUIUtility.showExceptionDialog(null, "Program error", e.getMessage(), e);
		}
	}

	/**
	 * Check if the file ends with the provided extension, disregarding case, in a
	 * locale safe manner
	 * 
	 * @param file
	 * @param ext
	 * @return
	 */
	public static boolean endsWith(File file, String ext)
	{
		String path = file.getPath();

		int i = path.lastIndexOf(".");
		String path_ext = path;
		if ( i > 0 )
			path_ext = path.substring(i);

		return path_ext.equalsIgnoreCase(ext);
	}
}
