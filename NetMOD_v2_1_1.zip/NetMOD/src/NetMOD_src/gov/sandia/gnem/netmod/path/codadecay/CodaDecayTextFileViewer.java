/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.path.codadecay;

import gov.sandia.gnem.netmod.gui.ChartViewer;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.gui.NetMODTable;
import gov.sandia.gnem.netmod.gui.NetMODTable.NetMODTableModel;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.numeric.Distance;
import gov.sandia.gnem.netmod.numeric.Interpolation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.AbstractXYDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * @author bjmerch
 *
 */
public class CodaDecayTextFileViewer extends NetModComponentViewer<CodaDecayTextFile>
{
    private class CodaDecayDataset extends AbstractXYDataset
    {
        int N = 100;
        private CodaDecayTextFile _codaDecay = null;

        @Override
        public int getItemCount(int series)
        {
            if ( series == 0 )
                return (_codaDecay == null ? 0 : _codaDecay.getDistances().length);
            else
                return (_codaDecay == null ? 0 : N * (_codaDecay.getDistances().length - 1) + 1);
        }

        @Override
        public int getSeriesCount()
        {
            return 2;
        }

        @Override
        public Comparable getSeriesKey(int series)
        {
            return "Coda Decay";
        }

        @Override
        public Number getX(int series, int item)
        {
            if (series == 0)
                return _codaDecay.getDistances()[item];
            else
            {
                int index = item / N;
                double[] d = _codaDecay.getDistances();

                if (index == d.length - 1)
                    return d[index];

                return Interpolation.linear(index * N, (index + 1) * N, d[index], d[index + 1], item);
            }
        }

        @Override
        public Number getY(int series, int item)
        {
            return _codaDecay.getCodaDecay(new Distance(getX(series, item).doubleValue()), null).getValue(0);
        }

        public void setCodaDecay(CodaDecayTextFile codaDecay)
        {
            _codaDecay = codaDecay;
            fireDatasetChanged();
        }
    }
    private class CodaDecayTableModel extends NetMODTableModel
    {
        private CodaDecayTextFile _codaDecay = null;

        @Override
        public int getColumnCount()
        {
            return 2;
        }

        @Override
        public String getColumnName(int column)
        {
            if (column == 0)
                return "Distance (deg)";
            else if (column == 1)
                return "Coda Decay Rate";

            return "";
        }

        @Override
        public int getRowCount()
        {
            return (_codaDecay == null ? 0 : _codaDecay.getDistances().length) + 10;
        }

        @Override
        public Object getValueAt(int row, int column)
        {
            if (_codaDecay == null || row >= _codaDecay.getDistances().length)
                return "";

            double d = _codaDecay.getDistances()[row];

            if (column == 0)
                return d;
            else if (column == 1)
                return _codaDecay.getCodaDecay(new Distance(d), null);

            return 0;
        }

        @Override
        public boolean isCellEditable(int r, int c)
        {
            return true;
        }

        public void setCodaDecay(CodaDecayTextFile codaDecay)
        {
            _codaDecay = codaDecay;
            fireTableDataChanged();
        }

        @Override
        public void setValueAt(Object aValue, int row, int column)
        {
            if (aValue == null || _codaDecay == null)
                return;

            try
            {
                double d = 0;

                //  Set value for an existing row
                if (row < _codaDecay.getDistances().length)
                    d = _codaDecay.getDistances()[row];
                double codaDecay = _codaDecay.getCodaDecay(new Distance(d), null).getValue(0);

                if (column == 0)
                {
                    _codaDecay.removeCodaDecay(d);
                    d = Double.parseDouble(aValue.toString());
                }
                else if (column == 1)
                    codaDecay = Double.parseDouble(aValue.toString());

                _codaDecay.setCodaDecay(d, codaDecay);

                fireTableDataChanged();
                if (_dataset != null)
                    _dataset.setCodaDecay(_codaDecay);

                //  Keep row selected
                int index = _codaDecay.findIndex(_codaDecay.getDistances(), d);
                _table.getSelectionModel().setSelectionInterval(index, index);
                _table.scrollRectToVisible(_table.getCellRect(index, 0, true));
            }
            catch (Exception e)
            {
            }
        }

        @Override
        public void remove(int[] rows)
        {
            for (int row : rows)
            {
                double d = _codaDecay.getDistances()[row];
                _codaDecay.removeCodaDecay(d);
            }
        }
    }

    private ChartViewer _chartViewer = new ChartViewer();
    private CodaDecayDataset _dataset = new CodaDecayDataset();

    private CodaDecayTableModel _tableModel = new CodaDecayTableModel();

    private NetMODTable _table = new NetMODTable(_tableModel);

    public CodaDecayTextFileViewer(CodaDecayTextFile nmc)
    {
        super(nmc, false, false, false);
        
        //  Set expanded state after super constructor so that fields are initialized
        setExpanded(true);
    }

    @Override
    public void apply(CodaDecayTextFile nmc)
    {
    }

    @Override
    public JPanel getExpandedPanel()
    {
        if (_expandedPanel == null)
        {
            JPanel panel = new JPanel(new GridBagLayout());

            //  Configure the chart viewer
            XYPlot plot = _chartViewer.getPlot();
            plot.getDomainAxis().setLabel("Epicentral Distance (degrees)");
            plot.getRangeAxis().setLabel("Scale Factor");

            // Response Dataset
            plot.setDataset(0, _dataset);

            //  Setup the table
            _table.setDragEnabled(true);
            _table.addKeyListener(new KeyAdapter()
            {
                public void keyReleased(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                    {
                        // Only grab the rows with BOTH cells selected
                        int[] rows = _table.getSelectedRows();

                        double[] distances = _nmc.getDistances();
                        for (int i = 0; i < rows.length; i++)
                            _nmc.removeCodaDecay(distances[rows[i]]);

                        reset(_nmc);
                    }
                }
            });

            JPanel spPanel = new JPanel(new BorderLayout());
            spPanel.add(BorderLayout.CENTER, new JScrollPane(_table));
            spPanel.setBorder(BorderFactory.createEmptyBorder(55, 20, 50, 20));
            spPanel.setPreferredSize(new Dimension(400, 0));

            //  Arrange the chart viewer and table
            JSplitPane splitPane = new JSplitPane();
            splitPane.setBorder(null);
            splitPane.setContinuousLayout(true);
            splitPane.setDividerLocation(0.6);
            splitPane.setOneTouchExpandable(false);
            splitPane.setResizeWeight(0.5);
            splitPane.setLeftComponent(_chartViewer);
            splitPane.setRightComponent(spPanel);

            //  Setup the panel
            GUIUtility.addRow(panel, GridBagConstraints.REMAINDER, splitPane);
            
            _expandedPanel = panel;
        }

        return _expandedPanel;
    };

    @Override
    public void reset(CodaDecayTextFile nmc)
    {
        _chartViewer.getChart().setTitle(nmc.getName());

        //  Update the plot
        _dataset.setCodaDecay(nmc);

        //  Update the table
        _tableModel.setCodaDecay(nmc);
    }
}
