/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.receiver;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.plugin.PhaseParameters;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectra;
import gov.sandia.gnem.netmod.receiver.noisespectra.NoiseSpectraPlugin;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjmerch
 *
 */
public class Station extends AbstractNetModComponent
{
    private Point.Double _location = new Point.Double(0.0, 0.0);
    private double _elevation = 0;
    private double _reliability;
    private double _mediaDensity;
    private String _stationType = "";
    private String _technology = "";
    private String _group = "";
    private int _numberChannels;
    private String _noiseSpectraFile = "";
    private NoiseSpectra _noiseSpectra = null;
    private double _noiseSpectraSD;
    private PhaseParameters<StationPhaseParameter> _phaseParameters;
    
    //  Cached viewer
    private transient StationViewer _viewer = null;
    public Station(NetModComponent parent, Collection<? extends Phase> phases)
    {
        super(parent);
        
        setName("New Station");

        //  Initialize the set of phases
        _phaseParameters  = new PhaseParameters<StationPhaseParameter>(parent); 
        for (Phase phase : phases)
            _phaseParameters.addParameter(new StationPhaseParameter(_phaseParameters, phase));
    }

    @Override
    public boolean canContain(NetModComponent component)
    {
        return (component instanceof NoiseSpectra || component instanceof PhaseParameters);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getNoiseSpectra());
        children.add(getPhaseParameters());

        return children;
    }

    /**
     * @return the elevation
     */
    public double getElevation()
    {
        return _elevation;
    }

    /**
     * Set the group name for this station.  Stations
     * with the same group are treated as the same "station"
     * and the simulation results from them are not treated independetly.
     * 
     * @return the group name
     */
    public String getGroup()
    {
        return _group;
    }

    /**
     * @return the latitude
     */
    public double getLatitude()
    {
        return _location.getLatitude();
    }

    /**
     * @return
     */
    public Point.Double getLocation()
    {
        return _location;
    }

    /**
     * @return the longitude
     */
    public double getLongitude()
    {
        return _location.getLongitude();
    }

    /**
     * @return the mediaDensity
     */
    public double getMediaDensity()
    {
        return _mediaDensity;
    }

    /**
     * @return the noiseSpectra
     */
    public NoiseSpectra getNoiseSpectra()
    {
        if ( _noiseSpectra == null )
        {
            _noiseSpectra = NoiseSpectraPlugin.getPlugin().getComponentFor(this, getNoiseSpectraFile());
            
            if (_noiseSpectra != null )
            	_noiseSpectra.setFilename(getNoiseSpectraFile());
        }
        
        return _noiseSpectra;
    }

    /**
     * @return the noiseSpectraFile
     */
    public String getNoiseSpectraFile()
    {
        return _noiseSpectraFile;
    }

    /**
     * @return the noiseSpectraSD
     */
    public double getNoiseSpectraSD()
    {
        return _noiseSpectraSD;
    }

    /**
     * @return the numberChannels
     */
    public int getNumberChannels()
    {
        return _numberChannels;
    }

    /**
     * @return the phaseParameters
     */
    public PhaseParameters<StationPhaseParameter> getPhaseParameters()
    {
        return _phaseParameters;
    }

    /**
     * @return the reliability
     */
    public double getReliability()
    {
        return _reliability;
    }

    /**
     * @return the stationType
     */
    public String getStationType()
    {
        return _stationType;
    }

    /**
     * @return the technology
     */
    public String getTechnology()
    {
        return _technology;
    }

    @Override
    public NetModComponentViewer<?> getViewer()
    {
        if (_viewer == null)
            _viewer = new StationViewer(this);
        else
            _viewer.refresh();

        return _viewer;
    }

    @Override
    public void setChildren(List<NetModComponent> children)
    {
        for (NetModComponent child : children)
        {
            if (child instanceof NoiseSpectra)
               setNoiseSpectra((NoiseSpectra) child);
            else if (child instanceof PhaseParameters)
                setPhaseParameters((PhaseParameters<StationPhaseParameter>) child);
        }

        clearCache();
    }

    /**
     * @param elevation the elevation to set
     */
    public void setElevation(double elevation)
    {
        _elevation = elevation;
    }

    /**
     * Set the group name for this station.  Stations
     * with the same group are treated as the same "station"
     * and the simulation results from them are not treated independetly.
     * 
     * @param group the group to set
     */
    public void setGroup(String group)
    {
        _group = group;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(double latitude)
    {
        _location = new Point.Double(latitude, getLongitude());
    }

    /**
     * @param longitude the longitude to set
     */
    public void setLongitude(double longitude)
    {
        _location = new Point.Double(getLatitude(), longitude);
    }

    /**
     * @param mediaDensity the mediaDensity to set
     */
    public void setMediaDensity(double mediaDensity)
    {
        _mediaDensity = mediaDensity;
    }

    /**
     * @param noiseSpectra the noiseSpectra to set
     */
    public void setNoiseSpectra(NoiseSpectra noiseSpectra)
    {
        if ( noiseSpectra != null )
            _noiseSpectraFile = noiseSpectra.getFilename();
        
        _noiseSpectra = noiseSpectra;
    }

    /**
     * @param noiseSpectraFile the noiseSpectraFile to set
     */
    public void setNoiseSpectraFile(String noiseSpectraFile)
    {
        if ( _noiseSpectraFile.equals(noiseSpectraFile) )
            return;
        
        //  Clear the previous noise spectra
        _noiseSpectraFile = noiseSpectraFile;
        setNoiseSpectra(null);
    }

    /**
     * @param noiseSpectraSD the noiseSpectraSD to set
     */
    public void setNoiseSpectraSD(double noiseSpectraSD)
    {
        _noiseSpectraSD = noiseSpectraSD;
    }

    /**
     * @param numberChannels the numberChannels to set
     */
    public void setNumberChannels(int numberChannels)
    {
        _numberChannels = numberChannels;
    }

    /**
     * @param phaseParameters the phaseParameters to set
     */
    public void setPhaseParameters(PhaseParameters<StationPhaseParameter> phaseParameters)
    {
        _phaseParameters = phaseParameters;
    }

    /**
     * @param reliability the reliability to set
     */
    public void setReliability(double reliability)
    {
        _reliability = reliability;
    }

    /**
     * @param stationType the stationType to set
     */
    public void setStationType(String stationType)
    {
        _stationType = stationType;
    }

    /**
     * @param technology the technology to set
     */
    public void setTechnology(String technology)
    {
        _technology = technology;
    }
}
