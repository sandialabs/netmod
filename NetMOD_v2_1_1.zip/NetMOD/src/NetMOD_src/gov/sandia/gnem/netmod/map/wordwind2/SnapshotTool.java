/*****************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.map.wordwind2;

import gov.nasa.worldwind.WorldWindow;
import gov.sandia.gnem.netmod.gui.GUIUtility;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Tool for making snapshots of the map
 * 
 * @author bjmerch
 *
 */
public class SnapshotTool extends AbstractAction
{
    private WorldWindow _wwd;

    public SnapshotTool(WorldWindow wwd)
    {
        _wwd = wwd;
    }
    
    @Override
    public void actionPerformed(ActionEvent event)
    {
        // Get the Widget's Location and Size
        Component wwd = (Component) _wwd;
        int wwdWidth = wwd.getWidth();
        int wwdHeight = wwd.getHeight();

        if (wwdHeight <= 0 || wwdWidth <= 0)
            return;

        try
        {
            //  Accessory panel
            JTextField widthTextField = new JTextField(Integer.toString(wwdWidth));
            JTextField heightTextField = new JTextField(Integer.toString(wwdHeight));
            
            JPanel accessory = new JPanel(new GridBagLayout());
            accessory.setBorder(BorderFactory.createEmptyBorder(10,  10, 10, 10));
            GUIUtility.addRow(accessory, 5, new JLabel(" "), new JLabel(" "));
            GUIUtility.addRow(accessory, new JLabel("Width: "), widthTextField);
            GUIUtility.addRow(accessory,  new JLabel("Height: "), heightTextField);
            GUIUtility.addRow(accessory, GridBagConstraints.REMAINDER, new JLabel(" "));

            // Create the File Dialog Setting it as Save Dialog
            File file = GUIUtility.showSaveDialog(wwd, null, "Save Screenshot", JFileChooser.FILES_ONLY, new String[] { "jpg", "png",
                    "bmp", "gif" }, accessory);
            
            if ( file == null )
                return;
            
            //  Get the requested width and height
            int width = wwdWidth;
            try
            {
                width = Integer.parseInt(widthTextField.getText());
            }
            catch (Exception e)
            {}
            
            int height = wwdHeight;
            try
            {
                height = Integer.parseInt(heightTextField.getText());
            }
            catch (Exception e)
            {}

            //  Create the image to draw to
            BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            //  Change the wwd size
            wwd.setSize(width, height);

            //  Draw the map
            Graphics2D g = image.createGraphics();
            wwd.printAll(g);
            g.dispose();
            image.flush();
            
            //  Change the wwd size back
            wwd.setSize(wwdWidth, wwdHeight);

            //  Determine the format
            String format = file.getAbsolutePath();
            format = format.substring(format.lastIndexOf(".")+1);

            // Save the ScreenShot
            ImageIO.write(image, format, file);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
