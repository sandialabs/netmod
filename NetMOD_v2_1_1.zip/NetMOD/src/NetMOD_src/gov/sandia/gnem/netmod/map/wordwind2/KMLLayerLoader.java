package gov.sandia.gnem.netmod.map.wordwind2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import gov.nasa.worldwind.Exportable;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.ogc.kml.KMLRoot;
import gov.nasa.worldwind.ogc.kml.impl.KMLController;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwindx.examples.kml.KMLDocumentBuilder;
import gov.sandia.gnem.netmod.io.IOUtility;

public class KMLLayerLoader
{

	/**
	 * Load a KML/KMZ from the provided file
	 * 
	 * @param file
	 * @return
	 */
	public static Layer load(File file)
	{
		KMLRoot kmlRoot;
		try
		{
			kmlRoot = KMLRoot.createAndParse(file);
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		kmlRoot.setField(AVKey.DISPLAY_NAME, file.getName());
		
		// Create a KMLController to adapt the KMLRoot to the WorldWind renderable interface.
        KMLController kmlController = new KMLController(kmlRoot);

        // Adds a new layer containing the KMLRoot to the end of the WorldWindow's layer list. This
        // retrieves the layer name from the KMLRoot's DISPLAY_NAME field.
        RenderableLayer layer = new RenderableLayer();
        layer.setName((String) kmlRoot.getField(AVKey.DISPLAY_NAME));
        layer.addRenderable(kmlController);
		
		return layer;
	}

	/**
	 * Save the provided layer as a KML file
	 * 
	 * @param file
	 * @param _layer
	 */
	public static void save(File file, RenderableLayer layer)
	{
		FileWriter writer = null;
		try
		{
			writer = new FileWriter(file);
            KMLDocumentBuilder kmlBuilder = new KMLDocumentBuilder(writer);
            
            // Export the objects
            for (Renderable r : layer.getRenderables())
            {
            	if ( r instanceof Exportable )
            		kmlBuilder.writeObject((Exportable) r);
            }

            kmlBuilder.close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (XMLStreamException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if ( writer != null )
				IOUtility.safeClose(writer);
		}
	
	}
}
