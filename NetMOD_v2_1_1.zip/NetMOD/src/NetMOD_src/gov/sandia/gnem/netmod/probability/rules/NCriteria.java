/**
 * 
 */
package gov.sandia.gnem.netmod.probability.rules;

import com.carrotsearch.hppc.ObjectDoubleMap;
import gov.sandia.gnem.netmod.gui.GUIUtility;
import gov.sandia.gnem.netmod.numeric.NumericUtility;
import gov.sandia.gnem.netmod.plugin.NetModComponent;
import gov.sandia.gnem.netmod.simulation.Phase;

import java.util.*;

/**
 * A Criteria that is defined as N or more of a SubCriteria
 * 
 * @author bjmerch
 *
 */
public class NCriteria extends Criteria
{
    public static final String N_OBS = "/";
    
    private SubCriteria _subcriteria;
    private int _n;
    
    public NCriteria(SubCriteria subcriteria, int n)
    {
        _subcriteria = subcriteria;
        _n = n;
        
        subcriteria.setParent(this);
    }

    @Override
    public List<NetModComponent> getChildren()
    {
        List<NetModComponent> children = new ArrayList<NetModComponent>();
        children.add(getSubCriteria());

        return children;
    }

    /**
     * Get the minimum number of required observations
     * 
     * @return
     */
    public int getN()
    {
        return _n;
    }

    @Override
    public Set<Phase> getPhases()
    {
        return getSubCriteria().getPhases();
    }
    
    @Override
    public double getProbability(Map<Phase, ObjectDoubleMap<String>> probabilities)
    {
        startIntrospection();
        recordIntrospection(this);
        
        //  Get the probabilities of the sub-criteria
        ObjectDoubleMap<String> p_sub = getSubCriteria().getProbability(probabilities);

        //  Number of stations needed
        int N = getN();
        
        //  Compute the probabilities of 0..N-1 of the stations
        double[] network = calculateNetworkProbabilities(p_sub, N);
        
        //  Subtract the probability of i stations
        double result = 1.0 - NumericUtility.sum(network);
        
        if (isIntrospection())
        {
            recordIntrospection("Probability: ", result);
            startIntrospection();
            recordIntrospection("Network Probabilities");
            for (int i = 0; i<N; i++)
                recordIntrospection(i + " Detection: ", network[i]);
            recordIntrospection(N + "+ Detections: ", result);
            stopIntrospection();
        }
        stopIntrospection();
        
        return result;
    }

    public SubCriteria getSubCriteria()
    {
        return _subcriteria;
    }
    
    public String toString()
    {
        return getSubCriteria() + N_OBS + getN();
    }
    
    /**
     * Takes as input the probabilities stations detected an event.
     * Calculates the probabilities that exactly 0,1,...,k-1 stations
     * detected that event where k is the maximum number of stations required to
     * detect the event for any of the detection criteria.  Follows the table 
     * based algorithm presented in
     *     Calculating the probability of rare events: why settle for an 
     *     approximation? H. S. Luft and B. W. Brown, Jr Health Serv Res. 
     *     1993 October; 28(4): 419 to 439.
     * which is based on several observations:    
     *  1) When k is small, it is better to calculate 1-Pr(<=k-1) events
     *     occur than it is to calculate Pr(>=k) events occur.
     *  2) An iterative process that uses only k memory elements and O(kN)   
     *     time (where N = number of stations) is available 
     *     
     *     The iterative process fills in a table top-bottom as follows:
     *     
     *       Station        Pr x events occur
     *          i   pi  qi  0           1                           2       ...
     *          0           1.0         0.0                         0.0
     *          
     *          1   p1  q1  q1          p1                          0.0
     *          2   p2  q2  q1*q2       q1p2 + q2p1                 p1p2        
     *          3   p3  q3  q1*q2*q3    (q1p2+q2p1)q3 + q1q2p3      p1p2q3 + (q1p2+q2p1)p3 
     *          ...         [Above]qi   [Above]qi + [AboveLeft]pi   ...............
     *      
     *      where pi = probability station 1 detected the event, qi = 1-pi
     *      However, we do not need to store the entire table but only the current
     *      row being worked on, which updates the previous row.
     *      
     * The result of this function is the final row of this table, which is 
     * the probability that, given all of the stations, exactly 0,1,...,k-1
     * stations detected the event.
     *     
     * @param stationProb detection probabilities for all stations
     * @param maxRequiredStations corresponds to k
     */
    protected double[] calculateNetworkProbabilities(ObjectDoubleMap<String> stationProb, int maxRequiredStations)
    {
        int k = maxRequiredStations;

        double[] probs = new double[k];
        if (k < 1)
            return probs;

        startIntrospection();
        recordIntrospection("Station,", "Probability,", "Cumulative Network Probabilities of [0..k-1] detections");

        //  Initialize table with 1.0
        Arrays.fill(probs, 0.0);
        probs[0] = 1.0;

        //  Get the list of stations, alphabetically
        List<String> stations = Arrays.asList(stationProb.keys().toArray(String.class));

        if ( isIntrospection() )
            Collections.sort(stations);

        //  Iterate over each station
        for (String sta : stations)
        {
            double pi = stationProb.get(sta);
            if ( Double.isNaN(pi) )
            		continue;
            
            double qi = 1.0 - pi;

            //  track position within table
            double above = 0.0;
            double aboveLeft;

            //  Iterate over the number of events
            for (int j = 0; j < k; j++)
            {
                //  update position within table
                aboveLeft = above;
                above = probs[j];

                //  Update the entry
                probs[j] = above * qi + aboveLeft * pi;
            }

            if (isIntrospection() & pi > 0)
                recordIntrospection(sta, "\t", pi, ":\t", GUIUtility.formatDoubles(probs, ",\t"));
        }

        stopIntrospection();

        return probs;
    }
}
