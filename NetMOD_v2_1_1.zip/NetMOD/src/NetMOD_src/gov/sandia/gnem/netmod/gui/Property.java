/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import gov.sandia.gnem.netmod.io.IOUtility;
import gov.sandia.gnem.netmod.io.NetSimParameters;
import gov.sandia.gnem.netmod.io.libpar.LibParParameters;
import gov.sandia.gnem.netmod.map.ShadingType;
import gov.sandia.gnem.netmod.simulation.SimulationOutputASCII;

import org.jfree.chart.ChartColor;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.*;

/**
 * Properties within the NetMOD application
 * 
 * @author bjmerch
 *
 */
public enum Property
{
    // General properties
    OUTPUT_NAME("OUTPUT_NAME", 
    		"$(" + NetSimParameters.simulTechnology + ")_" + 
    		"$(" + NetSimParameters.runType + ")_" +
    		"$(" + NetSimParameters.net + ")_" +
    		"$(" + NetSimParameters.eventDetectionCriteria + ")" ),
    OUTPUT_FORMAT("OUTPUT_FORMAT", SimulationOutputASCII._type),
    FILE_CHOOSER_DIRECTORY("FILE_CHOOSER_DIRECTORY", ""),
    FONT_SIZE("FONT_SIZE", "14"),
    ICON_SIZE("ICON_SIZE", "medium"),
    BACKGROUND_COLOR("BACKGROUND_COLOR", new Color(255, 255, 255)), //white
    DIVIDER_LOCATION("DIVIDER_LOCATION", "0.3"),
    NUMBER_THREADS("NUMBER_THREADS", "8"),

    // Chart viewer properties
    CHART_VIEWER_HEIGHT("CHART_VIEWER_HEIGHT", "300"),
    CHART_VIEWER_WIDTH("CHART_VIEWER_WIDTH", "700"),
    CHART_VIEWER_BACKGROUND_COLOR("CHART_VIEWER_BACKGROUND_COLOR", new Color(255, 255, 255)),
    CHART_VIEWER_ANTI_ALIASING("CHART_VIEWER_ANTI_ALIASING", "false"),
    CHART_VIEWER_LINE_WIDTH("CHART_VIEWER_LINE_WIDTH", "1.0"),
    CHART_VIEWER_LINE_COLOR_PALETTE("CHART_VIEWER_LINE_COLOR_PALETTE", getChartLineColors()),
    CHART_VIEWER_GRIDLINE_WIDTH("CHART_VIEWER_GRIDLINE_WIDTH", "1"),
    CHART_VIEWER_GRIDLINE_COLOR("CHART_VIEWER_GRIDLINE_COLOR", new Color(192, 192, 192)),
    CHART_VIEWER_LABEL_FONT_SIZE("CHART_VIEWER_LABEL_FONT_SIZE", "10"),
    
    //  Media Grid properties
    MEDIA_GRID_COLOR_PALETTE("MEDIA_GRID_COLOR_PALETTE", getMediaGridColors()),
    
    //  Map Properties
    MAP("MAP", "WorldWind"),
    MAP_BACKGROUND_COLOR("MAP_BACKGROUND_COLOR", new Color(240, 240, 240)),
    MAP_WEIGHT("MAP_WEIGHT", "light"),
    MAP_TOPOGRAPHY("MAP_TOPOGRAPHY", "data/world.topo.bathy.200408.3x5400x2700.jpg"),
    MAP_BOUNDARIES("MAP_BOUNDARIES", "data/polbnd15m.shp"),
    MAP_BOUNDARIES_LINE("MAP_BOUNDARIES_LINE", "true"),
    MAP_BOUNDARIES_LINE_WIDTH("MAP_BOUNDARIES_LINE_WIDTH", "2"),
    MAP_BOUNDARIES_LINE_COLOR("MAP_BOUNDARIES_LINE_COLOR", new Color(0,0,0,255)),
    MAP_BOUNDARIES_FILL("MAP_BOUNDARIES_FILL", "false"),
    MAP_BOUNDARIES_FILL_LAND_COLOR("MAP_BOUNDARIES_FILL_LAND_COLOR", new Color(255,251,195,255)),
    MAP_BOUNDARIES_FILL_WATER_COLOR("MAP_BOUNDARIES_FILL_WATER_COLOR", new Color(165,250,255,255)),
    MAP_OUTPUT_SHADING("MAP_OUTPUT_SHADING", ShadingType.bilinear.toString()),
    MAP_OUTPUT_CONTOUR_COLOR("MAP_OUTPUT_CONTOUR_COLOR", new Color(255, 255, 255)),
    MAP_OUTPUT_CONTOUR_WIDTH("MAP_OUTPUT_CONTOUR_WIDTH", "2"),
    MAP_SOURCE_COLOR("MAP_SOURCE_COLOR", Color.ORANGE),
    MAP_SOURCE_POINTSIZE("MAP_SOURCE_POINTSIZE", "12.0"),
    MAP_STATION_ENABLED_COLOR("MAP_STATION_ENABLED_COLOR", Color.GREEN),
    MAP_STATION_ENABLED_POINTSIZE("MAP_STATION_ENABLED_POINT_SIZE", "16.0"),
    MAP_STATION_ENABLED_LABEL_COLOR("MAP_STATION_ENABLED_LABEL_COLOR", Color.WHITE),
    MAP_STATION_ENABLED_FONTSIZE("MAP_STATION_ENABLED_FONT_SIZE", "12"),
    MAP_STATION_DISABLED_COLOR("MAP_STATION_DISABLED_COLOR", Color.RED),
    MAP_STATION_DISABLED_POINTSIZE("MAP_STATION_DISABLED_POINT_SIZE", "16.0"),
    MAP_STATION_DISABLED_LABEL_COLOR("MAP_STATION_DISABLED_LABEL_COLOR", Color.WHITE),
    MAP_STATION_DISABLED_FONTSIZE("MAP_STATION_DISABLED_FONT_SIZE", "12"),
    
    //  Algorithm flags
    NETSIM_PATH_SD("NETSIM_PATH_SD", "false"),  //  Flag, if true, to obtain the teleseismic path attenuation sd as NetSim does from the path media at the source.  If false, obtains it from the reference media
    NETSIM_C_INTERP("NETSIM_C_INTERP", "false"),  //  Flag, if true, to mimic the interpolation algorithms used in NetSim 2.4.1
    NETSIM_NOISE_SD_DB("NETSIM_NOISE_SD_DB", "false");  //  Flag, if true, to treat noise file SD as dB instead of log10
    
    private String _property_name;
    private String _default_value;
    private String _value = null;

    private Object _objectValue = null;

    //  Store properties with sorted keys.
    private static Properties properties = new Properties()
    {
        @Override
        public synchronized Enumeration<Object> keys()
        {
            return Collections.enumeration(new TreeSet<Object>(super.keySet()));
        }

        @Override
        public Set<Object> keySet()
        {
            return Collections.unmodifiableSet(new TreeSet<Object>(super.keySet()));
        }
    };
    static
    {
        //  Load default values into the properties object
        for (Property p : Property.values())
            setProperty(p.getPropertyName(), p.getDefaultValue());
    }

    private static File propertiesFile = IOUtility.openFile("NetMOD.cfg");

    private static boolean propertiesLoaded = false;
    
    public static Color[] getChartLineColors()
    {
        final Color[] colors = { ChartColor.VERY_DARK_RED, ChartColor.VERY_DARK_BLUE, ChartColor.VERY_DARK_GREEN, ChartColor.VERY_DARK_YELLOW,
            ChartColor.VERY_DARK_MAGENTA, ChartColor.VERY_DARK_CYAN, ChartColor.DARK_GRAY, ChartColor.LIGHT_RED, ChartColor.LIGHT_BLUE, ChartColor.LIGHT_GREEN,
            ChartColor.LIGHT_YELLOW, ChartColor.LIGHT_MAGENTA, ChartColor.LIGHT_CYAN };
        return colors;
    }

    public static Color[] getMediaGridColors()
    {
        final Color[] colors = { Color.DARK_GRAY, Color.GREEN, Color.BLUE, Color.RED, Color.ORANGE, Color.YELLOW, Color.PINK, Color.CYAN, Color.MAGENTA, Color.WHITE };
        
        return colors;
    }

    /**
     * Get the property value for the provided key.
     * 
     * @param key
     * @return
     */
    public static String getProperty(String key)
    {
        return properties.getProperty(key);
    }

    /**
     * Get the property keys.
     * 
     * @return
     */
    public static Set<String> getPropertyKeys()
    {
        return properties.stringPropertyNames();
    }

    public static void loadProperties()
    {
        loadProperties(propertiesFile);
    }
    
    /**
     * Load properties from the provided file
     * 
     * @param file
     */
    public static void loadProperties(File file)
    {
    	FileInputStream fis = null;
        try
        {
            // Create and/or load the saved application properties
            if (!file.exists())
                file.createNewFile(); // Create file if it does not already exist

            // Load properties from file (could be empty if we just created the file)
            fis = new FileInputStream(file);
            properties.load(fis);
            propertiesLoaded = true;
        }
        catch (Exception e)
        {
            propertiesLoaded = false;
        }
        finally
        {
        	if ( fis != null )
        		IOUtility.safeClose(fis);
        }

        // Load up default values for missing properties
        for (Property prop : Property.values())
            if (prop.getValue() == null || prop.getValue().isEmpty())
                prop.setValue(prop.getDefaultValue());
    }

    /**
     * Load properties from the provided command line parameters
     * 
     * @param parameters
     */
    public static void loadProperties(LibParParameters parameters)
    {
        //  examine each of the properties
        for (Property p : Property.values())
        {
            String value = parameters.get(p.getPropertyName());
            if ( value != null && !value.isEmpty())
                p.setValue(value);
        }
    }

    /**
     * Save the properties to the properties file
     */
    public static void saveProperties()
    {
        saveProperties(propertiesFile);
    }

    /**
     * Save the properties to the properties file
     */
    public static void saveProperties(File file)
    {
        if (propertiesLoaded)
        {
        	FileOutputStream fos = null;
            try
            {
                fos = new FileOutputStream(file);
                properties.store(fos, "--- NetMOD Application Properties ---");
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            finally
            {
            	if ( fos != null )
            		IOUtility.safeClose(fos);
            }
        }
    }

    public static void setPropertiesFile(File file)
    {
        propertiesFile = file;
    }

    /**
     * Set the property key to the provided value.
     * 
     * @param key
     * @param value
     */
    public static void setProperty(String key, String value)
    {
        properties.setProperty(key, value);
    }

    // Single color property
    private Property(String property_name, Color d)
    {
        _property_name = property_name;
        _default_value = d.getRed() + "," + d.getGreen() + "," + d.getBlue() + "," + d.getAlpha();
    }

    // Color palette property
    private Property(String property_name, Color[] colors)
    {
        _property_name = property_name;

        StringBuilder sb = new StringBuilder();
        for (Color c : colors)
        {
            sb.append(c.getRed()).append(',');
            sb.append(c.getGreen()).append(',');
            sb.append(c.getBlue()).append(',');
            sb.append(c.getAlpha()).append(';');
        }

        _default_value = sb.toString();
    }

    // String-based property
    private Property(String property_name, String default_value)
    {
        _property_name = property_name;
        _default_value = default_value;
    }

    // *** BOOLEAN PROPERTIES ***
    public boolean getBooleanValue()
    {
        if (_objectValue == null)
        {
            try
            {
                _objectValue = Boolean.valueOf(getValue());
            }
            catch (NumberFormatException e)
            {
                _objectValue = Boolean.valueOf(_default_value);
            }
        }

        return (Boolean) _objectValue;
    }

    // *** COLOR PALETTE PROPERTIES ***
    public List<Color> getColorPaletteValue()
    {
        if (_objectValue == null)
        {
            List<Color> colors = new ArrayList<Color>();

            String value = getValue();
            if (value == null || value.isEmpty())
                value = _default_value;

            for (String str : value.split(";"))
            {
                Color c = parseColor(str);

                if (c != null)
                    colors.add(c);
            }

            _objectValue = colors;
        }

        return (List<Color>) _objectValue;
    }

    // *** COLOR PROPERTIES ***
    public Color getColorValue()
    {
        if (_objectValue == null)
        {
            _objectValue = parseColor(getValue());
            if (_objectValue == null)
                _objectValue = parseColor(_default_value);
        }

        return (Color) _objectValue;
    }

    public String getDefaultValue()
    {
        return _default_value;
    }

    // *** FLOAT PROPERTIES ****
    public float getFloatValue()
    {
        if (_objectValue == null)
        {
            try
            {
                _objectValue = Float.valueOf(getValue());
            }
            catch (NumberFormatException e)
            {
                _objectValue = Float.valueOf(_default_value);
            }
        }

        return ((Number) _objectValue).floatValue();
    }

    // *** INTEGER PROPERTIES ***
    public int getIntegerValue()
    {
        if (_objectValue == null)
        {
            try
            {
                _objectValue = Integer.valueOf(getValue());
            }
            catch (NumberFormatException e)
            {
                _objectValue = Integer.valueOf(_default_value);
            }
        }

        return ((Number) _objectValue).intValue();
    }

    public int getNumberOfColors()
    {
        return getColorPaletteValue().size();
    }

    public String getPropertyName()
    {
        return _property_name;
    }

    // *** STRING PROPERTIES ***
    public String getValue()
    {
        if (_value == null)
            _value = properties.getProperty(_property_name);
        
        if ( _value == null )
            return "";

        return _value;
    }

    public void setBooleanValue(Boolean value)
    {
        _objectValue = value;
        setValue(value.toString());
    }

    public void setColorPaletteValue(List<Color> colors)
    {
        _objectValue = colors;

        StringBuilder str = new StringBuilder();
        for (Color c : colors)
        {
            str.append(c.getRed()).append(",");
            str.append(c.getGreen()).append(",");
            str.append(c.getBlue()).append(",");
            str.append(c.getAlpha()).append(";");
        }
        
        //  Remove the final semicolon
        if ( str.length() > 0 )
        	str.deleteCharAt(str.length()-1);

        setValue(str.toString());
    }

    public void setColorValue(Color c)
    {
        _objectValue = c;
        setValue(c.getRed() + "," + c.getGreen() + "," + c.getBlue() + "," + c.getAlpha());
    }

    public void setFloatValue(float value)
    {
        _objectValue = (Float) value;
        setValue(Float.toString(value));
    }

    public void setIntegerValue(int value)
    {
        _objectValue = value;
        setValue(Integer.toString(value));
    }

    public void setValue(String value)
    {
        _value = value;
        properties.setProperty(_property_name, value);
    }

    private Color parseColor(String str)
    {
        String[] ret = str.split(",");
        if (ret.length < 3 || ret.length > 4)
            return null;
        int[] rgb = new int[4];
        try
        {
            for (int i = 0; i < 4 && i < ret.length; i++)
            {
                rgb[i] = Integer.valueOf(ret[i]);
            }
            if (ret.length == 3)
            {
                rgb[3] = 255; // default is NO transparency
            }

            return new Color(rgb[0], rgb[1], rgb[2], rgb[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
