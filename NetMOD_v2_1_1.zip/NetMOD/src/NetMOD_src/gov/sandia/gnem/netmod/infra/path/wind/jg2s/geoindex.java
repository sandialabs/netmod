package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import gov.sandia.gnem.netmod.io.IOUtility;


public class geoindex {

    static double[] getGeoIndex(G2SDB g2sdb, int ccyyddd, float ut, boolean storm,
                                double[] ap) {

        //! ========================================================
        //! If needed, store the information into memory
        //! =======================================================
        int startyear = 1954; //from header
        int nrecs = 21366; //from header

        float f_ddd[];
        float yearbase[];
        float f_f107[];
        float f_f107a[];
        float f_apd[];
        float f_ap3[][];


        //! =====================================================================
        //! Read in sflux.dat
        //! =====================================================================
        if (g2sdb.info.year < 2012) {
            String path = System.getProperty("user.dir");
            f_f107 = readFile(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_f107.dat",
                    nrecs);
            f_f107a = readFile(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_f107a.dat",
                    nrecs);
            f_apd = readFile(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_apd.dat",
                    nrecs);
            f_ap3 = readFile2d(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_ap3.dat",
                    nrecs);
            yearbase = readFile(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_yearbase.dat",
                    nrecs);
            f_ddd = readFile(
                    path.substring(0, path.length() - 3) + "/data/sfluxmag_ddd.dat",
                    nrecs);

            //! Jan 1, 1966 is index = 0
            int year = ccyyddd / 1000;
            int ddd = ccyyddd - (year * 1000);
            int index = (int) yearbase[year - startyear + 1] + ddd;

            //! Do some minimal error checking here
            if (index > nrecs | ddd != f_ddd[index]) {
//      System.out.println("Error in getindex, using defaults");
                g2sdb.info.f107 = 105;
                g2sdb.info.f107a = 105;
                ap[0] = 4;
                ap[1] = 4;
                return ap;
            } else {
                g2sdb.info.f107a = f_f107a[index];
                g2sdb.info.f107 = f_f107[index];
                ap[0] = f_apd[index];
                ap[1] = f_apd[index];
            }

            //! =====================================================================
            //! Get the desired indicies
            //! =====================================================================

            //! an increase in index of apa is a decrease in time
            float j = (ut / 10800) + 1; //get the j index for the current 3 hour ap
            ap[1] = f_ap3[index][(int) j]; //Current 3 hour

            //! Now do the sums that MSIS storm uses
            if (storm) {
                for (int i = 2; i <= 4; i++) { // is fortran inclusive or exclusive???
                    j = j - 1;
                    if (j == 0) {
                        j = 7;
                        index = index - 1;
                    }
                    ap[i] = f_ap3[index][(int) j];
                }
                //! Average of 12 to 33 hours prior
                int sum = 0;
                for (int i = 0; i <= 7; i++) {
                    j = j - 1;
                    if (j == 0) {
                        j = 7;
                        index = index - 1;
                    }
                    //sum = sum + f_ap3[index][(int) j];
                }
                ap[5] = sum / 8;

                //! Average of 36 to 59 hours prior
                sum = 0;
                for (int i = 0; i <= 7; i++) {
                    j = j - 1;
                    if (j == 0) {
                        j = 7;
                        index = index - 1;
                    }
                    //sum = sum + f_ap3[index][(int) j];
                }
                ap[6] = sum / 8;
            }
        } else {
            g2sdb.info.f107 = 105;
            g2sdb.info.f107a = 105;
            ap[0] = 4;
            ap[1] = 4;
        }

        //! =====================================================================
        //! Calculate the index of the desired yyddd
        //! =====================================================================
        return ap;

    }

	private static float[] readFile(String filename, int nrecs)
	{
		float[] array = new float[nrecs];
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try
		{
			File file = IOUtility.openFile(filename);
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);
			String line;

			int index = 0; // starts at 5 because of header in file
			while ((line = bufferedReader.readLine()) != null)
			{
				array[index] = Float.parseFloat(line);
				index += 1;
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fileReader != null )
				IOUtility.safeClose(fileReader);
			if ( bufferedReader != null )
				IOUtility.safeClose(bufferedReader);
		}
		return array;
	}

	private static float[][] readFile2d(String filename, int nrecs)
	{
		float[][] array = new float[nrecs][8];
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try
		{
			File file = IOUtility.openFile(filename);
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			String[] partsHolder = new String[8];

			int index = 0; // starts at 5 because of header in file
			while ((line = bufferedReader.readLine()) != null)
			{
				String[] parts = line.split(" ");
				int j = 0;
				for (String p : parts)
				{
					if (!p.equals(""))
					{
						partsHolder[j] = p;
						j += 1;
					}
				}
				for (int i = 0; i < partsHolder.length; i++)
				{
					array[index][i] = Float.parseFloat(partsHolder[i]);
				}

				index += 1;
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if ( fileReader != null )
				IOUtility.safeClose(fileReader);
			if ( bufferedReader != null )
				IOUtility.safeClose(bufferedReader);
		}
		return array;
	}
}
