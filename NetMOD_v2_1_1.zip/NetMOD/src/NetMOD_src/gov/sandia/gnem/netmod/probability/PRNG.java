/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.probability;

import cern.jet.random.engine.MersenneTwister;
import cern.jet.random.engine.RandomEngine;

/**
 * Class for generating psuedo-random numbers for NetMOD.
 * This class is NOT thread-safe.  A single PRNG class
 * should be instantiated for each separate thread.
 */
public class PRNG
{
    //  Random number generator
    private RandomEngine _random;
    
    /**
     * Instantiate the generator with the provided seed 
     * @param seed use this seed to initialize the generator
     */
    public PRNG(int seed)
    {
        setSeed(seed);
    }

    /**
     * The underlying MersenneTwister already returns doubles in (0.0, 1.0)
     * so just return the next value.
     */
    public final double nextUniform()
    {
        return getUniformValue();
    }
    
    /**
     * Fill the provided array with uniform doubles in (0.0, 1.0)
     * 
     * @param values
     */
    public final void nextUniforms(double[] values)
    {
        //  Declare early for optimization
        int i;
        
        if ( values == null )
            return;
        
        int N = values.length;
        for (i=0; i<N; i++)
            values[i] = getUniformValue();
    }
    
    /**
     * Return the next normally distributed random variable with the specified mean
     * and standard deviation.
     * 
     * @return
     */
    public final double nextNormal(double mean, double std)
    {
        //  Polar form:  7 *, 1 /, 3 +-, 1 sqrt, 1 log
        double u = getUniformValue() * 2 - 1;
        double v = getUniformValue() * 2 - 1;
        double s = u * u + v * v;
        if (s == 0 || s >= 1)
            return nextNormal(mean, std);

        double tmp = Math.sqrt(-2 * Math.log(s) / s);

        return mean + std * u * tmp;
    }
    
    /**
     * Fill the provided array with normal doubles with the specified mean
     * and standard deviation.
     * 
     * @param values
     */
    public final void nextNormals(double[] values, double mean, double std)
    {
        //  Declare early for optimization
        int i;
        
        if ( values == null )
            return;
        
        int N = values.length-1;
        for (i=0; i<N; i+=2)
        {
            //  Box-Mueller Polar form
            double u = getUniformValue() * 2 - 1;
            double v = getUniformValue() * 2 - 1;
            double s = u * u + v * v;
            if ( s == 0 || s >= 1 )
            {
                i = i - 2;
                continue;
            }
            
            double tmp = std * Math.sqrt(- 2 * Math.log(s) / s);
            values[i] = mean + u * tmp;
            values[i+1] = mean + v * tmp;
        }
        
        //  Handle the case of an odd number
        if ( i == N )
            values[i] = nextNormal(mean, std);
    }
    
    /**
     * Fill the provided array with normal doubles with the specified mean
     * and standard deviation.
     * 
     * @param values
     */
    public final void nextNormalsAdd(double[] values, double mean, double std)
    {
        //  Declare early for optimization
        int i;
        
        if ( values == null )
            return;
        
        int N = values.length-1;
        for (i=0; i<N; i+=2)
        {
            //  Box-Mueller Polar form
            double u = getUniformValue() * 2 - 1;
            double v = getUniformValue() * 2 - 1;
            double s = u * u + v * v;
            if ( s == 0 || s >= 1 )
            {
                i = i - 2;
                continue;
            }
            
            double tmp = std * Math.sqrt(- 2 * Math.log(s) / s);
            values[i] += mean + u * tmp;
            values[i+1] += mean + v * tmp;
        }
        
        //  Handle the case of an odd number
        if ( i == N )
            values[i] += nextNormal(mean, std);
    }

    /**
     * Reseed this random number generator with the provided value
     * @param seed reseed with this value
     */
    public void setSeed(int seed)
    {
        if ( seed <= 0 )
            seed = (int) System.nanoTime();
        
        _random = new MersenneTwister(seed);
    }
    
    /**
     * Generate the next uniform random value
     * 
     * @return
     */
    private double getUniformValue()
    {
        return _random.raw();
    }
}
