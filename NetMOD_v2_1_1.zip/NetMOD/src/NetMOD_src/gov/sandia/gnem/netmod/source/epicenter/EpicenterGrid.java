/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 *
 * BSD Open Source License.
 * All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.source.epicenter;

import gov.sandia.gnem.netmod.geometry.Point;
import gov.sandia.gnem.netmod.gui.NetMOD;
import gov.sandia.gnem.netmod.gui.NetModComponentViewer;
import gov.sandia.gnem.netmod.map.Layer;
import gov.sandia.gnem.netmod.plugin.AbstractNetModComponent;
import gov.sandia.gnem.netmod.plugin.NetModComponent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Abstact implementation of an epicenter grid that stores the grid
 * as a list of points
 *
 * @author bjmerch
 */
public class EpicenterGrid extends AbstractNetModComponent {
    private boolean _regular = true;
    private double _latitudeStart = -80;
    private double _latitudeEnd = 80;
    private double _latitudeDelta = 10;
    private double _longitudeStart = -175;
    private double _longitudeEnd = 175;
    private double _longitudeDelta = 10;
    private double _elevation = -999;

    //  Points in the grid
    protected List<Point.Double> _points = null;

    private transient EpicenterGridViewer _viewer = null;

    public EpicenterGrid(NetModComponent parent) {
        super(parent);

        setName("Epicenter Grid");
    }

    public Point.Double get(int index) {
        if (_points == null)
            _points = buildGrid();

        return _points.get(index);
    }

    public double getLatitudeDelta() {
        return _latitudeDelta;
    }

    public double getLatitudeEnd() {
        return Math.max(_latitudeStart, _latitudeEnd);
    }

    public double getLatitudeStart() {
        return Math.min(_latitudeStart, _latitudeEnd);
    }

    public double getLongitudeDelta() {
        return _longitudeDelta;
    }

    public double getLongitudeEnd() {
        return Math.max(_longitudeStart, _longitudeEnd);
    }

    public double getLongitudeStart() {
        return Math.min(_longitudeStart, _longitudeEnd);
    }

    public double getElevation() {
        return _elevation;
    }

    public Layer<?> getMapLayer() {
        if (NetMOD.getMap() == null)
            return null;

        return NetMOD.getMap().createEpicenterLayer(this);
    }

    /**
     * @return the regular
     */
    public boolean getRegular() {
        return _regular;
    }

    @Override
    public NetModComponentViewer<?> getViewer() {
        if (_viewer == null)
            _viewer = new EpicenterGridViewer(this);

        return _viewer;
    }

    @Override
    public boolean isLeaf() {
        return true;
    }

    public Iterator<Point.Double> iterator() {
        if (_points == null)
            _points = buildGrid();

        return _points.iterator();
    }

    public void setLatitude(double start, double end, double delta) {
        _points = null;

        _latitudeStart = start;
        _latitudeEnd = end;
        _latitudeDelta = delta;
    }

    public void setLongitude(double start, double end, double delta) {
        _points = null;

        _longitudeStart = start;
        _longitudeEnd = end;
        _longitudeDelta = delta;
    }

    public void setElevation(double elevation) {
        _elevation = elevation;
    }

    /**
     * @param regular the regular to set
     */
    public void setRegular(boolean regular) {
        _regular = regular;
    }

    public int size() {
        if (_points == null)
            _points = buildGrid();

        return _points.size();
    }

    /**
     * Uses a grid description in terms of (southwest most point), (number of
     * points in each dimension), (delta values in each dimension) to create
     * a grid covering the same area but with evenl space points.
     * The number and delta (in degrees) are taken here to be appropriate
     * for the equator.  The number of points at other latitudes is less
     * depending on how far they are from the equator.  This is determined
     * based on how many km delta degrees longitude is at the equator.
     * The same delta (in km) is used at each latitude, resulting in fewer
     * points closer to the poles.
     *
     * @param aGridDescription describes the epicenter grid in terms of
     *                         initial position, delta between points, and number of desired points.
     */
    private List<Point.Double> buildEvenGrid() {
        List<Point.Double> points = new ArrayList<Point.Double>();

        double latitudeDelta = getLatitudeDelta();
        int Nlat = (int) ((getLatitudeEnd() - getLatitudeStart()) / latitudeDelta + 1);
        double elev = getElevation();

        //  Step over each latitude value
        for (int i = 0; i < Nlat; i++) {
            //  Compute the latitude
            double lat = getLatitudeStart() + i * latitudeDelta;

            //  Compute the longitude delta
            double longitudeDelta = getLongitudeDelta() / Math.cos(Math.toRadians(lat));

            //  Compute the number of longitude points
            int Nlon = (int) ((getLongitudeEnd() - getLongitudeStart()) / longitudeDelta + 1);

            //  Tweak the delta to fit the number of longitude points
            if (Nlon > 1)
                longitudeDelta = (getLongitudeEnd() - getLongitudeStart()) / (Nlon - 1);

            //  Compute an offset to evenly fill the space
            double longitudeOffset = (getLongitudeEnd() - getLongitudeStart() - (Nlon - 1) * longitudeDelta) / 2.0;

            //  Generate the points
            for (int j = 0; j < Nlon; j++) {
                //  Compute the longitude
                float lon = (float) (getLongitudeStart() + longitudeOffset + j * longitudeDelta);

                //  Store the point
                points.add(new Point.Double(lat, ((lon + 180) % 360) - 180, elev));
            }
        }

        return points;
    }

    /**
     * Build the grid
     *
     * @return
     */
    private List<Point.Double> buildGrid() {
        if (_regular)
            return buildRegularGrid();
        else
            return buildEvenGrid();
    }

    /**
     * Generate a range of values between start and end
     *
     * @param start
     * @param end
     * @param N
     * @return
     */
    private double[] buildRange(double start, double end, double delta) {
        int N = (int) ((end - start) / delta + 1);

        double[] values = new double[N];
        for (int i = 0; i < N; i++)
            values[i] = start + i * delta;

        return values;
    }

    /**
     * Builds a regular (in the sense of evenly spaced latitude/longitude values)
     * grid from the description.  Because of this regularity, the same number of
     * points will be created towards the poles as at the equator.
     *
     * @param aGridDescription describes the epicenter grid to create
     */
    private List<Point.Double> buildRegularGrid() {
        double[] latitudes = buildRange(getLatitudeStart(), getLatitudeEnd(), getLatitudeDelta());
        double[] longitudes = buildRange(getLongitudeStart(), getLongitudeEnd(), getLongitudeDelta());
        double elev = getElevation();
        List<Point.Double> points = new ArrayList<Point.Double>();
        for (int j = 0; j < longitudes.length; j++) {
            double lon = longitudes[j];

            if (lon < -180 || lon > 180)
                lon = ((lon + 180) % 360) - 180;

            for (int i = 0; i < latitudes.length; i++)
                points.add(new Point.Double(latitudes[i], lon, elev));
        }

        return points;
    }
}
