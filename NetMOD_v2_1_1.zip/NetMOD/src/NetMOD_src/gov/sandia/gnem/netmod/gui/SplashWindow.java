/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.net.URL;

/**
 * Implementation of a splash screen for NetMOD
 * 
 * @author bjmerch
 *
 */
public class SplashWindow extends Dialog
{
    private static SplashWindow _splash;

    /**
     * Closes the splash window.
     */
    public static void disposeSplash()
    {
        if (_splash != null)
        {
            _splash.getOwner().dispose();
            _splash = null;
        }
    }

    private boolean paintCalled = false;

    public static void splash(String title, Image image)
    {
        if (_splash == null && image != null)
        {
            // Create the splash image
            _splash = new SplashWindow(title, image);

            // Show the window.
            _splash.setVisible(true);

            if (!EventQueue.isDispatchThread() && Runtime.getRuntime().availableProcessors() == 1)
            {
                synchronized (_splash)
                {
                    while (!_splash.paintCalled)
                    {
                        try
                        {
                            _splash.wait();
                        }
                        catch (InterruptedException e)
                        {
                        }
                    }
                }
            }
        }
    }

    public static void splash(String title, URL imageURL)
    {
        if (imageURL != null)
            splash(title, Toolkit.getDefaultToolkit().createImage(imageURL));
    }

    /**
     * Creates a new instance.
     * @param parent the parent of the window.
     * @param image the splash image.
     */
    private SplashWindow(String title, Image image)
    {
        super(new Frame());

        // Load the image
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(image, 0);
        try
        {
            mt.waitForID(0);
        }
        catch (InterruptedException ie)
        {
        }

        // Abort on failure
        if (mt.isErrorID(0))
        {
            setSize(0, 0);
            synchronized (this)
            {
                paintCalled = true;
                notifyAll();
            }
            return;
        }

        setUndecorated(true);
        add(new SplashPanel(title, image));

        // Center the window on the screen
        pack();
        Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenDim.width - getSize().width) / 2, (screenDim.height - getSize().height) / 2);
    }

    private class SplashPanel extends Panel
    {
        private SplashPanel(String title, Image image)
        {
            setLayout(new BorderLayout());

            
            Label label = new Label(title, Label.CENTER);
            label.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 36));
            label.setForeground(new Color(136, 0, 21));
            
            add(label, BorderLayout.NORTH);
            add(new ImagePanel(image), BorderLayout.CENTER);

            TextArea textArea = new TextArea(GUIUtility.getNotice(), 80, 0, TextArea.SCROLLBARS_VERTICAL_ONLY);
            textArea.setEditable(false);
            add(textArea, BorderLayout.SOUTH);
        }

        @Override
        public void paint(Graphics g)
        {
            g.setColor(Color.DARK_GRAY);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(2.0f));
            g2.draw(new RoundRectangle2D.Double(1, 1, getSize().width - 2, getSize().height - 2, 10, 10));
        }

        @Override
        public void update(Graphics g)
        {
            paint(g);
        }
        
        public Insets getInsets()
        {
            return new Insets(10,10,10,10);
        }

        /**
         * Simple component for displaying an image
         * 
         * @author bjmerch
         *
         */
        private class ImagePanel extends Panel
        {
            private Image _image;

            private ImagePanel(Image image)
            {
                _image = image;

                int imgWidth = image.getWidth(this) + 80;
                int imgHeight = image.getHeight(this) + 20;
                setPreferredSize(new Dimension(imgWidth, imgHeight));
            }

            @Override
            public void paint(Graphics g)
            {
                g.setColor(SplashPanel.this.getComponent(1).getBackground());
                g.fillRect(0, 0, getSize().width, getSize().height);
                g.drawImage(_image, (getSize().width - _image.getWidth(null)) / 2, (getSize().height - _image.getHeight(null)) / 2, SplashWindow.this);

                if (!paintCalled)
                {
                    paintCalled = true;
                    synchronized (this)
                    {
                        notifyAll();
                    }
                }
            }

            @Override
            public void update(Graphics g)
            {
                paint(g);
            }
        }
    }
}
