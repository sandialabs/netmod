/*******************************************************************************
 * Copyright 2013 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * BSD Open Source License.
 * All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  
 *    * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of Sandia National Laboratories nor the names of its
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
package gov.sandia.gnem.netmod.gui;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Combine a browse button and a text field for displaying
 * file references.
 * 
 * @author bjmerch
 *
 */
public class FileField extends JPanel
{
    private JComponent _toolBar = GUIUtility.createToolBar();
    private JTextField _textField = new JTextField()
    {
        public void setText(String text)
        {
            //  Only reset if it's changed
            if ( !getText().equals(text) )
            {
                super.setText(text);
                
                //  Fire an actionPerformed for
                //  NetModComponentViewer.ComponentChangeListener
                fireActionPerformed();
            }
        }
    };

    /**
     * Construct a new file field with the provided controls inserted 
     * between the browse button and the text field.
     * 
     * @param tooltip
     * @param fileSelection JFileChooser file selection mode
     * @param controls
     */
    public FileField(String tooltip, int fileSelection, JComponent... controls)
    {
        super(new GridBagLayout());
        
        if ( tooltip != null )
            _textField.setToolTipText(tooltip);
        
        //  Keep text on the right side visible
        _textField.getDocument().addDocumentListener(new DocumentListener()
        {

            @Override
            public void changedUpdate(DocumentEvent arg0)
            {
                _textField.setScrollOffset(_textField.getHorizontalVisibility().getExtent());
            }

            @Override
            public void insertUpdate(DocumentEvent arg0)
            {
                _textField.setScrollOffset(_textField.getHorizontalVisibility().getExtent());
            }

            @Override
            public void removeUpdate(DocumentEvent arg0)
            {
                _textField.setScrollOffset(_textField.getHorizontalVisibility().getExtent());
            }
        }
        );

        _toolBar.add(createBrowseButton(fileSelection));
        for (JComponent control : controls)
            _toolBar.add(control);

        GUIUtility.addRow(this, _toolBar, _textField);
    }
    
    /**
     * Construct a new file field with the provided controls inserted 
     * between the browse button and the text field.
     * 
     * @param tooltip
     * @param controls
     */
    public FileField(String tooltip, JComponent... controls)
    {
        this(tooltip, JFileChooser.FILES_AND_DIRECTORIES, controls);
    }
    
    /**
     * Get the text of the file field
     * 
     * @return
     */
    public String getText()
    {
        return _textField.getText();
    }
    
    /**
     * Set the text of the file field
     * 
     * @param text
     */
    public void setText(String text)
    {
        _textField.setText(text);
        
        //  Keep text on the right side visible
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                _textField.setScrollOffset(_textField.getHorizontalVisibility().getExtent());
            }
        });
    }
    
    private JButton createBrowseButton(final int fileSelection)
    {
        JButton button = GUIUtility.createButton(Icons.OPEN.getIcon());
        
        if ( fileSelection == JFileChooser.DIRECTORIES_ONLY )
            button.setToolTipText("Select directory to open");
        else
            button.setToolTipText("Select file to open");

        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0)
            {
                File[] files = GUIUtility.showOpenDialog(FileField.this, getText(), "Open file", fileSelection, false, null, null);
                if ( files == null )
                    return;
                
                File file = files[0];
                
                //  Set the path to the text field
                setText(file.getPath());
            }
        });

        return button;
    }
}
