/**
 * 
 */
package gov.sandia.gnem.netmod.numeric;

import gov.sandia.gnem.netmod.probability.NonParametricCDF;
import gov.sandia.gnem.netmod.probability.NormalPDF;
import gov.sandia.gnem.netmod.probability.PDF;
import gov.sandia.gnem.netmod.probability.PRNG;

import java.util.Arrays;

/**
 * A Spectra of double values versus frequency.  
 * Assumes that the frequencies are arranged in a monotonically increasing order.
 * 
 * @author bjmerch
 *
 */
public class SpectraDouble extends Spectra
{   
    public static final SpectraDouble ZERO = new SpectraDouble(0.0);
    public static final SpectraDouble NEGATIVE_999 = new SpectraDouble(-999.0);
    
	protected double[] _values;

    /**
     * Allocate an array of SpectraDouble objects. 
     * 
     * @param length
     * @return
     */
    public static SpectraDouble[] allocateArray(int length)
    {
        SpectraDouble[] array = new SpectraDouble[length];
        
        for (int i=0; i<length; i++)
            array[i] = new SpectraDouble(0);
        
        return array;
    }
    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param d
     */
    public SpectraDouble(double d)
    {
        this(0.0, d, 1);
    }
    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param d
     */
    public SpectraDouble(double f, double d)
    {
    	this(f, d, 1);
    }
    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param d
     */
    public SpectraDouble(double f, double d, int N)
    {
    	super(f, N);
    	
    	_values = new double[N];
		Arrays.fill(_values, d);
    }
    
    /**
     * Create an empty spectra with the provided default value
     * 
     * @param d
     */
    public SpectraDouble(double d, int N)
    {
        this(0.0, d, N);
    }

    /**
     * Create an empty spectra with the provided values
     * 
     * @param d
     */
    public SpectraDouble(double[] f, double[] d)
    {
    	super(f);
    	_values = d;
    }
    
    /**
     * Construct a new spectra object with N frequencies
     * 
     * @param N
     */
    public SpectraDouble(int N)
    {
        this(0.0, 0.0, N);
    }
    
    
    /**
     * Construct a new spectra that is a copy of the provided spectra
     * 
     * @param spectra
     */
    public SpectraDouble(SpectraDouble spectra)
    {
    	this(spectra.getLength());
        set(spectra);
    }
    
    @Override
    public SpectraDouble add(double value)
    {
        if ( value == 0.0 )
            return this;
        
        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] += value;
        
        return this;
    }

    @Override
    public Spectra add(double value, PDF pdf)
    {
    	if ( pdf == null )
    		pdf = NormalPDF.ZERO;
    	
        int N = getLength();
        SpectraPDF newSpectra = new SpectraPDF(getFrequencies());
        
        for (int i=0; i<N; i++)
            newSpectra.setValue(i, getFrequency(i), pdf.add(_values[i] + value));
        
        return newSpectra;
    }

    @Override
    public Spectra add(PDF pdf)
    {
    	return add(0, pdf);
    }

    @Override
    public Spectra add(double value, PDF pdf, SpectraDouble spectra)
    {
    	if ( pdf == null )
    		pdf = NormalPDF.ZERO;
    	
        int N = getLength();
        SpectraPDF newSpectra = new SpectraPDF(getFrequencies());
        
        for (int i=0; i<N; i++)
            newSpectra.setValue(i, getFrequency(i), pdf.add(_values[i] + value + spectra.getFrequencyValue(_frequencies[i])));
        
        return newSpectra;
    }

    @Override
	public Spectra add(PDF pdf, SpectraPDF spectra)
    {
    	if ( pdf == null )
    		pdf = NormalPDF.ZERO;
    	
        int N = getLength();
        SpectraPDF newSpectra = new SpectraPDF(getFrequencies());
        
        for (int i=0; i<N; i++)
        {
            double f = getFrequency(i);
            
            newSpectra.setValue(i, f, pdf.add(getFrequencyValue(f), spectra.getFrequencyValue(f)));
        }
        
        return newSpectra;
    }

    @Override
    public SpectraDouble add(int index, double value)
    {
        _values[index] += value;
        
        return this;
    }

    @Override
    public Spectra add(Spectra spectra)
    {
        int N = getLength();
        
    	if ( spectra instanceof SpectraPDF )
    	{
            SpectraPDF sp = new SpectraPDF(getFrequencies());
            
    		for (int i=0; i<N; i++)
    		{
    			double f = getFrequency(i);
    			sp.setValue(i, f, ((SpectraPDF) spectra).getFrequencyValue(f));
    		}
    		
    		return sp;
    	}
    	else if ( spectra instanceof SpectraDouble )
    	{
    		for (int i=0; i<N; i++)
    		{
    			double f = getFrequency(i);
    			_values[i] += ((SpectraDouble) spectra).getFrequencyValue(f);
    		}
    	}
        
        return this;
    }

    @Override
    public boolean equals(Object o)
    {
    	if ( o == null )
    		return false;
    	
        if ( !(o instanceof SpectraDouble) )
            return false;
        
        SpectraDouble sd = (SpectraDouble) o;

        return NumericUtility.equals(_frequencies, sd._frequencies, 1e-4) &&
        		NumericUtility.equals(_values, sd._values, 1e-4);
    }
    
    @Override
    public int hashCode()
    {
    	return Arrays.hashCode(_frequencies);
    }
    
    /**
     * Version of getFrequencyValue that does not auto-box a primitive double
     * 
     * @param frequency
     * @return
     */
    public double getFrequencyValue(double frequency)
    {
        int N = getLength();
        if ( N == 0 )
            return 0.0;
        else if ( N == 1 )
            return _values[0];
        
        return Interpolation.interpolateQuadratic(_frequencies, _values, frequency);
    }
    
    @Override
    public double getMean()
    {
        int N = getLength();
        if ( N == 0 )
            return 0.0;
        else if ( N == 1 )
            return _values[0];
        
        //  Get the minimum frequency
        double sum = _values[0] * ((_frequencies[1] - _frequencies[0]) / 2.0);
        
        //  Get the middle frequencies
        for (int i=1; i<N-1; i++)
        {
            double df = (_frequencies[i+1] - _frequencies[i-1]) / 2.0;
            
            sum += _values[i] * df;
        }
        
        //  Get the maximum frequency
        sum += _values[N-1] * ((_frequencies[N-1] - _frequencies[N-2]) / 2.0);
        
        double mean = sum / (_frequencies[N-1] - _frequencies[0]);
        
        return mean;
    }
    
    @Override
    public double getMeanLog()
    {
        int N = getLength();
        if ( N == 0 )
            return 0.0;
        else if ( N == 1 )
            return _values[0];
        
        //  Get the minimum frequency
        double sum = Math.pow(10, _values[0]) * ((_frequencies[1] - _frequencies[0]) / 2.0);
        
        //  Get the middle frequencies
        for (int i=1; i<N-1; i++)
        {
            double df = (_frequencies[i+1] - _frequencies[i-1]) / 2.0;
            
            sum += Math.pow(10, _values[i]) * df;
        }
        
        //  Get the maximum frequency
        sum += Math.pow(10, _values[N-1]) * ((_frequencies[N-1] - _frequencies[N-2]) / 2.0);
        
        return Math.log10(sum / (_frequencies[N-1] - _frequencies[0]));
    }
    
    @Override
    public SpectraDouble log10()
    {
        int N = _values.length;
        
        for (int i=0; i<N; i++)
        {
            double val =  Math.log10(_values[i]);
            if ( Double.isInfinite(val) )
                val = 999;
            
            _values[i] = val;
        }
        
        return this;
    }

    @Override
    public SpectraDouble pow10()
    {
        int N = _values.length;

        for (int i = 0; i < N; i++)
            _values[i] = Math.pow(10, _values[i]);
        
        return this;
    }

    @Override
    public SpectraDouble scale(double value)
    {
        if ( value == 1 )
            return this;

        int N = _values.length;
        
        for (int i=0; i<N; i++)
            _values[i] *= value;
        
        return this;
    }
	
	@Override
    public Double getValue(int index)
    {
        return _values[index];
    }
	
    public void setValue(int index, double value)
    {
        _values[index] = value;
    }
	
	public void setValue(int index, double frequency, double value)
    {
        _frequencies[index] = frequency;
        _values[index] = value;
    }

	@Override
	public Double[] getValues()
	{
		return NumericUtility.toDoubleArray(_values);
	}

	@Override
	public Spectra addScaled(double scale, Spectra spectra)
	{
        int N = _values.length;
        
        if ( spectra instanceof SpectraDouble )
        {
        	SpectraDouble sd = (SpectraDouble) spectra;
        	
        	for (int i=0; i<N; i++)
        	{
        		double f = getFrequency(i);
        		_values[i] += scale * sd.getFrequencyValue(f);
        	}
        }
        else if ( spectra instanceof SpectraPDF )
        {
        	SpectraPDF newSpectra = new SpectraPDF(getFrequencies());
        	SpectraPDF sp = (SpectraPDF) spectra;
        	
        	for (int i=0; i<N; i++)
        	{
        		double f = getFrequency(i);
        		newSpectra.setValue(i, f, sp.getFrequencyValue(f).scale(scale * getValue(i)));
        	}
        	
        	return newSpectra;
        }
        
        return this;
	}

	@Override
	public double getMean(int i)
	{
		return _values[i];
	}

	@Override
	public PDF getMeanLogPDF()
	{
		return new NormalPDF(getMeanLog(), 0.0);
	}

	@Override
	public SpectraDouble getMeanSpectra()
	{
		return this;
	}

	@Override
	public double getStandardDeviation(int i)
	{
		return 0;
	}

	@Override
	public SpectraDouble getStandardDeviationSpectra()
	{
		return new SpectraDouble(0.0, getLength());
	}

	@Override
	public Spectra scale(double a, double b)
	{
        int N = _values.length;
        
        for (int i=0; i<N; i++)
        	_values[i] = a * _values[i] + b;
        
        return this;
	}

	@Override
	public Spectra scale(double value, Spectra... spectras)
	{
		int N = getLength();
		
		for (int i=0; i<N; i++)
		{
			double f = getFrequency(i);
			double x = value * getValue(i);
			
			for (Spectra s : spectras)
			{
				if ( s instanceof SpectraDouble )
					x *= ((SpectraDouble) s).getFrequencyValue(f);
				else if ( s instanceof SpectraPDF )
					x *= ((SpectraPDF) s).getFrequencyValue(f).getMean();	
			}
			
			setValue(i, x);
		}
		
		return this;
	}

	@Override
	public Spectra toMonteCarlo(PRNG prng, int n)
	{
		return this;
	}

	@Override
	public Spectra set(Spectra spectra)
	{
		if (spectra == this)
			return this;

		int N = spectra.getLength();
		_frequencies = Arrays.copyOf(spectra._frequencies, N);
		
		if ( spectra instanceof SpectraDouble )
			_values = Arrays.copyOf(((SpectraDouble) spectra)._values, N);
		else if ( spectra instanceof SpectraPDF )
		{
			_values = new double[N];
			for (int i=0; i<N; i++)
				_values[i] = ((SpectraPDF) spectra).getValue(i).getMean();
		}

		return this;
	}
}
