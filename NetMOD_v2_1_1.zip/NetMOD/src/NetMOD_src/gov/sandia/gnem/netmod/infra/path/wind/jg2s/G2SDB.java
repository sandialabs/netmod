package gov.sandia.gnem.netmod.infra.path.wind.jg2s;

import gov.sandia.gnem.netmod.infra.path.wind.jhwm08.HWM08;

/**
 * Container class for holding the G2S DB information
 *
 * @author bjmerch & jbobeck
 */
public class G2SDB {

  //
  //  (Vector) Spherical Harmonics and workspace pointer
  double[][][] zag, zbg;
  double[][][] zas, zbs;
  double[][][] pas, pbs;
  double[][][] brs, bis;
  double[][][] crs, cis;
  double[][][] tas, tbs;
  double[][][] das, dbs;
  //public double[][][] was, wbs;  This pointers are unused in the Java implementation

  //  Internal flags
  boolean DENSITY = false;
  boolean SIGMA = false;
  boolean SWAP = false;
  boolean V4 = false;

  //  Basis functions
  double[][] pbar;
  double[][] vbar, wbar;
  double[] cosl, sinl;

  //  Spectral truncation parameters
  int[] trunc;
  int ntrunc;
  int utrunc;
  int nzs;
  int nzsp;

  //  Vertical model grids
  float[] zs;
  float[] zgrid;

  //  Surace elevation data
  double zg;

  //  Altitude profile information
  public double glat;
  public double glon;
  double dz = 0.5;

  int nalts = 4001;
  int maxalt = 2001;

  public float[] alt = new float[maxalt];
  public float[] tmp = new float[maxalt];
  public float[] rho = new float[maxalt];
  float[] zon = new float[maxalt];
  float[] mer = new float[maxalt];
  float[] prs = new float[maxalt];
  public float zmax;
  int kmax;

  //  For time savings
  public boolean memalloc = false;
  int lastnalt = 1001;
  double lastlat = -999.0;
  double lastlon = -999.0;

  //  Geoindex functionality
  public String datapath = "";
  String g2sfile;
  public boolean override = false;


  //  Coefficient set file/generation/header information
  public static class GSINFO {

    public String version = "Default";
    public int year = 2000;
    int month = 01;
    public int day = 01;
    int daynumber = 0;
    float utc = 0.0f;
    public String desc = "blank header record";
    public float f107a = 150.0f;
    public float f107 = 150.0f;
    int apd = 4;
    int nlevels = 70;
    int maxtrunc = 73;
  }

  GSINFO info = new GSINFO();

  //  Physical, mathematical, and reference constants
  float Rd = 287.0f;  //  gas constant / dry air
  float pref = 1000.0f; //  reference pressure hPa
  float dref = 1.225e-3f;  //  reference density g/cm3
  public float pi = 3.141592653589793f;
  public float deg2rad = 3.141592653589793f / 180.0f;

  //  Alternate profile data fusion system parameters
  float alpha = 0.5f;  //  moderately rapid transition
  float beta = 85.0f;  //  75 km is transition point

  public HWM08 hwm08 = null;
}
